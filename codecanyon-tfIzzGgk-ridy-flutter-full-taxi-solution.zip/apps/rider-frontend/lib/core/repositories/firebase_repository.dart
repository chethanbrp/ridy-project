abstract class FirebaseRepository {
  Future<void> retrieveAndUpdateFcmToken();
}
