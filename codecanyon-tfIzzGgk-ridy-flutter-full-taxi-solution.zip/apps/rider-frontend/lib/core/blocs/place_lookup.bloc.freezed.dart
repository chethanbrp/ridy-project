// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'place_lookup.bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$PlaceLookupEvent {





@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is PlaceLookupEvent);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'PlaceLookupEvent()';
}


}

/// @nodoc
class $PlaceLookupEventCopyWith<$Res>  {
$PlaceLookupEventCopyWith(PlaceLookupEvent _, $Res Function(PlaceLookupEvent) __);
}


/// Adds pattern-matching-related methods to [PlaceLookupEvent].
extension PlaceLookupEventPatterns on PlaceLookupEvent {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>({TResult Function( PlaceLookupEvent$OnStarted value)?  onStarted,TResult Function( PlaceLookupEvent$OnQueryChanged value)?  onQueryChanged,required TResult orElse(),}){
final _that = this;
switch (_that) {
case PlaceLookupEvent$OnStarted() when onStarted != null:
return onStarted(_that);case PlaceLookupEvent$OnQueryChanged() when onQueryChanged != null:
return onQueryChanged(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>({required TResult Function( PlaceLookupEvent$OnStarted value)  onStarted,required TResult Function( PlaceLookupEvent$OnQueryChanged value)  onQueryChanged,}){
final _that = this;
switch (_that) {
case PlaceLookupEvent$OnStarted():
return onStarted(_that);case PlaceLookupEvent$OnQueryChanged():
return onQueryChanged(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>({TResult? Function( PlaceLookupEvent$OnStarted value)?  onStarted,TResult? Function( PlaceLookupEvent$OnQueryChanged value)?  onQueryChanged,}){
final _that = this;
switch (_that) {
case PlaceLookupEvent$OnStarted() when onStarted != null:
return onStarted(_that);case PlaceLookupEvent$OnQueryChanged() when onQueryChanged != null:
return onQueryChanged(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>({TResult Function()?  onStarted,TResult Function( String? query,  LatLng? latLng,  int radius,  String language,  MapProviderEnum mapProvider)?  onQueryChanged,required TResult orElse(),}) {final _that = this;
switch (_that) {
case PlaceLookupEvent$OnStarted() when onStarted != null:
return onStarted();case PlaceLookupEvent$OnQueryChanged() when onQueryChanged != null:
return onQueryChanged(_that.query,_that.latLng,_that.radius,_that.language,_that.mapProvider);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>({required TResult Function()  onStarted,required TResult Function( String? query,  LatLng? latLng,  int radius,  String language,  MapProviderEnum mapProvider)  onQueryChanged,}) {final _that = this;
switch (_that) {
case PlaceLookupEvent$OnStarted():
return onStarted();case PlaceLookupEvent$OnQueryChanged():
return onQueryChanged(_that.query,_that.latLng,_that.radius,_that.language,_that.mapProvider);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>({TResult? Function()?  onStarted,TResult? Function( String? query,  LatLng? latLng,  int radius,  String language,  MapProviderEnum mapProvider)?  onQueryChanged,}) {final _that = this;
switch (_that) {
case PlaceLookupEvent$OnStarted() when onStarted != null:
return onStarted();case PlaceLookupEvent$OnQueryChanged() when onQueryChanged != null:
return onQueryChanged(_that.query,_that.latLng,_that.radius,_that.language,_that.mapProvider);case _:
  return null;

}
}

}

/// @nodoc


class PlaceLookupEvent$OnStarted implements PlaceLookupEvent {
  const PlaceLookupEvent$OnStarted();
  






@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is PlaceLookupEvent$OnStarted);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'PlaceLookupEvent.onStarted()';
}


}




/// @nodoc


class PlaceLookupEvent$OnQueryChanged implements PlaceLookupEvent {
  const PlaceLookupEvent$OnQueryChanged({required this.query, required this.latLng, required this.radius, required this.language, required this.mapProvider});
  

 final  String? query;
 final  LatLng? latLng;
 final  int radius;
 final  String language;
 final  MapProviderEnum mapProvider;

/// Create a copy of PlaceLookupEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$PlaceLookupEvent$OnQueryChangedCopyWith<PlaceLookupEvent$OnQueryChanged> get copyWith => _$PlaceLookupEvent$OnQueryChangedCopyWithImpl<PlaceLookupEvent$OnQueryChanged>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is PlaceLookupEvent$OnQueryChanged&&(identical(other.query, query) || other.query == query)&&(identical(other.latLng, latLng) || other.latLng == latLng)&&(identical(other.radius, radius) || other.radius == radius)&&(identical(other.language, language) || other.language == language)&&(identical(other.mapProvider, mapProvider) || other.mapProvider == mapProvider));
}


@override
int get hashCode => Object.hash(runtimeType,query,latLng,radius,language,mapProvider);

@override
String toString() {
  return 'PlaceLookupEvent.onQueryChanged(query: $query, latLng: $latLng, radius: $radius, language: $language, mapProvider: $mapProvider)';
}


}

/// @nodoc
abstract mixin class $PlaceLookupEvent$OnQueryChangedCopyWith<$Res> implements $PlaceLookupEventCopyWith<$Res> {
  factory $PlaceLookupEvent$OnQueryChangedCopyWith(PlaceLookupEvent$OnQueryChanged value, $Res Function(PlaceLookupEvent$OnQueryChanged) _then) = _$PlaceLookupEvent$OnQueryChangedCopyWithImpl;
@useResult
$Res call({
 String? query, LatLng? latLng, int radius, String language, MapProviderEnum mapProvider
});




}
/// @nodoc
class _$PlaceLookupEvent$OnQueryChangedCopyWithImpl<$Res>
    implements $PlaceLookupEvent$OnQueryChangedCopyWith<$Res> {
  _$PlaceLookupEvent$OnQueryChangedCopyWithImpl(this._self, this._then);

  final PlaceLookupEvent$OnQueryChanged _self;
  final $Res Function(PlaceLookupEvent$OnQueryChanged) _then;

/// Create a copy of PlaceLookupEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? query = freezed,Object? latLng = freezed,Object? radius = null,Object? language = null,Object? mapProvider = null,}) {
  return _then(PlaceLookupEvent$OnQueryChanged(
query: freezed == query ? _self.query : query // ignore: cast_nullable_to_non_nullable
as String?,latLng: freezed == latLng ? _self.latLng : latLng // ignore: cast_nullable_to_non_nullable
as LatLng?,radius: null == radius ? _self.radius : radius // ignore: cast_nullable_to_non_nullable
as int,language: null == language ? _self.language : language // ignore: cast_nullable_to_non_nullable
as String,mapProvider: null == mapProvider ? _self.mapProvider : mapProvider // ignore: cast_nullable_to_non_nullable
as MapProviderEnum,
  ));
}


}

/// @nodoc
mixin _$PlaceLookupState {





@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is PlaceLookupState);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'PlaceLookupState()';
}


}

/// @nodoc
class $PlaceLookupStateCopyWith<$Res>  {
$PlaceLookupStateCopyWith(PlaceLookupState _, $Res Function(PlaceLookupState) __);
}


/// Adds pattern-matching-related methods to [PlaceLookupState].
extension PlaceLookupStatePatterns on PlaceLookupState {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>({TResult Function( PlaceLookupState$Initial value)?  initial,TResult Function( PlaceLookupState$Loading value)?  loading,TResult Function( PlaceLookupState$NoResults value)?  noResults,TResult Function( PlaceLookupState$MoreCharacters value)?  moreCharacters,TResult Function( PlaceLookupState$Loaded value)?  loaded,TResult Function( PlaceLookupState$Error value)?  error,required TResult orElse(),}){
final _that = this;
switch (_that) {
case PlaceLookupState$Initial() when initial != null:
return initial(_that);case PlaceLookupState$Loading() when loading != null:
return loading(_that);case PlaceLookupState$NoResults() when noResults != null:
return noResults(_that);case PlaceLookupState$MoreCharacters() when moreCharacters != null:
return moreCharacters(_that);case PlaceLookupState$Loaded() when loaded != null:
return loaded(_that);case PlaceLookupState$Error() when error != null:
return error(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>({required TResult Function( PlaceLookupState$Initial value)  initial,required TResult Function( PlaceLookupState$Loading value)  loading,required TResult Function( PlaceLookupState$NoResults value)  noResults,required TResult Function( PlaceLookupState$MoreCharacters value)  moreCharacters,required TResult Function( PlaceLookupState$Loaded value)  loaded,required TResult Function( PlaceLookupState$Error value)  error,}){
final _that = this;
switch (_that) {
case PlaceLookupState$Initial():
return initial(_that);case PlaceLookupState$Loading():
return loading(_that);case PlaceLookupState$NoResults():
return noResults(_that);case PlaceLookupState$MoreCharacters():
return moreCharacters(_that);case PlaceLookupState$Loaded():
return loaded(_that);case PlaceLookupState$Error():
return error(_that);}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>({TResult? Function( PlaceLookupState$Initial value)?  initial,TResult? Function( PlaceLookupState$Loading value)?  loading,TResult? Function( PlaceLookupState$NoResults value)?  noResults,TResult? Function( PlaceLookupState$MoreCharacters value)?  moreCharacters,TResult? Function( PlaceLookupState$Loaded value)?  loaded,TResult? Function( PlaceLookupState$Error value)?  error,}){
final _that = this;
switch (_that) {
case PlaceLookupState$Initial() when initial != null:
return initial(_that);case PlaceLookupState$Loading() when loading != null:
return loading(_that);case PlaceLookupState$NoResults() when noResults != null:
return noResults(_that);case PlaceLookupState$MoreCharacters() when moreCharacters != null:
return moreCharacters(_that);case PlaceLookupState$Loaded() when loaded != null:
return loaded(_that);case PlaceLookupState$Error() when error != null:
return error(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>({TResult Function()?  initial,TResult Function()?  loading,TResult Function()?  noResults,TResult Function()?  moreCharacters,TResult Function( List<Place> places)?  loaded,TResult Function( String message)?  error,required TResult orElse(),}) {final _that = this;
switch (_that) {
case PlaceLookupState$Initial() when initial != null:
return initial();case PlaceLookupState$Loading() when loading != null:
return loading();case PlaceLookupState$NoResults() when noResults != null:
return noResults();case PlaceLookupState$MoreCharacters() when moreCharacters != null:
return moreCharacters();case PlaceLookupState$Loaded() when loaded != null:
return loaded(_that.places);case PlaceLookupState$Error() when error != null:
return error(_that.message);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>({required TResult Function()  initial,required TResult Function()  loading,required TResult Function()  noResults,required TResult Function()  moreCharacters,required TResult Function( List<Place> places)  loaded,required TResult Function( String message)  error,}) {final _that = this;
switch (_that) {
case PlaceLookupState$Initial():
return initial();case PlaceLookupState$Loading():
return loading();case PlaceLookupState$NoResults():
return noResults();case PlaceLookupState$MoreCharacters():
return moreCharacters();case PlaceLookupState$Loaded():
return loaded(_that.places);case PlaceLookupState$Error():
return error(_that.message);}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>({TResult? Function()?  initial,TResult? Function()?  loading,TResult? Function()?  noResults,TResult? Function()?  moreCharacters,TResult? Function( List<Place> places)?  loaded,TResult? Function( String message)?  error,}) {final _that = this;
switch (_that) {
case PlaceLookupState$Initial() when initial != null:
return initial();case PlaceLookupState$Loading() when loading != null:
return loading();case PlaceLookupState$NoResults() when noResults != null:
return noResults();case PlaceLookupState$MoreCharacters() when moreCharacters != null:
return moreCharacters();case PlaceLookupState$Loaded() when loaded != null:
return loaded(_that.places);case PlaceLookupState$Error() when error != null:
return error(_that.message);case _:
  return null;

}
}

}

/// @nodoc


class PlaceLookupState$Initial implements PlaceLookupState {
  const PlaceLookupState$Initial();
  






@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is PlaceLookupState$Initial);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'PlaceLookupState.initial()';
}


}




/// @nodoc


class PlaceLookupState$Loading implements PlaceLookupState {
  const PlaceLookupState$Loading();
  






@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is PlaceLookupState$Loading);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'PlaceLookupState.loading()';
}


}




/// @nodoc


class PlaceLookupState$NoResults implements PlaceLookupState {
  const PlaceLookupState$NoResults();
  






@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is PlaceLookupState$NoResults);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'PlaceLookupState.noResults()';
}


}




/// @nodoc


class PlaceLookupState$MoreCharacters implements PlaceLookupState {
  const PlaceLookupState$MoreCharacters();
  






@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is PlaceLookupState$MoreCharacters);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'PlaceLookupState.moreCharacters()';
}


}




/// @nodoc


class PlaceLookupState$Loaded implements PlaceLookupState {
  const PlaceLookupState$Loaded({required final  List<Place> places}): _places = places;
  

 final  List<Place> _places;
 List<Place> get places {
  if (_places is EqualUnmodifiableListView) return _places;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_places);
}


/// Create a copy of PlaceLookupState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$PlaceLookupState$LoadedCopyWith<PlaceLookupState$Loaded> get copyWith => _$PlaceLookupState$LoadedCopyWithImpl<PlaceLookupState$Loaded>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is PlaceLookupState$Loaded&&const DeepCollectionEquality().equals(other._places, _places));
}


@override
int get hashCode => Object.hash(runtimeType,const DeepCollectionEquality().hash(_places));

@override
String toString() {
  return 'PlaceLookupState.loaded(places: $places)';
}


}

/// @nodoc
abstract mixin class $PlaceLookupState$LoadedCopyWith<$Res> implements $PlaceLookupStateCopyWith<$Res> {
  factory $PlaceLookupState$LoadedCopyWith(PlaceLookupState$Loaded value, $Res Function(PlaceLookupState$Loaded) _then) = _$PlaceLookupState$LoadedCopyWithImpl;
@useResult
$Res call({
 List<Place> places
});




}
/// @nodoc
class _$PlaceLookupState$LoadedCopyWithImpl<$Res>
    implements $PlaceLookupState$LoadedCopyWith<$Res> {
  _$PlaceLookupState$LoadedCopyWithImpl(this._self, this._then);

  final PlaceLookupState$Loaded _self;
  final $Res Function(PlaceLookupState$Loaded) _then;

/// Create a copy of PlaceLookupState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? places = null,}) {
  return _then(PlaceLookupState$Loaded(
places: null == places ? _self._places : places // ignore: cast_nullable_to_non_nullable
as List<Place>,
  ));
}


}

/// @nodoc


class PlaceLookupState$Error implements PlaceLookupState {
  const PlaceLookupState$Error(this.message);
  

 final  String message;

/// Create a copy of PlaceLookupState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$PlaceLookupState$ErrorCopyWith<PlaceLookupState$Error> get copyWith => _$PlaceLookupState$ErrorCopyWithImpl<PlaceLookupState$Error>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is PlaceLookupState$Error&&(identical(other.message, message) || other.message == message));
}


@override
int get hashCode => Object.hash(runtimeType,message);

@override
String toString() {
  return 'PlaceLookupState.error(message: $message)';
}


}

/// @nodoc
abstract mixin class $PlaceLookupState$ErrorCopyWith<$Res> implements $PlaceLookupStateCopyWith<$Res> {
  factory $PlaceLookupState$ErrorCopyWith(PlaceLookupState$Error value, $Res Function(PlaceLookupState$Error) _then) = _$PlaceLookupState$ErrorCopyWithImpl;
@useResult
$Res call({
 String message
});




}
/// @nodoc
class _$PlaceLookupState$ErrorCopyWithImpl<$Res>
    implements $PlaceLookupState$ErrorCopyWith<$Res> {
  _$PlaceLookupState$ErrorCopyWithImpl(this._self, this._then);

  final PlaceLookupState$Error _self;
  final $Res Function(PlaceLookupState$Error) _then;

/// Create a copy of PlaceLookupState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? message = null,}) {
  return _then(PlaceLookupState$Error(
null == message ? _self.message : message // ignore: cast_nullable_to_non_nullable
as String,
  ));
}


}

// dart format on
