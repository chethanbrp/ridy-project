// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'payment_methods.bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$PaymentMethodsState {

 ApiResponse<List<Fragment$PaymentMethod>> get paymentMethods; Fragment$PaymentMethod? get selectedSavedPaymentMethod;
/// Create a copy of PaymentMethodsState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$PaymentMethodsStateCopyWith<PaymentMethodsState> get copyWith => _$PaymentMethodsStateCopyWithImpl<PaymentMethodsState>(this as PaymentMethodsState, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is PaymentMethodsState&&(identical(other.paymentMethods, paymentMethods) || other.paymentMethods == paymentMethods)&&(identical(other.selectedSavedPaymentMethod, selectedSavedPaymentMethod) || other.selectedSavedPaymentMethod == selectedSavedPaymentMethod));
}


@override
int get hashCode => Object.hash(runtimeType,paymentMethods,selectedSavedPaymentMethod);

@override
String toString() {
  return 'PaymentMethodsState(paymentMethods: $paymentMethods, selectedSavedPaymentMethod: $selectedSavedPaymentMethod)';
}


}

/// @nodoc
abstract mixin class $PaymentMethodsStateCopyWith<$Res>  {
  factory $PaymentMethodsStateCopyWith(PaymentMethodsState value, $Res Function(PaymentMethodsState) _then) = _$PaymentMethodsStateCopyWithImpl;
@useResult
$Res call({
 ApiResponse<List<Fragment$PaymentMethod>> paymentMethods, Fragment$PaymentMethod? selectedSavedPaymentMethod
});


$ApiResponseCopyWith<List<Fragment$PaymentMethod>, $Res> get paymentMethods;

}
/// @nodoc
class _$PaymentMethodsStateCopyWithImpl<$Res>
    implements $PaymentMethodsStateCopyWith<$Res> {
  _$PaymentMethodsStateCopyWithImpl(this._self, this._then);

  final PaymentMethodsState _self;
  final $Res Function(PaymentMethodsState) _then;

/// Create a copy of PaymentMethodsState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? paymentMethods = null,Object? selectedSavedPaymentMethod = freezed,}) {
  return _then(_self.copyWith(
paymentMethods: null == paymentMethods ? _self.paymentMethods : paymentMethods // ignore: cast_nullable_to_non_nullable
as ApiResponse<List<Fragment$PaymentMethod>>,selectedSavedPaymentMethod: freezed == selectedSavedPaymentMethod ? _self.selectedSavedPaymentMethod : selectedSavedPaymentMethod // ignore: cast_nullable_to_non_nullable
as Fragment$PaymentMethod?,
  ));
}
/// Create a copy of PaymentMethodsState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<List<Fragment$PaymentMethod>, $Res> get paymentMethods {
  
  return $ApiResponseCopyWith<List<Fragment$PaymentMethod>, $Res>(_self.paymentMethods, (value) {
    return _then(_self.copyWith(paymentMethods: value));
  });
}
}


/// Adds pattern-matching-related methods to [PaymentMethodsState].
extension PaymentMethodsStatePatterns on PaymentMethodsState {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _PaymentMethodsState value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _PaymentMethodsState() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _PaymentMethodsState value)  $default,){
final _that = this;
switch (_that) {
case _PaymentMethodsState():
return $default(_that);}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _PaymentMethodsState value)?  $default,){
final _that = this;
switch (_that) {
case _PaymentMethodsState() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( ApiResponse<List<Fragment$PaymentMethod>> paymentMethods,  Fragment$PaymentMethod? selectedSavedPaymentMethod)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _PaymentMethodsState() when $default != null:
return $default(_that.paymentMethods,_that.selectedSavedPaymentMethod);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( ApiResponse<List<Fragment$PaymentMethod>> paymentMethods,  Fragment$PaymentMethod? selectedSavedPaymentMethod)  $default,) {final _that = this;
switch (_that) {
case _PaymentMethodsState():
return $default(_that.paymentMethods,_that.selectedSavedPaymentMethod);}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( ApiResponse<List<Fragment$PaymentMethod>> paymentMethods,  Fragment$PaymentMethod? selectedSavedPaymentMethod)?  $default,) {final _that = this;
switch (_that) {
case _PaymentMethodsState() when $default != null:
return $default(_that.paymentMethods,_that.selectedSavedPaymentMethod);case _:
  return null;

}
}

}

/// @nodoc


class _PaymentMethodsState extends PaymentMethodsState {
  const _PaymentMethodsState({this.paymentMethods = const ApiResponseInitial(), this.selectedSavedPaymentMethod}): super._();
  

@override@JsonKey() final  ApiResponse<List<Fragment$PaymentMethod>> paymentMethods;
@override final  Fragment$PaymentMethod? selectedSavedPaymentMethod;

/// Create a copy of PaymentMethodsState
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$PaymentMethodsStateCopyWith<_PaymentMethodsState> get copyWith => __$PaymentMethodsStateCopyWithImpl<_PaymentMethodsState>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _PaymentMethodsState&&(identical(other.paymentMethods, paymentMethods) || other.paymentMethods == paymentMethods)&&(identical(other.selectedSavedPaymentMethod, selectedSavedPaymentMethod) || other.selectedSavedPaymentMethod == selectedSavedPaymentMethod));
}


@override
int get hashCode => Object.hash(runtimeType,paymentMethods,selectedSavedPaymentMethod);

@override
String toString() {
  return 'PaymentMethodsState(paymentMethods: $paymentMethods, selectedSavedPaymentMethod: $selectedSavedPaymentMethod)';
}


}

/// @nodoc
abstract mixin class _$PaymentMethodsStateCopyWith<$Res> implements $PaymentMethodsStateCopyWith<$Res> {
  factory _$PaymentMethodsStateCopyWith(_PaymentMethodsState value, $Res Function(_PaymentMethodsState) _then) = __$PaymentMethodsStateCopyWithImpl;
@override @useResult
$Res call({
 ApiResponse<List<Fragment$PaymentMethod>> paymentMethods, Fragment$PaymentMethod? selectedSavedPaymentMethod
});


@override $ApiResponseCopyWith<List<Fragment$PaymentMethod>, $Res> get paymentMethods;

}
/// @nodoc
class __$PaymentMethodsStateCopyWithImpl<$Res>
    implements _$PaymentMethodsStateCopyWith<$Res> {
  __$PaymentMethodsStateCopyWithImpl(this._self, this._then);

  final _PaymentMethodsState _self;
  final $Res Function(_PaymentMethodsState) _then;

/// Create a copy of PaymentMethodsState
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? paymentMethods = null,Object? selectedSavedPaymentMethod = freezed,}) {
  return _then(_PaymentMethodsState(
paymentMethods: null == paymentMethods ? _self.paymentMethods : paymentMethods // ignore: cast_nullable_to_non_nullable
as ApiResponse<List<Fragment$PaymentMethod>>,selectedSavedPaymentMethod: freezed == selectedSavedPaymentMethod ? _self.selectedSavedPaymentMethod : selectedSavedPaymentMethod // ignore: cast_nullable_to_non_nullable
as Fragment$PaymentMethod?,
  ));
}

/// Create a copy of PaymentMethodsState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<List<Fragment$PaymentMethod>, $Res> get paymentMethods {
  
  return $ApiResponseCopyWith<List<Fragment$PaymentMethod>, $Res>(_self.paymentMethods, (value) {
    return _then(_self.copyWith(paymentMethods: value));
  });
}
}

/// @nodoc
mixin _$PaymentMethodsEvent {





@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is PaymentMethodsEvent);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'PaymentMethodsEvent()';
}


}

/// @nodoc
class $PaymentMethodsEventCopyWith<$Res>  {
$PaymentMethodsEventCopyWith(PaymentMethodsEvent _, $Res Function(PaymentMethodsEvent) __);
}


/// Adds pattern-matching-related methods to [PaymentMethodsEvent].
extension PaymentMethodsEventPatterns on PaymentMethodsEvent {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>({TResult Function( PaymentMethodsEvent$Load value)?  load,TResult Function( PaymentMethodsEvent$MarkAsDefault value)?  markAsDefault,TResult Function( PaymentMethodsEvent$DeletePaymentMethod value)?  deletePaymentMethod,required TResult orElse(),}){
final _that = this;
switch (_that) {
case PaymentMethodsEvent$Load() when load != null:
return load(_that);case PaymentMethodsEvent$MarkAsDefault() when markAsDefault != null:
return markAsDefault(_that);case PaymentMethodsEvent$DeletePaymentMethod() when deletePaymentMethod != null:
return deletePaymentMethod(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>({required TResult Function( PaymentMethodsEvent$Load value)  load,required TResult Function( PaymentMethodsEvent$MarkAsDefault value)  markAsDefault,required TResult Function( PaymentMethodsEvent$DeletePaymentMethod value)  deletePaymentMethod,}){
final _that = this;
switch (_that) {
case PaymentMethodsEvent$Load():
return load(_that);case PaymentMethodsEvent$MarkAsDefault():
return markAsDefault(_that);case PaymentMethodsEvent$DeletePaymentMethod():
return deletePaymentMethod(_that);}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>({TResult? Function( PaymentMethodsEvent$Load value)?  load,TResult? Function( PaymentMethodsEvent$MarkAsDefault value)?  markAsDefault,TResult? Function( PaymentMethodsEvent$DeletePaymentMethod value)?  deletePaymentMethod,}){
final _that = this;
switch (_that) {
case PaymentMethodsEvent$Load() when load != null:
return load(_that);case PaymentMethodsEvent$MarkAsDefault() when markAsDefault != null:
return markAsDefault(_that);case PaymentMethodsEvent$DeletePaymentMethod() when deletePaymentMethod != null:
return deletePaymentMethod(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>({TResult Function()?  load,TResult Function( String paymentMethodId)?  markAsDefault,TResult Function( String paymentMethodId)?  deletePaymentMethod,required TResult orElse(),}) {final _that = this;
switch (_that) {
case PaymentMethodsEvent$Load() when load != null:
return load();case PaymentMethodsEvent$MarkAsDefault() when markAsDefault != null:
return markAsDefault(_that.paymentMethodId);case PaymentMethodsEvent$DeletePaymentMethod() when deletePaymentMethod != null:
return deletePaymentMethod(_that.paymentMethodId);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>({required TResult Function()  load,required TResult Function( String paymentMethodId)  markAsDefault,required TResult Function( String paymentMethodId)  deletePaymentMethod,}) {final _that = this;
switch (_that) {
case PaymentMethodsEvent$Load():
return load();case PaymentMethodsEvent$MarkAsDefault():
return markAsDefault(_that.paymentMethodId);case PaymentMethodsEvent$DeletePaymentMethod():
return deletePaymentMethod(_that.paymentMethodId);}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>({TResult? Function()?  load,TResult? Function( String paymentMethodId)?  markAsDefault,TResult? Function( String paymentMethodId)?  deletePaymentMethod,}) {final _that = this;
switch (_that) {
case PaymentMethodsEvent$Load() when load != null:
return load();case PaymentMethodsEvent$MarkAsDefault() when markAsDefault != null:
return markAsDefault(_that.paymentMethodId);case PaymentMethodsEvent$DeletePaymentMethod() when deletePaymentMethod != null:
return deletePaymentMethod(_that.paymentMethodId);case _:
  return null;

}
}

}

/// @nodoc


class PaymentMethodsEvent$Load implements PaymentMethodsEvent {
  const PaymentMethodsEvent$Load();
  






@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is PaymentMethodsEvent$Load);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'PaymentMethodsEvent.load()';
}


}




/// @nodoc


class PaymentMethodsEvent$MarkAsDefault implements PaymentMethodsEvent {
  const PaymentMethodsEvent$MarkAsDefault({required this.paymentMethodId});
  

 final  String paymentMethodId;

/// Create a copy of PaymentMethodsEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$PaymentMethodsEvent$MarkAsDefaultCopyWith<PaymentMethodsEvent$MarkAsDefault> get copyWith => _$PaymentMethodsEvent$MarkAsDefaultCopyWithImpl<PaymentMethodsEvent$MarkAsDefault>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is PaymentMethodsEvent$MarkAsDefault&&(identical(other.paymentMethodId, paymentMethodId) || other.paymentMethodId == paymentMethodId));
}


@override
int get hashCode => Object.hash(runtimeType,paymentMethodId);

@override
String toString() {
  return 'PaymentMethodsEvent.markAsDefault(paymentMethodId: $paymentMethodId)';
}


}

/// @nodoc
abstract mixin class $PaymentMethodsEvent$MarkAsDefaultCopyWith<$Res> implements $PaymentMethodsEventCopyWith<$Res> {
  factory $PaymentMethodsEvent$MarkAsDefaultCopyWith(PaymentMethodsEvent$MarkAsDefault value, $Res Function(PaymentMethodsEvent$MarkAsDefault) _then) = _$PaymentMethodsEvent$MarkAsDefaultCopyWithImpl;
@useResult
$Res call({
 String paymentMethodId
});




}
/// @nodoc
class _$PaymentMethodsEvent$MarkAsDefaultCopyWithImpl<$Res>
    implements $PaymentMethodsEvent$MarkAsDefaultCopyWith<$Res> {
  _$PaymentMethodsEvent$MarkAsDefaultCopyWithImpl(this._self, this._then);

  final PaymentMethodsEvent$MarkAsDefault _self;
  final $Res Function(PaymentMethodsEvent$MarkAsDefault) _then;

/// Create a copy of PaymentMethodsEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? paymentMethodId = null,}) {
  return _then(PaymentMethodsEvent$MarkAsDefault(
paymentMethodId: null == paymentMethodId ? _self.paymentMethodId : paymentMethodId // ignore: cast_nullable_to_non_nullable
as String,
  ));
}


}

/// @nodoc


class PaymentMethodsEvent$DeletePaymentMethod implements PaymentMethodsEvent {
  const PaymentMethodsEvent$DeletePaymentMethod({required this.paymentMethodId});
  

 final  String paymentMethodId;

/// Create a copy of PaymentMethodsEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$PaymentMethodsEvent$DeletePaymentMethodCopyWith<PaymentMethodsEvent$DeletePaymentMethod> get copyWith => _$PaymentMethodsEvent$DeletePaymentMethodCopyWithImpl<PaymentMethodsEvent$DeletePaymentMethod>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is PaymentMethodsEvent$DeletePaymentMethod&&(identical(other.paymentMethodId, paymentMethodId) || other.paymentMethodId == paymentMethodId));
}


@override
int get hashCode => Object.hash(runtimeType,paymentMethodId);

@override
String toString() {
  return 'PaymentMethodsEvent.deletePaymentMethod(paymentMethodId: $paymentMethodId)';
}


}

/// @nodoc
abstract mixin class $PaymentMethodsEvent$DeletePaymentMethodCopyWith<$Res> implements $PaymentMethodsEventCopyWith<$Res> {
  factory $PaymentMethodsEvent$DeletePaymentMethodCopyWith(PaymentMethodsEvent$DeletePaymentMethod value, $Res Function(PaymentMethodsEvent$DeletePaymentMethod) _then) = _$PaymentMethodsEvent$DeletePaymentMethodCopyWithImpl;
@useResult
$Res call({
 String paymentMethodId
});




}
/// @nodoc
class _$PaymentMethodsEvent$DeletePaymentMethodCopyWithImpl<$Res>
    implements $PaymentMethodsEvent$DeletePaymentMethodCopyWith<$Res> {
  _$PaymentMethodsEvent$DeletePaymentMethodCopyWithImpl(this._self, this._then);

  final PaymentMethodsEvent$DeletePaymentMethod _self;
  final $Res Function(PaymentMethodsEvent$DeletePaymentMethod) _then;

/// Create a copy of PaymentMethodsEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? paymentMethodId = null,}) {
  return _then(PaymentMethodsEvent$DeletePaymentMethod(
paymentMethodId: null == paymentMethodId ? _self.paymentMethodId : paymentMethodId // ignore: cast_nullable_to_non_nullable
as String,
  ));
}


}

// dart format on
