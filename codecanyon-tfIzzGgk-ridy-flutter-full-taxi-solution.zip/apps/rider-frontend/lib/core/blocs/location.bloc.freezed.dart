// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'location.bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;
LocationState _$LocationStateFromJson(
  Map<String, dynamic> json
) {
        switch (json['runtimeType']) {
                  case 'loading':
          return LocationState$Loading.fromJson(
            json
          );
                case 'error':
          return LocationState$Error.fromJson(
            json
          );
                case 'determined':
          return LocationState$Determined.fromJson(
            json
          );
        
          default:
            throw CheckedFromJsonException(
  json,
  'runtimeType',
  'LocationState',
  'Invalid union type "${json['runtimeType']}"!'
);
        }
      
}

/// @nodoc
mixin _$LocationState {



  /// Serializes this LocationState to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is LocationState);
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'LocationState()';
}


}

/// @nodoc
class $LocationStateCopyWith<$Res>  {
$LocationStateCopyWith(LocationState _, $Res Function(LocationState) __);
}


/// Adds pattern-matching-related methods to [LocationState].
extension LocationStatePatterns on LocationState {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>({TResult Function( LocationState$Loading value)?  loading,TResult Function( LocationState$Error value)?  error,TResult Function( LocationState$Determined value)?  determined,required TResult orElse(),}){
final _that = this;
switch (_that) {
case LocationState$Loading() when loading != null:
return loading(_that);case LocationState$Error() when error != null:
return error(_that);case LocationState$Determined() when determined != null:
return determined(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>({required TResult Function( LocationState$Loading value)  loading,required TResult Function( LocationState$Error value)  error,required TResult Function( LocationState$Determined value)  determined,}){
final _that = this;
switch (_that) {
case LocationState$Loading():
return loading(_that);case LocationState$Error():
return error(_that);case LocationState$Determined():
return determined(_that);}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>({TResult? Function( LocationState$Loading value)?  loading,TResult? Function( LocationState$Error value)?  error,TResult? Function( LocationState$Determined value)?  determined,}){
final _that = this;
switch (_that) {
case LocationState$Loading() when loading != null:
return loading(_that);case LocationState$Error() when error != null:
return error(_that);case LocationState$Determined() when determined != null:
return determined(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>({TResult Function()?  loading,TResult Function( LocationError error)?  error,TResult Function( Place place)?  determined,required TResult orElse(),}) {final _that = this;
switch (_that) {
case LocationState$Loading() when loading != null:
return loading();case LocationState$Error() when error != null:
return error(_that.error);case LocationState$Determined() when determined != null:
return determined(_that.place);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>({required TResult Function()  loading,required TResult Function( LocationError error)  error,required TResult Function( Place place)  determined,}) {final _that = this;
switch (_that) {
case LocationState$Loading():
return loading();case LocationState$Error():
return error(_that.error);case LocationState$Determined():
return determined(_that.place);}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>({TResult? Function()?  loading,TResult? Function( LocationError error)?  error,TResult? Function( Place place)?  determined,}) {final _that = this;
switch (_that) {
case LocationState$Loading() when loading != null:
return loading();case LocationState$Error() when error != null:
return error(_that.error);case LocationState$Determined() when determined != null:
return determined(_that.place);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class LocationState$Loading extends LocationState {
  const LocationState$Loading({final  String? $type}): $type = $type ?? 'loading',super._();
  factory LocationState$Loading.fromJson(Map<String, dynamic> json) => _$LocationState$LoadingFromJson(json);



@JsonKey(name: 'runtimeType')
final String $type;



@override
Map<String, dynamic> toJson() {
  return _$LocationState$LoadingToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is LocationState$Loading);
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
  return 'LocationState.loading()';
}


}




/// @nodoc
@JsonSerializable()

class LocationState$Error extends LocationState {
  const LocationState$Error({required this.error, final  String? $type}): $type = $type ?? 'error',super._();
  factory LocationState$Error.fromJson(Map<String, dynamic> json) => _$LocationState$ErrorFromJson(json);

 final  LocationError error;

@JsonKey(name: 'runtimeType')
final String $type;


/// Create a copy of LocationState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$LocationState$ErrorCopyWith<LocationState$Error> get copyWith => _$LocationState$ErrorCopyWithImpl<LocationState$Error>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$LocationState$ErrorToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is LocationState$Error&&(identical(other.error, error) || other.error == error));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,error);

@override
String toString() {
  return 'LocationState.error(error: $error)';
}


}

/// @nodoc
abstract mixin class $LocationState$ErrorCopyWith<$Res> implements $LocationStateCopyWith<$Res> {
  factory $LocationState$ErrorCopyWith(LocationState$Error value, $Res Function(LocationState$Error) _then) = _$LocationState$ErrorCopyWithImpl;
@useResult
$Res call({
 LocationError error
});




}
/// @nodoc
class _$LocationState$ErrorCopyWithImpl<$Res>
    implements $LocationState$ErrorCopyWith<$Res> {
  _$LocationState$ErrorCopyWithImpl(this._self, this._then);

  final LocationState$Error _self;
  final $Res Function(LocationState$Error) _then;

/// Create a copy of LocationState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? error = null,}) {
  return _then(LocationState$Error(
error: null == error ? _self.error : error // ignore: cast_nullable_to_non_nullable
as LocationError,
  ));
}


}

/// @nodoc
@JsonSerializable()

class LocationState$Determined extends LocationState {
  const LocationState$Determined({required this.place, final  String? $type}): $type = $type ?? 'determined',super._();
  factory LocationState$Determined.fromJson(Map<String, dynamic> json) => _$LocationState$DeterminedFromJson(json);

 final  Place place;

@JsonKey(name: 'runtimeType')
final String $type;


/// Create a copy of LocationState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$LocationState$DeterminedCopyWith<LocationState$Determined> get copyWith => _$LocationState$DeterminedCopyWithImpl<LocationState$Determined>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$LocationState$DeterminedToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is LocationState$Determined&&(identical(other.place, place) || other.place == place));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,place);

@override
String toString() {
  return 'LocationState.determined(place: $place)';
}


}

/// @nodoc
abstract mixin class $LocationState$DeterminedCopyWith<$Res> implements $LocationStateCopyWith<$Res> {
  factory $LocationState$DeterminedCopyWith(LocationState$Determined value, $Res Function(LocationState$Determined) _then) = _$LocationState$DeterminedCopyWithImpl;
@useResult
$Res call({
 Place place
});




}
/// @nodoc
class _$LocationState$DeterminedCopyWithImpl<$Res>
    implements $LocationState$DeterminedCopyWith<$Res> {
  _$LocationState$DeterminedCopyWithImpl(this._self, this._then);

  final LocationState$Determined _self;
  final $Res Function(LocationState$Determined) _then;

/// Create a copy of LocationState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? place = null,}) {
  return _then(LocationState$Determined(
place: null == place ? _self.place : place // ignore: cast_nullable_to_non_nullable
as Place,
  ));
}


}

// dart format on
