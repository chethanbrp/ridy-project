// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'home.bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$HomeState implements DiagnosticableTreeMixin {

// General
 ApiResponse<Place> get currentLocationResponse; List<Fragment$EphemeralMessage> get ephemeralMessages; MapViewController? get mapViewController; OrderSubmissionPage get orderSubmissionPage;// Order Submission
 Enum$TaxiOrderType get orderType; List<Place?> get waypoints; List<Fragment$Coordinate> get driversAround;// Order Submission - Delivery
 Input$DeliveryContactInput? get senderContact; Input$DeliveryContactInput? get receiverContact;// Confirm Location
 int? get selectedWaypointIndex; ApiResponse<Place> get selectedLocationResponse;// Ride Preview
 ApiResponse<Query$CalculateFare> get ridePreviewFareResponse; PaymentMethodUnion? get selectedPaymentMethod; Fragment$ServiceCategory? get selectedServiceCategory; Fragment$Service? get selectedService; String? get couponCode; bool get isTwoWayRide; int? get waitTime; List<Fragment$RideOption> get rideOptions; DateTime? get selectedDateTime; ApiResponse<void> get createOrderResponse;// Ride In Progress
 ApiResponse<List<Fragment$ActiveOrder>> get currentOrdersResponse; String? get currentRideId; TrackOrderPage get page; ApiResponse<void> get cancelOrderResponse; ApiResponse<void> get sendMessageState; ApiResponse<void> get reviewSubmissionState;
/// Create a copy of HomeState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeStateCopyWith<HomeState> get copyWith => _$HomeStateCopyWithImpl<HomeState>(this as HomeState, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeState'))
    ..add(DiagnosticsProperty('currentLocationResponse', currentLocationResponse))..add(DiagnosticsProperty('ephemeralMessages', ephemeralMessages))..add(DiagnosticsProperty('mapViewController', mapViewController))..add(DiagnosticsProperty('orderSubmissionPage', orderSubmissionPage))..add(DiagnosticsProperty('orderType', orderType))..add(DiagnosticsProperty('waypoints', waypoints))..add(DiagnosticsProperty('driversAround', driversAround))..add(DiagnosticsProperty('senderContact', senderContact))..add(DiagnosticsProperty('receiverContact', receiverContact))..add(DiagnosticsProperty('selectedWaypointIndex', selectedWaypointIndex))..add(DiagnosticsProperty('selectedLocationResponse', selectedLocationResponse))..add(DiagnosticsProperty('ridePreviewFareResponse', ridePreviewFareResponse))..add(DiagnosticsProperty('selectedPaymentMethod', selectedPaymentMethod))..add(DiagnosticsProperty('selectedServiceCategory', selectedServiceCategory))..add(DiagnosticsProperty('selectedService', selectedService))..add(DiagnosticsProperty('couponCode', couponCode))..add(DiagnosticsProperty('isTwoWayRide', isTwoWayRide))..add(DiagnosticsProperty('waitTime', waitTime))..add(DiagnosticsProperty('rideOptions', rideOptions))..add(DiagnosticsProperty('selectedDateTime', selectedDateTime))..add(DiagnosticsProperty('createOrderResponse', createOrderResponse))..add(DiagnosticsProperty('currentOrdersResponse', currentOrdersResponse))..add(DiagnosticsProperty('currentRideId', currentRideId))..add(DiagnosticsProperty('page', page))..add(DiagnosticsProperty('cancelOrderResponse', cancelOrderResponse))..add(DiagnosticsProperty('sendMessageState', sendMessageState))..add(DiagnosticsProperty('reviewSubmissionState', reviewSubmissionState));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeState&&(identical(other.currentLocationResponse, currentLocationResponse) || other.currentLocationResponse == currentLocationResponse)&&const DeepCollectionEquality().equals(other.ephemeralMessages, ephemeralMessages)&&(identical(other.mapViewController, mapViewController) || other.mapViewController == mapViewController)&&(identical(other.orderSubmissionPage, orderSubmissionPage) || other.orderSubmissionPage == orderSubmissionPage)&&(identical(other.orderType, orderType) || other.orderType == orderType)&&const DeepCollectionEquality().equals(other.waypoints, waypoints)&&const DeepCollectionEquality().equals(other.driversAround, driversAround)&&(identical(other.senderContact, senderContact) || other.senderContact == senderContact)&&(identical(other.receiverContact, receiverContact) || other.receiverContact == receiverContact)&&(identical(other.selectedWaypointIndex, selectedWaypointIndex) || other.selectedWaypointIndex == selectedWaypointIndex)&&(identical(other.selectedLocationResponse, selectedLocationResponse) || other.selectedLocationResponse == selectedLocationResponse)&&(identical(other.ridePreviewFareResponse, ridePreviewFareResponse) || other.ridePreviewFareResponse == ridePreviewFareResponse)&&(identical(other.selectedPaymentMethod, selectedPaymentMethod) || other.selectedPaymentMethod == selectedPaymentMethod)&&(identical(other.selectedServiceCategory, selectedServiceCategory) || other.selectedServiceCategory == selectedServiceCategory)&&(identical(other.selectedService, selectedService) || other.selectedService == selectedService)&&(identical(other.couponCode, couponCode) || other.couponCode == couponCode)&&(identical(other.isTwoWayRide, isTwoWayRide) || other.isTwoWayRide == isTwoWayRide)&&(identical(other.waitTime, waitTime) || other.waitTime == waitTime)&&const DeepCollectionEquality().equals(other.rideOptions, rideOptions)&&(identical(other.selectedDateTime, selectedDateTime) || other.selectedDateTime == selectedDateTime)&&(identical(other.createOrderResponse, createOrderResponse) || other.createOrderResponse == createOrderResponse)&&(identical(other.currentOrdersResponse, currentOrdersResponse) || other.currentOrdersResponse == currentOrdersResponse)&&(identical(other.currentRideId, currentRideId) || other.currentRideId == currentRideId)&&(identical(other.page, page) || other.page == page)&&(identical(other.cancelOrderResponse, cancelOrderResponse) || other.cancelOrderResponse == cancelOrderResponse)&&(identical(other.sendMessageState, sendMessageState) || other.sendMessageState == sendMessageState)&&(identical(other.reviewSubmissionState, reviewSubmissionState) || other.reviewSubmissionState == reviewSubmissionState));
}


@override
int get hashCode => Object.hashAll([runtimeType,currentLocationResponse,const DeepCollectionEquality().hash(ephemeralMessages),mapViewController,orderSubmissionPage,orderType,const DeepCollectionEquality().hash(waypoints),const DeepCollectionEquality().hash(driversAround),senderContact,receiverContact,selectedWaypointIndex,selectedLocationResponse,ridePreviewFareResponse,selectedPaymentMethod,selectedServiceCategory,selectedService,couponCode,isTwoWayRide,waitTime,const DeepCollectionEquality().hash(rideOptions),selectedDateTime,createOrderResponse,currentOrdersResponse,currentRideId,page,cancelOrderResponse,sendMessageState,reviewSubmissionState]);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeState(currentLocationResponse: $currentLocationResponse, ephemeralMessages: $ephemeralMessages, mapViewController: $mapViewController, orderSubmissionPage: $orderSubmissionPage, orderType: $orderType, waypoints: $waypoints, driversAround: $driversAround, senderContact: $senderContact, receiverContact: $receiverContact, selectedWaypointIndex: $selectedWaypointIndex, selectedLocationResponse: $selectedLocationResponse, ridePreviewFareResponse: $ridePreviewFareResponse, selectedPaymentMethod: $selectedPaymentMethod, selectedServiceCategory: $selectedServiceCategory, selectedService: $selectedService, couponCode: $couponCode, isTwoWayRide: $isTwoWayRide, waitTime: $waitTime, rideOptions: $rideOptions, selectedDateTime: $selectedDateTime, createOrderResponse: $createOrderResponse, currentOrdersResponse: $currentOrdersResponse, currentRideId: $currentRideId, page: $page, cancelOrderResponse: $cancelOrderResponse, sendMessageState: $sendMessageState, reviewSubmissionState: $reviewSubmissionState)';
}


}

/// @nodoc
abstract mixin class $HomeStateCopyWith<$Res>  {
  factory $HomeStateCopyWith(HomeState value, $Res Function(HomeState) _then) = _$HomeStateCopyWithImpl;
@useResult
$Res call({
 ApiResponse<Place> currentLocationResponse, List<Fragment$EphemeralMessage> ephemeralMessages, MapViewController? mapViewController, OrderSubmissionPage orderSubmissionPage, Enum$TaxiOrderType orderType, List<Place?> waypoints, List<Fragment$Coordinate> driversAround, Input$DeliveryContactInput? senderContact, Input$DeliveryContactInput? receiverContact, int? selectedWaypointIndex, ApiResponse<Place> selectedLocationResponse, ApiResponse<Query$CalculateFare> ridePreviewFareResponse, PaymentMethodUnion? selectedPaymentMethod, Fragment$ServiceCategory? selectedServiceCategory, Fragment$Service? selectedService, String? couponCode, bool isTwoWayRide, int? waitTime, List<Fragment$RideOption> rideOptions, DateTime? selectedDateTime, ApiResponse<void> createOrderResponse, ApiResponse<List<Fragment$ActiveOrder>> currentOrdersResponse, String? currentRideId, TrackOrderPage page, ApiResponse<void> cancelOrderResponse, ApiResponse<void> sendMessageState, ApiResponse<void> reviewSubmissionState
});


$ApiResponseCopyWith<Place, $Res> get currentLocationResponse;$ApiResponseCopyWith<Place, $Res> get selectedLocationResponse;$ApiResponseCopyWith<Query$CalculateFare, $Res> get ridePreviewFareResponse;$ApiResponseCopyWith<void, $Res> get createOrderResponse;$ApiResponseCopyWith<List<Fragment$ActiveOrder>, $Res> get currentOrdersResponse;$ApiResponseCopyWith<void, $Res> get cancelOrderResponse;$ApiResponseCopyWith<void, $Res> get sendMessageState;$ApiResponseCopyWith<void, $Res> get reviewSubmissionState;

}
/// @nodoc
class _$HomeStateCopyWithImpl<$Res>
    implements $HomeStateCopyWith<$Res> {
  _$HomeStateCopyWithImpl(this._self, this._then);

  final HomeState _self;
  final $Res Function(HomeState) _then;

/// Create a copy of HomeState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? currentLocationResponse = null,Object? ephemeralMessages = null,Object? mapViewController = freezed,Object? orderSubmissionPage = null,Object? orderType = null,Object? waypoints = null,Object? driversAround = null,Object? senderContact = freezed,Object? receiverContact = freezed,Object? selectedWaypointIndex = freezed,Object? selectedLocationResponse = null,Object? ridePreviewFareResponse = null,Object? selectedPaymentMethod = freezed,Object? selectedServiceCategory = freezed,Object? selectedService = freezed,Object? couponCode = freezed,Object? isTwoWayRide = null,Object? waitTime = freezed,Object? rideOptions = null,Object? selectedDateTime = freezed,Object? createOrderResponse = null,Object? currentOrdersResponse = null,Object? currentRideId = freezed,Object? page = null,Object? cancelOrderResponse = null,Object? sendMessageState = null,Object? reviewSubmissionState = null,}) {
  return _then(_self.copyWith(
currentLocationResponse: null == currentLocationResponse ? _self.currentLocationResponse : currentLocationResponse // ignore: cast_nullable_to_non_nullable
as ApiResponse<Place>,ephemeralMessages: null == ephemeralMessages ? _self.ephemeralMessages : ephemeralMessages // ignore: cast_nullable_to_non_nullable
as List<Fragment$EphemeralMessage>,mapViewController: freezed == mapViewController ? _self.mapViewController : mapViewController // ignore: cast_nullable_to_non_nullable
as MapViewController?,orderSubmissionPage: null == orderSubmissionPage ? _self.orderSubmissionPage : orderSubmissionPage // ignore: cast_nullable_to_non_nullable
as OrderSubmissionPage,orderType: null == orderType ? _self.orderType : orderType // ignore: cast_nullable_to_non_nullable
as Enum$TaxiOrderType,waypoints: null == waypoints ? _self.waypoints : waypoints // ignore: cast_nullable_to_non_nullable
as List<Place?>,driversAround: null == driversAround ? _self.driversAround : driversAround // ignore: cast_nullable_to_non_nullable
as List<Fragment$Coordinate>,senderContact: freezed == senderContact ? _self.senderContact : senderContact // ignore: cast_nullable_to_non_nullable
as Input$DeliveryContactInput?,receiverContact: freezed == receiverContact ? _self.receiverContact : receiverContact // ignore: cast_nullable_to_non_nullable
as Input$DeliveryContactInput?,selectedWaypointIndex: freezed == selectedWaypointIndex ? _self.selectedWaypointIndex : selectedWaypointIndex // ignore: cast_nullable_to_non_nullable
as int?,selectedLocationResponse: null == selectedLocationResponse ? _self.selectedLocationResponse : selectedLocationResponse // ignore: cast_nullable_to_non_nullable
as ApiResponse<Place>,ridePreviewFareResponse: null == ridePreviewFareResponse ? _self.ridePreviewFareResponse : ridePreviewFareResponse // ignore: cast_nullable_to_non_nullable
as ApiResponse<Query$CalculateFare>,selectedPaymentMethod: freezed == selectedPaymentMethod ? _self.selectedPaymentMethod : selectedPaymentMethod // ignore: cast_nullable_to_non_nullable
as PaymentMethodUnion?,selectedServiceCategory: freezed == selectedServiceCategory ? _self.selectedServiceCategory : selectedServiceCategory // ignore: cast_nullable_to_non_nullable
as Fragment$ServiceCategory?,selectedService: freezed == selectedService ? _self.selectedService : selectedService // ignore: cast_nullable_to_non_nullable
as Fragment$Service?,couponCode: freezed == couponCode ? _self.couponCode : couponCode // ignore: cast_nullable_to_non_nullable
as String?,isTwoWayRide: null == isTwoWayRide ? _self.isTwoWayRide : isTwoWayRide // ignore: cast_nullable_to_non_nullable
as bool,waitTime: freezed == waitTime ? _self.waitTime : waitTime // ignore: cast_nullable_to_non_nullable
as int?,rideOptions: null == rideOptions ? _self.rideOptions : rideOptions // ignore: cast_nullable_to_non_nullable
as List<Fragment$RideOption>,selectedDateTime: freezed == selectedDateTime ? _self.selectedDateTime : selectedDateTime // ignore: cast_nullable_to_non_nullable
as DateTime?,createOrderResponse: null == createOrderResponse ? _self.createOrderResponse : createOrderResponse // ignore: cast_nullable_to_non_nullable
as ApiResponse<void>,currentOrdersResponse: null == currentOrdersResponse ? _self.currentOrdersResponse : currentOrdersResponse // ignore: cast_nullable_to_non_nullable
as ApiResponse<List<Fragment$ActiveOrder>>,currentRideId: freezed == currentRideId ? _self.currentRideId : currentRideId // ignore: cast_nullable_to_non_nullable
as String?,page: null == page ? _self.page : page // ignore: cast_nullable_to_non_nullable
as TrackOrderPage,cancelOrderResponse: null == cancelOrderResponse ? _self.cancelOrderResponse : cancelOrderResponse // ignore: cast_nullable_to_non_nullable
as ApiResponse<void>,sendMessageState: null == sendMessageState ? _self.sendMessageState : sendMessageState // ignore: cast_nullable_to_non_nullable
as ApiResponse<void>,reviewSubmissionState: null == reviewSubmissionState ? _self.reviewSubmissionState : reviewSubmissionState // ignore: cast_nullable_to_non_nullable
as ApiResponse<void>,
  ));
}
/// Create a copy of HomeState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<Place, $Res> get currentLocationResponse {
  
  return $ApiResponseCopyWith<Place, $Res>(_self.currentLocationResponse, (value) {
    return _then(_self.copyWith(currentLocationResponse: value));
  });
}/// Create a copy of HomeState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<Place, $Res> get selectedLocationResponse {
  
  return $ApiResponseCopyWith<Place, $Res>(_self.selectedLocationResponse, (value) {
    return _then(_self.copyWith(selectedLocationResponse: value));
  });
}/// Create a copy of HomeState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<Query$CalculateFare, $Res> get ridePreviewFareResponse {
  
  return $ApiResponseCopyWith<Query$CalculateFare, $Res>(_self.ridePreviewFareResponse, (value) {
    return _then(_self.copyWith(ridePreviewFareResponse: value));
  });
}/// Create a copy of HomeState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<void, $Res> get createOrderResponse {
  
  return $ApiResponseCopyWith<void, $Res>(_self.createOrderResponse, (value) {
    return _then(_self.copyWith(createOrderResponse: value));
  });
}/// Create a copy of HomeState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<List<Fragment$ActiveOrder>, $Res> get currentOrdersResponse {
  
  return $ApiResponseCopyWith<List<Fragment$ActiveOrder>, $Res>(_self.currentOrdersResponse, (value) {
    return _then(_self.copyWith(currentOrdersResponse: value));
  });
}/// Create a copy of HomeState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<void, $Res> get cancelOrderResponse {
  
  return $ApiResponseCopyWith<void, $Res>(_self.cancelOrderResponse, (value) {
    return _then(_self.copyWith(cancelOrderResponse: value));
  });
}/// Create a copy of HomeState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<void, $Res> get sendMessageState {
  
  return $ApiResponseCopyWith<void, $Res>(_self.sendMessageState, (value) {
    return _then(_self.copyWith(sendMessageState: value));
  });
}/// Create a copy of HomeState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<void, $Res> get reviewSubmissionState {
  
  return $ApiResponseCopyWith<void, $Res>(_self.reviewSubmissionState, (value) {
    return _then(_self.copyWith(reviewSubmissionState: value));
  });
}
}


/// Adds pattern-matching-related methods to [HomeState].
extension HomeStatePatterns on HomeState {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _HomeState value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _HomeState() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _HomeState value)  $default,){
final _that = this;
switch (_that) {
case _HomeState():
return $default(_that);}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _HomeState value)?  $default,){
final _that = this;
switch (_that) {
case _HomeState() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( ApiResponse<Place> currentLocationResponse,  List<Fragment$EphemeralMessage> ephemeralMessages,  MapViewController? mapViewController,  OrderSubmissionPage orderSubmissionPage,  Enum$TaxiOrderType orderType,  List<Place?> waypoints,  List<Fragment$Coordinate> driversAround,  Input$DeliveryContactInput? senderContact,  Input$DeliveryContactInput? receiverContact,  int? selectedWaypointIndex,  ApiResponse<Place> selectedLocationResponse,  ApiResponse<Query$CalculateFare> ridePreviewFareResponse,  PaymentMethodUnion? selectedPaymentMethod,  Fragment$ServiceCategory? selectedServiceCategory,  Fragment$Service? selectedService,  String? couponCode,  bool isTwoWayRide,  int? waitTime,  List<Fragment$RideOption> rideOptions,  DateTime? selectedDateTime,  ApiResponse<void> createOrderResponse,  ApiResponse<List<Fragment$ActiveOrder>> currentOrdersResponse,  String? currentRideId,  TrackOrderPage page,  ApiResponse<void> cancelOrderResponse,  ApiResponse<void> sendMessageState,  ApiResponse<void> reviewSubmissionState)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _HomeState() when $default != null:
return $default(_that.currentLocationResponse,_that.ephemeralMessages,_that.mapViewController,_that.orderSubmissionPage,_that.orderType,_that.waypoints,_that.driversAround,_that.senderContact,_that.receiverContact,_that.selectedWaypointIndex,_that.selectedLocationResponse,_that.ridePreviewFareResponse,_that.selectedPaymentMethod,_that.selectedServiceCategory,_that.selectedService,_that.couponCode,_that.isTwoWayRide,_that.waitTime,_that.rideOptions,_that.selectedDateTime,_that.createOrderResponse,_that.currentOrdersResponse,_that.currentRideId,_that.page,_that.cancelOrderResponse,_that.sendMessageState,_that.reviewSubmissionState);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( ApiResponse<Place> currentLocationResponse,  List<Fragment$EphemeralMessage> ephemeralMessages,  MapViewController? mapViewController,  OrderSubmissionPage orderSubmissionPage,  Enum$TaxiOrderType orderType,  List<Place?> waypoints,  List<Fragment$Coordinate> driversAround,  Input$DeliveryContactInput? senderContact,  Input$DeliveryContactInput? receiverContact,  int? selectedWaypointIndex,  ApiResponse<Place> selectedLocationResponse,  ApiResponse<Query$CalculateFare> ridePreviewFareResponse,  PaymentMethodUnion? selectedPaymentMethod,  Fragment$ServiceCategory? selectedServiceCategory,  Fragment$Service? selectedService,  String? couponCode,  bool isTwoWayRide,  int? waitTime,  List<Fragment$RideOption> rideOptions,  DateTime? selectedDateTime,  ApiResponse<void> createOrderResponse,  ApiResponse<List<Fragment$ActiveOrder>> currentOrdersResponse,  String? currentRideId,  TrackOrderPage page,  ApiResponse<void> cancelOrderResponse,  ApiResponse<void> sendMessageState,  ApiResponse<void> reviewSubmissionState)  $default,) {final _that = this;
switch (_that) {
case _HomeState():
return $default(_that.currentLocationResponse,_that.ephemeralMessages,_that.mapViewController,_that.orderSubmissionPage,_that.orderType,_that.waypoints,_that.driversAround,_that.senderContact,_that.receiverContact,_that.selectedWaypointIndex,_that.selectedLocationResponse,_that.ridePreviewFareResponse,_that.selectedPaymentMethod,_that.selectedServiceCategory,_that.selectedService,_that.couponCode,_that.isTwoWayRide,_that.waitTime,_that.rideOptions,_that.selectedDateTime,_that.createOrderResponse,_that.currentOrdersResponse,_that.currentRideId,_that.page,_that.cancelOrderResponse,_that.sendMessageState,_that.reviewSubmissionState);}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( ApiResponse<Place> currentLocationResponse,  List<Fragment$EphemeralMessage> ephemeralMessages,  MapViewController? mapViewController,  OrderSubmissionPage orderSubmissionPage,  Enum$TaxiOrderType orderType,  List<Place?> waypoints,  List<Fragment$Coordinate> driversAround,  Input$DeliveryContactInput? senderContact,  Input$DeliveryContactInput? receiverContact,  int? selectedWaypointIndex,  ApiResponse<Place> selectedLocationResponse,  ApiResponse<Query$CalculateFare> ridePreviewFareResponse,  PaymentMethodUnion? selectedPaymentMethod,  Fragment$ServiceCategory? selectedServiceCategory,  Fragment$Service? selectedService,  String? couponCode,  bool isTwoWayRide,  int? waitTime,  List<Fragment$RideOption> rideOptions,  DateTime? selectedDateTime,  ApiResponse<void> createOrderResponse,  ApiResponse<List<Fragment$ActiveOrder>> currentOrdersResponse,  String? currentRideId,  TrackOrderPage page,  ApiResponse<void> cancelOrderResponse,  ApiResponse<void> sendMessageState,  ApiResponse<void> reviewSubmissionState)?  $default,) {final _that = this;
switch (_that) {
case _HomeState() when $default != null:
return $default(_that.currentLocationResponse,_that.ephemeralMessages,_that.mapViewController,_that.orderSubmissionPage,_that.orderType,_that.waypoints,_that.driversAround,_that.senderContact,_that.receiverContact,_that.selectedWaypointIndex,_that.selectedLocationResponse,_that.ridePreviewFareResponse,_that.selectedPaymentMethod,_that.selectedServiceCategory,_that.selectedService,_that.couponCode,_that.isTwoWayRide,_that.waitTime,_that.rideOptions,_that.selectedDateTime,_that.createOrderResponse,_that.currentOrdersResponse,_that.currentRideId,_that.page,_that.cancelOrderResponse,_that.sendMessageState,_that.reviewSubmissionState);case _:
  return null;

}
}

}

/// @nodoc


class _HomeState extends HomeState with DiagnosticableTreeMixin {
  const _HomeState({this.currentLocationResponse = const ApiResponse.initial(), final  List<Fragment$EphemeralMessage> ephemeralMessages = const [], this.mapViewController, this.orderSubmissionPage = OrderSubmissionPage.welcome, this.orderType = Enum$TaxiOrderType.Ride, final  List<Place?> waypoints = const [], final  List<Fragment$Coordinate> driversAround = const [], this.senderContact, this.receiverContact, this.selectedWaypointIndex, this.selectedLocationResponse = const ApiResponse.initial(), this.ridePreviewFareResponse = const ApiResponse.initial(), this.selectedPaymentMethod, this.selectedServiceCategory, this.selectedService, this.couponCode, this.isTwoWayRide = false, this.waitTime, final  List<Fragment$RideOption> rideOptions = const [], this.selectedDateTime, this.createOrderResponse = const ApiResponse.initial(), this.currentOrdersResponse = const ApiResponse.initial(), this.currentRideId, this.page = TrackOrderPage.overview, this.cancelOrderResponse = const ApiResponseInitial(), this.sendMessageState = const ApiResponseInitial(), this.reviewSubmissionState = const ApiResponseInitial()}): _ephemeralMessages = ephemeralMessages,_waypoints = waypoints,_driversAround = driversAround,_rideOptions = rideOptions,super._();
  

// General
@override@JsonKey() final  ApiResponse<Place> currentLocationResponse;
 final  List<Fragment$EphemeralMessage> _ephemeralMessages;
@override@JsonKey() List<Fragment$EphemeralMessage> get ephemeralMessages {
  if (_ephemeralMessages is EqualUnmodifiableListView) return _ephemeralMessages;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_ephemeralMessages);
}

@override final  MapViewController? mapViewController;
@override@JsonKey() final  OrderSubmissionPage orderSubmissionPage;
// Order Submission
@override@JsonKey() final  Enum$TaxiOrderType orderType;
 final  List<Place?> _waypoints;
@override@JsonKey() List<Place?> get waypoints {
  if (_waypoints is EqualUnmodifiableListView) return _waypoints;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_waypoints);
}

 final  List<Fragment$Coordinate> _driversAround;
@override@JsonKey() List<Fragment$Coordinate> get driversAround {
  if (_driversAround is EqualUnmodifiableListView) return _driversAround;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_driversAround);
}

// Order Submission - Delivery
@override final  Input$DeliveryContactInput? senderContact;
@override final  Input$DeliveryContactInput? receiverContact;
// Confirm Location
@override final  int? selectedWaypointIndex;
@override@JsonKey() final  ApiResponse<Place> selectedLocationResponse;
// Ride Preview
@override@JsonKey() final  ApiResponse<Query$CalculateFare> ridePreviewFareResponse;
@override final  PaymentMethodUnion? selectedPaymentMethod;
@override final  Fragment$ServiceCategory? selectedServiceCategory;
@override final  Fragment$Service? selectedService;
@override final  String? couponCode;
@override@JsonKey() final  bool isTwoWayRide;
@override final  int? waitTime;
 final  List<Fragment$RideOption> _rideOptions;
@override@JsonKey() List<Fragment$RideOption> get rideOptions {
  if (_rideOptions is EqualUnmodifiableListView) return _rideOptions;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_rideOptions);
}

@override final  DateTime? selectedDateTime;
@override@JsonKey() final  ApiResponse<void> createOrderResponse;
// Ride In Progress
@override@JsonKey() final  ApiResponse<List<Fragment$ActiveOrder>> currentOrdersResponse;
@override final  String? currentRideId;
@override@JsonKey() final  TrackOrderPage page;
@override@JsonKey() final  ApiResponse<void> cancelOrderResponse;
@override@JsonKey() final  ApiResponse<void> sendMessageState;
@override@JsonKey() final  ApiResponse<void> reviewSubmissionState;

/// Create a copy of HomeState
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$HomeStateCopyWith<_HomeState> get copyWith => __$HomeStateCopyWithImpl<_HomeState>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeState'))
    ..add(DiagnosticsProperty('currentLocationResponse', currentLocationResponse))..add(DiagnosticsProperty('ephemeralMessages', ephemeralMessages))..add(DiagnosticsProperty('mapViewController', mapViewController))..add(DiagnosticsProperty('orderSubmissionPage', orderSubmissionPage))..add(DiagnosticsProperty('orderType', orderType))..add(DiagnosticsProperty('waypoints', waypoints))..add(DiagnosticsProperty('driversAround', driversAround))..add(DiagnosticsProperty('senderContact', senderContact))..add(DiagnosticsProperty('receiverContact', receiverContact))..add(DiagnosticsProperty('selectedWaypointIndex', selectedWaypointIndex))..add(DiagnosticsProperty('selectedLocationResponse', selectedLocationResponse))..add(DiagnosticsProperty('ridePreviewFareResponse', ridePreviewFareResponse))..add(DiagnosticsProperty('selectedPaymentMethod', selectedPaymentMethod))..add(DiagnosticsProperty('selectedServiceCategory', selectedServiceCategory))..add(DiagnosticsProperty('selectedService', selectedService))..add(DiagnosticsProperty('couponCode', couponCode))..add(DiagnosticsProperty('isTwoWayRide', isTwoWayRide))..add(DiagnosticsProperty('waitTime', waitTime))..add(DiagnosticsProperty('rideOptions', rideOptions))..add(DiagnosticsProperty('selectedDateTime', selectedDateTime))..add(DiagnosticsProperty('createOrderResponse', createOrderResponse))..add(DiagnosticsProperty('currentOrdersResponse', currentOrdersResponse))..add(DiagnosticsProperty('currentRideId', currentRideId))..add(DiagnosticsProperty('page', page))..add(DiagnosticsProperty('cancelOrderResponse', cancelOrderResponse))..add(DiagnosticsProperty('sendMessageState', sendMessageState))..add(DiagnosticsProperty('reviewSubmissionState', reviewSubmissionState));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _HomeState&&(identical(other.currentLocationResponse, currentLocationResponse) || other.currentLocationResponse == currentLocationResponse)&&const DeepCollectionEquality().equals(other._ephemeralMessages, _ephemeralMessages)&&(identical(other.mapViewController, mapViewController) || other.mapViewController == mapViewController)&&(identical(other.orderSubmissionPage, orderSubmissionPage) || other.orderSubmissionPage == orderSubmissionPage)&&(identical(other.orderType, orderType) || other.orderType == orderType)&&const DeepCollectionEquality().equals(other._waypoints, _waypoints)&&const DeepCollectionEquality().equals(other._driversAround, _driversAround)&&(identical(other.senderContact, senderContact) || other.senderContact == senderContact)&&(identical(other.receiverContact, receiverContact) || other.receiverContact == receiverContact)&&(identical(other.selectedWaypointIndex, selectedWaypointIndex) || other.selectedWaypointIndex == selectedWaypointIndex)&&(identical(other.selectedLocationResponse, selectedLocationResponse) || other.selectedLocationResponse == selectedLocationResponse)&&(identical(other.ridePreviewFareResponse, ridePreviewFareResponse) || other.ridePreviewFareResponse == ridePreviewFareResponse)&&(identical(other.selectedPaymentMethod, selectedPaymentMethod) || other.selectedPaymentMethod == selectedPaymentMethod)&&(identical(other.selectedServiceCategory, selectedServiceCategory) || other.selectedServiceCategory == selectedServiceCategory)&&(identical(other.selectedService, selectedService) || other.selectedService == selectedService)&&(identical(other.couponCode, couponCode) || other.couponCode == couponCode)&&(identical(other.isTwoWayRide, isTwoWayRide) || other.isTwoWayRide == isTwoWayRide)&&(identical(other.waitTime, waitTime) || other.waitTime == waitTime)&&const DeepCollectionEquality().equals(other._rideOptions, _rideOptions)&&(identical(other.selectedDateTime, selectedDateTime) || other.selectedDateTime == selectedDateTime)&&(identical(other.createOrderResponse, createOrderResponse) || other.createOrderResponse == createOrderResponse)&&(identical(other.currentOrdersResponse, currentOrdersResponse) || other.currentOrdersResponse == currentOrdersResponse)&&(identical(other.currentRideId, currentRideId) || other.currentRideId == currentRideId)&&(identical(other.page, page) || other.page == page)&&(identical(other.cancelOrderResponse, cancelOrderResponse) || other.cancelOrderResponse == cancelOrderResponse)&&(identical(other.sendMessageState, sendMessageState) || other.sendMessageState == sendMessageState)&&(identical(other.reviewSubmissionState, reviewSubmissionState) || other.reviewSubmissionState == reviewSubmissionState));
}


@override
int get hashCode => Object.hashAll([runtimeType,currentLocationResponse,const DeepCollectionEquality().hash(_ephemeralMessages),mapViewController,orderSubmissionPage,orderType,const DeepCollectionEquality().hash(_waypoints),const DeepCollectionEquality().hash(_driversAround),senderContact,receiverContact,selectedWaypointIndex,selectedLocationResponse,ridePreviewFareResponse,selectedPaymentMethod,selectedServiceCategory,selectedService,couponCode,isTwoWayRide,waitTime,const DeepCollectionEquality().hash(_rideOptions),selectedDateTime,createOrderResponse,currentOrdersResponse,currentRideId,page,cancelOrderResponse,sendMessageState,reviewSubmissionState]);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeState(currentLocationResponse: $currentLocationResponse, ephemeralMessages: $ephemeralMessages, mapViewController: $mapViewController, orderSubmissionPage: $orderSubmissionPage, orderType: $orderType, waypoints: $waypoints, driversAround: $driversAround, senderContact: $senderContact, receiverContact: $receiverContact, selectedWaypointIndex: $selectedWaypointIndex, selectedLocationResponse: $selectedLocationResponse, ridePreviewFareResponse: $ridePreviewFareResponse, selectedPaymentMethod: $selectedPaymentMethod, selectedServiceCategory: $selectedServiceCategory, selectedService: $selectedService, couponCode: $couponCode, isTwoWayRide: $isTwoWayRide, waitTime: $waitTime, rideOptions: $rideOptions, selectedDateTime: $selectedDateTime, createOrderResponse: $createOrderResponse, currentOrdersResponse: $currentOrdersResponse, currentRideId: $currentRideId, page: $page, cancelOrderResponse: $cancelOrderResponse, sendMessageState: $sendMessageState, reviewSubmissionState: $reviewSubmissionState)';
}


}

/// @nodoc
abstract mixin class _$HomeStateCopyWith<$Res> implements $HomeStateCopyWith<$Res> {
  factory _$HomeStateCopyWith(_HomeState value, $Res Function(_HomeState) _then) = __$HomeStateCopyWithImpl;
@override @useResult
$Res call({
 ApiResponse<Place> currentLocationResponse, List<Fragment$EphemeralMessage> ephemeralMessages, MapViewController? mapViewController, OrderSubmissionPage orderSubmissionPage, Enum$TaxiOrderType orderType, List<Place?> waypoints, List<Fragment$Coordinate> driversAround, Input$DeliveryContactInput? senderContact, Input$DeliveryContactInput? receiverContact, int? selectedWaypointIndex, ApiResponse<Place> selectedLocationResponse, ApiResponse<Query$CalculateFare> ridePreviewFareResponse, PaymentMethodUnion? selectedPaymentMethod, Fragment$ServiceCategory? selectedServiceCategory, Fragment$Service? selectedService, String? couponCode, bool isTwoWayRide, int? waitTime, List<Fragment$RideOption> rideOptions, DateTime? selectedDateTime, ApiResponse<void> createOrderResponse, ApiResponse<List<Fragment$ActiveOrder>> currentOrdersResponse, String? currentRideId, TrackOrderPage page, ApiResponse<void> cancelOrderResponse, ApiResponse<void> sendMessageState, ApiResponse<void> reviewSubmissionState
});


@override $ApiResponseCopyWith<Place, $Res> get currentLocationResponse;@override $ApiResponseCopyWith<Place, $Res> get selectedLocationResponse;@override $ApiResponseCopyWith<Query$CalculateFare, $Res> get ridePreviewFareResponse;@override $ApiResponseCopyWith<void, $Res> get createOrderResponse;@override $ApiResponseCopyWith<List<Fragment$ActiveOrder>, $Res> get currentOrdersResponse;@override $ApiResponseCopyWith<void, $Res> get cancelOrderResponse;@override $ApiResponseCopyWith<void, $Res> get sendMessageState;@override $ApiResponseCopyWith<void, $Res> get reviewSubmissionState;

}
/// @nodoc
class __$HomeStateCopyWithImpl<$Res>
    implements _$HomeStateCopyWith<$Res> {
  __$HomeStateCopyWithImpl(this._self, this._then);

  final _HomeState _self;
  final $Res Function(_HomeState) _then;

/// Create a copy of HomeState
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? currentLocationResponse = null,Object? ephemeralMessages = null,Object? mapViewController = freezed,Object? orderSubmissionPage = null,Object? orderType = null,Object? waypoints = null,Object? driversAround = null,Object? senderContact = freezed,Object? receiverContact = freezed,Object? selectedWaypointIndex = freezed,Object? selectedLocationResponse = null,Object? ridePreviewFareResponse = null,Object? selectedPaymentMethod = freezed,Object? selectedServiceCategory = freezed,Object? selectedService = freezed,Object? couponCode = freezed,Object? isTwoWayRide = null,Object? waitTime = freezed,Object? rideOptions = null,Object? selectedDateTime = freezed,Object? createOrderResponse = null,Object? currentOrdersResponse = null,Object? currentRideId = freezed,Object? page = null,Object? cancelOrderResponse = null,Object? sendMessageState = null,Object? reviewSubmissionState = null,}) {
  return _then(_HomeState(
currentLocationResponse: null == currentLocationResponse ? _self.currentLocationResponse : currentLocationResponse // ignore: cast_nullable_to_non_nullable
as ApiResponse<Place>,ephemeralMessages: null == ephemeralMessages ? _self._ephemeralMessages : ephemeralMessages // ignore: cast_nullable_to_non_nullable
as List<Fragment$EphemeralMessage>,mapViewController: freezed == mapViewController ? _self.mapViewController : mapViewController // ignore: cast_nullable_to_non_nullable
as MapViewController?,orderSubmissionPage: null == orderSubmissionPage ? _self.orderSubmissionPage : orderSubmissionPage // ignore: cast_nullable_to_non_nullable
as OrderSubmissionPage,orderType: null == orderType ? _self.orderType : orderType // ignore: cast_nullable_to_non_nullable
as Enum$TaxiOrderType,waypoints: null == waypoints ? _self._waypoints : waypoints // ignore: cast_nullable_to_non_nullable
as List<Place?>,driversAround: null == driversAround ? _self._driversAround : driversAround // ignore: cast_nullable_to_non_nullable
as List<Fragment$Coordinate>,senderContact: freezed == senderContact ? _self.senderContact : senderContact // ignore: cast_nullable_to_non_nullable
as Input$DeliveryContactInput?,receiverContact: freezed == receiverContact ? _self.receiverContact : receiverContact // ignore: cast_nullable_to_non_nullable
as Input$DeliveryContactInput?,selectedWaypointIndex: freezed == selectedWaypointIndex ? _self.selectedWaypointIndex : selectedWaypointIndex // ignore: cast_nullable_to_non_nullable
as int?,selectedLocationResponse: null == selectedLocationResponse ? _self.selectedLocationResponse : selectedLocationResponse // ignore: cast_nullable_to_non_nullable
as ApiResponse<Place>,ridePreviewFareResponse: null == ridePreviewFareResponse ? _self.ridePreviewFareResponse : ridePreviewFareResponse // ignore: cast_nullable_to_non_nullable
as ApiResponse<Query$CalculateFare>,selectedPaymentMethod: freezed == selectedPaymentMethod ? _self.selectedPaymentMethod : selectedPaymentMethod // ignore: cast_nullable_to_non_nullable
as PaymentMethodUnion?,selectedServiceCategory: freezed == selectedServiceCategory ? _self.selectedServiceCategory : selectedServiceCategory // ignore: cast_nullable_to_non_nullable
as Fragment$ServiceCategory?,selectedService: freezed == selectedService ? _self.selectedService : selectedService // ignore: cast_nullable_to_non_nullable
as Fragment$Service?,couponCode: freezed == couponCode ? _self.couponCode : couponCode // ignore: cast_nullable_to_non_nullable
as String?,isTwoWayRide: null == isTwoWayRide ? _self.isTwoWayRide : isTwoWayRide // ignore: cast_nullable_to_non_nullable
as bool,waitTime: freezed == waitTime ? _self.waitTime : waitTime // ignore: cast_nullable_to_non_nullable
as int?,rideOptions: null == rideOptions ? _self._rideOptions : rideOptions // ignore: cast_nullable_to_non_nullable
as List<Fragment$RideOption>,selectedDateTime: freezed == selectedDateTime ? _self.selectedDateTime : selectedDateTime // ignore: cast_nullable_to_non_nullable
as DateTime?,createOrderResponse: null == createOrderResponse ? _self.createOrderResponse : createOrderResponse // ignore: cast_nullable_to_non_nullable
as ApiResponse<void>,currentOrdersResponse: null == currentOrdersResponse ? _self.currentOrdersResponse : currentOrdersResponse // ignore: cast_nullable_to_non_nullable
as ApiResponse<List<Fragment$ActiveOrder>>,currentRideId: freezed == currentRideId ? _self.currentRideId : currentRideId // ignore: cast_nullable_to_non_nullable
as String?,page: null == page ? _self.page : page // ignore: cast_nullable_to_non_nullable
as TrackOrderPage,cancelOrderResponse: null == cancelOrderResponse ? _self.cancelOrderResponse : cancelOrderResponse // ignore: cast_nullable_to_non_nullable
as ApiResponse<void>,sendMessageState: null == sendMessageState ? _self.sendMessageState : sendMessageState // ignore: cast_nullable_to_non_nullable
as ApiResponse<void>,reviewSubmissionState: null == reviewSubmissionState ? _self.reviewSubmissionState : reviewSubmissionState // ignore: cast_nullable_to_non_nullable
as ApiResponse<void>,
  ));
}

/// Create a copy of HomeState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<Place, $Res> get currentLocationResponse {
  
  return $ApiResponseCopyWith<Place, $Res>(_self.currentLocationResponse, (value) {
    return _then(_self.copyWith(currentLocationResponse: value));
  });
}/// Create a copy of HomeState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<Place, $Res> get selectedLocationResponse {
  
  return $ApiResponseCopyWith<Place, $Res>(_self.selectedLocationResponse, (value) {
    return _then(_self.copyWith(selectedLocationResponse: value));
  });
}/// Create a copy of HomeState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<Query$CalculateFare, $Res> get ridePreviewFareResponse {
  
  return $ApiResponseCopyWith<Query$CalculateFare, $Res>(_self.ridePreviewFareResponse, (value) {
    return _then(_self.copyWith(ridePreviewFareResponse: value));
  });
}/// Create a copy of HomeState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<void, $Res> get createOrderResponse {
  
  return $ApiResponseCopyWith<void, $Res>(_self.createOrderResponse, (value) {
    return _then(_self.copyWith(createOrderResponse: value));
  });
}/// Create a copy of HomeState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<List<Fragment$ActiveOrder>, $Res> get currentOrdersResponse {
  
  return $ApiResponseCopyWith<List<Fragment$ActiveOrder>, $Res>(_self.currentOrdersResponse, (value) {
    return _then(_self.copyWith(currentOrdersResponse: value));
  });
}/// Create a copy of HomeState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<void, $Res> get cancelOrderResponse {
  
  return $ApiResponseCopyWith<void, $Res>(_self.cancelOrderResponse, (value) {
    return _then(_self.copyWith(cancelOrderResponse: value));
  });
}/// Create a copy of HomeState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<void, $Res> get sendMessageState {
  
  return $ApiResponseCopyWith<void, $Res>(_self.sendMessageState, (value) {
    return _then(_self.copyWith(sendMessageState: value));
  });
}/// Create a copy of HomeState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<void, $Res> get reviewSubmissionState {
  
  return $ApiResponseCopyWith<void, $Res>(_self.reviewSubmissionState, (value) {
    return _then(_self.copyWith(reviewSubmissionState: value));
  });
}
}

/// @nodoc
mixin _$HomeEvent implements DiagnosticableTreeMixin {




@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent'))
    ;
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent()';
}


}

/// @nodoc
class $HomeEventCopyWith<$Res>  {
$HomeEventCopyWith(HomeEvent _, $Res Function(HomeEvent) __);
}


/// Adds pattern-matching-related methods to [HomeEvent].
extension HomeEventPatterns on HomeEvent {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>({TResult Function( HomeEvent$OnStarted value)?  onStarted,TResult Function( HomeEvent$OnMapReady value)?  onMapReady,TResult Function( HomeEvent$OnMapMoved value)?  onMapMoved,TResult Function( HomeEvent$OnAddStop value)?  onAddStop,TResult Function( HomeEvent$OnRemoveStop value)?  onRemoveStop,TResult Function( HomeEvent$InitializeWelcome value)?  initializeWelcome,TResult Function( HomeEvent$ChangeOrderSubmissionPage value)?  changeOrderSubmissionPage,TResult Function( HomeEvent$OnRideOptionSelected value)?  onRideOptionSelected,TResult Function( HomeEvent$OnDeliveryOptionSelected value)?  onDeliveryOptionSelected,TResult Function( HomeEvent$ChangeTrackOrderPage value)?  changeTrackOrderPage,TResult Function( HomeEvent$OnWaypointConfirmed value)?  onWaypointConfirmed,TResult Function( HomeEvent$ShowConfirmWaypoint value)?  showConfirmWaypoint,TResult Function( HomeEvent$OnChatMessageSent value)?  onChatMessageSent,TResult Function( HomeEvent$ShowPreview value)?  showPreview,TResult Function( HomeEvent$OnServiceCategorySelected value)?  onServiceCategorySelected,TResult Function( HomeEvent$OnServiceSelected value)?  onServiceSelected,TResult Function( HomeEvent$OnPaymentMethodSelected value)?  onPaymentMethodSelected,TResult Function( HomeEvent$SubmitOrder value)?  submitOrder,TResult Function( HomeEvent$OnRidePreferencesUpdated value)?  onRidePreferencesUpdated,TResult Function( HomeEvent$OnCouponCodeUpdated value)?  onCouponCodeChanged,TResult Function( HomeEvent$FocusOnWaypoint value)?  focusOnWaypoint,TResult Function( HomeEvent$CancelRide value)?  cancelRide,TResult Function( HomeEvent$OnReviewSubmitted value)?  onReviewSubmitted,TResult Function( HomeEvent$MarkEphemeralMessageAsSeen value)?  markEphemeralMessageAsSeen,required TResult orElse(),}){
final _that = this;
switch (_that) {
case HomeEvent$OnStarted() when onStarted != null:
return onStarted(_that);case HomeEvent$OnMapReady() when onMapReady != null:
return onMapReady(_that);case HomeEvent$OnMapMoved() when onMapMoved != null:
return onMapMoved(_that);case HomeEvent$OnAddStop() when onAddStop != null:
return onAddStop(_that);case HomeEvent$OnRemoveStop() when onRemoveStop != null:
return onRemoveStop(_that);case HomeEvent$InitializeWelcome() when initializeWelcome != null:
return initializeWelcome(_that);case HomeEvent$ChangeOrderSubmissionPage() when changeOrderSubmissionPage != null:
return changeOrderSubmissionPage(_that);case HomeEvent$OnRideOptionSelected() when onRideOptionSelected != null:
return onRideOptionSelected(_that);case HomeEvent$OnDeliveryOptionSelected() when onDeliveryOptionSelected != null:
return onDeliveryOptionSelected(_that);case HomeEvent$ChangeTrackOrderPage() when changeTrackOrderPage != null:
return changeTrackOrderPage(_that);case HomeEvent$OnWaypointConfirmed() when onWaypointConfirmed != null:
return onWaypointConfirmed(_that);case HomeEvent$ShowConfirmWaypoint() when showConfirmWaypoint != null:
return showConfirmWaypoint(_that);case HomeEvent$OnChatMessageSent() when onChatMessageSent != null:
return onChatMessageSent(_that);case HomeEvent$ShowPreview() when showPreview != null:
return showPreview(_that);case HomeEvent$OnServiceCategorySelected() when onServiceCategorySelected != null:
return onServiceCategorySelected(_that);case HomeEvent$OnServiceSelected() when onServiceSelected != null:
return onServiceSelected(_that);case HomeEvent$OnPaymentMethodSelected() when onPaymentMethodSelected != null:
return onPaymentMethodSelected(_that);case HomeEvent$SubmitOrder() when submitOrder != null:
return submitOrder(_that);case HomeEvent$OnRidePreferencesUpdated() when onRidePreferencesUpdated != null:
return onRidePreferencesUpdated(_that);case HomeEvent$OnCouponCodeUpdated() when onCouponCodeChanged != null:
return onCouponCodeChanged(_that);case HomeEvent$FocusOnWaypoint() when focusOnWaypoint != null:
return focusOnWaypoint(_that);case HomeEvent$CancelRide() when cancelRide != null:
return cancelRide(_that);case HomeEvent$OnReviewSubmitted() when onReviewSubmitted != null:
return onReviewSubmitted(_that);case HomeEvent$MarkEphemeralMessageAsSeen() when markEphemeralMessageAsSeen != null:
return markEphemeralMessageAsSeen(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>({required TResult Function( HomeEvent$OnStarted value)  onStarted,required TResult Function( HomeEvent$OnMapReady value)  onMapReady,required TResult Function( HomeEvent$OnMapMoved value)  onMapMoved,required TResult Function( HomeEvent$OnAddStop value)  onAddStop,required TResult Function( HomeEvent$OnRemoveStop value)  onRemoveStop,required TResult Function( HomeEvent$InitializeWelcome value)  initializeWelcome,required TResult Function( HomeEvent$ChangeOrderSubmissionPage value)  changeOrderSubmissionPage,required TResult Function( HomeEvent$OnRideOptionSelected value)  onRideOptionSelected,required TResult Function( HomeEvent$OnDeliveryOptionSelected value)  onDeliveryOptionSelected,required TResult Function( HomeEvent$ChangeTrackOrderPage value)  changeTrackOrderPage,required TResult Function( HomeEvent$OnWaypointConfirmed value)  onWaypointConfirmed,required TResult Function( HomeEvent$ShowConfirmWaypoint value)  showConfirmWaypoint,required TResult Function( HomeEvent$OnChatMessageSent value)  onChatMessageSent,required TResult Function( HomeEvent$ShowPreview value)  showPreview,required TResult Function( HomeEvent$OnServiceCategorySelected value)  onServiceCategorySelected,required TResult Function( HomeEvent$OnServiceSelected value)  onServiceSelected,required TResult Function( HomeEvent$OnPaymentMethodSelected value)  onPaymentMethodSelected,required TResult Function( HomeEvent$SubmitOrder value)  submitOrder,required TResult Function( HomeEvent$OnRidePreferencesUpdated value)  onRidePreferencesUpdated,required TResult Function( HomeEvent$OnCouponCodeUpdated value)  onCouponCodeChanged,required TResult Function( HomeEvent$FocusOnWaypoint value)  focusOnWaypoint,required TResult Function( HomeEvent$CancelRide value)  cancelRide,required TResult Function( HomeEvent$OnReviewSubmitted value)  onReviewSubmitted,required TResult Function( HomeEvent$MarkEphemeralMessageAsSeen value)  markEphemeralMessageAsSeen,}){
final _that = this;
switch (_that) {
case HomeEvent$OnStarted():
return onStarted(_that);case HomeEvent$OnMapReady():
return onMapReady(_that);case HomeEvent$OnMapMoved():
return onMapMoved(_that);case HomeEvent$OnAddStop():
return onAddStop(_that);case HomeEvent$OnRemoveStop():
return onRemoveStop(_that);case HomeEvent$InitializeWelcome():
return initializeWelcome(_that);case HomeEvent$ChangeOrderSubmissionPage():
return changeOrderSubmissionPage(_that);case HomeEvent$OnRideOptionSelected():
return onRideOptionSelected(_that);case HomeEvent$OnDeliveryOptionSelected():
return onDeliveryOptionSelected(_that);case HomeEvent$ChangeTrackOrderPage():
return changeTrackOrderPage(_that);case HomeEvent$OnWaypointConfirmed():
return onWaypointConfirmed(_that);case HomeEvent$ShowConfirmWaypoint():
return showConfirmWaypoint(_that);case HomeEvent$OnChatMessageSent():
return onChatMessageSent(_that);case HomeEvent$ShowPreview():
return showPreview(_that);case HomeEvent$OnServiceCategorySelected():
return onServiceCategorySelected(_that);case HomeEvent$OnServiceSelected():
return onServiceSelected(_that);case HomeEvent$OnPaymentMethodSelected():
return onPaymentMethodSelected(_that);case HomeEvent$SubmitOrder():
return submitOrder(_that);case HomeEvent$OnRidePreferencesUpdated():
return onRidePreferencesUpdated(_that);case HomeEvent$OnCouponCodeUpdated():
return onCouponCodeChanged(_that);case HomeEvent$FocusOnWaypoint():
return focusOnWaypoint(_that);case HomeEvent$CancelRide():
return cancelRide(_that);case HomeEvent$OnReviewSubmitted():
return onReviewSubmitted(_that);case HomeEvent$MarkEphemeralMessageAsSeen():
return markEphemeralMessageAsSeen(_that);}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>({TResult? Function( HomeEvent$OnStarted value)?  onStarted,TResult? Function( HomeEvent$OnMapReady value)?  onMapReady,TResult? Function( HomeEvent$OnMapMoved value)?  onMapMoved,TResult? Function( HomeEvent$OnAddStop value)?  onAddStop,TResult? Function( HomeEvent$OnRemoveStop value)?  onRemoveStop,TResult? Function( HomeEvent$InitializeWelcome value)?  initializeWelcome,TResult? Function( HomeEvent$ChangeOrderSubmissionPage value)?  changeOrderSubmissionPage,TResult? Function( HomeEvent$OnRideOptionSelected value)?  onRideOptionSelected,TResult? Function( HomeEvent$OnDeliveryOptionSelected value)?  onDeliveryOptionSelected,TResult? Function( HomeEvent$ChangeTrackOrderPage value)?  changeTrackOrderPage,TResult? Function( HomeEvent$OnWaypointConfirmed value)?  onWaypointConfirmed,TResult? Function( HomeEvent$ShowConfirmWaypoint value)?  showConfirmWaypoint,TResult? Function( HomeEvent$OnChatMessageSent value)?  onChatMessageSent,TResult? Function( HomeEvent$ShowPreview value)?  showPreview,TResult? Function( HomeEvent$OnServiceCategorySelected value)?  onServiceCategorySelected,TResult? Function( HomeEvent$OnServiceSelected value)?  onServiceSelected,TResult? Function( HomeEvent$OnPaymentMethodSelected value)?  onPaymentMethodSelected,TResult? Function( HomeEvent$SubmitOrder value)?  submitOrder,TResult? Function( HomeEvent$OnRidePreferencesUpdated value)?  onRidePreferencesUpdated,TResult? Function( HomeEvent$OnCouponCodeUpdated value)?  onCouponCodeChanged,TResult? Function( HomeEvent$FocusOnWaypoint value)?  focusOnWaypoint,TResult? Function( HomeEvent$CancelRide value)?  cancelRide,TResult? Function( HomeEvent$OnReviewSubmitted value)?  onReviewSubmitted,TResult? Function( HomeEvent$MarkEphemeralMessageAsSeen value)?  markEphemeralMessageAsSeen,}){
final _that = this;
switch (_that) {
case HomeEvent$OnStarted() when onStarted != null:
return onStarted(_that);case HomeEvent$OnMapReady() when onMapReady != null:
return onMapReady(_that);case HomeEvent$OnMapMoved() when onMapMoved != null:
return onMapMoved(_that);case HomeEvent$OnAddStop() when onAddStop != null:
return onAddStop(_that);case HomeEvent$OnRemoveStop() when onRemoveStop != null:
return onRemoveStop(_that);case HomeEvent$InitializeWelcome() when initializeWelcome != null:
return initializeWelcome(_that);case HomeEvent$ChangeOrderSubmissionPage() when changeOrderSubmissionPage != null:
return changeOrderSubmissionPage(_that);case HomeEvent$OnRideOptionSelected() when onRideOptionSelected != null:
return onRideOptionSelected(_that);case HomeEvent$OnDeliveryOptionSelected() when onDeliveryOptionSelected != null:
return onDeliveryOptionSelected(_that);case HomeEvent$ChangeTrackOrderPage() when changeTrackOrderPage != null:
return changeTrackOrderPage(_that);case HomeEvent$OnWaypointConfirmed() when onWaypointConfirmed != null:
return onWaypointConfirmed(_that);case HomeEvent$ShowConfirmWaypoint() when showConfirmWaypoint != null:
return showConfirmWaypoint(_that);case HomeEvent$OnChatMessageSent() when onChatMessageSent != null:
return onChatMessageSent(_that);case HomeEvent$ShowPreview() when showPreview != null:
return showPreview(_that);case HomeEvent$OnServiceCategorySelected() when onServiceCategorySelected != null:
return onServiceCategorySelected(_that);case HomeEvent$OnServiceSelected() when onServiceSelected != null:
return onServiceSelected(_that);case HomeEvent$OnPaymentMethodSelected() when onPaymentMethodSelected != null:
return onPaymentMethodSelected(_that);case HomeEvent$SubmitOrder() when submitOrder != null:
return submitOrder(_that);case HomeEvent$OnRidePreferencesUpdated() when onRidePreferencesUpdated != null:
return onRidePreferencesUpdated(_that);case HomeEvent$OnCouponCodeUpdated() when onCouponCodeChanged != null:
return onCouponCodeChanged(_that);case HomeEvent$FocusOnWaypoint() when focusOnWaypoint != null:
return focusOnWaypoint(_that);case HomeEvent$CancelRide() when cancelRide != null:
return cancelRide(_that);case HomeEvent$OnReviewSubmitted() when onReviewSubmitted != null:
return onReviewSubmitted(_that);case HomeEvent$MarkEphemeralMessageAsSeen() when markEphemeralMessageAsSeen != null:
return markEphemeralMessageAsSeen(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>({TResult Function( bool authenticated,  Place? currentLocationPlace)?  onStarted,TResult Function( MapViewController controller)?  onMapReady,TResult Function( ApiResponse<Place> selectedLocation)?  onMapMoved,TResult Function()?  onAddStop,TResult Function( int index)?  onRemoveStop,TResult Function( Place? pickupPoint)?  initializeWelcome,TResult Function( OrderSubmissionPage orderSubmissionPage)?  changeOrderSubmissionPage,TResult Function()?  onRideOptionSelected,TResult Function()?  onDeliveryOptionSelected,TResult Function( TrackOrderPage page)?  changeTrackOrderPage,TResult Function()?  onWaypointConfirmed,TResult Function( Place selectedLocation)?  showConfirmWaypoint,TResult Function( String message)?  onChatMessageSent,TResult Function( Place? destination)?  showPreview,TResult Function( Fragment$ServiceCategory serviceCategory)?  onServiceCategorySelected,TResult Function( Fragment$Service service,  bool value)?  onServiceSelected,TResult Function( PaymentMethodUnion paymentMethod)?  onPaymentMethodSelected,TResult Function( DateTime? selectedDateTime)?  submitOrder,TResult Function( bool isTwoWayTrip,  int? waitTime,  List<Fragment$RideOption> rideOptions)?  onRidePreferencesUpdated,TResult Function( String couponCode)?  onCouponCodeChanged,TResult Function( int index)?  focusOnWaypoint,TResult Function( String orderId,  String? cancelReasonId,  String? cancelReasonNote)?  cancelRide,TResult Function( String orderId,  int rating,  String? comment,  List<Fragment$ReviewParameter> parameters,  bool isFavorite)?  onReviewSubmitted,TResult Function( String ephemeralMessageId)?  markEphemeralMessageAsSeen,required TResult orElse(),}) {final _that = this;
switch (_that) {
case HomeEvent$OnStarted() when onStarted != null:
return onStarted(_that.authenticated,_that.currentLocationPlace);case HomeEvent$OnMapReady() when onMapReady != null:
return onMapReady(_that.controller);case HomeEvent$OnMapMoved() when onMapMoved != null:
return onMapMoved(_that.selectedLocation);case HomeEvent$OnAddStop() when onAddStop != null:
return onAddStop();case HomeEvent$OnRemoveStop() when onRemoveStop != null:
return onRemoveStop(_that.index);case HomeEvent$InitializeWelcome() when initializeWelcome != null:
return initializeWelcome(_that.pickupPoint);case HomeEvent$ChangeOrderSubmissionPage() when changeOrderSubmissionPage != null:
return changeOrderSubmissionPage(_that.orderSubmissionPage);case HomeEvent$OnRideOptionSelected() when onRideOptionSelected != null:
return onRideOptionSelected();case HomeEvent$OnDeliveryOptionSelected() when onDeliveryOptionSelected != null:
return onDeliveryOptionSelected();case HomeEvent$ChangeTrackOrderPage() when changeTrackOrderPage != null:
return changeTrackOrderPage(_that.page);case HomeEvent$OnWaypointConfirmed() when onWaypointConfirmed != null:
return onWaypointConfirmed();case HomeEvent$ShowConfirmWaypoint() when showConfirmWaypoint != null:
return showConfirmWaypoint(_that.selectedLocation);case HomeEvent$OnChatMessageSent() when onChatMessageSent != null:
return onChatMessageSent(_that.message);case HomeEvent$ShowPreview() when showPreview != null:
return showPreview(_that.destination);case HomeEvent$OnServiceCategorySelected() when onServiceCategorySelected != null:
return onServiceCategorySelected(_that.serviceCategory);case HomeEvent$OnServiceSelected() when onServiceSelected != null:
return onServiceSelected(_that.service,_that.value);case HomeEvent$OnPaymentMethodSelected() when onPaymentMethodSelected != null:
return onPaymentMethodSelected(_that.paymentMethod);case HomeEvent$SubmitOrder() when submitOrder != null:
return submitOrder(_that.selectedDateTime);case HomeEvent$OnRidePreferencesUpdated() when onRidePreferencesUpdated != null:
return onRidePreferencesUpdated(_that.isTwoWayTrip,_that.waitTime,_that.rideOptions);case HomeEvent$OnCouponCodeUpdated() when onCouponCodeChanged != null:
return onCouponCodeChanged(_that.couponCode);case HomeEvent$FocusOnWaypoint() when focusOnWaypoint != null:
return focusOnWaypoint(_that.index);case HomeEvent$CancelRide() when cancelRide != null:
return cancelRide(_that.orderId,_that.cancelReasonId,_that.cancelReasonNote);case HomeEvent$OnReviewSubmitted() when onReviewSubmitted != null:
return onReviewSubmitted(_that.orderId,_that.rating,_that.comment,_that.parameters,_that.isFavorite);case HomeEvent$MarkEphemeralMessageAsSeen() when markEphemeralMessageAsSeen != null:
return markEphemeralMessageAsSeen(_that.ephemeralMessageId);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>({required TResult Function( bool authenticated,  Place? currentLocationPlace)  onStarted,required TResult Function( MapViewController controller)  onMapReady,required TResult Function( ApiResponse<Place> selectedLocation)  onMapMoved,required TResult Function()  onAddStop,required TResult Function( int index)  onRemoveStop,required TResult Function( Place? pickupPoint)  initializeWelcome,required TResult Function( OrderSubmissionPage orderSubmissionPage)  changeOrderSubmissionPage,required TResult Function()  onRideOptionSelected,required TResult Function()  onDeliveryOptionSelected,required TResult Function( TrackOrderPage page)  changeTrackOrderPage,required TResult Function()  onWaypointConfirmed,required TResult Function( Place selectedLocation)  showConfirmWaypoint,required TResult Function( String message)  onChatMessageSent,required TResult Function( Place? destination)  showPreview,required TResult Function( Fragment$ServiceCategory serviceCategory)  onServiceCategorySelected,required TResult Function( Fragment$Service service,  bool value)  onServiceSelected,required TResult Function( PaymentMethodUnion paymentMethod)  onPaymentMethodSelected,required TResult Function( DateTime? selectedDateTime)  submitOrder,required TResult Function( bool isTwoWayTrip,  int? waitTime,  List<Fragment$RideOption> rideOptions)  onRidePreferencesUpdated,required TResult Function( String couponCode)  onCouponCodeChanged,required TResult Function( int index)  focusOnWaypoint,required TResult Function( String orderId,  String? cancelReasonId,  String? cancelReasonNote)  cancelRide,required TResult Function( String orderId,  int rating,  String? comment,  List<Fragment$ReviewParameter> parameters,  bool isFavorite)  onReviewSubmitted,required TResult Function( String ephemeralMessageId)  markEphemeralMessageAsSeen,}) {final _that = this;
switch (_that) {
case HomeEvent$OnStarted():
return onStarted(_that.authenticated,_that.currentLocationPlace);case HomeEvent$OnMapReady():
return onMapReady(_that.controller);case HomeEvent$OnMapMoved():
return onMapMoved(_that.selectedLocation);case HomeEvent$OnAddStop():
return onAddStop();case HomeEvent$OnRemoveStop():
return onRemoveStop(_that.index);case HomeEvent$InitializeWelcome():
return initializeWelcome(_that.pickupPoint);case HomeEvent$ChangeOrderSubmissionPage():
return changeOrderSubmissionPage(_that.orderSubmissionPage);case HomeEvent$OnRideOptionSelected():
return onRideOptionSelected();case HomeEvent$OnDeliveryOptionSelected():
return onDeliveryOptionSelected();case HomeEvent$ChangeTrackOrderPage():
return changeTrackOrderPage(_that.page);case HomeEvent$OnWaypointConfirmed():
return onWaypointConfirmed();case HomeEvent$ShowConfirmWaypoint():
return showConfirmWaypoint(_that.selectedLocation);case HomeEvent$OnChatMessageSent():
return onChatMessageSent(_that.message);case HomeEvent$ShowPreview():
return showPreview(_that.destination);case HomeEvent$OnServiceCategorySelected():
return onServiceCategorySelected(_that.serviceCategory);case HomeEvent$OnServiceSelected():
return onServiceSelected(_that.service,_that.value);case HomeEvent$OnPaymentMethodSelected():
return onPaymentMethodSelected(_that.paymentMethod);case HomeEvent$SubmitOrder():
return submitOrder(_that.selectedDateTime);case HomeEvent$OnRidePreferencesUpdated():
return onRidePreferencesUpdated(_that.isTwoWayTrip,_that.waitTime,_that.rideOptions);case HomeEvent$OnCouponCodeUpdated():
return onCouponCodeChanged(_that.couponCode);case HomeEvent$FocusOnWaypoint():
return focusOnWaypoint(_that.index);case HomeEvent$CancelRide():
return cancelRide(_that.orderId,_that.cancelReasonId,_that.cancelReasonNote);case HomeEvent$OnReviewSubmitted():
return onReviewSubmitted(_that.orderId,_that.rating,_that.comment,_that.parameters,_that.isFavorite);case HomeEvent$MarkEphemeralMessageAsSeen():
return markEphemeralMessageAsSeen(_that.ephemeralMessageId);}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>({TResult? Function( bool authenticated,  Place? currentLocationPlace)?  onStarted,TResult? Function( MapViewController controller)?  onMapReady,TResult? Function( ApiResponse<Place> selectedLocation)?  onMapMoved,TResult? Function()?  onAddStop,TResult? Function( int index)?  onRemoveStop,TResult? Function( Place? pickupPoint)?  initializeWelcome,TResult? Function( OrderSubmissionPage orderSubmissionPage)?  changeOrderSubmissionPage,TResult? Function()?  onRideOptionSelected,TResult? Function()?  onDeliveryOptionSelected,TResult? Function( TrackOrderPage page)?  changeTrackOrderPage,TResult? Function()?  onWaypointConfirmed,TResult? Function( Place selectedLocation)?  showConfirmWaypoint,TResult? Function( String message)?  onChatMessageSent,TResult? Function( Place? destination)?  showPreview,TResult? Function( Fragment$ServiceCategory serviceCategory)?  onServiceCategorySelected,TResult? Function( Fragment$Service service,  bool value)?  onServiceSelected,TResult? Function( PaymentMethodUnion paymentMethod)?  onPaymentMethodSelected,TResult? Function( DateTime? selectedDateTime)?  submitOrder,TResult? Function( bool isTwoWayTrip,  int? waitTime,  List<Fragment$RideOption> rideOptions)?  onRidePreferencesUpdated,TResult? Function( String couponCode)?  onCouponCodeChanged,TResult? Function( int index)?  focusOnWaypoint,TResult? Function( String orderId,  String? cancelReasonId,  String? cancelReasonNote)?  cancelRide,TResult? Function( String orderId,  int rating,  String? comment,  List<Fragment$ReviewParameter> parameters,  bool isFavorite)?  onReviewSubmitted,TResult? Function( String ephemeralMessageId)?  markEphemeralMessageAsSeen,}) {final _that = this;
switch (_that) {
case HomeEvent$OnStarted() when onStarted != null:
return onStarted(_that.authenticated,_that.currentLocationPlace);case HomeEvent$OnMapReady() when onMapReady != null:
return onMapReady(_that.controller);case HomeEvent$OnMapMoved() when onMapMoved != null:
return onMapMoved(_that.selectedLocation);case HomeEvent$OnAddStop() when onAddStop != null:
return onAddStop();case HomeEvent$OnRemoveStop() when onRemoveStop != null:
return onRemoveStop(_that.index);case HomeEvent$InitializeWelcome() when initializeWelcome != null:
return initializeWelcome(_that.pickupPoint);case HomeEvent$ChangeOrderSubmissionPage() when changeOrderSubmissionPage != null:
return changeOrderSubmissionPage(_that.orderSubmissionPage);case HomeEvent$OnRideOptionSelected() when onRideOptionSelected != null:
return onRideOptionSelected();case HomeEvent$OnDeliveryOptionSelected() when onDeliveryOptionSelected != null:
return onDeliveryOptionSelected();case HomeEvent$ChangeTrackOrderPage() when changeTrackOrderPage != null:
return changeTrackOrderPage(_that.page);case HomeEvent$OnWaypointConfirmed() when onWaypointConfirmed != null:
return onWaypointConfirmed();case HomeEvent$ShowConfirmWaypoint() when showConfirmWaypoint != null:
return showConfirmWaypoint(_that.selectedLocation);case HomeEvent$OnChatMessageSent() when onChatMessageSent != null:
return onChatMessageSent(_that.message);case HomeEvent$ShowPreview() when showPreview != null:
return showPreview(_that.destination);case HomeEvent$OnServiceCategorySelected() when onServiceCategorySelected != null:
return onServiceCategorySelected(_that.serviceCategory);case HomeEvent$OnServiceSelected() when onServiceSelected != null:
return onServiceSelected(_that.service,_that.value);case HomeEvent$OnPaymentMethodSelected() when onPaymentMethodSelected != null:
return onPaymentMethodSelected(_that.paymentMethod);case HomeEvent$SubmitOrder() when submitOrder != null:
return submitOrder(_that.selectedDateTime);case HomeEvent$OnRidePreferencesUpdated() when onRidePreferencesUpdated != null:
return onRidePreferencesUpdated(_that.isTwoWayTrip,_that.waitTime,_that.rideOptions);case HomeEvent$OnCouponCodeUpdated() when onCouponCodeChanged != null:
return onCouponCodeChanged(_that.couponCode);case HomeEvent$FocusOnWaypoint() when focusOnWaypoint != null:
return focusOnWaypoint(_that.index);case HomeEvent$CancelRide() when cancelRide != null:
return cancelRide(_that.orderId,_that.cancelReasonId,_that.cancelReasonNote);case HomeEvent$OnReviewSubmitted() when onReviewSubmitted != null:
return onReviewSubmitted(_that.orderId,_that.rating,_that.comment,_that.parameters,_that.isFavorite);case HomeEvent$MarkEphemeralMessageAsSeen() when markEphemeralMessageAsSeen != null:
return markEphemeralMessageAsSeen(_that.ephemeralMessageId);case _:
  return null;

}
}

}

/// @nodoc


class HomeEvent$OnStarted with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$OnStarted({required this.authenticated, required this.currentLocationPlace});
  

 final  bool authenticated;
 final  Place? currentLocationPlace;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeEvent$OnStartedCopyWith<HomeEvent$OnStarted> get copyWith => _$HomeEvent$OnStartedCopyWithImpl<HomeEvent$OnStarted>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.onStarted'))
    ..add(DiagnosticsProperty('authenticated', authenticated))..add(DiagnosticsProperty('currentLocationPlace', currentLocationPlace));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$OnStarted&&(identical(other.authenticated, authenticated) || other.authenticated == authenticated)&&(identical(other.currentLocationPlace, currentLocationPlace) || other.currentLocationPlace == currentLocationPlace));
}


@override
int get hashCode => Object.hash(runtimeType,authenticated,currentLocationPlace);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.onStarted(authenticated: $authenticated, currentLocationPlace: $currentLocationPlace)';
}


}

/// @nodoc
abstract mixin class $HomeEvent$OnStartedCopyWith<$Res> implements $HomeEventCopyWith<$Res> {
  factory $HomeEvent$OnStartedCopyWith(HomeEvent$OnStarted value, $Res Function(HomeEvent$OnStarted) _then) = _$HomeEvent$OnStartedCopyWithImpl;
@useResult
$Res call({
 bool authenticated, Place? currentLocationPlace
});




}
/// @nodoc
class _$HomeEvent$OnStartedCopyWithImpl<$Res>
    implements $HomeEvent$OnStartedCopyWith<$Res> {
  _$HomeEvent$OnStartedCopyWithImpl(this._self, this._then);

  final HomeEvent$OnStarted _self;
  final $Res Function(HomeEvent$OnStarted) _then;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? authenticated = null,Object? currentLocationPlace = freezed,}) {
  return _then(HomeEvent$OnStarted(
authenticated: null == authenticated ? _self.authenticated : authenticated // ignore: cast_nullable_to_non_nullable
as bool,currentLocationPlace: freezed == currentLocationPlace ? _self.currentLocationPlace : currentLocationPlace // ignore: cast_nullable_to_non_nullable
as Place?,
  ));
}


}

/// @nodoc


class HomeEvent$OnMapReady with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$OnMapReady({required this.controller});
  

 final  MapViewController controller;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeEvent$OnMapReadyCopyWith<HomeEvent$OnMapReady> get copyWith => _$HomeEvent$OnMapReadyCopyWithImpl<HomeEvent$OnMapReady>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.onMapReady'))
    ..add(DiagnosticsProperty('controller', controller));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$OnMapReady&&(identical(other.controller, controller) || other.controller == controller));
}


@override
int get hashCode => Object.hash(runtimeType,controller);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.onMapReady(controller: $controller)';
}


}

/// @nodoc
abstract mixin class $HomeEvent$OnMapReadyCopyWith<$Res> implements $HomeEventCopyWith<$Res> {
  factory $HomeEvent$OnMapReadyCopyWith(HomeEvent$OnMapReady value, $Res Function(HomeEvent$OnMapReady) _then) = _$HomeEvent$OnMapReadyCopyWithImpl;
@useResult
$Res call({
 MapViewController controller
});




}
/// @nodoc
class _$HomeEvent$OnMapReadyCopyWithImpl<$Res>
    implements $HomeEvent$OnMapReadyCopyWith<$Res> {
  _$HomeEvent$OnMapReadyCopyWithImpl(this._self, this._then);

  final HomeEvent$OnMapReady _self;
  final $Res Function(HomeEvent$OnMapReady) _then;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? controller = null,}) {
  return _then(HomeEvent$OnMapReady(
controller: null == controller ? _self.controller : controller // ignore: cast_nullable_to_non_nullable
as MapViewController,
  ));
}


}

/// @nodoc


class HomeEvent$OnMapMoved with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$OnMapMoved({required this.selectedLocation});
  

 final  ApiResponse<Place> selectedLocation;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeEvent$OnMapMovedCopyWith<HomeEvent$OnMapMoved> get copyWith => _$HomeEvent$OnMapMovedCopyWithImpl<HomeEvent$OnMapMoved>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.onMapMoved'))
    ..add(DiagnosticsProperty('selectedLocation', selectedLocation));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$OnMapMoved&&(identical(other.selectedLocation, selectedLocation) || other.selectedLocation == selectedLocation));
}


@override
int get hashCode => Object.hash(runtimeType,selectedLocation);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.onMapMoved(selectedLocation: $selectedLocation)';
}


}

/// @nodoc
abstract mixin class $HomeEvent$OnMapMovedCopyWith<$Res> implements $HomeEventCopyWith<$Res> {
  factory $HomeEvent$OnMapMovedCopyWith(HomeEvent$OnMapMoved value, $Res Function(HomeEvent$OnMapMoved) _then) = _$HomeEvent$OnMapMovedCopyWithImpl;
@useResult
$Res call({
 ApiResponse<Place> selectedLocation
});


$ApiResponseCopyWith<Place, $Res> get selectedLocation;

}
/// @nodoc
class _$HomeEvent$OnMapMovedCopyWithImpl<$Res>
    implements $HomeEvent$OnMapMovedCopyWith<$Res> {
  _$HomeEvent$OnMapMovedCopyWithImpl(this._self, this._then);

  final HomeEvent$OnMapMoved _self;
  final $Res Function(HomeEvent$OnMapMoved) _then;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? selectedLocation = null,}) {
  return _then(HomeEvent$OnMapMoved(
selectedLocation: null == selectedLocation ? _self.selectedLocation : selectedLocation // ignore: cast_nullable_to_non_nullable
as ApiResponse<Place>,
  ));
}

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<Place, $Res> get selectedLocation {
  
  return $ApiResponseCopyWith<Place, $Res>(_self.selectedLocation, (value) {
    return _then(_self.copyWith(selectedLocation: value));
  });
}
}

/// @nodoc


class HomeEvent$OnAddStop with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$OnAddStop();
  





@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.onAddStop'))
    ;
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$OnAddStop);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.onAddStop()';
}


}




/// @nodoc


class HomeEvent$OnRemoveStop with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$OnRemoveStop({required this.index});
  

 final  int index;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeEvent$OnRemoveStopCopyWith<HomeEvent$OnRemoveStop> get copyWith => _$HomeEvent$OnRemoveStopCopyWithImpl<HomeEvent$OnRemoveStop>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.onRemoveStop'))
    ..add(DiagnosticsProperty('index', index));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$OnRemoveStop&&(identical(other.index, index) || other.index == index));
}


@override
int get hashCode => Object.hash(runtimeType,index);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.onRemoveStop(index: $index)';
}


}

/// @nodoc
abstract mixin class $HomeEvent$OnRemoveStopCopyWith<$Res> implements $HomeEventCopyWith<$Res> {
  factory $HomeEvent$OnRemoveStopCopyWith(HomeEvent$OnRemoveStop value, $Res Function(HomeEvent$OnRemoveStop) _then) = _$HomeEvent$OnRemoveStopCopyWithImpl;
@useResult
$Res call({
 int index
});




}
/// @nodoc
class _$HomeEvent$OnRemoveStopCopyWithImpl<$Res>
    implements $HomeEvent$OnRemoveStopCopyWith<$Res> {
  _$HomeEvent$OnRemoveStopCopyWithImpl(this._self, this._then);

  final HomeEvent$OnRemoveStop _self;
  final $Res Function(HomeEvent$OnRemoveStop) _then;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? index = null,}) {
  return _then(HomeEvent$OnRemoveStop(
index: null == index ? _self.index : index // ignore: cast_nullable_to_non_nullable
as int,
  ));
}


}

/// @nodoc


class HomeEvent$InitializeWelcome with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$InitializeWelcome({required this.pickupPoint});
  

 final  Place? pickupPoint;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeEvent$InitializeWelcomeCopyWith<HomeEvent$InitializeWelcome> get copyWith => _$HomeEvent$InitializeWelcomeCopyWithImpl<HomeEvent$InitializeWelcome>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.initializeWelcome'))
    ..add(DiagnosticsProperty('pickupPoint', pickupPoint));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$InitializeWelcome&&(identical(other.pickupPoint, pickupPoint) || other.pickupPoint == pickupPoint));
}


@override
int get hashCode => Object.hash(runtimeType,pickupPoint);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.initializeWelcome(pickupPoint: $pickupPoint)';
}


}

/// @nodoc
abstract mixin class $HomeEvent$InitializeWelcomeCopyWith<$Res> implements $HomeEventCopyWith<$Res> {
  factory $HomeEvent$InitializeWelcomeCopyWith(HomeEvent$InitializeWelcome value, $Res Function(HomeEvent$InitializeWelcome) _then) = _$HomeEvent$InitializeWelcomeCopyWithImpl;
@useResult
$Res call({
 Place? pickupPoint
});




}
/// @nodoc
class _$HomeEvent$InitializeWelcomeCopyWithImpl<$Res>
    implements $HomeEvent$InitializeWelcomeCopyWith<$Res> {
  _$HomeEvent$InitializeWelcomeCopyWithImpl(this._self, this._then);

  final HomeEvent$InitializeWelcome _self;
  final $Res Function(HomeEvent$InitializeWelcome) _then;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? pickupPoint = freezed,}) {
  return _then(HomeEvent$InitializeWelcome(
pickupPoint: freezed == pickupPoint ? _self.pickupPoint : pickupPoint // ignore: cast_nullable_to_non_nullable
as Place?,
  ));
}


}

/// @nodoc


class HomeEvent$ChangeOrderSubmissionPage with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$ChangeOrderSubmissionPage({required this.orderSubmissionPage});
  

 final  OrderSubmissionPage orderSubmissionPage;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeEvent$ChangeOrderSubmissionPageCopyWith<HomeEvent$ChangeOrderSubmissionPage> get copyWith => _$HomeEvent$ChangeOrderSubmissionPageCopyWithImpl<HomeEvent$ChangeOrderSubmissionPage>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.changeOrderSubmissionPage'))
    ..add(DiagnosticsProperty('orderSubmissionPage', orderSubmissionPage));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$ChangeOrderSubmissionPage&&(identical(other.orderSubmissionPage, orderSubmissionPage) || other.orderSubmissionPage == orderSubmissionPage));
}


@override
int get hashCode => Object.hash(runtimeType,orderSubmissionPage);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.changeOrderSubmissionPage(orderSubmissionPage: $orderSubmissionPage)';
}


}

/// @nodoc
abstract mixin class $HomeEvent$ChangeOrderSubmissionPageCopyWith<$Res> implements $HomeEventCopyWith<$Res> {
  factory $HomeEvent$ChangeOrderSubmissionPageCopyWith(HomeEvent$ChangeOrderSubmissionPage value, $Res Function(HomeEvent$ChangeOrderSubmissionPage) _then) = _$HomeEvent$ChangeOrderSubmissionPageCopyWithImpl;
@useResult
$Res call({
 OrderSubmissionPage orderSubmissionPage
});




}
/// @nodoc
class _$HomeEvent$ChangeOrderSubmissionPageCopyWithImpl<$Res>
    implements $HomeEvent$ChangeOrderSubmissionPageCopyWith<$Res> {
  _$HomeEvent$ChangeOrderSubmissionPageCopyWithImpl(this._self, this._then);

  final HomeEvent$ChangeOrderSubmissionPage _self;
  final $Res Function(HomeEvent$ChangeOrderSubmissionPage) _then;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? orderSubmissionPage = null,}) {
  return _then(HomeEvent$ChangeOrderSubmissionPage(
orderSubmissionPage: null == orderSubmissionPage ? _self.orderSubmissionPage : orderSubmissionPage // ignore: cast_nullable_to_non_nullable
as OrderSubmissionPage,
  ));
}


}

/// @nodoc


class HomeEvent$OnRideOptionSelected with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$OnRideOptionSelected();
  





@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.onRideOptionSelected'))
    ;
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$OnRideOptionSelected);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.onRideOptionSelected()';
}


}




/// @nodoc


class HomeEvent$OnDeliveryOptionSelected with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$OnDeliveryOptionSelected();
  





@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.onDeliveryOptionSelected'))
    ;
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$OnDeliveryOptionSelected);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.onDeliveryOptionSelected()';
}


}




/// @nodoc


class HomeEvent$ChangeTrackOrderPage with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$ChangeTrackOrderPage({required this.page});
  

 final  TrackOrderPage page;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeEvent$ChangeTrackOrderPageCopyWith<HomeEvent$ChangeTrackOrderPage> get copyWith => _$HomeEvent$ChangeTrackOrderPageCopyWithImpl<HomeEvent$ChangeTrackOrderPage>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.changeTrackOrderPage'))
    ..add(DiagnosticsProperty('page', page));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$ChangeTrackOrderPage&&(identical(other.page, page) || other.page == page));
}


@override
int get hashCode => Object.hash(runtimeType,page);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.changeTrackOrderPage(page: $page)';
}


}

/// @nodoc
abstract mixin class $HomeEvent$ChangeTrackOrderPageCopyWith<$Res> implements $HomeEventCopyWith<$Res> {
  factory $HomeEvent$ChangeTrackOrderPageCopyWith(HomeEvent$ChangeTrackOrderPage value, $Res Function(HomeEvent$ChangeTrackOrderPage) _then) = _$HomeEvent$ChangeTrackOrderPageCopyWithImpl;
@useResult
$Res call({
 TrackOrderPage page
});




}
/// @nodoc
class _$HomeEvent$ChangeTrackOrderPageCopyWithImpl<$Res>
    implements $HomeEvent$ChangeTrackOrderPageCopyWith<$Res> {
  _$HomeEvent$ChangeTrackOrderPageCopyWithImpl(this._self, this._then);

  final HomeEvent$ChangeTrackOrderPage _self;
  final $Res Function(HomeEvent$ChangeTrackOrderPage) _then;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? page = null,}) {
  return _then(HomeEvent$ChangeTrackOrderPage(
page: null == page ? _self.page : page // ignore: cast_nullable_to_non_nullable
as TrackOrderPage,
  ));
}


}

/// @nodoc


class HomeEvent$OnWaypointConfirmed with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$OnWaypointConfirmed();
  





@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.onWaypointConfirmed'))
    ;
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$OnWaypointConfirmed);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.onWaypointConfirmed()';
}


}




/// @nodoc


class HomeEvent$ShowConfirmWaypoint with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$ShowConfirmWaypoint({required this.selectedLocation});
  

 final  Place selectedLocation;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeEvent$ShowConfirmWaypointCopyWith<HomeEvent$ShowConfirmWaypoint> get copyWith => _$HomeEvent$ShowConfirmWaypointCopyWithImpl<HomeEvent$ShowConfirmWaypoint>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.showConfirmWaypoint'))
    ..add(DiagnosticsProperty('selectedLocation', selectedLocation));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$ShowConfirmWaypoint&&(identical(other.selectedLocation, selectedLocation) || other.selectedLocation == selectedLocation));
}


@override
int get hashCode => Object.hash(runtimeType,selectedLocation);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.showConfirmWaypoint(selectedLocation: $selectedLocation)';
}


}

/// @nodoc
abstract mixin class $HomeEvent$ShowConfirmWaypointCopyWith<$Res> implements $HomeEventCopyWith<$Res> {
  factory $HomeEvent$ShowConfirmWaypointCopyWith(HomeEvent$ShowConfirmWaypoint value, $Res Function(HomeEvent$ShowConfirmWaypoint) _then) = _$HomeEvent$ShowConfirmWaypointCopyWithImpl;
@useResult
$Res call({
 Place selectedLocation
});




}
/// @nodoc
class _$HomeEvent$ShowConfirmWaypointCopyWithImpl<$Res>
    implements $HomeEvent$ShowConfirmWaypointCopyWith<$Res> {
  _$HomeEvent$ShowConfirmWaypointCopyWithImpl(this._self, this._then);

  final HomeEvent$ShowConfirmWaypoint _self;
  final $Res Function(HomeEvent$ShowConfirmWaypoint) _then;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? selectedLocation = null,}) {
  return _then(HomeEvent$ShowConfirmWaypoint(
selectedLocation: null == selectedLocation ? _self.selectedLocation : selectedLocation // ignore: cast_nullable_to_non_nullable
as Place,
  ));
}


}

/// @nodoc


class HomeEvent$OnChatMessageSent with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$OnChatMessageSent({required this.message});
  

 final  String message;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeEvent$OnChatMessageSentCopyWith<HomeEvent$OnChatMessageSent> get copyWith => _$HomeEvent$OnChatMessageSentCopyWithImpl<HomeEvent$OnChatMessageSent>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.onChatMessageSent'))
    ..add(DiagnosticsProperty('message', message));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$OnChatMessageSent&&(identical(other.message, message) || other.message == message));
}


@override
int get hashCode => Object.hash(runtimeType,message);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.onChatMessageSent(message: $message)';
}


}

/// @nodoc
abstract mixin class $HomeEvent$OnChatMessageSentCopyWith<$Res> implements $HomeEventCopyWith<$Res> {
  factory $HomeEvent$OnChatMessageSentCopyWith(HomeEvent$OnChatMessageSent value, $Res Function(HomeEvent$OnChatMessageSent) _then) = _$HomeEvent$OnChatMessageSentCopyWithImpl;
@useResult
$Res call({
 String message
});




}
/// @nodoc
class _$HomeEvent$OnChatMessageSentCopyWithImpl<$Res>
    implements $HomeEvent$OnChatMessageSentCopyWith<$Res> {
  _$HomeEvent$OnChatMessageSentCopyWithImpl(this._self, this._then);

  final HomeEvent$OnChatMessageSent _self;
  final $Res Function(HomeEvent$OnChatMessageSent) _then;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? message = null,}) {
  return _then(HomeEvent$OnChatMessageSent(
message: null == message ? _self.message : message // ignore: cast_nullable_to_non_nullable
as String,
  ));
}


}

/// @nodoc


class HomeEvent$ShowPreview with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$ShowPreview({this.destination});
  

 final  Place? destination;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeEvent$ShowPreviewCopyWith<HomeEvent$ShowPreview> get copyWith => _$HomeEvent$ShowPreviewCopyWithImpl<HomeEvent$ShowPreview>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.showPreview'))
    ..add(DiagnosticsProperty('destination', destination));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$ShowPreview&&(identical(other.destination, destination) || other.destination == destination));
}


@override
int get hashCode => Object.hash(runtimeType,destination);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.showPreview(destination: $destination)';
}


}

/// @nodoc
abstract mixin class $HomeEvent$ShowPreviewCopyWith<$Res> implements $HomeEventCopyWith<$Res> {
  factory $HomeEvent$ShowPreviewCopyWith(HomeEvent$ShowPreview value, $Res Function(HomeEvent$ShowPreview) _then) = _$HomeEvent$ShowPreviewCopyWithImpl;
@useResult
$Res call({
 Place? destination
});




}
/// @nodoc
class _$HomeEvent$ShowPreviewCopyWithImpl<$Res>
    implements $HomeEvent$ShowPreviewCopyWith<$Res> {
  _$HomeEvent$ShowPreviewCopyWithImpl(this._self, this._then);

  final HomeEvent$ShowPreview _self;
  final $Res Function(HomeEvent$ShowPreview) _then;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? destination = freezed,}) {
  return _then(HomeEvent$ShowPreview(
destination: freezed == destination ? _self.destination : destination // ignore: cast_nullable_to_non_nullable
as Place?,
  ));
}


}

/// @nodoc


class HomeEvent$OnServiceCategorySelected with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$OnServiceCategorySelected({required this.serviceCategory});
  

 final  Fragment$ServiceCategory serviceCategory;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeEvent$OnServiceCategorySelectedCopyWith<HomeEvent$OnServiceCategorySelected> get copyWith => _$HomeEvent$OnServiceCategorySelectedCopyWithImpl<HomeEvent$OnServiceCategorySelected>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.onServiceCategorySelected'))
    ..add(DiagnosticsProperty('serviceCategory', serviceCategory));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$OnServiceCategorySelected&&(identical(other.serviceCategory, serviceCategory) || other.serviceCategory == serviceCategory));
}


@override
int get hashCode => Object.hash(runtimeType,serviceCategory);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.onServiceCategorySelected(serviceCategory: $serviceCategory)';
}


}

/// @nodoc
abstract mixin class $HomeEvent$OnServiceCategorySelectedCopyWith<$Res> implements $HomeEventCopyWith<$Res> {
  factory $HomeEvent$OnServiceCategorySelectedCopyWith(HomeEvent$OnServiceCategorySelected value, $Res Function(HomeEvent$OnServiceCategorySelected) _then) = _$HomeEvent$OnServiceCategorySelectedCopyWithImpl;
@useResult
$Res call({
 Fragment$ServiceCategory serviceCategory
});




}
/// @nodoc
class _$HomeEvent$OnServiceCategorySelectedCopyWithImpl<$Res>
    implements $HomeEvent$OnServiceCategorySelectedCopyWith<$Res> {
  _$HomeEvent$OnServiceCategorySelectedCopyWithImpl(this._self, this._then);

  final HomeEvent$OnServiceCategorySelected _self;
  final $Res Function(HomeEvent$OnServiceCategorySelected) _then;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? serviceCategory = null,}) {
  return _then(HomeEvent$OnServiceCategorySelected(
serviceCategory: null == serviceCategory ? _self.serviceCategory : serviceCategory // ignore: cast_nullable_to_non_nullable
as Fragment$ServiceCategory,
  ));
}


}

/// @nodoc


class HomeEvent$OnServiceSelected with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$OnServiceSelected({required this.service, required this.value});
  

 final  Fragment$Service service;
 final  bool value;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeEvent$OnServiceSelectedCopyWith<HomeEvent$OnServiceSelected> get copyWith => _$HomeEvent$OnServiceSelectedCopyWithImpl<HomeEvent$OnServiceSelected>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.onServiceSelected'))
    ..add(DiagnosticsProperty('service', service))..add(DiagnosticsProperty('value', value));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$OnServiceSelected&&(identical(other.service, service) || other.service == service)&&(identical(other.value, value) || other.value == value));
}


@override
int get hashCode => Object.hash(runtimeType,service,value);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.onServiceSelected(service: $service, value: $value)';
}


}

/// @nodoc
abstract mixin class $HomeEvent$OnServiceSelectedCopyWith<$Res> implements $HomeEventCopyWith<$Res> {
  factory $HomeEvent$OnServiceSelectedCopyWith(HomeEvent$OnServiceSelected value, $Res Function(HomeEvent$OnServiceSelected) _then) = _$HomeEvent$OnServiceSelectedCopyWithImpl;
@useResult
$Res call({
 Fragment$Service service, bool value
});




}
/// @nodoc
class _$HomeEvent$OnServiceSelectedCopyWithImpl<$Res>
    implements $HomeEvent$OnServiceSelectedCopyWith<$Res> {
  _$HomeEvent$OnServiceSelectedCopyWithImpl(this._self, this._then);

  final HomeEvent$OnServiceSelected _self;
  final $Res Function(HomeEvent$OnServiceSelected) _then;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? service = null,Object? value = null,}) {
  return _then(HomeEvent$OnServiceSelected(
service: null == service ? _self.service : service // ignore: cast_nullable_to_non_nullable
as Fragment$Service,value: null == value ? _self.value : value // ignore: cast_nullable_to_non_nullable
as bool,
  ));
}


}

/// @nodoc


class HomeEvent$OnPaymentMethodSelected with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$OnPaymentMethodSelected({required this.paymentMethod});
  

 final  PaymentMethodUnion paymentMethod;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeEvent$OnPaymentMethodSelectedCopyWith<HomeEvent$OnPaymentMethodSelected> get copyWith => _$HomeEvent$OnPaymentMethodSelectedCopyWithImpl<HomeEvent$OnPaymentMethodSelected>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.onPaymentMethodSelected'))
    ..add(DiagnosticsProperty('paymentMethod', paymentMethod));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$OnPaymentMethodSelected&&(identical(other.paymentMethod, paymentMethod) || other.paymentMethod == paymentMethod));
}


@override
int get hashCode => Object.hash(runtimeType,paymentMethod);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.onPaymentMethodSelected(paymentMethod: $paymentMethod)';
}


}

/// @nodoc
abstract mixin class $HomeEvent$OnPaymentMethodSelectedCopyWith<$Res> implements $HomeEventCopyWith<$Res> {
  factory $HomeEvent$OnPaymentMethodSelectedCopyWith(HomeEvent$OnPaymentMethodSelected value, $Res Function(HomeEvent$OnPaymentMethodSelected) _then) = _$HomeEvent$OnPaymentMethodSelectedCopyWithImpl;
@useResult
$Res call({
 PaymentMethodUnion paymentMethod
});




}
/// @nodoc
class _$HomeEvent$OnPaymentMethodSelectedCopyWithImpl<$Res>
    implements $HomeEvent$OnPaymentMethodSelectedCopyWith<$Res> {
  _$HomeEvent$OnPaymentMethodSelectedCopyWithImpl(this._self, this._then);

  final HomeEvent$OnPaymentMethodSelected _self;
  final $Res Function(HomeEvent$OnPaymentMethodSelected) _then;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? paymentMethod = null,}) {
  return _then(HomeEvent$OnPaymentMethodSelected(
paymentMethod: null == paymentMethod ? _self.paymentMethod : paymentMethod // ignore: cast_nullable_to_non_nullable
as PaymentMethodUnion,
  ));
}


}

/// @nodoc


class HomeEvent$SubmitOrder with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$SubmitOrder({required this.selectedDateTime});
  

 final  DateTime? selectedDateTime;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeEvent$SubmitOrderCopyWith<HomeEvent$SubmitOrder> get copyWith => _$HomeEvent$SubmitOrderCopyWithImpl<HomeEvent$SubmitOrder>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.submitOrder'))
    ..add(DiagnosticsProperty('selectedDateTime', selectedDateTime));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$SubmitOrder&&(identical(other.selectedDateTime, selectedDateTime) || other.selectedDateTime == selectedDateTime));
}


@override
int get hashCode => Object.hash(runtimeType,selectedDateTime);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.submitOrder(selectedDateTime: $selectedDateTime)';
}


}

/// @nodoc
abstract mixin class $HomeEvent$SubmitOrderCopyWith<$Res> implements $HomeEventCopyWith<$Res> {
  factory $HomeEvent$SubmitOrderCopyWith(HomeEvent$SubmitOrder value, $Res Function(HomeEvent$SubmitOrder) _then) = _$HomeEvent$SubmitOrderCopyWithImpl;
@useResult
$Res call({
 DateTime? selectedDateTime
});




}
/// @nodoc
class _$HomeEvent$SubmitOrderCopyWithImpl<$Res>
    implements $HomeEvent$SubmitOrderCopyWith<$Res> {
  _$HomeEvent$SubmitOrderCopyWithImpl(this._self, this._then);

  final HomeEvent$SubmitOrder _self;
  final $Res Function(HomeEvent$SubmitOrder) _then;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? selectedDateTime = freezed,}) {
  return _then(HomeEvent$SubmitOrder(
selectedDateTime: freezed == selectedDateTime ? _self.selectedDateTime : selectedDateTime // ignore: cast_nullable_to_non_nullable
as DateTime?,
  ));
}


}

/// @nodoc


class HomeEvent$OnRidePreferencesUpdated with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$OnRidePreferencesUpdated({required this.isTwoWayTrip, required this.waitTime, required final  List<Fragment$RideOption> rideOptions}): _rideOptions = rideOptions;
  

 final  bool isTwoWayTrip;
 final  int? waitTime;
 final  List<Fragment$RideOption> _rideOptions;
 List<Fragment$RideOption> get rideOptions {
  if (_rideOptions is EqualUnmodifiableListView) return _rideOptions;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_rideOptions);
}


/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeEvent$OnRidePreferencesUpdatedCopyWith<HomeEvent$OnRidePreferencesUpdated> get copyWith => _$HomeEvent$OnRidePreferencesUpdatedCopyWithImpl<HomeEvent$OnRidePreferencesUpdated>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.onRidePreferencesUpdated'))
    ..add(DiagnosticsProperty('isTwoWayTrip', isTwoWayTrip))..add(DiagnosticsProperty('waitTime', waitTime))..add(DiagnosticsProperty('rideOptions', rideOptions));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$OnRidePreferencesUpdated&&(identical(other.isTwoWayTrip, isTwoWayTrip) || other.isTwoWayTrip == isTwoWayTrip)&&(identical(other.waitTime, waitTime) || other.waitTime == waitTime)&&const DeepCollectionEquality().equals(other._rideOptions, _rideOptions));
}


@override
int get hashCode => Object.hash(runtimeType,isTwoWayTrip,waitTime,const DeepCollectionEquality().hash(_rideOptions));

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.onRidePreferencesUpdated(isTwoWayTrip: $isTwoWayTrip, waitTime: $waitTime, rideOptions: $rideOptions)';
}


}

/// @nodoc
abstract mixin class $HomeEvent$OnRidePreferencesUpdatedCopyWith<$Res> implements $HomeEventCopyWith<$Res> {
  factory $HomeEvent$OnRidePreferencesUpdatedCopyWith(HomeEvent$OnRidePreferencesUpdated value, $Res Function(HomeEvent$OnRidePreferencesUpdated) _then) = _$HomeEvent$OnRidePreferencesUpdatedCopyWithImpl;
@useResult
$Res call({
 bool isTwoWayTrip, int? waitTime, List<Fragment$RideOption> rideOptions
});




}
/// @nodoc
class _$HomeEvent$OnRidePreferencesUpdatedCopyWithImpl<$Res>
    implements $HomeEvent$OnRidePreferencesUpdatedCopyWith<$Res> {
  _$HomeEvent$OnRidePreferencesUpdatedCopyWithImpl(this._self, this._then);

  final HomeEvent$OnRidePreferencesUpdated _self;
  final $Res Function(HomeEvent$OnRidePreferencesUpdated) _then;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? isTwoWayTrip = null,Object? waitTime = freezed,Object? rideOptions = null,}) {
  return _then(HomeEvent$OnRidePreferencesUpdated(
isTwoWayTrip: null == isTwoWayTrip ? _self.isTwoWayTrip : isTwoWayTrip // ignore: cast_nullable_to_non_nullable
as bool,waitTime: freezed == waitTime ? _self.waitTime : waitTime // ignore: cast_nullable_to_non_nullable
as int?,rideOptions: null == rideOptions ? _self._rideOptions : rideOptions // ignore: cast_nullable_to_non_nullable
as List<Fragment$RideOption>,
  ));
}


}

/// @nodoc


class HomeEvent$OnCouponCodeUpdated with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$OnCouponCodeUpdated({required this.couponCode});
  

 final  String couponCode;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeEvent$OnCouponCodeUpdatedCopyWith<HomeEvent$OnCouponCodeUpdated> get copyWith => _$HomeEvent$OnCouponCodeUpdatedCopyWithImpl<HomeEvent$OnCouponCodeUpdated>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.onCouponCodeChanged'))
    ..add(DiagnosticsProperty('couponCode', couponCode));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$OnCouponCodeUpdated&&(identical(other.couponCode, couponCode) || other.couponCode == couponCode));
}


@override
int get hashCode => Object.hash(runtimeType,couponCode);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.onCouponCodeChanged(couponCode: $couponCode)';
}


}

/// @nodoc
abstract mixin class $HomeEvent$OnCouponCodeUpdatedCopyWith<$Res> implements $HomeEventCopyWith<$Res> {
  factory $HomeEvent$OnCouponCodeUpdatedCopyWith(HomeEvent$OnCouponCodeUpdated value, $Res Function(HomeEvent$OnCouponCodeUpdated) _then) = _$HomeEvent$OnCouponCodeUpdatedCopyWithImpl;
@useResult
$Res call({
 String couponCode
});




}
/// @nodoc
class _$HomeEvent$OnCouponCodeUpdatedCopyWithImpl<$Res>
    implements $HomeEvent$OnCouponCodeUpdatedCopyWith<$Res> {
  _$HomeEvent$OnCouponCodeUpdatedCopyWithImpl(this._self, this._then);

  final HomeEvent$OnCouponCodeUpdated _self;
  final $Res Function(HomeEvent$OnCouponCodeUpdated) _then;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? couponCode = null,}) {
  return _then(HomeEvent$OnCouponCodeUpdated(
couponCode: null == couponCode ? _self.couponCode : couponCode // ignore: cast_nullable_to_non_nullable
as String,
  ));
}


}

/// @nodoc


class HomeEvent$FocusOnWaypoint with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$FocusOnWaypoint({required this.index});
  

 final  int index;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeEvent$FocusOnWaypointCopyWith<HomeEvent$FocusOnWaypoint> get copyWith => _$HomeEvent$FocusOnWaypointCopyWithImpl<HomeEvent$FocusOnWaypoint>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.focusOnWaypoint'))
    ..add(DiagnosticsProperty('index', index));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$FocusOnWaypoint&&(identical(other.index, index) || other.index == index));
}


@override
int get hashCode => Object.hash(runtimeType,index);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.focusOnWaypoint(index: $index)';
}


}

/// @nodoc
abstract mixin class $HomeEvent$FocusOnWaypointCopyWith<$Res> implements $HomeEventCopyWith<$Res> {
  factory $HomeEvent$FocusOnWaypointCopyWith(HomeEvent$FocusOnWaypoint value, $Res Function(HomeEvent$FocusOnWaypoint) _then) = _$HomeEvent$FocusOnWaypointCopyWithImpl;
@useResult
$Res call({
 int index
});




}
/// @nodoc
class _$HomeEvent$FocusOnWaypointCopyWithImpl<$Res>
    implements $HomeEvent$FocusOnWaypointCopyWith<$Res> {
  _$HomeEvent$FocusOnWaypointCopyWithImpl(this._self, this._then);

  final HomeEvent$FocusOnWaypoint _self;
  final $Res Function(HomeEvent$FocusOnWaypoint) _then;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? index = null,}) {
  return _then(HomeEvent$FocusOnWaypoint(
index: null == index ? _self.index : index // ignore: cast_nullable_to_non_nullable
as int,
  ));
}


}

/// @nodoc


class HomeEvent$CancelRide with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$CancelRide({required this.orderId, required this.cancelReasonId, required this.cancelReasonNote});
  

 final  String orderId;
 final  String? cancelReasonId;
 final  String? cancelReasonNote;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeEvent$CancelRideCopyWith<HomeEvent$CancelRide> get copyWith => _$HomeEvent$CancelRideCopyWithImpl<HomeEvent$CancelRide>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.cancelRide'))
    ..add(DiagnosticsProperty('orderId', orderId))..add(DiagnosticsProperty('cancelReasonId', cancelReasonId))..add(DiagnosticsProperty('cancelReasonNote', cancelReasonNote));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$CancelRide&&(identical(other.orderId, orderId) || other.orderId == orderId)&&(identical(other.cancelReasonId, cancelReasonId) || other.cancelReasonId == cancelReasonId)&&(identical(other.cancelReasonNote, cancelReasonNote) || other.cancelReasonNote == cancelReasonNote));
}


@override
int get hashCode => Object.hash(runtimeType,orderId,cancelReasonId,cancelReasonNote);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.cancelRide(orderId: $orderId, cancelReasonId: $cancelReasonId, cancelReasonNote: $cancelReasonNote)';
}


}

/// @nodoc
abstract mixin class $HomeEvent$CancelRideCopyWith<$Res> implements $HomeEventCopyWith<$Res> {
  factory $HomeEvent$CancelRideCopyWith(HomeEvent$CancelRide value, $Res Function(HomeEvent$CancelRide) _then) = _$HomeEvent$CancelRideCopyWithImpl;
@useResult
$Res call({
 String orderId, String? cancelReasonId, String? cancelReasonNote
});




}
/// @nodoc
class _$HomeEvent$CancelRideCopyWithImpl<$Res>
    implements $HomeEvent$CancelRideCopyWith<$Res> {
  _$HomeEvent$CancelRideCopyWithImpl(this._self, this._then);

  final HomeEvent$CancelRide _self;
  final $Res Function(HomeEvent$CancelRide) _then;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? orderId = null,Object? cancelReasonId = freezed,Object? cancelReasonNote = freezed,}) {
  return _then(HomeEvent$CancelRide(
orderId: null == orderId ? _self.orderId : orderId // ignore: cast_nullable_to_non_nullable
as String,cancelReasonId: freezed == cancelReasonId ? _self.cancelReasonId : cancelReasonId // ignore: cast_nullable_to_non_nullable
as String?,cancelReasonNote: freezed == cancelReasonNote ? _self.cancelReasonNote : cancelReasonNote // ignore: cast_nullable_to_non_nullable
as String?,
  ));
}


}

/// @nodoc


class HomeEvent$OnReviewSubmitted with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$OnReviewSubmitted({required this.orderId, required this.rating, required this.comment, required final  List<Fragment$ReviewParameter> parameters, required this.isFavorite}): _parameters = parameters;
  

 final  String orderId;
 final  int rating;
 final  String? comment;
 final  List<Fragment$ReviewParameter> _parameters;
 List<Fragment$ReviewParameter> get parameters {
  if (_parameters is EqualUnmodifiableListView) return _parameters;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_parameters);
}

 final  bool isFavorite;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeEvent$OnReviewSubmittedCopyWith<HomeEvent$OnReviewSubmitted> get copyWith => _$HomeEvent$OnReviewSubmittedCopyWithImpl<HomeEvent$OnReviewSubmitted>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.onReviewSubmitted'))
    ..add(DiagnosticsProperty('orderId', orderId))..add(DiagnosticsProperty('rating', rating))..add(DiagnosticsProperty('comment', comment))..add(DiagnosticsProperty('parameters', parameters))..add(DiagnosticsProperty('isFavorite', isFavorite));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$OnReviewSubmitted&&(identical(other.orderId, orderId) || other.orderId == orderId)&&(identical(other.rating, rating) || other.rating == rating)&&(identical(other.comment, comment) || other.comment == comment)&&const DeepCollectionEquality().equals(other._parameters, _parameters)&&(identical(other.isFavorite, isFavorite) || other.isFavorite == isFavorite));
}


@override
int get hashCode => Object.hash(runtimeType,orderId,rating,comment,const DeepCollectionEquality().hash(_parameters),isFavorite);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.onReviewSubmitted(orderId: $orderId, rating: $rating, comment: $comment, parameters: $parameters, isFavorite: $isFavorite)';
}


}

/// @nodoc
abstract mixin class $HomeEvent$OnReviewSubmittedCopyWith<$Res> implements $HomeEventCopyWith<$Res> {
  factory $HomeEvent$OnReviewSubmittedCopyWith(HomeEvent$OnReviewSubmitted value, $Res Function(HomeEvent$OnReviewSubmitted) _then) = _$HomeEvent$OnReviewSubmittedCopyWithImpl;
@useResult
$Res call({
 String orderId, int rating, String? comment, List<Fragment$ReviewParameter> parameters, bool isFavorite
});




}
/// @nodoc
class _$HomeEvent$OnReviewSubmittedCopyWithImpl<$Res>
    implements $HomeEvent$OnReviewSubmittedCopyWith<$Res> {
  _$HomeEvent$OnReviewSubmittedCopyWithImpl(this._self, this._then);

  final HomeEvent$OnReviewSubmitted _self;
  final $Res Function(HomeEvent$OnReviewSubmitted) _then;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? orderId = null,Object? rating = null,Object? comment = freezed,Object? parameters = null,Object? isFavorite = null,}) {
  return _then(HomeEvent$OnReviewSubmitted(
orderId: null == orderId ? _self.orderId : orderId // ignore: cast_nullable_to_non_nullable
as String,rating: null == rating ? _self.rating : rating // ignore: cast_nullable_to_non_nullable
as int,comment: freezed == comment ? _self.comment : comment // ignore: cast_nullable_to_non_nullable
as String?,parameters: null == parameters ? _self._parameters : parameters // ignore: cast_nullable_to_non_nullable
as List<Fragment$ReviewParameter>,isFavorite: null == isFavorite ? _self.isFavorite : isFavorite // ignore: cast_nullable_to_non_nullable
as bool,
  ));
}


}

/// @nodoc


class HomeEvent$MarkEphemeralMessageAsSeen with DiagnosticableTreeMixin implements HomeEvent {
  const HomeEvent$MarkEphemeralMessageAsSeen({required this.ephemeralMessageId});
  

 final  String ephemeralMessageId;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$HomeEvent$MarkEphemeralMessageAsSeenCopyWith<HomeEvent$MarkEphemeralMessageAsSeen> get copyWith => _$HomeEvent$MarkEphemeralMessageAsSeenCopyWithImpl<HomeEvent$MarkEphemeralMessageAsSeen>(this, _$identity);


@override
void debugFillProperties(DiagnosticPropertiesBuilder properties) {
  properties
    ..add(DiagnosticsProperty('type', 'HomeEvent.markEphemeralMessageAsSeen'))
    ..add(DiagnosticsProperty('ephemeralMessageId', ephemeralMessageId));
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is HomeEvent$MarkEphemeralMessageAsSeen&&(identical(other.ephemeralMessageId, ephemeralMessageId) || other.ephemeralMessageId == ephemeralMessageId));
}


@override
int get hashCode => Object.hash(runtimeType,ephemeralMessageId);

@override
String toString({ DiagnosticLevel minLevel = DiagnosticLevel.info }) {
  return 'HomeEvent.markEphemeralMessageAsSeen(ephemeralMessageId: $ephemeralMessageId)';
}


}

/// @nodoc
abstract mixin class $HomeEvent$MarkEphemeralMessageAsSeenCopyWith<$Res> implements $HomeEventCopyWith<$Res> {
  factory $HomeEvent$MarkEphemeralMessageAsSeenCopyWith(HomeEvent$MarkEphemeralMessageAsSeen value, $Res Function(HomeEvent$MarkEphemeralMessageAsSeen) _then) = _$HomeEvent$MarkEphemeralMessageAsSeenCopyWithImpl;
@useResult
$Res call({
 String ephemeralMessageId
});




}
/// @nodoc
class _$HomeEvent$MarkEphemeralMessageAsSeenCopyWithImpl<$Res>
    implements $HomeEvent$MarkEphemeralMessageAsSeenCopyWith<$Res> {
  _$HomeEvent$MarkEphemeralMessageAsSeenCopyWithImpl(this._self, this._then);

  final HomeEvent$MarkEphemeralMessageAsSeen _self;
  final $Res Function(HomeEvent$MarkEphemeralMessageAsSeen) _then;

/// Create a copy of HomeEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? ephemeralMessageId = null,}) {
  return _then(HomeEvent$MarkEphemeralMessageAsSeen(
ephemeralMessageId: null == ephemeralMessageId ? _self.ephemeralMessageId : ephemeralMessageId // ignore: cast_nullable_to_non_nullable
as String,
  ));
}


}

// dart format on
