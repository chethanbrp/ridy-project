enum AddBalanceStatus { success, failed, redirect }
