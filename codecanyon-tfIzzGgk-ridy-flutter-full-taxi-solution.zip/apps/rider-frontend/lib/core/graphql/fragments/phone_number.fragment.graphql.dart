import 'package:gql/ast.dart';
import 'package:graphql/client.dart' as graphql;

class Fragment$PhoneNumber {
  Fragment$PhoneNumber({
    required this.countryCode,
    required this.number,
    this.$__typename = 'PhoneNumber',
  });

  factory Fragment$PhoneNumber.fromJson(Map<String, dynamic> json) {
    final l$countryCode = json['countryCode'];
    final l$number = json['number'];
    final l$$__typename = json['__typename'];
    return Fragment$PhoneNumber(
      countryCode: (l$countryCode as String),
      number: (l$number as String),
      $__typename: (l$$__typename as String),
    );
  }

  final String countryCode;

  final String number;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$countryCode = countryCode;
    _resultData['countryCode'] = l$countryCode;
    final l$number = number;
    _resultData['number'] = l$number;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$countryCode = countryCode;
    final l$number = number;
    final l$$__typename = $__typename;
    return Object.hashAll([l$countryCode, l$number, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$PhoneNumber || runtimeType != other.runtimeType) {
      return false;
    }
    final l$countryCode = countryCode;
    final lOther$countryCode = other.countryCode;
    if (l$countryCode != lOther$countryCode) {
      return false;
    }
    final l$number = number;
    final lOther$number = other.number;
    if (l$number != lOther$number) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$PhoneNumber on Fragment$PhoneNumber {
  CopyWith$Fragment$PhoneNumber<Fragment$PhoneNumber> get copyWith =>
      CopyWith$Fragment$PhoneNumber(this, (i) => i);
}

abstract class CopyWith$Fragment$PhoneNumber<TRes> {
  factory CopyWith$Fragment$PhoneNumber(
    Fragment$PhoneNumber instance,
    TRes Function(Fragment$PhoneNumber) then,
  ) = _CopyWithImpl$Fragment$PhoneNumber;

  factory CopyWith$Fragment$PhoneNumber.stub(TRes res) =
      _CopyWithStubImpl$Fragment$PhoneNumber;

  TRes call({String? countryCode, String? number, String? $__typename});
}

class _CopyWithImpl$Fragment$PhoneNumber<TRes>
    implements CopyWith$Fragment$PhoneNumber<TRes> {
  _CopyWithImpl$Fragment$PhoneNumber(this._instance, this._then);

  final Fragment$PhoneNumber _instance;

  final TRes Function(Fragment$PhoneNumber) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? countryCode = _undefined,
    Object? number = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Fragment$PhoneNumber(
      countryCode: countryCode == _undefined || countryCode == null
          ? _instance.countryCode
          : (countryCode as String),
      number: number == _undefined || number == null
          ? _instance.number
          : (number as String),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );
}

class _CopyWithStubImpl$Fragment$PhoneNumber<TRes>
    implements CopyWith$Fragment$PhoneNumber<TRes> {
  _CopyWithStubImpl$Fragment$PhoneNumber(this._res);

  TRes _res;

  call({String? countryCode, String? number, String? $__typename}) => _res;
}

const fragmentDefinitionPhoneNumber = FragmentDefinitionNode(
  name: NameNode(value: 'PhoneNumber'),
  typeCondition: TypeConditionNode(
    on: NamedTypeNode(name: NameNode(value: 'PhoneNumber'), isNonNull: false),
  ),
  directives: [],
  selectionSet: SelectionSetNode(
    selections: [
      FieldNode(
        name: NameNode(value: 'countryCode'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'number'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: '__typename'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
    ],
  ),
);
const documentNodeFragmentPhoneNumber = DocumentNode(
  definitions: [fragmentDefinitionPhoneNumber],
);

extension ClientExtension$Fragment$PhoneNumber on graphql.GraphQLClient {
  void writeFragment$PhoneNumber({
    required Fragment$PhoneNumber data,
    required Map<String, dynamic> idFields,
    bool broadcast = true,
  }) => this.writeFragment(
    graphql.FragmentRequest(
      idFields: idFields,
      fragment: const graphql.Fragment(
        fragmentName: 'PhoneNumber',
        document: documentNodeFragmentPhoneNumber,
      ),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Fragment$PhoneNumber? readFragment$PhoneNumber({
    required Map<String, dynamic> idFields,
    bool optimistic = true,
  }) {
    final result = this.readFragment(
      graphql.FragmentRequest(
        idFields: idFields,
        fragment: const graphql.Fragment(
          fragmentName: 'PhoneNumber',
          document: documentNodeFragmentPhoneNumber,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Fragment$PhoneNumber.fromJson(result);
  }
}
