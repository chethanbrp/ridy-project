import 'package:gql/ast.dart';
import 'package:graphql/client.dart' as graphql;

class Fragment$cancelReason {
  Fragment$cancelReason({
    required this.id,
    required this.title,
    this.$__typename = 'OrderCancelReason',
  });

  factory Fragment$cancelReason.fromJson(Map<String, dynamic> json) {
    final l$id = json['id'];
    final l$title = json['title'];
    final l$$__typename = json['__typename'];
    return Fragment$cancelReason(
      id: (l$id as String),
      title: (l$title as String),
      $__typename: (l$$__typename as String),
    );
  }

  final String id;

  final String title;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$id = id;
    _resultData['id'] = l$id;
    final l$title = title;
    _resultData['title'] = l$title;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$id = id;
    final l$title = title;
    final l$$__typename = $__typename;
    return Object.hashAll([l$id, l$title, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$cancelReason || runtimeType != other.runtimeType) {
      return false;
    }
    final l$id = id;
    final lOther$id = other.id;
    if (l$id != lOther$id) {
      return false;
    }
    final l$title = title;
    final lOther$title = other.title;
    if (l$title != lOther$title) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$cancelReason on Fragment$cancelReason {
  CopyWith$Fragment$cancelReason<Fragment$cancelReason> get copyWith =>
      CopyWith$Fragment$cancelReason(this, (i) => i);
}

abstract class CopyWith$Fragment$cancelReason<TRes> {
  factory CopyWith$Fragment$cancelReason(
    Fragment$cancelReason instance,
    TRes Function(Fragment$cancelReason) then,
  ) = _CopyWithImpl$Fragment$cancelReason;

  factory CopyWith$Fragment$cancelReason.stub(TRes res) =
      _CopyWithStubImpl$Fragment$cancelReason;

  TRes call({String? id, String? title, String? $__typename});
}

class _CopyWithImpl$Fragment$cancelReason<TRes>
    implements CopyWith$Fragment$cancelReason<TRes> {
  _CopyWithImpl$Fragment$cancelReason(this._instance, this._then);

  final Fragment$cancelReason _instance;

  final TRes Function(Fragment$cancelReason) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? id = _undefined,
    Object? title = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Fragment$cancelReason(
      id: id == _undefined || id == null ? _instance.id : (id as String),
      title: title == _undefined || title == null
          ? _instance.title
          : (title as String),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );
}

class _CopyWithStubImpl$Fragment$cancelReason<TRes>
    implements CopyWith$Fragment$cancelReason<TRes> {
  _CopyWithStubImpl$Fragment$cancelReason(this._res);

  TRes _res;

  call({String? id, String? title, String? $__typename}) => _res;
}

const fragmentDefinitioncancelReason = FragmentDefinitionNode(
  name: NameNode(value: 'cancelReason'),
  typeCondition: TypeConditionNode(
    on: NamedTypeNode(
      name: NameNode(value: 'OrderCancelReason'),
      isNonNull: false,
    ),
  ),
  directives: [],
  selectionSet: SelectionSetNode(
    selections: [
      FieldNode(
        name: NameNode(value: 'id'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'title'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: '__typename'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
    ],
  ),
);
const documentNodeFragmentcancelReason = DocumentNode(
  definitions: [fragmentDefinitioncancelReason],
);

extension ClientExtension$Fragment$cancelReason on graphql.GraphQLClient {
  void writeFragment$cancelReason({
    required Fragment$cancelReason data,
    required Map<String, dynamic> idFields,
    bool broadcast = true,
  }) => this.writeFragment(
    graphql.FragmentRequest(
      idFields: idFields,
      fragment: const graphql.Fragment(
        fragmentName: 'cancelReason',
        document: documentNodeFragmentcancelReason,
      ),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Fragment$cancelReason? readFragment$cancelReason({
    required Map<String, dynamic> idFields,
    bool optimistic = true,
  }) {
    final result = this.readFragment(
      graphql.FragmentRequest(
        idFields: idFields,
        fragment: const graphql.Fragment(
          fragmentName: 'cancelReason',
          document: documentNodeFragmentcancelReason,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Fragment$cancelReason.fromJson(result);
  }
}
