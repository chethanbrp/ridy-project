import 'package:flutter_common/core/graphql/scalars/datetime.dart';
import 'package:gql/ast.dart';
import 'package:graphql/client.dart' as graphql;

class Fragment$ChatMessage {
  Fragment$ChatMessage({
    required this.message,
    required this.isFromMe,
    this.seenAt,
    required this.createdAt,
    this.$__typename = 'ChatMessage',
  });

  factory Fragment$ChatMessage.fromJson(Map<String, dynamic> json) {
    final l$message = json['message'];
    final l$isFromMe = json['isFromMe'];
    final l$seenAt = json['seenAt'];
    final l$createdAt = json['createdAt'];
    final l$$__typename = json['__typename'];
    return Fragment$ChatMessage(
      message: (l$message as String),
      isFromMe: (l$isFromMe as bool),
      seenAt: l$seenAt == null
          ? null
          : fromGraphQLDateTimeToDartDateTime(l$seenAt),
      createdAt: fromGraphQLDateTimeToDartDateTime(l$createdAt),
      $__typename: (l$$__typename as String),
    );
  }

  final String message;

  final bool isFromMe;

  final DateTime? seenAt;

  final DateTime createdAt;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$message = message;
    _resultData['message'] = l$message;
    final l$isFromMe = isFromMe;
    _resultData['isFromMe'] = l$isFromMe;
    final l$seenAt = seenAt;
    _resultData['seenAt'] = l$seenAt == null
        ? null
        : fromDartDateTimeToGraphQLDateTime(l$seenAt);
    final l$createdAt = createdAt;
    _resultData['createdAt'] = fromDartDateTimeToGraphQLDateTime(l$createdAt);
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$message = message;
    final l$isFromMe = isFromMe;
    final l$seenAt = seenAt;
    final l$createdAt = createdAt;
    final l$$__typename = $__typename;
    return Object.hashAll([
      l$message,
      l$isFromMe,
      l$seenAt,
      l$createdAt,
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$ChatMessage || runtimeType != other.runtimeType) {
      return false;
    }
    final l$message = message;
    final lOther$message = other.message;
    if (l$message != lOther$message) {
      return false;
    }
    final l$isFromMe = isFromMe;
    final lOther$isFromMe = other.isFromMe;
    if (l$isFromMe != lOther$isFromMe) {
      return false;
    }
    final l$seenAt = seenAt;
    final lOther$seenAt = other.seenAt;
    if (l$seenAt != lOther$seenAt) {
      return false;
    }
    final l$createdAt = createdAt;
    final lOther$createdAt = other.createdAt;
    if (l$createdAt != lOther$createdAt) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$ChatMessage on Fragment$ChatMessage {
  CopyWith$Fragment$ChatMessage<Fragment$ChatMessage> get copyWith =>
      CopyWith$Fragment$ChatMessage(this, (i) => i);
}

abstract class CopyWith$Fragment$ChatMessage<TRes> {
  factory CopyWith$Fragment$ChatMessage(
    Fragment$ChatMessage instance,
    TRes Function(Fragment$ChatMessage) then,
  ) = _CopyWithImpl$Fragment$ChatMessage;

  factory CopyWith$Fragment$ChatMessage.stub(TRes res) =
      _CopyWithStubImpl$Fragment$ChatMessage;

  TRes call({
    String? message,
    bool? isFromMe,
    DateTime? seenAt,
    DateTime? createdAt,
    String? $__typename,
  });
}

class _CopyWithImpl$Fragment$ChatMessage<TRes>
    implements CopyWith$Fragment$ChatMessage<TRes> {
  _CopyWithImpl$Fragment$ChatMessage(this._instance, this._then);

  final Fragment$ChatMessage _instance;

  final TRes Function(Fragment$ChatMessage) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? message = _undefined,
    Object? isFromMe = _undefined,
    Object? seenAt = _undefined,
    Object? createdAt = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Fragment$ChatMessage(
      message: message == _undefined || message == null
          ? _instance.message
          : (message as String),
      isFromMe: isFromMe == _undefined || isFromMe == null
          ? _instance.isFromMe
          : (isFromMe as bool),
      seenAt: seenAt == _undefined ? _instance.seenAt : (seenAt as DateTime?),
      createdAt: createdAt == _undefined || createdAt == null
          ? _instance.createdAt
          : (createdAt as DateTime),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );
}

class _CopyWithStubImpl$Fragment$ChatMessage<TRes>
    implements CopyWith$Fragment$ChatMessage<TRes> {
  _CopyWithStubImpl$Fragment$ChatMessage(this._res);

  TRes _res;

  call({
    String? message,
    bool? isFromMe,
    DateTime? seenAt,
    DateTime? createdAt,
    String? $__typename,
  }) => _res;
}

const fragmentDefinitionChatMessage = FragmentDefinitionNode(
  name: NameNode(value: 'ChatMessage'),
  typeCondition: TypeConditionNode(
    on: NamedTypeNode(name: NameNode(value: 'ChatMessage'), isNonNull: false),
  ),
  directives: [],
  selectionSet: SelectionSetNode(
    selections: [
      FieldNode(
        name: NameNode(value: 'message'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'isFromMe'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'seenAt'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'createdAt'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: '__typename'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
    ],
  ),
);
const documentNodeFragmentChatMessage = DocumentNode(
  definitions: [fragmentDefinitionChatMessage],
);

extension ClientExtension$Fragment$ChatMessage on graphql.GraphQLClient {
  void writeFragment$ChatMessage({
    required Fragment$ChatMessage data,
    required Map<String, dynamic> idFields,
    bool broadcast = true,
  }) => this.writeFragment(
    graphql.FragmentRequest(
      idFields: idFields,
      fragment: const graphql.Fragment(
        fragmentName: 'ChatMessage',
        document: documentNodeFragmentChatMessage,
      ),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Fragment$ChatMessage? readFragment$ChatMessage({
    required Map<String, dynamic> idFields,
    bool optimistic = true,
  }) {
    final result = this.readFragment(
      graphql.FragmentRequest(
        idFields: idFields,
        fragment: const graphql.Fragment(
          fragmentName: 'ChatMessage',
          document: documentNodeFragmentChatMessage,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Fragment$ChatMessage.fromJson(result);
  }
}
