import '../schema.gql.dart';
import 'package:gql/ast.dart';
import 'package:graphql/client.dart' as graphql;

class Fragment$EphemeralMessage {
  Fragment$EphemeralMessage({
    required this.type,
    this.driverFullName,
    this.driverProfileUrl,
    required this.orderId,
    this.vehicleName,
    this.serviceName,
    this.serviceImageUrl,
    this.$__typename = 'EphemeralMessage',
  });

  factory Fragment$EphemeralMessage.fromJson(Map<String, dynamic> json) {
    final l$type = json['type'];
    final l$driverFullName = json['driverFullName'];
    final l$driverProfileUrl = json['driverProfileUrl'];
    final l$orderId = json['orderId'];
    final l$vehicleName = json['vehicleName'];
    final l$serviceName = json['serviceName'];
    final l$serviceImageUrl = json['serviceImageUrl'];
    final l$$__typename = json['__typename'];
    return Fragment$EphemeralMessage(
      type: fromJson$Enum$EphemeralMessageType((l$type as String)),
      driverFullName: (l$driverFullName as String?),
      driverProfileUrl: (l$driverProfileUrl as String?),
      orderId: (l$orderId as String),
      vehicleName: (l$vehicleName as String?),
      serviceName: (l$serviceName as String?),
      serviceImageUrl: (l$serviceImageUrl as String?),
      $__typename: (l$$__typename as String),
    );
  }

  final Enum$EphemeralMessageType type;

  final String? driverFullName;

  final String? driverProfileUrl;

  final String orderId;

  final String? vehicleName;

  final String? serviceName;

  final String? serviceImageUrl;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$type = type;
    _resultData['type'] = toJson$Enum$EphemeralMessageType(l$type);
    final l$driverFullName = driverFullName;
    _resultData['driverFullName'] = l$driverFullName;
    final l$driverProfileUrl = driverProfileUrl;
    _resultData['driverProfileUrl'] = l$driverProfileUrl;
    final l$orderId = orderId;
    _resultData['orderId'] = l$orderId;
    final l$vehicleName = vehicleName;
    _resultData['vehicleName'] = l$vehicleName;
    final l$serviceName = serviceName;
    _resultData['serviceName'] = l$serviceName;
    final l$serviceImageUrl = serviceImageUrl;
    _resultData['serviceImageUrl'] = l$serviceImageUrl;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$type = type;
    final l$driverFullName = driverFullName;
    final l$driverProfileUrl = driverProfileUrl;
    final l$orderId = orderId;
    final l$vehicleName = vehicleName;
    final l$serviceName = serviceName;
    final l$serviceImageUrl = serviceImageUrl;
    final l$$__typename = $__typename;
    return Object.hashAll([
      l$type,
      l$driverFullName,
      l$driverProfileUrl,
      l$orderId,
      l$vehicleName,
      l$serviceName,
      l$serviceImageUrl,
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$EphemeralMessage ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$type = type;
    final lOther$type = other.type;
    if (l$type != lOther$type) {
      return false;
    }
    final l$driverFullName = driverFullName;
    final lOther$driverFullName = other.driverFullName;
    if (l$driverFullName != lOther$driverFullName) {
      return false;
    }
    final l$driverProfileUrl = driverProfileUrl;
    final lOther$driverProfileUrl = other.driverProfileUrl;
    if (l$driverProfileUrl != lOther$driverProfileUrl) {
      return false;
    }
    final l$orderId = orderId;
    final lOther$orderId = other.orderId;
    if (l$orderId != lOther$orderId) {
      return false;
    }
    final l$vehicleName = vehicleName;
    final lOther$vehicleName = other.vehicleName;
    if (l$vehicleName != lOther$vehicleName) {
      return false;
    }
    final l$serviceName = serviceName;
    final lOther$serviceName = other.serviceName;
    if (l$serviceName != lOther$serviceName) {
      return false;
    }
    final l$serviceImageUrl = serviceImageUrl;
    final lOther$serviceImageUrl = other.serviceImageUrl;
    if (l$serviceImageUrl != lOther$serviceImageUrl) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$EphemeralMessage
    on Fragment$EphemeralMessage {
  CopyWith$Fragment$EphemeralMessage<Fragment$EphemeralMessage> get copyWith =>
      CopyWith$Fragment$EphemeralMessage(this, (i) => i);
}

abstract class CopyWith$Fragment$EphemeralMessage<TRes> {
  factory CopyWith$Fragment$EphemeralMessage(
    Fragment$EphemeralMessage instance,
    TRes Function(Fragment$EphemeralMessage) then,
  ) = _CopyWithImpl$Fragment$EphemeralMessage;

  factory CopyWith$Fragment$EphemeralMessage.stub(TRes res) =
      _CopyWithStubImpl$Fragment$EphemeralMessage;

  TRes call({
    Enum$EphemeralMessageType? type,
    String? driverFullName,
    String? driverProfileUrl,
    String? orderId,
    String? vehicleName,
    String? serviceName,
    String? serviceImageUrl,
    String? $__typename,
  });
}

class _CopyWithImpl$Fragment$EphemeralMessage<TRes>
    implements CopyWith$Fragment$EphemeralMessage<TRes> {
  _CopyWithImpl$Fragment$EphemeralMessage(this._instance, this._then);

  final Fragment$EphemeralMessage _instance;

  final TRes Function(Fragment$EphemeralMessage) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? type = _undefined,
    Object? driverFullName = _undefined,
    Object? driverProfileUrl = _undefined,
    Object? orderId = _undefined,
    Object? vehicleName = _undefined,
    Object? serviceName = _undefined,
    Object? serviceImageUrl = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Fragment$EphemeralMessage(
      type: type == _undefined || type == null
          ? _instance.type
          : (type as Enum$EphemeralMessageType),
      driverFullName: driverFullName == _undefined
          ? _instance.driverFullName
          : (driverFullName as String?),
      driverProfileUrl: driverProfileUrl == _undefined
          ? _instance.driverProfileUrl
          : (driverProfileUrl as String?),
      orderId: orderId == _undefined || orderId == null
          ? _instance.orderId
          : (orderId as String),
      vehicleName: vehicleName == _undefined
          ? _instance.vehicleName
          : (vehicleName as String?),
      serviceName: serviceName == _undefined
          ? _instance.serviceName
          : (serviceName as String?),
      serviceImageUrl: serviceImageUrl == _undefined
          ? _instance.serviceImageUrl
          : (serviceImageUrl as String?),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );
}

class _CopyWithStubImpl$Fragment$EphemeralMessage<TRes>
    implements CopyWith$Fragment$EphemeralMessage<TRes> {
  _CopyWithStubImpl$Fragment$EphemeralMessage(this._res);

  TRes _res;

  call({
    Enum$EphemeralMessageType? type,
    String? driverFullName,
    String? driverProfileUrl,
    String? orderId,
    String? vehicleName,
    String? serviceName,
    String? serviceImageUrl,
    String? $__typename,
  }) => _res;
}

const fragmentDefinitionEphemeralMessage = FragmentDefinitionNode(
  name: NameNode(value: 'EphemeralMessage'),
  typeCondition: TypeConditionNode(
    on: NamedTypeNode(
      name: NameNode(value: 'EphemeralMessage'),
      isNonNull: false,
    ),
  ),
  directives: [],
  selectionSet: SelectionSetNode(
    selections: [
      FieldNode(
        name: NameNode(value: 'type'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'driverFullName'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'driverProfileUrl'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'orderId'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'vehicleName'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'serviceName'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'serviceImageUrl'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: '__typename'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
    ],
  ),
);
const documentNodeFragmentEphemeralMessage = DocumentNode(
  definitions: [fragmentDefinitionEphemeralMessage],
);

extension ClientExtension$Fragment$EphemeralMessage on graphql.GraphQLClient {
  void writeFragment$EphemeralMessage({
    required Fragment$EphemeralMessage data,
    required Map<String, dynamic> idFields,
    bool broadcast = true,
  }) => this.writeFragment(
    graphql.FragmentRequest(
      idFields: idFields,
      fragment: const graphql.Fragment(
        fragmentName: 'EphemeralMessage',
        document: documentNodeFragmentEphemeralMessage,
      ),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Fragment$EphemeralMessage? readFragment$EphemeralMessage({
    required Map<String, dynamic> idFields,
    bool optimistic = true,
  }) {
    final result = this.readFragment(
      graphql.FragmentRequest(
        idFields: idFields,
        fragment: const graphql.Fragment(
          fragmentName: 'EphemeralMessage',
          document: documentNodeFragmentEphemeralMessage,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Fragment$EphemeralMessage.fromJson(result);
  }
}
