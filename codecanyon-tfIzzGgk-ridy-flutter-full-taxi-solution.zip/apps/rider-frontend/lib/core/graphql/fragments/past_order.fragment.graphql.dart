import '../schema.gql.dart';
import 'driver.fragment.graphql.dart';
import 'package:flutter_common/core/graphql/scalars/datetime.dart';
import 'package:gql/ast.dart';
import 'package:graphql/client.dart' as graphql;
import 'payment_method.fragment.graphql.dart';
import 'phone_number.fragment.graphql.dart';
import 'point.fragment.graphql.dart';

class Fragment$PastOrder {
  Fragment$PastOrder({
    required this.id,
    required this.serviceName,
    required this.type,
    required this.currency,
    required this.serviceImageAddress,
    this.pickupEta,
    this.dropoffEta,
    this.waitMinutes,
    required this.directions,
    required this.estimatedDistance,
    required this.estimatedDuration,
    required this.createdAt,
    this.scheduledAt,
    required this.options,
    this.driver,
    required this.status,
    required this.totalCost,
    this.couponDiscount,
    required this.paymentMethod,
    required this.waypoints,
    this.$__typename = 'PastOrder',
  });

  factory Fragment$PastOrder.fromJson(Map<String, dynamic> json) {
    final l$id = json['id'];
    final l$serviceName = json['serviceName'];
    final l$type = json['type'];
    final l$currency = json['currency'];
    final l$serviceImageAddress = json['serviceImageAddress'];
    final l$pickupEta = json['pickupEta'];
    final l$dropoffEta = json['dropoffEta'];
    final l$waitMinutes = json['waitMinutes'];
    final l$directions = json['directions'];
    final l$estimatedDistance = json['estimatedDistance'];
    final l$estimatedDuration = json['estimatedDuration'];
    final l$createdAt = json['createdAt'];
    final l$scheduledAt = json['scheduledAt'];
    final l$options = json['options'];
    final l$driver = json['driver'];
    final l$status = json['status'];
    final l$totalCost = json['totalCost'];
    final l$couponDiscount = json['couponDiscount'];
    final l$paymentMethod = json['paymentMethod'];
    final l$waypoints = json['waypoints'];
    final l$$__typename = json['__typename'];
    return Fragment$PastOrder(
      id: (l$id as String),
      serviceName: (l$serviceName as String),
      type: fromJson$Enum$TaxiOrderType((l$type as String)),
      currency: (l$currency as String),
      serviceImageAddress: (l$serviceImageAddress as String),
      pickupEta: l$pickupEta == null
          ? null
          : fromGraphQLDateTimeToDartDateTime(l$pickupEta),
      dropoffEta: l$dropoffEta == null
          ? null
          : fromGraphQLDateTimeToDartDateTime(l$dropoffEta),
      waitMinutes: (l$waitMinutes as int?),
      directions: (l$directions as List<dynamic>)
          .map((e) => Fragment$Coordinate.fromJson((e as Map<String, dynamic>)))
          .toList(),
      estimatedDistance: (l$estimatedDistance as int),
      estimatedDuration: (l$estimatedDuration as int),
      createdAt: fromGraphQLDateTimeToDartDateTime(l$createdAt),
      scheduledAt: l$scheduledAt == null
          ? null
          : fromGraphQLDateTimeToDartDateTime(l$scheduledAt),
      options: (l$options as List<dynamic>)
          .map(
            (e) => Fragment$PastOrder$options.fromJson(
              (e as Map<String, dynamic>),
            ),
          )
          .toList(),
      driver: l$driver == null
          ? null
          : Fragment$PastOrderDriver.fromJson(
              (l$driver as Map<String, dynamic>),
            ),
      status: fromJson$Enum$OrderStatus((l$status as String)),
      totalCost: (l$totalCost as num).toDouble(),
      couponDiscount: (l$couponDiscount as num?)?.toDouble(),
      paymentMethod: Fragment$PaymentMethod.fromJson(
        (l$paymentMethod as Map<String, dynamic>),
      ),
      waypoints: (l$waypoints as List<dynamic>)
          .map((e) => Fragment$Waypoint.fromJson((e as Map<String, dynamic>)))
          .toList(),
      $__typename: (l$$__typename as String),
    );
  }

  final String id;

  final String serviceName;

  final Enum$TaxiOrderType type;

  final String currency;

  final String serviceImageAddress;

  final DateTime? pickupEta;

  final DateTime? dropoffEta;

  final int? waitMinutes;

  final List<Fragment$Coordinate> directions;

  final int estimatedDistance;

  final int estimatedDuration;

  final DateTime createdAt;

  final DateTime? scheduledAt;

  final List<Fragment$PastOrder$options> options;

  final Fragment$PastOrderDriver? driver;

  final Enum$OrderStatus status;

  final double totalCost;

  final double? couponDiscount;

  final Fragment$PaymentMethod paymentMethod;

  final List<Fragment$Waypoint> waypoints;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$id = id;
    _resultData['id'] = l$id;
    final l$serviceName = serviceName;
    _resultData['serviceName'] = l$serviceName;
    final l$type = type;
    _resultData['type'] = toJson$Enum$TaxiOrderType(l$type);
    final l$currency = currency;
    _resultData['currency'] = l$currency;
    final l$serviceImageAddress = serviceImageAddress;
    _resultData['serviceImageAddress'] = l$serviceImageAddress;
    final l$pickupEta = pickupEta;
    _resultData['pickupEta'] = l$pickupEta == null
        ? null
        : fromDartDateTimeToGraphQLDateTime(l$pickupEta);
    final l$dropoffEta = dropoffEta;
    _resultData['dropoffEta'] = l$dropoffEta == null
        ? null
        : fromDartDateTimeToGraphQLDateTime(l$dropoffEta);
    final l$waitMinutes = waitMinutes;
    _resultData['waitMinutes'] = l$waitMinutes;
    final l$directions = directions;
    _resultData['directions'] = l$directions.map((e) => e.toJson()).toList();
    final l$estimatedDistance = estimatedDistance;
    _resultData['estimatedDistance'] = l$estimatedDistance;
    final l$estimatedDuration = estimatedDuration;
    _resultData['estimatedDuration'] = l$estimatedDuration;
    final l$createdAt = createdAt;
    _resultData['createdAt'] = fromDartDateTimeToGraphQLDateTime(l$createdAt);
    final l$scheduledAt = scheduledAt;
    _resultData['scheduledAt'] = l$scheduledAt == null
        ? null
        : fromDartDateTimeToGraphQLDateTime(l$scheduledAt);
    final l$options = options;
    _resultData['options'] = l$options.map((e) => e.toJson()).toList();
    final l$driver = driver;
    _resultData['driver'] = l$driver?.toJson();
    final l$status = status;
    _resultData['status'] = toJson$Enum$OrderStatus(l$status);
    final l$totalCost = totalCost;
    _resultData['totalCost'] = l$totalCost;
    final l$couponDiscount = couponDiscount;
    _resultData['couponDiscount'] = l$couponDiscount;
    final l$paymentMethod = paymentMethod;
    _resultData['paymentMethod'] = l$paymentMethod.toJson();
    final l$waypoints = waypoints;
    _resultData['waypoints'] = l$waypoints.map((e) => e.toJson()).toList();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$id = id;
    final l$serviceName = serviceName;
    final l$type = type;
    final l$currency = currency;
    final l$serviceImageAddress = serviceImageAddress;
    final l$pickupEta = pickupEta;
    final l$dropoffEta = dropoffEta;
    final l$waitMinutes = waitMinutes;
    final l$directions = directions;
    final l$estimatedDistance = estimatedDistance;
    final l$estimatedDuration = estimatedDuration;
    final l$createdAt = createdAt;
    final l$scheduledAt = scheduledAt;
    final l$options = options;
    final l$driver = driver;
    final l$status = status;
    final l$totalCost = totalCost;
    final l$couponDiscount = couponDiscount;
    final l$paymentMethod = paymentMethod;
    final l$waypoints = waypoints;
    final l$$__typename = $__typename;
    return Object.hashAll([
      l$id,
      l$serviceName,
      l$type,
      l$currency,
      l$serviceImageAddress,
      l$pickupEta,
      l$dropoffEta,
      l$waitMinutes,
      Object.hashAll(l$directions.map((v) => v)),
      l$estimatedDistance,
      l$estimatedDuration,
      l$createdAt,
      l$scheduledAt,
      Object.hashAll(l$options.map((v) => v)),
      l$driver,
      l$status,
      l$totalCost,
      l$couponDiscount,
      l$paymentMethod,
      Object.hashAll(l$waypoints.map((v) => v)),
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$PastOrder || runtimeType != other.runtimeType) {
      return false;
    }
    final l$id = id;
    final lOther$id = other.id;
    if (l$id != lOther$id) {
      return false;
    }
    final l$serviceName = serviceName;
    final lOther$serviceName = other.serviceName;
    if (l$serviceName != lOther$serviceName) {
      return false;
    }
    final l$type = type;
    final lOther$type = other.type;
    if (l$type != lOther$type) {
      return false;
    }
    final l$currency = currency;
    final lOther$currency = other.currency;
    if (l$currency != lOther$currency) {
      return false;
    }
    final l$serviceImageAddress = serviceImageAddress;
    final lOther$serviceImageAddress = other.serviceImageAddress;
    if (l$serviceImageAddress != lOther$serviceImageAddress) {
      return false;
    }
    final l$pickupEta = pickupEta;
    final lOther$pickupEta = other.pickupEta;
    if (l$pickupEta != lOther$pickupEta) {
      return false;
    }
    final l$dropoffEta = dropoffEta;
    final lOther$dropoffEta = other.dropoffEta;
    if (l$dropoffEta != lOther$dropoffEta) {
      return false;
    }
    final l$waitMinutes = waitMinutes;
    final lOther$waitMinutes = other.waitMinutes;
    if (l$waitMinutes != lOther$waitMinutes) {
      return false;
    }
    final l$directions = directions;
    final lOther$directions = other.directions;
    if (l$directions.length != lOther$directions.length) {
      return false;
    }
    for (int i = 0; i < l$directions.length; i++) {
      final l$directions$entry = l$directions[i];
      final lOther$directions$entry = lOther$directions[i];
      if (l$directions$entry != lOther$directions$entry) {
        return false;
      }
    }
    final l$estimatedDistance = estimatedDistance;
    final lOther$estimatedDistance = other.estimatedDistance;
    if (l$estimatedDistance != lOther$estimatedDistance) {
      return false;
    }
    final l$estimatedDuration = estimatedDuration;
    final lOther$estimatedDuration = other.estimatedDuration;
    if (l$estimatedDuration != lOther$estimatedDuration) {
      return false;
    }
    final l$createdAt = createdAt;
    final lOther$createdAt = other.createdAt;
    if (l$createdAt != lOther$createdAt) {
      return false;
    }
    final l$scheduledAt = scheduledAt;
    final lOther$scheduledAt = other.scheduledAt;
    if (l$scheduledAt != lOther$scheduledAt) {
      return false;
    }
    final l$options = options;
    final lOther$options = other.options;
    if (l$options.length != lOther$options.length) {
      return false;
    }
    for (int i = 0; i < l$options.length; i++) {
      final l$options$entry = l$options[i];
      final lOther$options$entry = lOther$options[i];
      if (l$options$entry != lOther$options$entry) {
        return false;
      }
    }
    final l$driver = driver;
    final lOther$driver = other.driver;
    if (l$driver != lOther$driver) {
      return false;
    }
    final l$status = status;
    final lOther$status = other.status;
    if (l$status != lOther$status) {
      return false;
    }
    final l$totalCost = totalCost;
    final lOther$totalCost = other.totalCost;
    if (l$totalCost != lOther$totalCost) {
      return false;
    }
    final l$couponDiscount = couponDiscount;
    final lOther$couponDiscount = other.couponDiscount;
    if (l$couponDiscount != lOther$couponDiscount) {
      return false;
    }
    final l$paymentMethod = paymentMethod;
    final lOther$paymentMethod = other.paymentMethod;
    if (l$paymentMethod != lOther$paymentMethod) {
      return false;
    }
    final l$waypoints = waypoints;
    final lOther$waypoints = other.waypoints;
    if (l$waypoints.length != lOther$waypoints.length) {
      return false;
    }
    for (int i = 0; i < l$waypoints.length; i++) {
      final l$waypoints$entry = l$waypoints[i];
      final lOther$waypoints$entry = lOther$waypoints[i];
      if (l$waypoints$entry != lOther$waypoints$entry) {
        return false;
      }
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$PastOrder on Fragment$PastOrder {
  CopyWith$Fragment$PastOrder<Fragment$PastOrder> get copyWith =>
      CopyWith$Fragment$PastOrder(this, (i) => i);
}

abstract class CopyWith$Fragment$PastOrder<TRes> {
  factory CopyWith$Fragment$PastOrder(
    Fragment$PastOrder instance,
    TRes Function(Fragment$PastOrder) then,
  ) = _CopyWithImpl$Fragment$PastOrder;

  factory CopyWith$Fragment$PastOrder.stub(TRes res) =
      _CopyWithStubImpl$Fragment$PastOrder;

  TRes call({
    String? id,
    String? serviceName,
    Enum$TaxiOrderType? type,
    String? currency,
    String? serviceImageAddress,
    DateTime? pickupEta,
    DateTime? dropoffEta,
    int? waitMinutes,
    List<Fragment$Coordinate>? directions,
    int? estimatedDistance,
    int? estimatedDuration,
    DateTime? createdAt,
    DateTime? scheduledAt,
    List<Fragment$PastOrder$options>? options,
    Fragment$PastOrderDriver? driver,
    Enum$OrderStatus? status,
    double? totalCost,
    double? couponDiscount,
    Fragment$PaymentMethod? paymentMethod,
    List<Fragment$Waypoint>? waypoints,
    String? $__typename,
  });
  TRes directions(
    Iterable<Fragment$Coordinate> Function(
      Iterable<CopyWith$Fragment$Coordinate<Fragment$Coordinate>>,
    )
    _fn,
  );
  TRes options(
    Iterable<Fragment$PastOrder$options> Function(
      Iterable<CopyWith$Fragment$PastOrder$options<Fragment$PastOrder$options>>,
    )
    _fn,
  );
  CopyWith$Fragment$PastOrderDriver<TRes> get driver;
  CopyWith$Fragment$PaymentMethod<TRes> get paymentMethod;
  TRes waypoints(
    Iterable<Fragment$Waypoint> Function(
      Iterable<CopyWith$Fragment$Waypoint<Fragment$Waypoint>>,
    )
    _fn,
  );
}

class _CopyWithImpl$Fragment$PastOrder<TRes>
    implements CopyWith$Fragment$PastOrder<TRes> {
  _CopyWithImpl$Fragment$PastOrder(this._instance, this._then);

  final Fragment$PastOrder _instance;

  final TRes Function(Fragment$PastOrder) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? id = _undefined,
    Object? serviceName = _undefined,
    Object? type = _undefined,
    Object? currency = _undefined,
    Object? serviceImageAddress = _undefined,
    Object? pickupEta = _undefined,
    Object? dropoffEta = _undefined,
    Object? waitMinutes = _undefined,
    Object? directions = _undefined,
    Object? estimatedDistance = _undefined,
    Object? estimatedDuration = _undefined,
    Object? createdAt = _undefined,
    Object? scheduledAt = _undefined,
    Object? options = _undefined,
    Object? driver = _undefined,
    Object? status = _undefined,
    Object? totalCost = _undefined,
    Object? couponDiscount = _undefined,
    Object? paymentMethod = _undefined,
    Object? waypoints = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Fragment$PastOrder(
      id: id == _undefined || id == null ? _instance.id : (id as String),
      serviceName: serviceName == _undefined || serviceName == null
          ? _instance.serviceName
          : (serviceName as String),
      type: type == _undefined || type == null
          ? _instance.type
          : (type as Enum$TaxiOrderType),
      currency: currency == _undefined || currency == null
          ? _instance.currency
          : (currency as String),
      serviceImageAddress:
          serviceImageAddress == _undefined || serviceImageAddress == null
          ? _instance.serviceImageAddress
          : (serviceImageAddress as String),
      pickupEta: pickupEta == _undefined
          ? _instance.pickupEta
          : (pickupEta as DateTime?),
      dropoffEta: dropoffEta == _undefined
          ? _instance.dropoffEta
          : (dropoffEta as DateTime?),
      waitMinutes: waitMinutes == _undefined
          ? _instance.waitMinutes
          : (waitMinutes as int?),
      directions: directions == _undefined || directions == null
          ? _instance.directions
          : (directions as List<Fragment$Coordinate>),
      estimatedDistance:
          estimatedDistance == _undefined || estimatedDistance == null
          ? _instance.estimatedDistance
          : (estimatedDistance as int),
      estimatedDuration:
          estimatedDuration == _undefined || estimatedDuration == null
          ? _instance.estimatedDuration
          : (estimatedDuration as int),
      createdAt: createdAt == _undefined || createdAt == null
          ? _instance.createdAt
          : (createdAt as DateTime),
      scheduledAt: scheduledAt == _undefined
          ? _instance.scheduledAt
          : (scheduledAt as DateTime?),
      options: options == _undefined || options == null
          ? _instance.options
          : (options as List<Fragment$PastOrder$options>),
      driver: driver == _undefined
          ? _instance.driver
          : (driver as Fragment$PastOrderDriver?),
      status: status == _undefined || status == null
          ? _instance.status
          : (status as Enum$OrderStatus),
      totalCost: totalCost == _undefined || totalCost == null
          ? _instance.totalCost
          : (totalCost as double),
      couponDiscount: couponDiscount == _undefined
          ? _instance.couponDiscount
          : (couponDiscount as double?),
      paymentMethod: paymentMethod == _undefined || paymentMethod == null
          ? _instance.paymentMethod
          : (paymentMethod as Fragment$PaymentMethod),
      waypoints: waypoints == _undefined || waypoints == null
          ? _instance.waypoints
          : (waypoints as List<Fragment$Waypoint>),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  TRes directions(
    Iterable<Fragment$Coordinate> Function(
      Iterable<CopyWith$Fragment$Coordinate<Fragment$Coordinate>>,
    )
    _fn,
  ) => call(
    directions: _fn(
      _instance.directions.map(
        (e) => CopyWith$Fragment$Coordinate(e, (i) => i),
      ),
    ).toList(),
  );

  TRes options(
    Iterable<Fragment$PastOrder$options> Function(
      Iterable<CopyWith$Fragment$PastOrder$options<Fragment$PastOrder$options>>,
    )
    _fn,
  ) => call(
    options: _fn(
      _instance.options.map(
        (e) => CopyWith$Fragment$PastOrder$options(e, (i) => i),
      ),
    ).toList(),
  );

  CopyWith$Fragment$PastOrderDriver<TRes> get driver {
    final local$driver = _instance.driver;
    return local$driver == null
        ? CopyWith$Fragment$PastOrderDriver.stub(_then(_instance))
        : CopyWith$Fragment$PastOrderDriver(
            local$driver,
            (e) => call(driver: e),
          );
  }

  CopyWith$Fragment$PaymentMethod<TRes> get paymentMethod {
    final local$paymentMethod = _instance.paymentMethod;
    return CopyWith$Fragment$PaymentMethod(
      local$paymentMethod,
      (e) => call(paymentMethod: e),
    );
  }

  TRes waypoints(
    Iterable<Fragment$Waypoint> Function(
      Iterable<CopyWith$Fragment$Waypoint<Fragment$Waypoint>>,
    )
    _fn,
  ) => call(
    waypoints: _fn(
      _instance.waypoints.map((e) => CopyWith$Fragment$Waypoint(e, (i) => i)),
    ).toList(),
  );
}

class _CopyWithStubImpl$Fragment$PastOrder<TRes>
    implements CopyWith$Fragment$PastOrder<TRes> {
  _CopyWithStubImpl$Fragment$PastOrder(this._res);

  TRes _res;

  call({
    String? id,
    String? serviceName,
    Enum$TaxiOrderType? type,
    String? currency,
    String? serviceImageAddress,
    DateTime? pickupEta,
    DateTime? dropoffEta,
    int? waitMinutes,
    List<Fragment$Coordinate>? directions,
    int? estimatedDistance,
    int? estimatedDuration,
    DateTime? createdAt,
    DateTime? scheduledAt,
    List<Fragment$PastOrder$options>? options,
    Fragment$PastOrderDriver? driver,
    Enum$OrderStatus? status,
    double? totalCost,
    double? couponDiscount,
    Fragment$PaymentMethod? paymentMethod,
    List<Fragment$Waypoint>? waypoints,
    String? $__typename,
  }) => _res;

  directions(_fn) => _res;

  options(_fn) => _res;

  CopyWith$Fragment$PastOrderDriver<TRes> get driver =>
      CopyWith$Fragment$PastOrderDriver.stub(_res);

  CopyWith$Fragment$PaymentMethod<TRes> get paymentMethod =>
      CopyWith$Fragment$PaymentMethod.stub(_res);

  waypoints(_fn) => _res;
}

const fragmentDefinitionPastOrder = FragmentDefinitionNode(
  name: NameNode(value: 'PastOrder'),
  typeCondition: TypeConditionNode(
    on: NamedTypeNode(name: NameNode(value: 'PastOrder'), isNonNull: false),
  ),
  directives: [],
  selectionSet: SelectionSetNode(
    selections: [
      FieldNode(
        name: NameNode(value: 'id'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'serviceName'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'type'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'currency'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'serviceImageAddress'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'pickupEta'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'dropoffEta'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'waitMinutes'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'directions'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: SelectionSetNode(
          selections: [
            FragmentSpreadNode(
              name: NameNode(value: 'Coordinate'),
              directives: [],
            ),
            FieldNode(
              name: NameNode(value: '__typename'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
          ],
        ),
      ),
      FieldNode(
        name: NameNode(value: 'estimatedDistance'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'estimatedDuration'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'createdAt'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'scheduledAt'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'options'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: SelectionSetNode(
          selections: [
            FieldNode(
              name: NameNode(value: 'icon'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
            FieldNode(
              name: NameNode(value: 'name'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
            FieldNode(
              name: NameNode(value: '__typename'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
          ],
        ),
      ),
      FieldNode(
        name: NameNode(value: 'driver'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: SelectionSetNode(
          selections: [
            FragmentSpreadNode(
              name: NameNode(value: 'PastOrderDriver'),
              directives: [],
            ),
            FieldNode(
              name: NameNode(value: '__typename'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
          ],
        ),
      ),
      FieldNode(
        name: NameNode(value: 'status'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'totalCost'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'couponDiscount'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'paymentMethod'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: SelectionSetNode(
          selections: [
            FragmentSpreadNode(
              name: NameNode(value: 'PaymentMethod'),
              directives: [],
            ),
            FieldNode(
              name: NameNode(value: '__typename'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
          ],
        ),
      ),
      FieldNode(
        name: NameNode(value: 'waypoints'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: SelectionSetNode(
          selections: [
            FragmentSpreadNode(
              name: NameNode(value: 'Waypoint'),
              directives: [],
            ),
            FieldNode(
              name: NameNode(value: '__typename'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
          ],
        ),
      ),
      FieldNode(
        name: NameNode(value: '__typename'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
    ],
  ),
);
const documentNodeFragmentPastOrder = DocumentNode(
  definitions: [
    fragmentDefinitionPastOrder,
    fragmentDefinitionCoordinate,
    fragmentDefinitionPastOrderDriver,
    fragmentDefinitionPaymentMethod,
    fragmentDefinitionSavedAccount,
    fragmentDefinitionOnlinePaymentMethod,
    fragmentDefinitionWaypoint,
    fragmentDefinitionRideWaypoint,
    fragmentDefinitionDeliveryWaypoint,
    fragmentDefinitionPhoneNumber,
    fragmentDefinitionShopWaypoint,
  ],
);

extension ClientExtension$Fragment$PastOrder on graphql.GraphQLClient {
  void writeFragment$PastOrder({
    required Fragment$PastOrder data,
    required Map<String, dynamic> idFields,
    bool broadcast = true,
  }) => this.writeFragment(
    graphql.FragmentRequest(
      idFields: idFields,
      fragment: const graphql.Fragment(
        fragmentName: 'PastOrder',
        document: documentNodeFragmentPastOrder,
      ),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Fragment$PastOrder? readFragment$PastOrder({
    required Map<String, dynamic> idFields,
    bool optimistic = true,
  }) {
    final result = this.readFragment(
      graphql.FragmentRequest(
        idFields: idFields,
        fragment: const graphql.Fragment(
          fragmentName: 'PastOrder',
          document: documentNodeFragmentPastOrder,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Fragment$PastOrder.fromJson(result);
  }
}

class Fragment$PastOrder$options {
  Fragment$PastOrder$options({
    required this.icon,
    required this.name,
    this.$__typename = 'RideOption',
  });

  factory Fragment$PastOrder$options.fromJson(Map<String, dynamic> json) {
    final l$icon = json['icon'];
    final l$name = json['name'];
    final l$$__typename = json['__typename'];
    return Fragment$PastOrder$options(
      icon: fromJson$Enum$ServiceOptionIcon((l$icon as String)),
      name: (l$name as String),
      $__typename: (l$$__typename as String),
    );
  }

  final Enum$ServiceOptionIcon icon;

  final String name;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$icon = icon;
    _resultData['icon'] = toJson$Enum$ServiceOptionIcon(l$icon);
    final l$name = name;
    _resultData['name'] = l$name;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$icon = icon;
    final l$name = name;
    final l$$__typename = $__typename;
    return Object.hashAll([l$icon, l$name, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$PastOrder$options ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$icon = icon;
    final lOther$icon = other.icon;
    if (l$icon != lOther$icon) {
      return false;
    }
    final l$name = name;
    final lOther$name = other.name;
    if (l$name != lOther$name) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$PastOrder$options
    on Fragment$PastOrder$options {
  CopyWith$Fragment$PastOrder$options<Fragment$PastOrder$options>
  get copyWith => CopyWith$Fragment$PastOrder$options(this, (i) => i);
}

abstract class CopyWith$Fragment$PastOrder$options<TRes> {
  factory CopyWith$Fragment$PastOrder$options(
    Fragment$PastOrder$options instance,
    TRes Function(Fragment$PastOrder$options) then,
  ) = _CopyWithImpl$Fragment$PastOrder$options;

  factory CopyWith$Fragment$PastOrder$options.stub(TRes res) =
      _CopyWithStubImpl$Fragment$PastOrder$options;

  TRes call({Enum$ServiceOptionIcon? icon, String? name, String? $__typename});
}

class _CopyWithImpl$Fragment$PastOrder$options<TRes>
    implements CopyWith$Fragment$PastOrder$options<TRes> {
  _CopyWithImpl$Fragment$PastOrder$options(this._instance, this._then);

  final Fragment$PastOrder$options _instance;

  final TRes Function(Fragment$PastOrder$options) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? icon = _undefined,
    Object? name = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Fragment$PastOrder$options(
      icon: icon == _undefined || icon == null
          ? _instance.icon
          : (icon as Enum$ServiceOptionIcon),
      name: name == _undefined || name == null
          ? _instance.name
          : (name as String),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );
}

class _CopyWithStubImpl$Fragment$PastOrder$options<TRes>
    implements CopyWith$Fragment$PastOrder$options<TRes> {
  _CopyWithStubImpl$Fragment$PastOrder$options(this._res);

  TRes _res;

  call({Enum$ServiceOptionIcon? icon, String? name, String? $__typename}) =>
      _res;
}
