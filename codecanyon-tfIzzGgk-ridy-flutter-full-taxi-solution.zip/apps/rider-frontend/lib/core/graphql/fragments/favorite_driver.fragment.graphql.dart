import 'package:gql/ast.dart';
import 'package:graphql/client.dart' as graphql;

class Fragment$FavoriteDriver {
  Fragment$FavoriteDriver({
    required this.id,
    this.fullName,
    this.profileImageUrl,
    this.rating,
    this.mobileNumber,
    this.vehicleName,
    this.vehicleColor,
    this.vehiclePlate,
    this.$__typename = 'PastOrderDriver',
  });

  factory Fragment$FavoriteDriver.fromJson(Map<String, dynamic> json) {
    final l$id = json['id'];
    final l$fullName = json['fullName'];
    final l$profileImageUrl = json['profileImageUrl'];
    final l$rating = json['rating'];
    final l$mobileNumber = json['mobileNumber'];
    final l$vehicleName = json['vehicleName'];
    final l$vehicleColor = json['vehicleColor'];
    final l$vehiclePlate = json['vehiclePlate'];
    final l$$__typename = json['__typename'];
    return Fragment$FavoriteDriver(
      id: (l$id as String),
      fullName: (l$fullName as String?),
      profileImageUrl: (l$profileImageUrl as String?),
      rating: (l$rating as int?),
      mobileNumber: (l$mobileNumber as String?),
      vehicleName: (l$vehicleName as String?),
      vehicleColor: (l$vehicleColor as String?),
      vehiclePlate: (l$vehiclePlate as String?),
      $__typename: (l$$__typename as String),
    );
  }

  final String id;

  final String? fullName;

  final String? profileImageUrl;

  final int? rating;

  final String? mobileNumber;

  final String? vehicleName;

  final String? vehicleColor;

  final String? vehiclePlate;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$id = id;
    _resultData['id'] = l$id;
    final l$fullName = fullName;
    _resultData['fullName'] = l$fullName;
    final l$profileImageUrl = profileImageUrl;
    _resultData['profileImageUrl'] = l$profileImageUrl;
    final l$rating = rating;
    _resultData['rating'] = l$rating;
    final l$mobileNumber = mobileNumber;
    _resultData['mobileNumber'] = l$mobileNumber;
    final l$vehicleName = vehicleName;
    _resultData['vehicleName'] = l$vehicleName;
    final l$vehicleColor = vehicleColor;
    _resultData['vehicleColor'] = l$vehicleColor;
    final l$vehiclePlate = vehiclePlate;
    _resultData['vehiclePlate'] = l$vehiclePlate;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$id = id;
    final l$fullName = fullName;
    final l$profileImageUrl = profileImageUrl;
    final l$rating = rating;
    final l$mobileNumber = mobileNumber;
    final l$vehicleName = vehicleName;
    final l$vehicleColor = vehicleColor;
    final l$vehiclePlate = vehiclePlate;
    final l$$__typename = $__typename;
    return Object.hashAll([
      l$id,
      l$fullName,
      l$profileImageUrl,
      l$rating,
      l$mobileNumber,
      l$vehicleName,
      l$vehicleColor,
      l$vehiclePlate,
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$FavoriteDriver || runtimeType != other.runtimeType) {
      return false;
    }
    final l$id = id;
    final lOther$id = other.id;
    if (l$id != lOther$id) {
      return false;
    }
    final l$fullName = fullName;
    final lOther$fullName = other.fullName;
    if (l$fullName != lOther$fullName) {
      return false;
    }
    final l$profileImageUrl = profileImageUrl;
    final lOther$profileImageUrl = other.profileImageUrl;
    if (l$profileImageUrl != lOther$profileImageUrl) {
      return false;
    }
    final l$rating = rating;
    final lOther$rating = other.rating;
    if (l$rating != lOther$rating) {
      return false;
    }
    final l$mobileNumber = mobileNumber;
    final lOther$mobileNumber = other.mobileNumber;
    if (l$mobileNumber != lOther$mobileNumber) {
      return false;
    }
    final l$vehicleName = vehicleName;
    final lOther$vehicleName = other.vehicleName;
    if (l$vehicleName != lOther$vehicleName) {
      return false;
    }
    final l$vehicleColor = vehicleColor;
    final lOther$vehicleColor = other.vehicleColor;
    if (l$vehicleColor != lOther$vehicleColor) {
      return false;
    }
    final l$vehiclePlate = vehiclePlate;
    final lOther$vehiclePlate = other.vehiclePlate;
    if (l$vehiclePlate != lOther$vehiclePlate) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$FavoriteDriver on Fragment$FavoriteDriver {
  CopyWith$Fragment$FavoriteDriver<Fragment$FavoriteDriver> get copyWith =>
      CopyWith$Fragment$FavoriteDriver(this, (i) => i);
}

abstract class CopyWith$Fragment$FavoriteDriver<TRes> {
  factory CopyWith$Fragment$FavoriteDriver(
    Fragment$FavoriteDriver instance,
    TRes Function(Fragment$FavoriteDriver) then,
  ) = _CopyWithImpl$Fragment$FavoriteDriver;

  factory CopyWith$Fragment$FavoriteDriver.stub(TRes res) =
      _CopyWithStubImpl$Fragment$FavoriteDriver;

  TRes call({
    String? id,
    String? fullName,
    String? profileImageUrl,
    int? rating,
    String? mobileNumber,
    String? vehicleName,
    String? vehicleColor,
    String? vehiclePlate,
    String? $__typename,
  });
}

class _CopyWithImpl$Fragment$FavoriteDriver<TRes>
    implements CopyWith$Fragment$FavoriteDriver<TRes> {
  _CopyWithImpl$Fragment$FavoriteDriver(this._instance, this._then);

  final Fragment$FavoriteDriver _instance;

  final TRes Function(Fragment$FavoriteDriver) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? id = _undefined,
    Object? fullName = _undefined,
    Object? profileImageUrl = _undefined,
    Object? rating = _undefined,
    Object? mobileNumber = _undefined,
    Object? vehicleName = _undefined,
    Object? vehicleColor = _undefined,
    Object? vehiclePlate = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Fragment$FavoriteDriver(
      id: id == _undefined || id == null ? _instance.id : (id as String),
      fullName: fullName == _undefined
          ? _instance.fullName
          : (fullName as String?),
      profileImageUrl: profileImageUrl == _undefined
          ? _instance.profileImageUrl
          : (profileImageUrl as String?),
      rating: rating == _undefined ? _instance.rating : (rating as int?),
      mobileNumber: mobileNumber == _undefined
          ? _instance.mobileNumber
          : (mobileNumber as String?),
      vehicleName: vehicleName == _undefined
          ? _instance.vehicleName
          : (vehicleName as String?),
      vehicleColor: vehicleColor == _undefined
          ? _instance.vehicleColor
          : (vehicleColor as String?),
      vehiclePlate: vehiclePlate == _undefined
          ? _instance.vehiclePlate
          : (vehiclePlate as String?),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );
}

class _CopyWithStubImpl$Fragment$FavoriteDriver<TRes>
    implements CopyWith$Fragment$FavoriteDriver<TRes> {
  _CopyWithStubImpl$Fragment$FavoriteDriver(this._res);

  TRes _res;

  call({
    String? id,
    String? fullName,
    String? profileImageUrl,
    int? rating,
    String? mobileNumber,
    String? vehicleName,
    String? vehicleColor,
    String? vehiclePlate,
    String? $__typename,
  }) => _res;
}

const fragmentDefinitionFavoriteDriver = FragmentDefinitionNode(
  name: NameNode(value: 'FavoriteDriver'),
  typeCondition: TypeConditionNode(
    on: NamedTypeNode(
      name: NameNode(value: 'PastOrderDriver'),
      isNonNull: false,
    ),
  ),
  directives: [],
  selectionSet: SelectionSetNode(
    selections: [
      FieldNode(
        name: NameNode(value: 'id'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'fullName'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'profileImageUrl'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'rating'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'mobileNumber'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'vehicleName'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'vehicleColor'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'vehiclePlate'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'vehicleName'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: '__typename'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
    ],
  ),
);
const documentNodeFragmentFavoriteDriver = DocumentNode(
  definitions: [fragmentDefinitionFavoriteDriver],
);

extension ClientExtension$Fragment$FavoriteDriver on graphql.GraphQLClient {
  void writeFragment$FavoriteDriver({
    required Fragment$FavoriteDriver data,
    required Map<String, dynamic> idFields,
    bool broadcast = true,
  }) => this.writeFragment(
    graphql.FragmentRequest(
      idFields: idFields,
      fragment: const graphql.Fragment(
        fragmentName: 'FavoriteDriver',
        document: documentNodeFragmentFavoriteDriver,
      ),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Fragment$FavoriteDriver? readFragment$FavoriteDriver({
    required Map<String, dynamic> idFields,
    bool optimistic = true,
  }) {
    final result = this.readFragment(
      graphql.FragmentRequest(
        idFields: idFields,
        fragment: const graphql.Fragment(
          fragmentName: 'FavoriteDriver',
          document: documentNodeFragmentFavoriteDriver,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Fragment$FavoriteDriver.fromJson(result);
  }
}
