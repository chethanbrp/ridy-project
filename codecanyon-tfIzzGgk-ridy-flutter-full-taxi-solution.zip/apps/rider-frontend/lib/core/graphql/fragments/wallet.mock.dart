import 'package:rider_flutter/core/graphql/fragments/wallet.fragment.graphql.dart';

final mockWallet1 = Fragment$Wallet(
  balance: 100.0,
  currency: 'USD',
);
