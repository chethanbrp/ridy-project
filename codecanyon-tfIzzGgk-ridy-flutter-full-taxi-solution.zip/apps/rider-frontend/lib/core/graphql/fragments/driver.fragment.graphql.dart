import 'package:gql/ast.dart';
import 'package:graphql/client.dart' as graphql;
import 'point.fragment.graphql.dart';

class Fragment$ActiveOrderDriver {
  Fragment$ActiveOrderDriver({
    this.fullName,
    this.location,
    this.profileImageUrl,
    this.rating,
    this.mobileNumber,
    this.vehicleName,
    this.vehicleColor,
    this.vehiclePlate,
    this.$__typename = 'ActiveOrderDriver',
  });

  factory Fragment$ActiveOrderDriver.fromJson(Map<String, dynamic> json) {
    final l$fullName = json['fullName'];
    final l$location = json['location'];
    final l$profileImageUrl = json['profileImageUrl'];
    final l$rating = json['rating'];
    final l$mobileNumber = json['mobileNumber'];
    final l$vehicleName = json['vehicleName'];
    final l$vehicleColor = json['vehicleColor'];
    final l$vehiclePlate = json['vehiclePlate'];
    final l$$__typename = json['__typename'];
    return Fragment$ActiveOrderDriver(
      fullName: (l$fullName as String?),
      location: l$location == null
          ? null
          : Fragment$Coordinate.fromJson((l$location as Map<String, dynamic>)),
      profileImageUrl: (l$profileImageUrl as String?),
      rating: (l$rating as int?),
      mobileNumber: (l$mobileNumber as String?),
      vehicleName: (l$vehicleName as String?),
      vehicleColor: (l$vehicleColor as String?),
      vehiclePlate: (l$vehiclePlate as String?),
      $__typename: (l$$__typename as String),
    );
  }

  final String? fullName;

  final Fragment$Coordinate? location;

  final String? profileImageUrl;

  final int? rating;

  final String? mobileNumber;

  final String? vehicleName;

  final String? vehicleColor;

  final String? vehiclePlate;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$fullName = fullName;
    _resultData['fullName'] = l$fullName;
    final l$location = location;
    _resultData['location'] = l$location?.toJson();
    final l$profileImageUrl = profileImageUrl;
    _resultData['profileImageUrl'] = l$profileImageUrl;
    final l$rating = rating;
    _resultData['rating'] = l$rating;
    final l$mobileNumber = mobileNumber;
    _resultData['mobileNumber'] = l$mobileNumber;
    final l$vehicleName = vehicleName;
    _resultData['vehicleName'] = l$vehicleName;
    final l$vehicleColor = vehicleColor;
    _resultData['vehicleColor'] = l$vehicleColor;
    final l$vehiclePlate = vehiclePlate;
    _resultData['vehiclePlate'] = l$vehiclePlate;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$fullName = fullName;
    final l$location = location;
    final l$profileImageUrl = profileImageUrl;
    final l$rating = rating;
    final l$mobileNumber = mobileNumber;
    final l$vehicleName = vehicleName;
    final l$vehicleColor = vehicleColor;
    final l$vehiclePlate = vehiclePlate;
    final l$$__typename = $__typename;
    return Object.hashAll([
      l$fullName,
      l$location,
      l$profileImageUrl,
      l$rating,
      l$mobileNumber,
      l$vehicleName,
      l$vehicleColor,
      l$vehiclePlate,
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$ActiveOrderDriver ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$fullName = fullName;
    final lOther$fullName = other.fullName;
    if (l$fullName != lOther$fullName) {
      return false;
    }
    final l$location = location;
    final lOther$location = other.location;
    if (l$location != lOther$location) {
      return false;
    }
    final l$profileImageUrl = profileImageUrl;
    final lOther$profileImageUrl = other.profileImageUrl;
    if (l$profileImageUrl != lOther$profileImageUrl) {
      return false;
    }
    final l$rating = rating;
    final lOther$rating = other.rating;
    if (l$rating != lOther$rating) {
      return false;
    }
    final l$mobileNumber = mobileNumber;
    final lOther$mobileNumber = other.mobileNumber;
    if (l$mobileNumber != lOther$mobileNumber) {
      return false;
    }
    final l$vehicleName = vehicleName;
    final lOther$vehicleName = other.vehicleName;
    if (l$vehicleName != lOther$vehicleName) {
      return false;
    }
    final l$vehicleColor = vehicleColor;
    final lOther$vehicleColor = other.vehicleColor;
    if (l$vehicleColor != lOther$vehicleColor) {
      return false;
    }
    final l$vehiclePlate = vehiclePlate;
    final lOther$vehiclePlate = other.vehiclePlate;
    if (l$vehiclePlate != lOther$vehiclePlate) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$ActiveOrderDriver
    on Fragment$ActiveOrderDriver {
  CopyWith$Fragment$ActiveOrderDriver<Fragment$ActiveOrderDriver>
  get copyWith => CopyWith$Fragment$ActiveOrderDriver(this, (i) => i);
}

abstract class CopyWith$Fragment$ActiveOrderDriver<TRes> {
  factory CopyWith$Fragment$ActiveOrderDriver(
    Fragment$ActiveOrderDriver instance,
    TRes Function(Fragment$ActiveOrderDriver) then,
  ) = _CopyWithImpl$Fragment$ActiveOrderDriver;

  factory CopyWith$Fragment$ActiveOrderDriver.stub(TRes res) =
      _CopyWithStubImpl$Fragment$ActiveOrderDriver;

  TRes call({
    String? fullName,
    Fragment$Coordinate? location,
    String? profileImageUrl,
    int? rating,
    String? mobileNumber,
    String? vehicleName,
    String? vehicleColor,
    String? vehiclePlate,
    String? $__typename,
  });
  CopyWith$Fragment$Coordinate<TRes> get location;
}

class _CopyWithImpl$Fragment$ActiveOrderDriver<TRes>
    implements CopyWith$Fragment$ActiveOrderDriver<TRes> {
  _CopyWithImpl$Fragment$ActiveOrderDriver(this._instance, this._then);

  final Fragment$ActiveOrderDriver _instance;

  final TRes Function(Fragment$ActiveOrderDriver) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? fullName = _undefined,
    Object? location = _undefined,
    Object? profileImageUrl = _undefined,
    Object? rating = _undefined,
    Object? mobileNumber = _undefined,
    Object? vehicleName = _undefined,
    Object? vehicleColor = _undefined,
    Object? vehiclePlate = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Fragment$ActiveOrderDriver(
      fullName: fullName == _undefined
          ? _instance.fullName
          : (fullName as String?),
      location: location == _undefined
          ? _instance.location
          : (location as Fragment$Coordinate?),
      profileImageUrl: profileImageUrl == _undefined
          ? _instance.profileImageUrl
          : (profileImageUrl as String?),
      rating: rating == _undefined ? _instance.rating : (rating as int?),
      mobileNumber: mobileNumber == _undefined
          ? _instance.mobileNumber
          : (mobileNumber as String?),
      vehicleName: vehicleName == _undefined
          ? _instance.vehicleName
          : (vehicleName as String?),
      vehicleColor: vehicleColor == _undefined
          ? _instance.vehicleColor
          : (vehicleColor as String?),
      vehiclePlate: vehiclePlate == _undefined
          ? _instance.vehiclePlate
          : (vehiclePlate as String?),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  CopyWith$Fragment$Coordinate<TRes> get location {
    final local$location = _instance.location;
    return local$location == null
        ? CopyWith$Fragment$Coordinate.stub(_then(_instance))
        : CopyWith$Fragment$Coordinate(
            local$location,
            (e) => call(location: e),
          );
  }
}

class _CopyWithStubImpl$Fragment$ActiveOrderDriver<TRes>
    implements CopyWith$Fragment$ActiveOrderDriver<TRes> {
  _CopyWithStubImpl$Fragment$ActiveOrderDriver(this._res);

  TRes _res;

  call({
    String? fullName,
    Fragment$Coordinate? location,
    String? profileImageUrl,
    int? rating,
    String? mobileNumber,
    String? vehicleName,
    String? vehicleColor,
    String? vehiclePlate,
    String? $__typename,
  }) => _res;

  CopyWith$Fragment$Coordinate<TRes> get location =>
      CopyWith$Fragment$Coordinate.stub(_res);
}

const fragmentDefinitionActiveOrderDriver = FragmentDefinitionNode(
  name: NameNode(value: 'ActiveOrderDriver'),
  typeCondition: TypeConditionNode(
    on: NamedTypeNode(
      name: NameNode(value: 'ActiveOrderDriver'),
      isNonNull: false,
    ),
  ),
  directives: [],
  selectionSet: SelectionSetNode(
    selections: [
      FieldNode(
        name: NameNode(value: 'fullName'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'location'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: SelectionSetNode(
          selections: [
            FragmentSpreadNode(
              name: NameNode(value: 'Coordinate'),
              directives: [],
            ),
            FieldNode(
              name: NameNode(value: '__typename'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
          ],
        ),
      ),
      FieldNode(
        name: NameNode(value: 'profileImageUrl'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'rating'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'mobileNumber'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'vehicleName'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'vehicleColor'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'vehiclePlate'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'vehicleName'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: '__typename'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
    ],
  ),
);
const documentNodeFragmentActiveOrderDriver = DocumentNode(
  definitions: [
    fragmentDefinitionActiveOrderDriver,
    fragmentDefinitionCoordinate,
  ],
);

extension ClientExtension$Fragment$ActiveOrderDriver on graphql.GraphQLClient {
  void writeFragment$ActiveOrderDriver({
    required Fragment$ActiveOrderDriver data,
    required Map<String, dynamic> idFields,
    bool broadcast = true,
  }) => this.writeFragment(
    graphql.FragmentRequest(
      idFields: idFields,
      fragment: const graphql.Fragment(
        fragmentName: 'ActiveOrderDriver',
        document: documentNodeFragmentActiveOrderDriver,
      ),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Fragment$ActiveOrderDriver? readFragment$ActiveOrderDriver({
    required Map<String, dynamic> idFields,
    bool optimistic = true,
  }) {
    final result = this.readFragment(
      graphql.FragmentRequest(
        idFields: idFields,
        fragment: const graphql.Fragment(
          fragmentName: 'ActiveOrderDriver',
          document: documentNodeFragmentActiveOrderDriver,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Fragment$ActiveOrderDriver.fromJson(result);
  }
}

class Fragment$PastOrderDriver {
  Fragment$PastOrderDriver({
    this.fullName,
    this.profileImageUrl,
    this.rating,
    this.mobileNumber,
    this.vehicleName,
    this.vehicleColor,
    this.vehiclePlate,
    this.$__typename = 'PastOrderDriver',
  });

  factory Fragment$PastOrderDriver.fromJson(Map<String, dynamic> json) {
    final l$fullName = json['fullName'];
    final l$profileImageUrl = json['profileImageUrl'];
    final l$rating = json['rating'];
    final l$mobileNumber = json['mobileNumber'];
    final l$vehicleName = json['vehicleName'];
    final l$vehicleColor = json['vehicleColor'];
    final l$vehiclePlate = json['vehiclePlate'];
    final l$$__typename = json['__typename'];
    return Fragment$PastOrderDriver(
      fullName: (l$fullName as String?),
      profileImageUrl: (l$profileImageUrl as String?),
      rating: (l$rating as int?),
      mobileNumber: (l$mobileNumber as String?),
      vehicleName: (l$vehicleName as String?),
      vehicleColor: (l$vehicleColor as String?),
      vehiclePlate: (l$vehiclePlate as String?),
      $__typename: (l$$__typename as String),
    );
  }

  final String? fullName;

  final String? profileImageUrl;

  final int? rating;

  final String? mobileNumber;

  final String? vehicleName;

  final String? vehicleColor;

  final String? vehiclePlate;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$fullName = fullName;
    _resultData['fullName'] = l$fullName;
    final l$profileImageUrl = profileImageUrl;
    _resultData['profileImageUrl'] = l$profileImageUrl;
    final l$rating = rating;
    _resultData['rating'] = l$rating;
    final l$mobileNumber = mobileNumber;
    _resultData['mobileNumber'] = l$mobileNumber;
    final l$vehicleName = vehicleName;
    _resultData['vehicleName'] = l$vehicleName;
    final l$vehicleColor = vehicleColor;
    _resultData['vehicleColor'] = l$vehicleColor;
    final l$vehiclePlate = vehiclePlate;
    _resultData['vehiclePlate'] = l$vehiclePlate;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$fullName = fullName;
    final l$profileImageUrl = profileImageUrl;
    final l$rating = rating;
    final l$mobileNumber = mobileNumber;
    final l$vehicleName = vehicleName;
    final l$vehicleColor = vehicleColor;
    final l$vehiclePlate = vehiclePlate;
    final l$$__typename = $__typename;
    return Object.hashAll([
      l$fullName,
      l$profileImageUrl,
      l$rating,
      l$mobileNumber,
      l$vehicleName,
      l$vehicleColor,
      l$vehiclePlate,
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$PastOrderDriver ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$fullName = fullName;
    final lOther$fullName = other.fullName;
    if (l$fullName != lOther$fullName) {
      return false;
    }
    final l$profileImageUrl = profileImageUrl;
    final lOther$profileImageUrl = other.profileImageUrl;
    if (l$profileImageUrl != lOther$profileImageUrl) {
      return false;
    }
    final l$rating = rating;
    final lOther$rating = other.rating;
    if (l$rating != lOther$rating) {
      return false;
    }
    final l$mobileNumber = mobileNumber;
    final lOther$mobileNumber = other.mobileNumber;
    if (l$mobileNumber != lOther$mobileNumber) {
      return false;
    }
    final l$vehicleName = vehicleName;
    final lOther$vehicleName = other.vehicleName;
    if (l$vehicleName != lOther$vehicleName) {
      return false;
    }
    final l$vehicleColor = vehicleColor;
    final lOther$vehicleColor = other.vehicleColor;
    if (l$vehicleColor != lOther$vehicleColor) {
      return false;
    }
    final l$vehiclePlate = vehiclePlate;
    final lOther$vehiclePlate = other.vehiclePlate;
    if (l$vehiclePlate != lOther$vehiclePlate) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$PastOrderDriver
    on Fragment$PastOrderDriver {
  CopyWith$Fragment$PastOrderDriver<Fragment$PastOrderDriver> get copyWith =>
      CopyWith$Fragment$PastOrderDriver(this, (i) => i);
}

abstract class CopyWith$Fragment$PastOrderDriver<TRes> {
  factory CopyWith$Fragment$PastOrderDriver(
    Fragment$PastOrderDriver instance,
    TRes Function(Fragment$PastOrderDriver) then,
  ) = _CopyWithImpl$Fragment$PastOrderDriver;

  factory CopyWith$Fragment$PastOrderDriver.stub(TRes res) =
      _CopyWithStubImpl$Fragment$PastOrderDriver;

  TRes call({
    String? fullName,
    String? profileImageUrl,
    int? rating,
    String? mobileNumber,
    String? vehicleName,
    String? vehicleColor,
    String? vehiclePlate,
    String? $__typename,
  });
}

class _CopyWithImpl$Fragment$PastOrderDriver<TRes>
    implements CopyWith$Fragment$PastOrderDriver<TRes> {
  _CopyWithImpl$Fragment$PastOrderDriver(this._instance, this._then);

  final Fragment$PastOrderDriver _instance;

  final TRes Function(Fragment$PastOrderDriver) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? fullName = _undefined,
    Object? profileImageUrl = _undefined,
    Object? rating = _undefined,
    Object? mobileNumber = _undefined,
    Object? vehicleName = _undefined,
    Object? vehicleColor = _undefined,
    Object? vehiclePlate = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Fragment$PastOrderDriver(
      fullName: fullName == _undefined
          ? _instance.fullName
          : (fullName as String?),
      profileImageUrl: profileImageUrl == _undefined
          ? _instance.profileImageUrl
          : (profileImageUrl as String?),
      rating: rating == _undefined ? _instance.rating : (rating as int?),
      mobileNumber: mobileNumber == _undefined
          ? _instance.mobileNumber
          : (mobileNumber as String?),
      vehicleName: vehicleName == _undefined
          ? _instance.vehicleName
          : (vehicleName as String?),
      vehicleColor: vehicleColor == _undefined
          ? _instance.vehicleColor
          : (vehicleColor as String?),
      vehiclePlate: vehiclePlate == _undefined
          ? _instance.vehiclePlate
          : (vehiclePlate as String?),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );
}

class _CopyWithStubImpl$Fragment$PastOrderDriver<TRes>
    implements CopyWith$Fragment$PastOrderDriver<TRes> {
  _CopyWithStubImpl$Fragment$PastOrderDriver(this._res);

  TRes _res;

  call({
    String? fullName,
    String? profileImageUrl,
    int? rating,
    String? mobileNumber,
    String? vehicleName,
    String? vehicleColor,
    String? vehiclePlate,
    String? $__typename,
  }) => _res;
}

const fragmentDefinitionPastOrderDriver = FragmentDefinitionNode(
  name: NameNode(value: 'PastOrderDriver'),
  typeCondition: TypeConditionNode(
    on: NamedTypeNode(
      name: NameNode(value: 'PastOrderDriver'),
      isNonNull: false,
    ),
  ),
  directives: [],
  selectionSet: SelectionSetNode(
    selections: [
      FieldNode(
        name: NameNode(value: 'fullName'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'profileImageUrl'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'rating'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'mobileNumber'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'vehicleName'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'vehicleColor'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'vehiclePlate'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'vehicleName'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: '__typename'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
    ],
  ),
);
const documentNodeFragmentPastOrderDriver = DocumentNode(
  definitions: [fragmentDefinitionPastOrderDriver],
);

extension ClientExtension$Fragment$PastOrderDriver on graphql.GraphQLClient {
  void writeFragment$PastOrderDriver({
    required Fragment$PastOrderDriver data,
    required Map<String, dynamic> idFields,
    bool broadcast = true,
  }) => this.writeFragment(
    graphql.FragmentRequest(
      idFields: idFields,
      fragment: const graphql.Fragment(
        fragmentName: 'PastOrderDriver',
        document: documentNodeFragmentPastOrderDriver,
      ),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Fragment$PastOrderDriver? readFragment$PastOrderDriver({
    required Map<String, dynamic> idFields,
    bool optimistic = true,
  }) {
    final result = this.readFragment(
      graphql.FragmentRequest(
        idFields: idFields,
        fragment: const graphql.Fragment(
          fragmentName: 'PastOrderDriver',
          document: documentNodeFragmentPastOrderDriver,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Fragment$PastOrderDriver.fromJson(result);
  }
}
