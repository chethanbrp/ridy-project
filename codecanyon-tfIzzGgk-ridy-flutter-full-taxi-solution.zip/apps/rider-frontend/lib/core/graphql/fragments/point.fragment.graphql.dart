import '../schema.gql.dart';
import 'package:gql/ast.dart';
import 'package:graphql/client.dart' as graphql;
import 'phone_number.fragment.graphql.dart';

class Fragment$Coordinate {
  Fragment$Coordinate({
    required this.lat,
    required this.lng,
    this.heading,
    this.$__typename = 'Point',
  });

  factory Fragment$Coordinate.fromJson(Map<String, dynamic> json) {
    final l$lat = json['lat'];
    final l$lng = json['lng'];
    final l$heading = json['heading'];
    final l$$__typename = json['__typename'];
    return Fragment$Coordinate(
      lat: (l$lat as num).toDouble(),
      lng: (l$lng as num).toDouble(),
      heading: (l$heading as int?),
      $__typename: (l$$__typename as String),
    );
  }

  final double lat;

  final double lng;

  final int? heading;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$lat = lat;
    _resultData['lat'] = l$lat;
    final l$lng = lng;
    _resultData['lng'] = l$lng;
    final l$heading = heading;
    _resultData['heading'] = l$heading;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$lat = lat;
    final l$lng = lng;
    final l$heading = heading;
    final l$$__typename = $__typename;
    return Object.hashAll([l$lat, l$lng, l$heading, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$Coordinate || runtimeType != other.runtimeType) {
      return false;
    }
    final l$lat = lat;
    final lOther$lat = other.lat;
    if (l$lat != lOther$lat) {
      return false;
    }
    final l$lng = lng;
    final lOther$lng = other.lng;
    if (l$lng != lOther$lng) {
      return false;
    }
    final l$heading = heading;
    final lOther$heading = other.heading;
    if (l$heading != lOther$heading) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$Coordinate on Fragment$Coordinate {
  CopyWith$Fragment$Coordinate<Fragment$Coordinate> get copyWith =>
      CopyWith$Fragment$Coordinate(this, (i) => i);
}

abstract class CopyWith$Fragment$Coordinate<TRes> {
  factory CopyWith$Fragment$Coordinate(
    Fragment$Coordinate instance,
    TRes Function(Fragment$Coordinate) then,
  ) = _CopyWithImpl$Fragment$Coordinate;

  factory CopyWith$Fragment$Coordinate.stub(TRes res) =
      _CopyWithStubImpl$Fragment$Coordinate;

  TRes call({double? lat, double? lng, int? heading, String? $__typename});
}

class _CopyWithImpl$Fragment$Coordinate<TRes>
    implements CopyWith$Fragment$Coordinate<TRes> {
  _CopyWithImpl$Fragment$Coordinate(this._instance, this._then);

  final Fragment$Coordinate _instance;

  final TRes Function(Fragment$Coordinate) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? lat = _undefined,
    Object? lng = _undefined,
    Object? heading = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Fragment$Coordinate(
      lat: lat == _undefined || lat == null ? _instance.lat : (lat as double),
      lng: lng == _undefined || lng == null ? _instance.lng : (lng as double),
      heading: heading == _undefined ? _instance.heading : (heading as int?),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );
}

class _CopyWithStubImpl$Fragment$Coordinate<TRes>
    implements CopyWith$Fragment$Coordinate<TRes> {
  _CopyWithStubImpl$Fragment$Coordinate(this._res);

  TRes _res;

  call({double? lat, double? lng, int? heading, String? $__typename}) => _res;
}

const fragmentDefinitionCoordinate = FragmentDefinitionNode(
  name: NameNode(value: 'Coordinate'),
  typeCondition: TypeConditionNode(
    on: NamedTypeNode(name: NameNode(value: 'Point'), isNonNull: false),
  ),
  directives: [],
  selectionSet: SelectionSetNode(
    selections: [
      FieldNode(
        name: NameNode(value: 'lat'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'lng'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'heading'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: '__typename'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
    ],
  ),
);
const documentNodeFragmentCoordinate = DocumentNode(
  definitions: [fragmentDefinitionCoordinate],
);

extension ClientExtension$Fragment$Coordinate on graphql.GraphQLClient {
  void writeFragment$Coordinate({
    required Fragment$Coordinate data,
    required Map<String, dynamic> idFields,
    bool broadcast = true,
  }) => this.writeFragment(
    graphql.FragmentRequest(
      idFields: idFields,
      fragment: const graphql.Fragment(
        fragmentName: 'Coordinate',
        document: documentNodeFragmentCoordinate,
      ),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Fragment$Coordinate? readFragment$Coordinate({
    required Map<String, dynamic> idFields,
    bool optimistic = true,
  }) {
    final result = this.readFragment(
      graphql.FragmentRequest(
        idFields: idFields,
        fragment: const graphql.Fragment(
          fragmentName: 'Coordinate',
          document: documentNodeFragmentCoordinate,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Fragment$Coordinate.fromJson(result);
  }
}

class Fragment$Place {
  Fragment$Place({
    required this.point,
    this.title,
    required this.address,
    this.$__typename = 'PlaceDTO',
  });

  factory Fragment$Place.fromJson(Map<String, dynamic> json) {
    final l$point = json['point'];
    final l$title = json['title'];
    final l$address = json['address'];
    final l$$__typename = json['__typename'];
    return Fragment$Place(
      point: Fragment$Coordinate.fromJson((l$point as Map<String, dynamic>)),
      title: (l$title as String?),
      address: (l$address as String),
      $__typename: (l$$__typename as String),
    );
  }

  final Fragment$Coordinate point;

  final String? title;

  final String address;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$point = point;
    _resultData['point'] = l$point.toJson();
    final l$title = title;
    _resultData['title'] = l$title;
    final l$address = address;
    _resultData['address'] = l$address;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$point = point;
    final l$title = title;
    final l$address = address;
    final l$$__typename = $__typename;
    return Object.hashAll([l$point, l$title, l$address, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$Place || runtimeType != other.runtimeType) {
      return false;
    }
    final l$point = point;
    final lOther$point = other.point;
    if (l$point != lOther$point) {
      return false;
    }
    final l$title = title;
    final lOther$title = other.title;
    if (l$title != lOther$title) {
      return false;
    }
    final l$address = address;
    final lOther$address = other.address;
    if (l$address != lOther$address) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$Place on Fragment$Place {
  CopyWith$Fragment$Place<Fragment$Place> get copyWith =>
      CopyWith$Fragment$Place(this, (i) => i);
}

abstract class CopyWith$Fragment$Place<TRes> {
  factory CopyWith$Fragment$Place(
    Fragment$Place instance,
    TRes Function(Fragment$Place) then,
  ) = _CopyWithImpl$Fragment$Place;

  factory CopyWith$Fragment$Place.stub(TRes res) =
      _CopyWithStubImpl$Fragment$Place;

  TRes call({
    Fragment$Coordinate? point,
    String? title,
    String? address,
    String? $__typename,
  });
  CopyWith$Fragment$Coordinate<TRes> get point;
}

class _CopyWithImpl$Fragment$Place<TRes>
    implements CopyWith$Fragment$Place<TRes> {
  _CopyWithImpl$Fragment$Place(this._instance, this._then);

  final Fragment$Place _instance;

  final TRes Function(Fragment$Place) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? point = _undefined,
    Object? title = _undefined,
    Object? address = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Fragment$Place(
      point: point == _undefined || point == null
          ? _instance.point
          : (point as Fragment$Coordinate),
      title: title == _undefined ? _instance.title : (title as String?),
      address: address == _undefined || address == null
          ? _instance.address
          : (address as String),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  CopyWith$Fragment$Coordinate<TRes> get point {
    final local$point = _instance.point;
    return CopyWith$Fragment$Coordinate(local$point, (e) => call(point: e));
  }
}

class _CopyWithStubImpl$Fragment$Place<TRes>
    implements CopyWith$Fragment$Place<TRes> {
  _CopyWithStubImpl$Fragment$Place(this._res);

  TRes _res;

  call({
    Fragment$Coordinate? point,
    String? title,
    String? address,
    String? $__typename,
  }) => _res;

  CopyWith$Fragment$Coordinate<TRes> get point =>
      CopyWith$Fragment$Coordinate.stub(_res);
}

const fragmentDefinitionPlace = FragmentDefinitionNode(
  name: NameNode(value: 'Place'),
  typeCondition: TypeConditionNode(
    on: NamedTypeNode(name: NameNode(value: 'PlaceDTO'), isNonNull: false),
  ),
  directives: [],
  selectionSet: SelectionSetNode(
    selections: [
      FieldNode(
        name: NameNode(value: 'point'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: SelectionSetNode(
          selections: [
            FragmentSpreadNode(
              name: NameNode(value: 'Coordinate'),
              directives: [],
            ),
            FieldNode(
              name: NameNode(value: '__typename'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
          ],
        ),
      ),
      FieldNode(
        name: NameNode(value: 'title'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'address'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: '__typename'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
    ],
  ),
);
const documentNodeFragmentPlace = DocumentNode(
  definitions: [fragmentDefinitionPlace, fragmentDefinitionCoordinate],
);

extension ClientExtension$Fragment$Place on graphql.GraphQLClient {
  void writeFragment$Place({
    required Fragment$Place data,
    required Map<String, dynamic> idFields,
    bool broadcast = true,
  }) => this.writeFragment(
    graphql.FragmentRequest(
      idFields: idFields,
      fragment: const graphql.Fragment(
        fragmentName: 'Place',
        document: documentNodeFragmentPlace,
      ),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Fragment$Place? readFragment$Place({
    required Map<String, dynamic> idFields,
    bool optimistic = true,
  }) {
    final result = this.readFragment(
      graphql.FragmentRequest(
        idFields: idFields,
        fragment: const graphql.Fragment(
          fragmentName: 'Place',
          document: documentNodeFragmentPlace,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Fragment$Place.fromJson(result);
  }
}

class Fragment$Waypoint {
  Fragment$Waypoint({
    required this.$__typename,
    required this.location,
    required this.address,
    required this.role,
  });

  factory Fragment$Waypoint.fromJson(Map<String, dynamic> json) {
    switch (json["__typename"] as String) {
      case "RideWaypoint":
        return Fragment$Waypoint$$RideWaypoint.fromJson(json);

      case "DeliveryWaypoint":
        return Fragment$Waypoint$$DeliveryWaypoint.fromJson(json);

      case "ShopWaypoint":
        return Fragment$Waypoint$$ShopWaypoint.fromJson(json);

      default:
        final l$$__typename = json['__typename'];
        final l$location = json['location'];
        final l$address = json['address'];
        final l$role = json['role'];
        return Fragment$Waypoint(
          $__typename: (l$$__typename as String),
          location: Fragment$Coordinate.fromJson(
            (l$location as Map<String, dynamic>),
          ),
          address: (l$address as String),
          role: fromJson$Enum$WaypointRole((l$role as String)),
        );
    }
  }

  final String $__typename;

  final Fragment$Coordinate location;

  final String address;

  final Enum$WaypointRole role;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    final l$location = location;
    _resultData['location'] = l$location.toJson();
    final l$address = address;
    _resultData['address'] = l$address;
    final l$role = role;
    _resultData['role'] = toJson$Enum$WaypointRole(l$role);
    return _resultData;
  }

  @override
  int get hashCode {
    final l$$__typename = $__typename;
    final l$location = location;
    final l$address = address;
    final l$role = role;
    return Object.hashAll([l$$__typename, l$location, l$address, l$role]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$Waypoint || runtimeType != other.runtimeType) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    final l$location = location;
    final lOther$location = other.location;
    if (l$location != lOther$location) {
      return false;
    }
    final l$address = address;
    final lOther$address = other.address;
    if (l$address != lOther$address) {
      return false;
    }
    final l$role = role;
    final lOther$role = other.role;
    if (l$role != lOther$role) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$Waypoint on Fragment$Waypoint {
  CopyWith$Fragment$Waypoint<Fragment$Waypoint> get copyWith =>
      CopyWith$Fragment$Waypoint(this, (i) => i);

  _T when<_T>({
    required _T Function(Fragment$Waypoint$$RideWaypoint) rideWaypoint,
    required _T Function(Fragment$Waypoint$$DeliveryWaypoint) deliveryWaypoint,
    required _T Function(Fragment$Waypoint$$ShopWaypoint) shopWaypoint,
    required _T Function() orElse,
  }) {
    switch ($__typename) {
      case "RideWaypoint":
        return rideWaypoint(this as Fragment$Waypoint$$RideWaypoint);

      case "DeliveryWaypoint":
        return deliveryWaypoint(this as Fragment$Waypoint$$DeliveryWaypoint);

      case "ShopWaypoint":
        return shopWaypoint(this as Fragment$Waypoint$$ShopWaypoint);

      default:
        return orElse();
    }
  }

  _T maybeWhen<_T>({
    _T Function(Fragment$Waypoint$$RideWaypoint)? rideWaypoint,
    _T Function(Fragment$Waypoint$$DeliveryWaypoint)? deliveryWaypoint,
    _T Function(Fragment$Waypoint$$ShopWaypoint)? shopWaypoint,
    required _T Function() orElse,
  }) {
    switch ($__typename) {
      case "RideWaypoint":
        if (rideWaypoint != null) {
          return rideWaypoint(this as Fragment$Waypoint$$RideWaypoint);
        } else {
          return orElse();
        }

      case "DeliveryWaypoint":
        if (deliveryWaypoint != null) {
          return deliveryWaypoint(this as Fragment$Waypoint$$DeliveryWaypoint);
        } else {
          return orElse();
        }

      case "ShopWaypoint":
        if (shopWaypoint != null) {
          return shopWaypoint(this as Fragment$Waypoint$$ShopWaypoint);
        } else {
          return orElse();
        }

      default:
        return orElse();
    }
  }
}

abstract class CopyWith$Fragment$Waypoint<TRes> {
  factory CopyWith$Fragment$Waypoint(
    Fragment$Waypoint instance,
    TRes Function(Fragment$Waypoint) then,
  ) = _CopyWithImpl$Fragment$Waypoint;

  factory CopyWith$Fragment$Waypoint.stub(TRes res) =
      _CopyWithStubImpl$Fragment$Waypoint;

  TRes call({
    String? $__typename,
    Fragment$Coordinate? location,
    String? address,
    Enum$WaypointRole? role,
  });
  CopyWith$Fragment$Coordinate<TRes> get location;
}

class _CopyWithImpl$Fragment$Waypoint<TRes>
    implements CopyWith$Fragment$Waypoint<TRes> {
  _CopyWithImpl$Fragment$Waypoint(this._instance, this._then);

  final Fragment$Waypoint _instance;

  final TRes Function(Fragment$Waypoint) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? $__typename = _undefined,
    Object? location = _undefined,
    Object? address = _undefined,
    Object? role = _undefined,
  }) => _then(
    Fragment$Waypoint(
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
      location: location == _undefined || location == null
          ? _instance.location
          : (location as Fragment$Coordinate),
      address: address == _undefined || address == null
          ? _instance.address
          : (address as String),
      role: role == _undefined || role == null
          ? _instance.role
          : (role as Enum$WaypointRole),
    ),
  );

  CopyWith$Fragment$Coordinate<TRes> get location {
    final local$location = _instance.location;
    return CopyWith$Fragment$Coordinate(
      local$location,
      (e) => call(location: e),
    );
  }
}

class _CopyWithStubImpl$Fragment$Waypoint<TRes>
    implements CopyWith$Fragment$Waypoint<TRes> {
  _CopyWithStubImpl$Fragment$Waypoint(this._res);

  TRes _res;

  call({
    String? $__typename,
    Fragment$Coordinate? location,
    String? address,
    Enum$WaypointRole? role,
  }) => _res;

  CopyWith$Fragment$Coordinate<TRes> get location =>
      CopyWith$Fragment$Coordinate.stub(_res);
}

const fragmentDefinitionWaypoint = FragmentDefinitionNode(
  name: NameNode(value: 'Waypoint'),
  typeCondition: TypeConditionNode(
    on: NamedTypeNode(name: NameNode(value: 'WaypointBase'), isNonNull: false),
  ),
  directives: [],
  selectionSet: SelectionSetNode(
    selections: [
      FieldNode(
        name: NameNode(value: '__typename'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'location'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: SelectionSetNode(
          selections: [
            FragmentSpreadNode(
              name: NameNode(value: 'Coordinate'),
              directives: [],
            ),
            FieldNode(
              name: NameNode(value: '__typename'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
          ],
        ),
      ),
      FieldNode(
        name: NameNode(value: 'address'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'role'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      InlineFragmentNode(
        typeCondition: TypeConditionNode(
          on: NamedTypeNode(
            name: NameNode(value: 'RideWaypoint'),
            isNonNull: false,
          ),
        ),
        directives: [],
        selectionSet: SelectionSetNode(
          selections: [
            FragmentSpreadNode(
              name: NameNode(value: 'RideWaypoint'),
              directives: [],
            ),
            FieldNode(
              name: NameNode(value: '__typename'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
          ],
        ),
      ),
      InlineFragmentNode(
        typeCondition: TypeConditionNode(
          on: NamedTypeNode(
            name: NameNode(value: 'DeliveryWaypoint'),
            isNonNull: false,
          ),
        ),
        directives: [],
        selectionSet: SelectionSetNode(
          selections: [
            FragmentSpreadNode(
              name: NameNode(value: 'DeliveryWaypoint'),
              directives: [],
            ),
            FieldNode(
              name: NameNode(value: '__typename'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
          ],
        ),
      ),
      InlineFragmentNode(
        typeCondition: TypeConditionNode(
          on: NamedTypeNode(
            name: NameNode(value: 'ShopWaypoint'),
            isNonNull: false,
          ),
        ),
        directives: [],
        selectionSet: SelectionSetNode(
          selections: [
            FragmentSpreadNode(
              name: NameNode(value: 'ShopWaypoint'),
              directives: [],
            ),
            FieldNode(
              name: NameNode(value: '__typename'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
          ],
        ),
      ),
    ],
  ),
);
const documentNodeFragmentWaypoint = DocumentNode(
  definitions: [
    fragmentDefinitionWaypoint,
    fragmentDefinitionCoordinate,
    fragmentDefinitionRideWaypoint,
    fragmentDefinitionDeliveryWaypoint,
    fragmentDefinitionPhoneNumber,
    fragmentDefinitionShopWaypoint,
  ],
);

extension ClientExtension$Fragment$Waypoint on graphql.GraphQLClient {
  void writeFragment$Waypoint({
    required Fragment$Waypoint data,
    required Map<String, dynamic> idFields,
    bool broadcast = true,
  }) => this.writeFragment(
    graphql.FragmentRequest(
      idFields: idFields,
      fragment: const graphql.Fragment(
        fragmentName: 'Waypoint',
        document: documentNodeFragmentWaypoint,
      ),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Fragment$Waypoint? readFragment$Waypoint({
    required Map<String, dynamic> idFields,
    bool optimistic = true,
  }) {
    final result = this.readFragment(
      graphql.FragmentRequest(
        idFields: idFields,
        fragment: const graphql.Fragment(
          fragmentName: 'Waypoint',
          document: documentNodeFragmentWaypoint,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Fragment$Waypoint.fromJson(result);
  }
}

class Fragment$Waypoint$$RideWaypoint
    implements Fragment$RideWaypoint, Fragment$Waypoint {
  Fragment$Waypoint$$RideWaypoint({
    required this.location,
    required this.address,
    this.$__typename = 'RideWaypoint',
    required this.role,
  });

  factory Fragment$Waypoint$$RideWaypoint.fromJson(Map<String, dynamic> json) {
    final l$location = json['location'];
    final l$address = json['address'];
    final l$$__typename = json['__typename'];
    final l$role = json['role'];
    return Fragment$Waypoint$$RideWaypoint(
      location: Fragment$Coordinate.fromJson(
        (l$location as Map<String, dynamic>),
      ),
      address: (l$address as String),
      $__typename: (l$$__typename as String),
      role: fromJson$Enum$WaypointRole((l$role as String)),
    );
  }

  final Fragment$Coordinate location;

  final String address;

  final String $__typename;

  final Enum$WaypointRole role;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$location = location;
    _resultData['location'] = l$location.toJson();
    final l$address = address;
    _resultData['address'] = l$address;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    final l$role = role;
    _resultData['role'] = toJson$Enum$WaypointRole(l$role);
    return _resultData;
  }

  @override
  int get hashCode {
    final l$location = location;
    final l$address = address;
    final l$$__typename = $__typename;
    final l$role = role;
    return Object.hashAll([l$location, l$address, l$$__typename, l$role]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$Waypoint$$RideWaypoint ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$location = location;
    final lOther$location = other.location;
    if (l$location != lOther$location) {
      return false;
    }
    final l$address = address;
    final lOther$address = other.address;
    if (l$address != lOther$address) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    final l$role = role;
    final lOther$role = other.role;
    if (l$role != lOther$role) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$Waypoint$$RideWaypoint
    on Fragment$Waypoint$$RideWaypoint {
  CopyWith$Fragment$Waypoint$$RideWaypoint<Fragment$Waypoint$$RideWaypoint>
  get copyWith => CopyWith$Fragment$Waypoint$$RideWaypoint(this, (i) => i);
}

abstract class CopyWith$Fragment$Waypoint$$RideWaypoint<TRes> {
  factory CopyWith$Fragment$Waypoint$$RideWaypoint(
    Fragment$Waypoint$$RideWaypoint instance,
    TRes Function(Fragment$Waypoint$$RideWaypoint) then,
  ) = _CopyWithImpl$Fragment$Waypoint$$RideWaypoint;

  factory CopyWith$Fragment$Waypoint$$RideWaypoint.stub(TRes res) =
      _CopyWithStubImpl$Fragment$Waypoint$$RideWaypoint;

  TRes call({
    Fragment$Coordinate? location,
    String? address,
    String? $__typename,
    Enum$WaypointRole? role,
  });
  CopyWith$Fragment$Coordinate<TRes> get location;
}

class _CopyWithImpl$Fragment$Waypoint$$RideWaypoint<TRes>
    implements CopyWith$Fragment$Waypoint$$RideWaypoint<TRes> {
  _CopyWithImpl$Fragment$Waypoint$$RideWaypoint(this._instance, this._then);

  final Fragment$Waypoint$$RideWaypoint _instance;

  final TRes Function(Fragment$Waypoint$$RideWaypoint) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? location = _undefined,
    Object? address = _undefined,
    Object? $__typename = _undefined,
    Object? role = _undefined,
  }) => _then(
    Fragment$Waypoint$$RideWaypoint(
      location: location == _undefined || location == null
          ? _instance.location
          : (location as Fragment$Coordinate),
      address: address == _undefined || address == null
          ? _instance.address
          : (address as String),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
      role: role == _undefined || role == null
          ? _instance.role
          : (role as Enum$WaypointRole),
    ),
  );

  CopyWith$Fragment$Coordinate<TRes> get location {
    final local$location = _instance.location;
    return CopyWith$Fragment$Coordinate(
      local$location,
      (e) => call(location: e),
    );
  }
}

class _CopyWithStubImpl$Fragment$Waypoint$$RideWaypoint<TRes>
    implements CopyWith$Fragment$Waypoint$$RideWaypoint<TRes> {
  _CopyWithStubImpl$Fragment$Waypoint$$RideWaypoint(this._res);

  TRes _res;

  call({
    Fragment$Coordinate? location,
    String? address,
    String? $__typename,
    Enum$WaypointRole? role,
  }) => _res;

  CopyWith$Fragment$Coordinate<TRes> get location =>
      CopyWith$Fragment$Coordinate.stub(_res);
}

class Fragment$Waypoint$$DeliveryWaypoint
    implements Fragment$DeliveryWaypoint, Fragment$Waypoint {
  Fragment$Waypoint$$DeliveryWaypoint({
    required this.location,
    required this.address,
    this.deliveryContact,
    this.$__typename = 'DeliveryWaypoint',
    required this.role,
  });

  factory Fragment$Waypoint$$DeliveryWaypoint.fromJson(
    Map<String, dynamic> json,
  ) {
    final l$location = json['location'];
    final l$address = json['address'];
    final l$deliveryContact = json['deliveryContact'];
    final l$$__typename = json['__typename'];
    final l$role = json['role'];
    return Fragment$Waypoint$$DeliveryWaypoint(
      location: Fragment$Coordinate.fromJson(
        (l$location as Map<String, dynamic>),
      ),
      address: (l$address as String),
      deliveryContact: l$deliveryContact == null
          ? null
          : Fragment$Waypoint$$DeliveryWaypoint$deliveryContact.fromJson(
              (l$deliveryContact as Map<String, dynamic>),
            ),
      $__typename: (l$$__typename as String),
      role: fromJson$Enum$WaypointRole((l$role as String)),
    );
  }

  final Fragment$Coordinate location;

  final String address;

  final Fragment$Waypoint$$DeliveryWaypoint$deliveryContact? deliveryContact;

  final String $__typename;

  final Enum$WaypointRole role;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$location = location;
    _resultData['location'] = l$location.toJson();
    final l$address = address;
    _resultData['address'] = l$address;
    final l$deliveryContact = deliveryContact;
    _resultData['deliveryContact'] = l$deliveryContact?.toJson();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    final l$role = role;
    _resultData['role'] = toJson$Enum$WaypointRole(l$role);
    return _resultData;
  }

  @override
  int get hashCode {
    final l$location = location;
    final l$address = address;
    final l$deliveryContact = deliveryContact;
    final l$$__typename = $__typename;
    final l$role = role;
    return Object.hashAll([
      l$location,
      l$address,
      l$deliveryContact,
      l$$__typename,
      l$role,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$Waypoint$$DeliveryWaypoint ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$location = location;
    final lOther$location = other.location;
    if (l$location != lOther$location) {
      return false;
    }
    final l$address = address;
    final lOther$address = other.address;
    if (l$address != lOther$address) {
      return false;
    }
    final l$deliveryContact = deliveryContact;
    final lOther$deliveryContact = other.deliveryContact;
    if (l$deliveryContact != lOther$deliveryContact) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    final l$role = role;
    final lOther$role = other.role;
    if (l$role != lOther$role) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$Waypoint$$DeliveryWaypoint
    on Fragment$Waypoint$$DeliveryWaypoint {
  CopyWith$Fragment$Waypoint$$DeliveryWaypoint<
    Fragment$Waypoint$$DeliveryWaypoint
  >
  get copyWith => CopyWith$Fragment$Waypoint$$DeliveryWaypoint(this, (i) => i);
}

abstract class CopyWith$Fragment$Waypoint$$DeliveryWaypoint<TRes> {
  factory CopyWith$Fragment$Waypoint$$DeliveryWaypoint(
    Fragment$Waypoint$$DeliveryWaypoint instance,
    TRes Function(Fragment$Waypoint$$DeliveryWaypoint) then,
  ) = _CopyWithImpl$Fragment$Waypoint$$DeliveryWaypoint;

  factory CopyWith$Fragment$Waypoint$$DeliveryWaypoint.stub(TRes res) =
      _CopyWithStubImpl$Fragment$Waypoint$$DeliveryWaypoint;

  TRes call({
    Fragment$Coordinate? location,
    String? address,
    Fragment$Waypoint$$DeliveryWaypoint$deliveryContact? deliveryContact,
    String? $__typename,
    Enum$WaypointRole? role,
  });
  CopyWith$Fragment$Coordinate<TRes> get location;
  CopyWith$Fragment$Waypoint$$DeliveryWaypoint$deliveryContact<TRes>
  get deliveryContact;
}

class _CopyWithImpl$Fragment$Waypoint$$DeliveryWaypoint<TRes>
    implements CopyWith$Fragment$Waypoint$$DeliveryWaypoint<TRes> {
  _CopyWithImpl$Fragment$Waypoint$$DeliveryWaypoint(this._instance, this._then);

  final Fragment$Waypoint$$DeliveryWaypoint _instance;

  final TRes Function(Fragment$Waypoint$$DeliveryWaypoint) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? location = _undefined,
    Object? address = _undefined,
    Object? deliveryContact = _undefined,
    Object? $__typename = _undefined,
    Object? role = _undefined,
  }) => _then(
    Fragment$Waypoint$$DeliveryWaypoint(
      location: location == _undefined || location == null
          ? _instance.location
          : (location as Fragment$Coordinate),
      address: address == _undefined || address == null
          ? _instance.address
          : (address as String),
      deliveryContact: deliveryContact == _undefined
          ? _instance.deliveryContact
          : (deliveryContact
                as Fragment$Waypoint$$DeliveryWaypoint$deliveryContact?),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
      role: role == _undefined || role == null
          ? _instance.role
          : (role as Enum$WaypointRole),
    ),
  );

  CopyWith$Fragment$Coordinate<TRes> get location {
    final local$location = _instance.location;
    return CopyWith$Fragment$Coordinate(
      local$location,
      (e) => call(location: e),
    );
  }

  CopyWith$Fragment$Waypoint$$DeliveryWaypoint$deliveryContact<TRes>
  get deliveryContact {
    final local$deliveryContact = _instance.deliveryContact;
    return local$deliveryContact == null
        ? CopyWith$Fragment$Waypoint$$DeliveryWaypoint$deliveryContact.stub(
            _then(_instance),
          )
        : CopyWith$Fragment$Waypoint$$DeliveryWaypoint$deliveryContact(
            local$deliveryContact,
            (e) => call(deliveryContact: e),
          );
  }
}

class _CopyWithStubImpl$Fragment$Waypoint$$DeliveryWaypoint<TRes>
    implements CopyWith$Fragment$Waypoint$$DeliveryWaypoint<TRes> {
  _CopyWithStubImpl$Fragment$Waypoint$$DeliveryWaypoint(this._res);

  TRes _res;

  call({
    Fragment$Coordinate? location,
    String? address,
    Fragment$Waypoint$$DeliveryWaypoint$deliveryContact? deliveryContact,
    String? $__typename,
    Enum$WaypointRole? role,
  }) => _res;

  CopyWith$Fragment$Coordinate<TRes> get location =>
      CopyWith$Fragment$Coordinate.stub(_res);

  CopyWith$Fragment$Waypoint$$DeliveryWaypoint$deliveryContact<TRes>
  get deliveryContact =>
      CopyWith$Fragment$Waypoint$$DeliveryWaypoint$deliveryContact.stub(_res);
}

class Fragment$Waypoint$$DeliveryWaypoint$deliveryContact
    implements Fragment$DeliveryWaypoint$deliveryContact {
  Fragment$Waypoint$$DeliveryWaypoint$deliveryContact({
    required this.name,
    this.companyName,
    required this.addressLine1,
    required this.phoneNumber,
    this.$__typename = 'DeliveryContact',
  });

  factory Fragment$Waypoint$$DeliveryWaypoint$deliveryContact.fromJson(
    Map<String, dynamic> json,
  ) {
    final l$name = json['name'];
    final l$companyName = json['companyName'];
    final l$addressLine1 = json['addressLine1'];
    final l$phoneNumber = json['phoneNumber'];
    final l$$__typename = json['__typename'];
    return Fragment$Waypoint$$DeliveryWaypoint$deliveryContact(
      name: (l$name as String),
      companyName: (l$companyName as String?),
      addressLine1: (l$addressLine1 as String),
      phoneNumber: Fragment$PhoneNumber.fromJson(
        (l$phoneNumber as Map<String, dynamic>),
      ),
      $__typename: (l$$__typename as String),
    );
  }

  final String name;

  final String? companyName;

  final String addressLine1;

  final Fragment$PhoneNumber phoneNumber;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$name = name;
    _resultData['name'] = l$name;
    final l$companyName = companyName;
    _resultData['companyName'] = l$companyName;
    final l$addressLine1 = addressLine1;
    _resultData['addressLine1'] = l$addressLine1;
    final l$phoneNumber = phoneNumber;
    _resultData['phoneNumber'] = l$phoneNumber.toJson();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$name = name;
    final l$companyName = companyName;
    final l$addressLine1 = addressLine1;
    final l$phoneNumber = phoneNumber;
    final l$$__typename = $__typename;
    return Object.hashAll([
      l$name,
      l$companyName,
      l$addressLine1,
      l$phoneNumber,
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$Waypoint$$DeliveryWaypoint$deliveryContact ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$name = name;
    final lOther$name = other.name;
    if (l$name != lOther$name) {
      return false;
    }
    final l$companyName = companyName;
    final lOther$companyName = other.companyName;
    if (l$companyName != lOther$companyName) {
      return false;
    }
    final l$addressLine1 = addressLine1;
    final lOther$addressLine1 = other.addressLine1;
    if (l$addressLine1 != lOther$addressLine1) {
      return false;
    }
    final l$phoneNumber = phoneNumber;
    final lOther$phoneNumber = other.phoneNumber;
    if (l$phoneNumber != lOther$phoneNumber) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$Waypoint$$DeliveryWaypoint$deliveryContact
    on Fragment$Waypoint$$DeliveryWaypoint$deliveryContact {
  CopyWith$Fragment$Waypoint$$DeliveryWaypoint$deliveryContact<
    Fragment$Waypoint$$DeliveryWaypoint$deliveryContact
  >
  get copyWith => CopyWith$Fragment$Waypoint$$DeliveryWaypoint$deliveryContact(
    this,
    (i) => i,
  );
}

abstract class CopyWith$Fragment$Waypoint$$DeliveryWaypoint$deliveryContact<
  TRes
> {
  factory CopyWith$Fragment$Waypoint$$DeliveryWaypoint$deliveryContact(
    Fragment$Waypoint$$DeliveryWaypoint$deliveryContact instance,
    TRes Function(Fragment$Waypoint$$DeliveryWaypoint$deliveryContact) then,
  ) = _CopyWithImpl$Fragment$Waypoint$$DeliveryWaypoint$deliveryContact;

  factory CopyWith$Fragment$Waypoint$$DeliveryWaypoint$deliveryContact.stub(
    TRes res,
  ) = _CopyWithStubImpl$Fragment$Waypoint$$DeliveryWaypoint$deliveryContact;

  TRes call({
    String? name,
    String? companyName,
    String? addressLine1,
    Fragment$PhoneNumber? phoneNumber,
    String? $__typename,
  });
  CopyWith$Fragment$PhoneNumber<TRes> get phoneNumber;
}

class _CopyWithImpl$Fragment$Waypoint$$DeliveryWaypoint$deliveryContact<TRes>
    implements
        CopyWith$Fragment$Waypoint$$DeliveryWaypoint$deliveryContact<TRes> {
  _CopyWithImpl$Fragment$Waypoint$$DeliveryWaypoint$deliveryContact(
    this._instance,
    this._then,
  );

  final Fragment$Waypoint$$DeliveryWaypoint$deliveryContact _instance;

  final TRes Function(Fragment$Waypoint$$DeliveryWaypoint$deliveryContact)
  _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? name = _undefined,
    Object? companyName = _undefined,
    Object? addressLine1 = _undefined,
    Object? phoneNumber = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Fragment$Waypoint$$DeliveryWaypoint$deliveryContact(
      name: name == _undefined || name == null
          ? _instance.name
          : (name as String),
      companyName: companyName == _undefined
          ? _instance.companyName
          : (companyName as String?),
      addressLine1: addressLine1 == _undefined || addressLine1 == null
          ? _instance.addressLine1
          : (addressLine1 as String),
      phoneNumber: phoneNumber == _undefined || phoneNumber == null
          ? _instance.phoneNumber
          : (phoneNumber as Fragment$PhoneNumber),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  CopyWith$Fragment$PhoneNumber<TRes> get phoneNumber {
    final local$phoneNumber = _instance.phoneNumber;
    return CopyWith$Fragment$PhoneNumber(
      local$phoneNumber,
      (e) => call(phoneNumber: e),
    );
  }
}

class _CopyWithStubImpl$Fragment$Waypoint$$DeliveryWaypoint$deliveryContact<
  TRes
>
    implements
        CopyWith$Fragment$Waypoint$$DeliveryWaypoint$deliveryContact<TRes> {
  _CopyWithStubImpl$Fragment$Waypoint$$DeliveryWaypoint$deliveryContact(
    this._res,
  );

  TRes _res;

  call({
    String? name,
    String? companyName,
    String? addressLine1,
    Fragment$PhoneNumber? phoneNumber,
    String? $__typename,
  }) => _res;

  CopyWith$Fragment$PhoneNumber<TRes> get phoneNumber =>
      CopyWith$Fragment$PhoneNumber.stub(_res);
}

class Fragment$Waypoint$$ShopWaypoint
    implements Fragment$ShopWaypoint, Fragment$Waypoint {
  Fragment$Waypoint$$ShopWaypoint({
    required this.location,
    required this.address,
    required this.shopName,
    required this.shopImageUrl,
    this.$__typename = 'ShopWaypoint',
    required this.role,
  });

  factory Fragment$Waypoint$$ShopWaypoint.fromJson(Map<String, dynamic> json) {
    final l$location = json['location'];
    final l$address = json['address'];
    final l$shopName = json['shopName'];
    final l$shopImageUrl = json['shopImageUrl'];
    final l$$__typename = json['__typename'];
    final l$role = json['role'];
    return Fragment$Waypoint$$ShopWaypoint(
      location: Fragment$Coordinate.fromJson(
        (l$location as Map<String, dynamic>),
      ),
      address: (l$address as String),
      shopName: (l$shopName as String),
      shopImageUrl: (l$shopImageUrl as String),
      $__typename: (l$$__typename as String),
      role: fromJson$Enum$WaypointRole((l$role as String)),
    );
  }

  final Fragment$Coordinate location;

  final String address;

  final String shopName;

  final String shopImageUrl;

  final String $__typename;

  final Enum$WaypointRole role;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$location = location;
    _resultData['location'] = l$location.toJson();
    final l$address = address;
    _resultData['address'] = l$address;
    final l$shopName = shopName;
    _resultData['shopName'] = l$shopName;
    final l$shopImageUrl = shopImageUrl;
    _resultData['shopImageUrl'] = l$shopImageUrl;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    final l$role = role;
    _resultData['role'] = toJson$Enum$WaypointRole(l$role);
    return _resultData;
  }

  @override
  int get hashCode {
    final l$location = location;
    final l$address = address;
    final l$shopName = shopName;
    final l$shopImageUrl = shopImageUrl;
    final l$$__typename = $__typename;
    final l$role = role;
    return Object.hashAll([
      l$location,
      l$address,
      l$shopName,
      l$shopImageUrl,
      l$$__typename,
      l$role,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$Waypoint$$ShopWaypoint ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$location = location;
    final lOther$location = other.location;
    if (l$location != lOther$location) {
      return false;
    }
    final l$address = address;
    final lOther$address = other.address;
    if (l$address != lOther$address) {
      return false;
    }
    final l$shopName = shopName;
    final lOther$shopName = other.shopName;
    if (l$shopName != lOther$shopName) {
      return false;
    }
    final l$shopImageUrl = shopImageUrl;
    final lOther$shopImageUrl = other.shopImageUrl;
    if (l$shopImageUrl != lOther$shopImageUrl) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    final l$role = role;
    final lOther$role = other.role;
    if (l$role != lOther$role) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$Waypoint$$ShopWaypoint
    on Fragment$Waypoint$$ShopWaypoint {
  CopyWith$Fragment$Waypoint$$ShopWaypoint<Fragment$Waypoint$$ShopWaypoint>
  get copyWith => CopyWith$Fragment$Waypoint$$ShopWaypoint(this, (i) => i);
}

abstract class CopyWith$Fragment$Waypoint$$ShopWaypoint<TRes> {
  factory CopyWith$Fragment$Waypoint$$ShopWaypoint(
    Fragment$Waypoint$$ShopWaypoint instance,
    TRes Function(Fragment$Waypoint$$ShopWaypoint) then,
  ) = _CopyWithImpl$Fragment$Waypoint$$ShopWaypoint;

  factory CopyWith$Fragment$Waypoint$$ShopWaypoint.stub(TRes res) =
      _CopyWithStubImpl$Fragment$Waypoint$$ShopWaypoint;

  TRes call({
    Fragment$Coordinate? location,
    String? address,
    String? shopName,
    String? shopImageUrl,
    String? $__typename,
    Enum$WaypointRole? role,
  });
  CopyWith$Fragment$Coordinate<TRes> get location;
}

class _CopyWithImpl$Fragment$Waypoint$$ShopWaypoint<TRes>
    implements CopyWith$Fragment$Waypoint$$ShopWaypoint<TRes> {
  _CopyWithImpl$Fragment$Waypoint$$ShopWaypoint(this._instance, this._then);

  final Fragment$Waypoint$$ShopWaypoint _instance;

  final TRes Function(Fragment$Waypoint$$ShopWaypoint) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? location = _undefined,
    Object? address = _undefined,
    Object? shopName = _undefined,
    Object? shopImageUrl = _undefined,
    Object? $__typename = _undefined,
    Object? role = _undefined,
  }) => _then(
    Fragment$Waypoint$$ShopWaypoint(
      location: location == _undefined || location == null
          ? _instance.location
          : (location as Fragment$Coordinate),
      address: address == _undefined || address == null
          ? _instance.address
          : (address as String),
      shopName: shopName == _undefined || shopName == null
          ? _instance.shopName
          : (shopName as String),
      shopImageUrl: shopImageUrl == _undefined || shopImageUrl == null
          ? _instance.shopImageUrl
          : (shopImageUrl as String),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
      role: role == _undefined || role == null
          ? _instance.role
          : (role as Enum$WaypointRole),
    ),
  );

  CopyWith$Fragment$Coordinate<TRes> get location {
    final local$location = _instance.location;
    return CopyWith$Fragment$Coordinate(
      local$location,
      (e) => call(location: e),
    );
  }
}

class _CopyWithStubImpl$Fragment$Waypoint$$ShopWaypoint<TRes>
    implements CopyWith$Fragment$Waypoint$$ShopWaypoint<TRes> {
  _CopyWithStubImpl$Fragment$Waypoint$$ShopWaypoint(this._res);

  TRes _res;

  call({
    Fragment$Coordinate? location,
    String? address,
    String? shopName,
    String? shopImageUrl,
    String? $__typename,
    Enum$WaypointRole? role,
  }) => _res;

  CopyWith$Fragment$Coordinate<TRes> get location =>
      CopyWith$Fragment$Coordinate.stub(_res);
}

class Fragment$RideWaypoint {
  Fragment$RideWaypoint({
    required this.location,
    required this.address,
    this.$__typename = 'RideWaypoint',
  });

  factory Fragment$RideWaypoint.fromJson(Map<String, dynamic> json) {
    final l$location = json['location'];
    final l$address = json['address'];
    final l$$__typename = json['__typename'];
    return Fragment$RideWaypoint(
      location: Fragment$Coordinate.fromJson(
        (l$location as Map<String, dynamic>),
      ),
      address: (l$address as String),
      $__typename: (l$$__typename as String),
    );
  }

  final Fragment$Coordinate location;

  final String address;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$location = location;
    _resultData['location'] = l$location.toJson();
    final l$address = address;
    _resultData['address'] = l$address;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$location = location;
    final l$address = address;
    final l$$__typename = $__typename;
    return Object.hashAll([l$location, l$address, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$RideWaypoint || runtimeType != other.runtimeType) {
      return false;
    }
    final l$location = location;
    final lOther$location = other.location;
    if (l$location != lOther$location) {
      return false;
    }
    final l$address = address;
    final lOther$address = other.address;
    if (l$address != lOther$address) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$RideWaypoint on Fragment$RideWaypoint {
  CopyWith$Fragment$RideWaypoint<Fragment$RideWaypoint> get copyWith =>
      CopyWith$Fragment$RideWaypoint(this, (i) => i);
}

abstract class CopyWith$Fragment$RideWaypoint<TRes> {
  factory CopyWith$Fragment$RideWaypoint(
    Fragment$RideWaypoint instance,
    TRes Function(Fragment$RideWaypoint) then,
  ) = _CopyWithImpl$Fragment$RideWaypoint;

  factory CopyWith$Fragment$RideWaypoint.stub(TRes res) =
      _CopyWithStubImpl$Fragment$RideWaypoint;

  TRes call({
    Fragment$Coordinate? location,
    String? address,
    String? $__typename,
  });
  CopyWith$Fragment$Coordinate<TRes> get location;
}

class _CopyWithImpl$Fragment$RideWaypoint<TRes>
    implements CopyWith$Fragment$RideWaypoint<TRes> {
  _CopyWithImpl$Fragment$RideWaypoint(this._instance, this._then);

  final Fragment$RideWaypoint _instance;

  final TRes Function(Fragment$RideWaypoint) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? location = _undefined,
    Object? address = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Fragment$RideWaypoint(
      location: location == _undefined || location == null
          ? _instance.location
          : (location as Fragment$Coordinate),
      address: address == _undefined || address == null
          ? _instance.address
          : (address as String),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  CopyWith$Fragment$Coordinate<TRes> get location {
    final local$location = _instance.location;
    return CopyWith$Fragment$Coordinate(
      local$location,
      (e) => call(location: e),
    );
  }
}

class _CopyWithStubImpl$Fragment$RideWaypoint<TRes>
    implements CopyWith$Fragment$RideWaypoint<TRes> {
  _CopyWithStubImpl$Fragment$RideWaypoint(this._res);

  TRes _res;

  call({Fragment$Coordinate? location, String? address, String? $__typename}) =>
      _res;

  CopyWith$Fragment$Coordinate<TRes> get location =>
      CopyWith$Fragment$Coordinate.stub(_res);
}

const fragmentDefinitionRideWaypoint = FragmentDefinitionNode(
  name: NameNode(value: 'RideWaypoint'),
  typeCondition: TypeConditionNode(
    on: NamedTypeNode(name: NameNode(value: 'RideWaypoint'), isNonNull: false),
  ),
  directives: [],
  selectionSet: SelectionSetNode(
    selections: [
      FieldNode(
        name: NameNode(value: 'location'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: SelectionSetNode(
          selections: [
            FragmentSpreadNode(
              name: NameNode(value: 'Coordinate'),
              directives: [],
            ),
            FieldNode(
              name: NameNode(value: '__typename'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
          ],
        ),
      ),
      FieldNode(
        name: NameNode(value: 'address'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: '__typename'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
    ],
  ),
);
const documentNodeFragmentRideWaypoint = DocumentNode(
  definitions: [fragmentDefinitionRideWaypoint, fragmentDefinitionCoordinate],
);

extension ClientExtension$Fragment$RideWaypoint on graphql.GraphQLClient {
  void writeFragment$RideWaypoint({
    required Fragment$RideWaypoint data,
    required Map<String, dynamic> idFields,
    bool broadcast = true,
  }) => this.writeFragment(
    graphql.FragmentRequest(
      idFields: idFields,
      fragment: const graphql.Fragment(
        fragmentName: 'RideWaypoint',
        document: documentNodeFragmentRideWaypoint,
      ),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Fragment$RideWaypoint? readFragment$RideWaypoint({
    required Map<String, dynamic> idFields,
    bool optimistic = true,
  }) {
    final result = this.readFragment(
      graphql.FragmentRequest(
        idFields: idFields,
        fragment: const graphql.Fragment(
          fragmentName: 'RideWaypoint',
          document: documentNodeFragmentRideWaypoint,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Fragment$RideWaypoint.fromJson(result);
  }
}

class Fragment$DeliveryWaypoint {
  Fragment$DeliveryWaypoint({
    required this.location,
    required this.address,
    this.deliveryContact,
    this.$__typename = 'DeliveryWaypoint',
  });

  factory Fragment$DeliveryWaypoint.fromJson(Map<String, dynamic> json) {
    final l$location = json['location'];
    final l$address = json['address'];
    final l$deliveryContact = json['deliveryContact'];
    final l$$__typename = json['__typename'];
    return Fragment$DeliveryWaypoint(
      location: Fragment$Coordinate.fromJson(
        (l$location as Map<String, dynamic>),
      ),
      address: (l$address as String),
      deliveryContact: l$deliveryContact == null
          ? null
          : Fragment$DeliveryWaypoint$deliveryContact.fromJson(
              (l$deliveryContact as Map<String, dynamic>),
            ),
      $__typename: (l$$__typename as String),
    );
  }

  final Fragment$Coordinate location;

  final String address;

  final Fragment$DeliveryWaypoint$deliveryContact? deliveryContact;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$location = location;
    _resultData['location'] = l$location.toJson();
    final l$address = address;
    _resultData['address'] = l$address;
    final l$deliveryContact = deliveryContact;
    _resultData['deliveryContact'] = l$deliveryContact?.toJson();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$location = location;
    final l$address = address;
    final l$deliveryContact = deliveryContact;
    final l$$__typename = $__typename;
    return Object.hashAll([
      l$location,
      l$address,
      l$deliveryContact,
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$DeliveryWaypoint ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$location = location;
    final lOther$location = other.location;
    if (l$location != lOther$location) {
      return false;
    }
    final l$address = address;
    final lOther$address = other.address;
    if (l$address != lOther$address) {
      return false;
    }
    final l$deliveryContact = deliveryContact;
    final lOther$deliveryContact = other.deliveryContact;
    if (l$deliveryContact != lOther$deliveryContact) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$DeliveryWaypoint
    on Fragment$DeliveryWaypoint {
  CopyWith$Fragment$DeliveryWaypoint<Fragment$DeliveryWaypoint> get copyWith =>
      CopyWith$Fragment$DeliveryWaypoint(this, (i) => i);
}

abstract class CopyWith$Fragment$DeliveryWaypoint<TRes> {
  factory CopyWith$Fragment$DeliveryWaypoint(
    Fragment$DeliveryWaypoint instance,
    TRes Function(Fragment$DeliveryWaypoint) then,
  ) = _CopyWithImpl$Fragment$DeliveryWaypoint;

  factory CopyWith$Fragment$DeliveryWaypoint.stub(TRes res) =
      _CopyWithStubImpl$Fragment$DeliveryWaypoint;

  TRes call({
    Fragment$Coordinate? location,
    String? address,
    Fragment$DeliveryWaypoint$deliveryContact? deliveryContact,
    String? $__typename,
  });
  CopyWith$Fragment$Coordinate<TRes> get location;
  CopyWith$Fragment$DeliveryWaypoint$deliveryContact<TRes> get deliveryContact;
}

class _CopyWithImpl$Fragment$DeliveryWaypoint<TRes>
    implements CopyWith$Fragment$DeliveryWaypoint<TRes> {
  _CopyWithImpl$Fragment$DeliveryWaypoint(this._instance, this._then);

  final Fragment$DeliveryWaypoint _instance;

  final TRes Function(Fragment$DeliveryWaypoint) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? location = _undefined,
    Object? address = _undefined,
    Object? deliveryContact = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Fragment$DeliveryWaypoint(
      location: location == _undefined || location == null
          ? _instance.location
          : (location as Fragment$Coordinate),
      address: address == _undefined || address == null
          ? _instance.address
          : (address as String),
      deliveryContact: deliveryContact == _undefined
          ? _instance.deliveryContact
          : (deliveryContact as Fragment$DeliveryWaypoint$deliveryContact?),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  CopyWith$Fragment$Coordinate<TRes> get location {
    final local$location = _instance.location;
    return CopyWith$Fragment$Coordinate(
      local$location,
      (e) => call(location: e),
    );
  }

  CopyWith$Fragment$DeliveryWaypoint$deliveryContact<TRes> get deliveryContact {
    final local$deliveryContact = _instance.deliveryContact;
    return local$deliveryContact == null
        ? CopyWith$Fragment$DeliveryWaypoint$deliveryContact.stub(
            _then(_instance),
          )
        : CopyWith$Fragment$DeliveryWaypoint$deliveryContact(
            local$deliveryContact,
            (e) => call(deliveryContact: e),
          );
  }
}

class _CopyWithStubImpl$Fragment$DeliveryWaypoint<TRes>
    implements CopyWith$Fragment$DeliveryWaypoint<TRes> {
  _CopyWithStubImpl$Fragment$DeliveryWaypoint(this._res);

  TRes _res;

  call({
    Fragment$Coordinate? location,
    String? address,
    Fragment$DeliveryWaypoint$deliveryContact? deliveryContact,
    String? $__typename,
  }) => _res;

  CopyWith$Fragment$Coordinate<TRes> get location =>
      CopyWith$Fragment$Coordinate.stub(_res);

  CopyWith$Fragment$DeliveryWaypoint$deliveryContact<TRes>
  get deliveryContact =>
      CopyWith$Fragment$DeliveryWaypoint$deliveryContact.stub(_res);
}

const fragmentDefinitionDeliveryWaypoint = FragmentDefinitionNode(
  name: NameNode(value: 'DeliveryWaypoint'),
  typeCondition: TypeConditionNode(
    on: NamedTypeNode(
      name: NameNode(value: 'DeliveryWaypoint'),
      isNonNull: false,
    ),
  ),
  directives: [],
  selectionSet: SelectionSetNode(
    selections: [
      FieldNode(
        name: NameNode(value: 'location'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: SelectionSetNode(
          selections: [
            FragmentSpreadNode(
              name: NameNode(value: 'Coordinate'),
              directives: [],
            ),
            FieldNode(
              name: NameNode(value: '__typename'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
          ],
        ),
      ),
      FieldNode(
        name: NameNode(value: 'address'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'deliveryContact'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: SelectionSetNode(
          selections: [
            FieldNode(
              name: NameNode(value: 'name'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
            FieldNode(
              name: NameNode(value: 'companyName'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
            FieldNode(
              name: NameNode(value: 'addressLine1'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
            FieldNode(
              name: NameNode(value: 'phoneNumber'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: SelectionSetNode(
                selections: [
                  FragmentSpreadNode(
                    name: NameNode(value: 'PhoneNumber'),
                    directives: [],
                  ),
                  FieldNode(
                    name: NameNode(value: '__typename'),
                    alias: null,
                    arguments: [],
                    directives: [],
                    selectionSet: null,
                  ),
                ],
              ),
            ),
            FieldNode(
              name: NameNode(value: '__typename'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
          ],
        ),
      ),
      FieldNode(
        name: NameNode(value: '__typename'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
    ],
  ),
);
const documentNodeFragmentDeliveryWaypoint = DocumentNode(
  definitions: [
    fragmentDefinitionDeliveryWaypoint,
    fragmentDefinitionCoordinate,
    fragmentDefinitionPhoneNumber,
  ],
);

extension ClientExtension$Fragment$DeliveryWaypoint on graphql.GraphQLClient {
  void writeFragment$DeliveryWaypoint({
    required Fragment$DeliveryWaypoint data,
    required Map<String, dynamic> idFields,
    bool broadcast = true,
  }) => this.writeFragment(
    graphql.FragmentRequest(
      idFields: idFields,
      fragment: const graphql.Fragment(
        fragmentName: 'DeliveryWaypoint',
        document: documentNodeFragmentDeliveryWaypoint,
      ),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Fragment$DeliveryWaypoint? readFragment$DeliveryWaypoint({
    required Map<String, dynamic> idFields,
    bool optimistic = true,
  }) {
    final result = this.readFragment(
      graphql.FragmentRequest(
        idFields: idFields,
        fragment: const graphql.Fragment(
          fragmentName: 'DeliveryWaypoint',
          document: documentNodeFragmentDeliveryWaypoint,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Fragment$DeliveryWaypoint.fromJson(result);
  }
}

class Fragment$DeliveryWaypoint$deliveryContact {
  Fragment$DeliveryWaypoint$deliveryContact({
    required this.name,
    this.companyName,
    required this.addressLine1,
    required this.phoneNumber,
    this.$__typename = 'DeliveryContact',
  });

  factory Fragment$DeliveryWaypoint$deliveryContact.fromJson(
    Map<String, dynamic> json,
  ) {
    final l$name = json['name'];
    final l$companyName = json['companyName'];
    final l$addressLine1 = json['addressLine1'];
    final l$phoneNumber = json['phoneNumber'];
    final l$$__typename = json['__typename'];
    return Fragment$DeliveryWaypoint$deliveryContact(
      name: (l$name as String),
      companyName: (l$companyName as String?),
      addressLine1: (l$addressLine1 as String),
      phoneNumber: Fragment$PhoneNumber.fromJson(
        (l$phoneNumber as Map<String, dynamic>),
      ),
      $__typename: (l$$__typename as String),
    );
  }

  final String name;

  final String? companyName;

  final String addressLine1;

  final Fragment$PhoneNumber phoneNumber;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$name = name;
    _resultData['name'] = l$name;
    final l$companyName = companyName;
    _resultData['companyName'] = l$companyName;
    final l$addressLine1 = addressLine1;
    _resultData['addressLine1'] = l$addressLine1;
    final l$phoneNumber = phoneNumber;
    _resultData['phoneNumber'] = l$phoneNumber.toJson();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$name = name;
    final l$companyName = companyName;
    final l$addressLine1 = addressLine1;
    final l$phoneNumber = phoneNumber;
    final l$$__typename = $__typename;
    return Object.hashAll([
      l$name,
      l$companyName,
      l$addressLine1,
      l$phoneNumber,
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$DeliveryWaypoint$deliveryContact ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$name = name;
    final lOther$name = other.name;
    if (l$name != lOther$name) {
      return false;
    }
    final l$companyName = companyName;
    final lOther$companyName = other.companyName;
    if (l$companyName != lOther$companyName) {
      return false;
    }
    final l$addressLine1 = addressLine1;
    final lOther$addressLine1 = other.addressLine1;
    if (l$addressLine1 != lOther$addressLine1) {
      return false;
    }
    final l$phoneNumber = phoneNumber;
    final lOther$phoneNumber = other.phoneNumber;
    if (l$phoneNumber != lOther$phoneNumber) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$DeliveryWaypoint$deliveryContact
    on Fragment$DeliveryWaypoint$deliveryContact {
  CopyWith$Fragment$DeliveryWaypoint$deliveryContact<
    Fragment$DeliveryWaypoint$deliveryContact
  >
  get copyWith =>
      CopyWith$Fragment$DeliveryWaypoint$deliveryContact(this, (i) => i);
}

abstract class CopyWith$Fragment$DeliveryWaypoint$deliveryContact<TRes> {
  factory CopyWith$Fragment$DeliveryWaypoint$deliveryContact(
    Fragment$DeliveryWaypoint$deliveryContact instance,
    TRes Function(Fragment$DeliveryWaypoint$deliveryContact) then,
  ) = _CopyWithImpl$Fragment$DeliveryWaypoint$deliveryContact;

  factory CopyWith$Fragment$DeliveryWaypoint$deliveryContact.stub(TRes res) =
      _CopyWithStubImpl$Fragment$DeliveryWaypoint$deliveryContact;

  TRes call({
    String? name,
    String? companyName,
    String? addressLine1,
    Fragment$PhoneNumber? phoneNumber,
    String? $__typename,
  });
  CopyWith$Fragment$PhoneNumber<TRes> get phoneNumber;
}

class _CopyWithImpl$Fragment$DeliveryWaypoint$deliveryContact<TRes>
    implements CopyWith$Fragment$DeliveryWaypoint$deliveryContact<TRes> {
  _CopyWithImpl$Fragment$DeliveryWaypoint$deliveryContact(
    this._instance,
    this._then,
  );

  final Fragment$DeliveryWaypoint$deliveryContact _instance;

  final TRes Function(Fragment$DeliveryWaypoint$deliveryContact) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? name = _undefined,
    Object? companyName = _undefined,
    Object? addressLine1 = _undefined,
    Object? phoneNumber = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Fragment$DeliveryWaypoint$deliveryContact(
      name: name == _undefined || name == null
          ? _instance.name
          : (name as String),
      companyName: companyName == _undefined
          ? _instance.companyName
          : (companyName as String?),
      addressLine1: addressLine1 == _undefined || addressLine1 == null
          ? _instance.addressLine1
          : (addressLine1 as String),
      phoneNumber: phoneNumber == _undefined || phoneNumber == null
          ? _instance.phoneNumber
          : (phoneNumber as Fragment$PhoneNumber),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  CopyWith$Fragment$PhoneNumber<TRes> get phoneNumber {
    final local$phoneNumber = _instance.phoneNumber;
    return CopyWith$Fragment$PhoneNumber(
      local$phoneNumber,
      (e) => call(phoneNumber: e),
    );
  }
}

class _CopyWithStubImpl$Fragment$DeliveryWaypoint$deliveryContact<TRes>
    implements CopyWith$Fragment$DeliveryWaypoint$deliveryContact<TRes> {
  _CopyWithStubImpl$Fragment$DeliveryWaypoint$deliveryContact(this._res);

  TRes _res;

  call({
    String? name,
    String? companyName,
    String? addressLine1,
    Fragment$PhoneNumber? phoneNumber,
    String? $__typename,
  }) => _res;

  CopyWith$Fragment$PhoneNumber<TRes> get phoneNumber =>
      CopyWith$Fragment$PhoneNumber.stub(_res);
}

class Fragment$ShopWaypoint {
  Fragment$ShopWaypoint({
    required this.location,
    required this.address,
    required this.shopName,
    required this.shopImageUrl,
    this.$__typename = 'ShopWaypoint',
  });

  factory Fragment$ShopWaypoint.fromJson(Map<String, dynamic> json) {
    final l$location = json['location'];
    final l$address = json['address'];
    final l$shopName = json['shopName'];
    final l$shopImageUrl = json['shopImageUrl'];
    final l$$__typename = json['__typename'];
    return Fragment$ShopWaypoint(
      location: Fragment$Coordinate.fromJson(
        (l$location as Map<String, dynamic>),
      ),
      address: (l$address as String),
      shopName: (l$shopName as String),
      shopImageUrl: (l$shopImageUrl as String),
      $__typename: (l$$__typename as String),
    );
  }

  final Fragment$Coordinate location;

  final String address;

  final String shopName;

  final String shopImageUrl;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$location = location;
    _resultData['location'] = l$location.toJson();
    final l$address = address;
    _resultData['address'] = l$address;
    final l$shopName = shopName;
    _resultData['shopName'] = l$shopName;
    final l$shopImageUrl = shopImageUrl;
    _resultData['shopImageUrl'] = l$shopImageUrl;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$location = location;
    final l$address = address;
    final l$shopName = shopName;
    final l$shopImageUrl = shopImageUrl;
    final l$$__typename = $__typename;
    return Object.hashAll([
      l$location,
      l$address,
      l$shopName,
      l$shopImageUrl,
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$ShopWaypoint || runtimeType != other.runtimeType) {
      return false;
    }
    final l$location = location;
    final lOther$location = other.location;
    if (l$location != lOther$location) {
      return false;
    }
    final l$address = address;
    final lOther$address = other.address;
    if (l$address != lOther$address) {
      return false;
    }
    final l$shopName = shopName;
    final lOther$shopName = other.shopName;
    if (l$shopName != lOther$shopName) {
      return false;
    }
    final l$shopImageUrl = shopImageUrl;
    final lOther$shopImageUrl = other.shopImageUrl;
    if (l$shopImageUrl != lOther$shopImageUrl) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$ShopWaypoint on Fragment$ShopWaypoint {
  CopyWith$Fragment$ShopWaypoint<Fragment$ShopWaypoint> get copyWith =>
      CopyWith$Fragment$ShopWaypoint(this, (i) => i);
}

abstract class CopyWith$Fragment$ShopWaypoint<TRes> {
  factory CopyWith$Fragment$ShopWaypoint(
    Fragment$ShopWaypoint instance,
    TRes Function(Fragment$ShopWaypoint) then,
  ) = _CopyWithImpl$Fragment$ShopWaypoint;

  factory CopyWith$Fragment$ShopWaypoint.stub(TRes res) =
      _CopyWithStubImpl$Fragment$ShopWaypoint;

  TRes call({
    Fragment$Coordinate? location,
    String? address,
    String? shopName,
    String? shopImageUrl,
    String? $__typename,
  });
  CopyWith$Fragment$Coordinate<TRes> get location;
}

class _CopyWithImpl$Fragment$ShopWaypoint<TRes>
    implements CopyWith$Fragment$ShopWaypoint<TRes> {
  _CopyWithImpl$Fragment$ShopWaypoint(this._instance, this._then);

  final Fragment$ShopWaypoint _instance;

  final TRes Function(Fragment$ShopWaypoint) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? location = _undefined,
    Object? address = _undefined,
    Object? shopName = _undefined,
    Object? shopImageUrl = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Fragment$ShopWaypoint(
      location: location == _undefined || location == null
          ? _instance.location
          : (location as Fragment$Coordinate),
      address: address == _undefined || address == null
          ? _instance.address
          : (address as String),
      shopName: shopName == _undefined || shopName == null
          ? _instance.shopName
          : (shopName as String),
      shopImageUrl: shopImageUrl == _undefined || shopImageUrl == null
          ? _instance.shopImageUrl
          : (shopImageUrl as String),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  CopyWith$Fragment$Coordinate<TRes> get location {
    final local$location = _instance.location;
    return CopyWith$Fragment$Coordinate(
      local$location,
      (e) => call(location: e),
    );
  }
}

class _CopyWithStubImpl$Fragment$ShopWaypoint<TRes>
    implements CopyWith$Fragment$ShopWaypoint<TRes> {
  _CopyWithStubImpl$Fragment$ShopWaypoint(this._res);

  TRes _res;

  call({
    Fragment$Coordinate? location,
    String? address,
    String? shopName,
    String? shopImageUrl,
    String? $__typename,
  }) => _res;

  CopyWith$Fragment$Coordinate<TRes> get location =>
      CopyWith$Fragment$Coordinate.stub(_res);
}

const fragmentDefinitionShopWaypoint = FragmentDefinitionNode(
  name: NameNode(value: 'ShopWaypoint'),
  typeCondition: TypeConditionNode(
    on: NamedTypeNode(name: NameNode(value: 'ShopWaypoint'), isNonNull: false),
  ),
  directives: [],
  selectionSet: SelectionSetNode(
    selections: [
      FieldNode(
        name: NameNode(value: 'location'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: SelectionSetNode(
          selections: [
            FragmentSpreadNode(
              name: NameNode(value: 'Coordinate'),
              directives: [],
            ),
            FieldNode(
              name: NameNode(value: '__typename'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
          ],
        ),
      ),
      FieldNode(
        name: NameNode(value: 'address'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'shopName'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'shopImageUrl'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: '__typename'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
    ],
  ),
);
const documentNodeFragmentShopWaypoint = DocumentNode(
  definitions: [fragmentDefinitionShopWaypoint, fragmentDefinitionCoordinate],
);

extension ClientExtension$Fragment$ShopWaypoint on graphql.GraphQLClient {
  void writeFragment$ShopWaypoint({
    required Fragment$ShopWaypoint data,
    required Map<String, dynamic> idFields,
    bool broadcast = true,
  }) => this.writeFragment(
    graphql.FragmentRequest(
      idFields: idFields,
      fragment: const graphql.Fragment(
        fragmentName: 'ShopWaypoint',
        document: documentNodeFragmentShopWaypoint,
      ),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Fragment$ShopWaypoint? readFragment$ShopWaypoint({
    required Map<String, dynamic> idFields,
    bool optimistic = true,
  }) {
    final result = this.readFragment(
      graphql.FragmentRequest(
        idFields: idFields,
        fragment: const graphql.Fragment(
          fragmentName: 'ShopWaypoint',
          document: documentNodeFragmentShopWaypoint,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Fragment$ShopWaypoint.fromJson(result);
  }
}
