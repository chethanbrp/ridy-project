import '../schema.gql.dart';
import 'package:gql/ast.dart';
import 'package:graphql/client.dart' as graphql;

class Fragment$PaymentMethod {
  Fragment$PaymentMethod({
    required this.$__typename,
    required this.mode,
    this.nullableId,
  });

  factory Fragment$PaymentMethod.fromJson(Map<String, dynamic> json) {
    switch (json["__typename"] as String) {
      case "CashPaymentMethod":
        return Fragment$PaymentMethod$$CashPaymentMethod.fromJson(json);

      case "WalletPaymentMethod":
        return Fragment$PaymentMethod$$WalletPaymentMethod.fromJson(json);

      case "SavedAccount":
        return Fragment$PaymentMethod$$SavedAccount.fromJson(json);

      case "OnlinePaymentMethod":
        return Fragment$PaymentMethod$$OnlinePaymentMethod.fromJson(json);

      default:
        final l$$__typename = json['__typename'];
        final l$mode = json['mode'];
        final l$nullableId = json['nullableId'];
        return Fragment$PaymentMethod(
          $__typename: (l$$__typename as String),
          mode: fromJson$Enum$PaymentMode((l$mode as String)),
          nullableId: (l$nullableId as String?),
        );
    }
  }

  final String $__typename;

  final Enum$PaymentMode mode;

  final String? nullableId;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    final l$mode = mode;
    _resultData['mode'] = toJson$Enum$PaymentMode(l$mode);
    final l$nullableId = nullableId;
    _resultData['nullableId'] = l$nullableId;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$$__typename = $__typename;
    final l$mode = mode;
    final l$nullableId = nullableId;
    return Object.hashAll([l$$__typename, l$mode, l$nullableId]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$PaymentMethod || runtimeType != other.runtimeType) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    final l$mode = mode;
    final lOther$mode = other.mode;
    if (l$mode != lOther$mode) {
      return false;
    }
    final l$nullableId = nullableId;
    final lOther$nullableId = other.nullableId;
    if (l$nullableId != lOther$nullableId) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$PaymentMethod on Fragment$PaymentMethod {
  CopyWith$Fragment$PaymentMethod<Fragment$PaymentMethod> get copyWith =>
      CopyWith$Fragment$PaymentMethod(this, (i) => i);

  _T when<_T>({
    required _T Function(Fragment$PaymentMethod$$CashPaymentMethod)
    cashPaymentMethod,
    required _T Function(Fragment$PaymentMethod$$WalletPaymentMethod)
    walletPaymentMethod,
    required _T Function(Fragment$PaymentMethod$$SavedAccount) savedAccount,
    required _T Function(Fragment$PaymentMethod$$OnlinePaymentMethod)
    onlinePaymentMethod,
    required _T Function() orElse,
  }) {
    switch ($__typename) {
      case "CashPaymentMethod":
        return cashPaymentMethod(
          this as Fragment$PaymentMethod$$CashPaymentMethod,
        );

      case "WalletPaymentMethod":
        return walletPaymentMethod(
          this as Fragment$PaymentMethod$$WalletPaymentMethod,
        );

      case "SavedAccount":
        return savedAccount(this as Fragment$PaymentMethod$$SavedAccount);

      case "OnlinePaymentMethod":
        return onlinePaymentMethod(
          this as Fragment$PaymentMethod$$OnlinePaymentMethod,
        );

      default:
        return orElse();
    }
  }

  _T maybeWhen<_T>({
    _T Function(Fragment$PaymentMethod$$CashPaymentMethod)? cashPaymentMethod,
    _T Function(Fragment$PaymentMethod$$WalletPaymentMethod)?
    walletPaymentMethod,
    _T Function(Fragment$PaymentMethod$$SavedAccount)? savedAccount,
    _T Function(Fragment$PaymentMethod$$OnlinePaymentMethod)?
    onlinePaymentMethod,
    required _T Function() orElse,
  }) {
    switch ($__typename) {
      case "CashPaymentMethod":
        if (cashPaymentMethod != null) {
          return cashPaymentMethod(
            this as Fragment$PaymentMethod$$CashPaymentMethod,
          );
        } else {
          return orElse();
        }

      case "WalletPaymentMethod":
        if (walletPaymentMethod != null) {
          return walletPaymentMethod(
            this as Fragment$PaymentMethod$$WalletPaymentMethod,
          );
        } else {
          return orElse();
        }

      case "SavedAccount":
        if (savedAccount != null) {
          return savedAccount(this as Fragment$PaymentMethod$$SavedAccount);
        } else {
          return orElse();
        }

      case "OnlinePaymentMethod":
        if (onlinePaymentMethod != null) {
          return onlinePaymentMethod(
            this as Fragment$PaymentMethod$$OnlinePaymentMethod,
          );
        } else {
          return orElse();
        }

      default:
        return orElse();
    }
  }
}

abstract class CopyWith$Fragment$PaymentMethod<TRes> {
  factory CopyWith$Fragment$PaymentMethod(
    Fragment$PaymentMethod instance,
    TRes Function(Fragment$PaymentMethod) then,
  ) = _CopyWithImpl$Fragment$PaymentMethod;

  factory CopyWith$Fragment$PaymentMethod.stub(TRes res) =
      _CopyWithStubImpl$Fragment$PaymentMethod;

  TRes call({String? $__typename, Enum$PaymentMode? mode, String? nullableId});
}

class _CopyWithImpl$Fragment$PaymentMethod<TRes>
    implements CopyWith$Fragment$PaymentMethod<TRes> {
  _CopyWithImpl$Fragment$PaymentMethod(this._instance, this._then);

  final Fragment$PaymentMethod _instance;

  final TRes Function(Fragment$PaymentMethod) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? $__typename = _undefined,
    Object? mode = _undefined,
    Object? nullableId = _undefined,
  }) => _then(
    Fragment$PaymentMethod(
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
      mode: mode == _undefined || mode == null
          ? _instance.mode
          : (mode as Enum$PaymentMode),
      nullableId: nullableId == _undefined
          ? _instance.nullableId
          : (nullableId as String?),
    ),
  );
}

class _CopyWithStubImpl$Fragment$PaymentMethod<TRes>
    implements CopyWith$Fragment$PaymentMethod<TRes> {
  _CopyWithStubImpl$Fragment$PaymentMethod(this._res);

  TRes _res;

  call({String? $__typename, Enum$PaymentMode? mode, String? nullableId}) =>
      _res;
}

const fragmentDefinitionPaymentMethod = FragmentDefinitionNode(
  name: NameNode(value: 'PaymentMethod'),
  typeCondition: TypeConditionNode(
    on: NamedTypeNode(
      name: NameNode(value: 'PaymentMethodBase'),
      isNonNull: false,
    ),
  ),
  directives: [],
  selectionSet: SelectionSetNode(
    selections: [
      FieldNode(
        name: NameNode(value: '__typename'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'mode'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'id'),
        alias: NameNode(value: 'nullableId'),
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      InlineFragmentNode(
        typeCondition: TypeConditionNode(
          on: NamedTypeNode(
            name: NameNode(value: 'CashPaymentMethod'),
            isNonNull: false,
          ),
        ),
        directives: [],
        selectionSet: SelectionSetNode(
          selections: [
            FieldNode(
              name: NameNode(value: 'mode'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
            FieldNode(
              name: NameNode(value: '__typename'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
          ],
        ),
      ),
      InlineFragmentNode(
        typeCondition: TypeConditionNode(
          on: NamedTypeNode(
            name: NameNode(value: 'WalletPaymentMethod'),
            isNonNull: false,
          ),
        ),
        directives: [],
        selectionSet: SelectionSetNode(
          selections: [
            FieldNode(
              name: NameNode(value: 'mode'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
            FieldNode(
              name: NameNode(value: '__typename'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
          ],
        ),
      ),
      InlineFragmentNode(
        typeCondition: TypeConditionNode(
          on: NamedTypeNode(
            name: NameNode(value: 'SavedAccount'),
            isNonNull: false,
          ),
        ),
        directives: [],
        selectionSet: SelectionSetNode(
          selections: [
            FragmentSpreadNode(
              name: NameNode(value: 'SavedAccount'),
              directives: [],
            ),
            FieldNode(
              name: NameNode(value: '__typename'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
          ],
        ),
      ),
      InlineFragmentNode(
        typeCondition: TypeConditionNode(
          on: NamedTypeNode(
            name: NameNode(value: 'OnlinePaymentMethod'),
            isNonNull: false,
          ),
        ),
        directives: [],
        selectionSet: SelectionSetNode(
          selections: [
            FragmentSpreadNode(
              name: NameNode(value: 'OnlinePaymentMethod'),
              directives: [],
            ),
            FieldNode(
              name: NameNode(value: '__typename'),
              alias: null,
              arguments: [],
              directives: [],
              selectionSet: null,
            ),
          ],
        ),
      ),
    ],
  ),
);
const documentNodeFragmentPaymentMethod = DocumentNode(
  definitions: [
    fragmentDefinitionPaymentMethod,
    fragmentDefinitionSavedAccount,
    fragmentDefinitionOnlinePaymentMethod,
  ],
);

extension ClientExtension$Fragment$PaymentMethod on graphql.GraphQLClient {
  void writeFragment$PaymentMethod({
    required Fragment$PaymentMethod data,
    required Map<String, dynamic> idFields,
    bool broadcast = true,
  }) => this.writeFragment(
    graphql.FragmentRequest(
      idFields: idFields,
      fragment: const graphql.Fragment(
        fragmentName: 'PaymentMethod',
        document: documentNodeFragmentPaymentMethod,
      ),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Fragment$PaymentMethod? readFragment$PaymentMethod({
    required Map<String, dynamic> idFields,
    bool optimistic = true,
  }) {
    final result = this.readFragment(
      graphql.FragmentRequest(
        idFields: idFields,
        fragment: const graphql.Fragment(
          fragmentName: 'PaymentMethod',
          document: documentNodeFragmentPaymentMethod,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Fragment$PaymentMethod.fromJson(result);
  }
}

class Fragment$PaymentMethod$$CashPaymentMethod
    implements Fragment$PaymentMethod {
  Fragment$PaymentMethod$$CashPaymentMethod({
    required this.mode,
    this.$__typename = 'CashPaymentMethod',
    this.nullableId,
  });

  factory Fragment$PaymentMethod$$CashPaymentMethod.fromJson(
    Map<String, dynamic> json,
  ) {
    final l$mode = json['mode'];
    final l$$__typename = json['__typename'];
    final l$nullableId = json['nullableId'];
    return Fragment$PaymentMethod$$CashPaymentMethod(
      mode: fromJson$Enum$PaymentMode((l$mode as String)),
      $__typename: (l$$__typename as String),
      nullableId: (l$nullableId as String?),
    );
  }

  final Enum$PaymentMode mode;

  final String $__typename;

  final String? nullableId;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$mode = mode;
    _resultData['mode'] = toJson$Enum$PaymentMode(l$mode);
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    final l$nullableId = nullableId;
    _resultData['nullableId'] = l$nullableId;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$mode = mode;
    final l$$__typename = $__typename;
    final l$nullableId = nullableId;
    return Object.hashAll([l$mode, l$$__typename, l$nullableId]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$PaymentMethod$$CashPaymentMethod ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$mode = mode;
    final lOther$mode = other.mode;
    if (l$mode != lOther$mode) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    final l$nullableId = nullableId;
    final lOther$nullableId = other.nullableId;
    if (l$nullableId != lOther$nullableId) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$PaymentMethod$$CashPaymentMethod
    on Fragment$PaymentMethod$$CashPaymentMethod {
  CopyWith$Fragment$PaymentMethod$$CashPaymentMethod<
    Fragment$PaymentMethod$$CashPaymentMethod
  >
  get copyWith =>
      CopyWith$Fragment$PaymentMethod$$CashPaymentMethod(this, (i) => i);
}

abstract class CopyWith$Fragment$PaymentMethod$$CashPaymentMethod<TRes> {
  factory CopyWith$Fragment$PaymentMethod$$CashPaymentMethod(
    Fragment$PaymentMethod$$CashPaymentMethod instance,
    TRes Function(Fragment$PaymentMethod$$CashPaymentMethod) then,
  ) = _CopyWithImpl$Fragment$PaymentMethod$$CashPaymentMethod;

  factory CopyWith$Fragment$PaymentMethod$$CashPaymentMethod.stub(TRes res) =
      _CopyWithStubImpl$Fragment$PaymentMethod$$CashPaymentMethod;

  TRes call({Enum$PaymentMode? mode, String? $__typename, String? nullableId});
}

class _CopyWithImpl$Fragment$PaymentMethod$$CashPaymentMethod<TRes>
    implements CopyWith$Fragment$PaymentMethod$$CashPaymentMethod<TRes> {
  _CopyWithImpl$Fragment$PaymentMethod$$CashPaymentMethod(
    this._instance,
    this._then,
  );

  final Fragment$PaymentMethod$$CashPaymentMethod _instance;

  final TRes Function(Fragment$PaymentMethod$$CashPaymentMethod) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? mode = _undefined,
    Object? $__typename = _undefined,
    Object? nullableId = _undefined,
  }) => _then(
    Fragment$PaymentMethod$$CashPaymentMethod(
      mode: mode == _undefined || mode == null
          ? _instance.mode
          : (mode as Enum$PaymentMode),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
      nullableId: nullableId == _undefined
          ? _instance.nullableId
          : (nullableId as String?),
    ),
  );
}

class _CopyWithStubImpl$Fragment$PaymentMethod$$CashPaymentMethod<TRes>
    implements CopyWith$Fragment$PaymentMethod$$CashPaymentMethod<TRes> {
  _CopyWithStubImpl$Fragment$PaymentMethod$$CashPaymentMethod(this._res);

  TRes _res;

  call({Enum$PaymentMode? mode, String? $__typename, String? nullableId}) =>
      _res;
}

class Fragment$PaymentMethod$$WalletPaymentMethod
    implements Fragment$PaymentMethod {
  Fragment$PaymentMethod$$WalletPaymentMethod({
    required this.mode,
    this.$__typename = 'WalletPaymentMethod',
    this.nullableId,
  });

  factory Fragment$PaymentMethod$$WalletPaymentMethod.fromJson(
    Map<String, dynamic> json,
  ) {
    final l$mode = json['mode'];
    final l$$__typename = json['__typename'];
    final l$nullableId = json['nullableId'];
    return Fragment$PaymentMethod$$WalletPaymentMethod(
      mode: fromJson$Enum$PaymentMode((l$mode as String)),
      $__typename: (l$$__typename as String),
      nullableId: (l$nullableId as String?),
    );
  }

  final Enum$PaymentMode mode;

  final String $__typename;

  final String? nullableId;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$mode = mode;
    _resultData['mode'] = toJson$Enum$PaymentMode(l$mode);
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    final l$nullableId = nullableId;
    _resultData['nullableId'] = l$nullableId;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$mode = mode;
    final l$$__typename = $__typename;
    final l$nullableId = nullableId;
    return Object.hashAll([l$mode, l$$__typename, l$nullableId]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$PaymentMethod$$WalletPaymentMethod ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$mode = mode;
    final lOther$mode = other.mode;
    if (l$mode != lOther$mode) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    final l$nullableId = nullableId;
    final lOther$nullableId = other.nullableId;
    if (l$nullableId != lOther$nullableId) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$PaymentMethod$$WalletPaymentMethod
    on Fragment$PaymentMethod$$WalletPaymentMethod {
  CopyWith$Fragment$PaymentMethod$$WalletPaymentMethod<
    Fragment$PaymentMethod$$WalletPaymentMethod
  >
  get copyWith =>
      CopyWith$Fragment$PaymentMethod$$WalletPaymentMethod(this, (i) => i);
}

abstract class CopyWith$Fragment$PaymentMethod$$WalletPaymentMethod<TRes> {
  factory CopyWith$Fragment$PaymentMethod$$WalletPaymentMethod(
    Fragment$PaymentMethod$$WalletPaymentMethod instance,
    TRes Function(Fragment$PaymentMethod$$WalletPaymentMethod) then,
  ) = _CopyWithImpl$Fragment$PaymentMethod$$WalletPaymentMethod;

  factory CopyWith$Fragment$PaymentMethod$$WalletPaymentMethod.stub(TRes res) =
      _CopyWithStubImpl$Fragment$PaymentMethod$$WalletPaymentMethod;

  TRes call({Enum$PaymentMode? mode, String? $__typename, String? nullableId});
}

class _CopyWithImpl$Fragment$PaymentMethod$$WalletPaymentMethod<TRes>
    implements CopyWith$Fragment$PaymentMethod$$WalletPaymentMethod<TRes> {
  _CopyWithImpl$Fragment$PaymentMethod$$WalletPaymentMethod(
    this._instance,
    this._then,
  );

  final Fragment$PaymentMethod$$WalletPaymentMethod _instance;

  final TRes Function(Fragment$PaymentMethod$$WalletPaymentMethod) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? mode = _undefined,
    Object? $__typename = _undefined,
    Object? nullableId = _undefined,
  }) => _then(
    Fragment$PaymentMethod$$WalletPaymentMethod(
      mode: mode == _undefined || mode == null
          ? _instance.mode
          : (mode as Enum$PaymentMode),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
      nullableId: nullableId == _undefined
          ? _instance.nullableId
          : (nullableId as String?),
    ),
  );
}

class _CopyWithStubImpl$Fragment$PaymentMethod$$WalletPaymentMethod<TRes>
    implements CopyWith$Fragment$PaymentMethod$$WalletPaymentMethod<TRes> {
  _CopyWithStubImpl$Fragment$PaymentMethod$$WalletPaymentMethod(this._res);

  TRes _res;

  call({Enum$PaymentMode? mode, String? $__typename, String? nullableId}) =>
      _res;
}

class Fragment$PaymentMethod$$SavedAccount
    implements Fragment$SavedAccount, Fragment$PaymentMethod {
  Fragment$PaymentMethod$$SavedAccount({
    required this.id,
    required this.name,
    required this.isDefault,
    this.providerBrand,
    this.$__typename = 'SavedAccount',
    required this.mode,
    required this.nullableId,
  });

  factory Fragment$PaymentMethod$$SavedAccount.fromJson(
    Map<String, dynamic> json,
  ) {
    final l$id = json['id'];
    final l$name = json['name'];
    final l$isDefault = json['isDefault'];
    final l$providerBrand = json['providerBrand'];
    final l$$__typename = json['__typename'];
    final l$mode = json['mode'];
    final l$nullableId = json['nullableId'];
    return Fragment$PaymentMethod$$SavedAccount(
      id: (l$id as String),
      name: (l$name as String),
      isDefault: (l$isDefault as bool),
      providerBrand: l$providerBrand == null
          ? null
          : fromJson$Enum$ProviderBrand((l$providerBrand as String)),
      $__typename: (l$$__typename as String),
      mode: fromJson$Enum$PaymentMode((l$mode as String)),
      nullableId: (l$nullableId as String),
    );
  }

  final String id;

  final String name;

  final bool isDefault;

  final Enum$ProviderBrand? providerBrand;

  final String $__typename;

  final Enum$PaymentMode mode;

  final String nullableId;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$id = id;
    _resultData['id'] = l$id;
    final l$name = name;
    _resultData['name'] = l$name;
    final l$isDefault = isDefault;
    _resultData['isDefault'] = l$isDefault;
    final l$providerBrand = providerBrand;
    _resultData['providerBrand'] = l$providerBrand == null
        ? null
        : toJson$Enum$ProviderBrand(l$providerBrand);
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    final l$mode = mode;
    _resultData['mode'] = toJson$Enum$PaymentMode(l$mode);
    final l$nullableId = nullableId;
    _resultData['nullableId'] = l$nullableId;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$id = id;
    final l$name = name;
    final l$isDefault = isDefault;
    final l$providerBrand = providerBrand;
    final l$$__typename = $__typename;
    final l$mode = mode;
    final l$nullableId = nullableId;
    return Object.hashAll([
      l$id,
      l$name,
      l$isDefault,
      l$providerBrand,
      l$$__typename,
      l$mode,
      l$nullableId,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$PaymentMethod$$SavedAccount ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$id = id;
    final lOther$id = other.id;
    if (l$id != lOther$id) {
      return false;
    }
    final l$name = name;
    final lOther$name = other.name;
    if (l$name != lOther$name) {
      return false;
    }
    final l$isDefault = isDefault;
    final lOther$isDefault = other.isDefault;
    if (l$isDefault != lOther$isDefault) {
      return false;
    }
    final l$providerBrand = providerBrand;
    final lOther$providerBrand = other.providerBrand;
    if (l$providerBrand != lOther$providerBrand) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    final l$mode = mode;
    final lOther$mode = other.mode;
    if (l$mode != lOther$mode) {
      return false;
    }
    final l$nullableId = nullableId;
    final lOther$nullableId = other.nullableId;
    if (l$nullableId != lOther$nullableId) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$PaymentMethod$$SavedAccount
    on Fragment$PaymentMethod$$SavedAccount {
  CopyWith$Fragment$PaymentMethod$$SavedAccount<
    Fragment$PaymentMethod$$SavedAccount
  >
  get copyWith => CopyWith$Fragment$PaymentMethod$$SavedAccount(this, (i) => i);
}

abstract class CopyWith$Fragment$PaymentMethod$$SavedAccount<TRes> {
  factory CopyWith$Fragment$PaymentMethod$$SavedAccount(
    Fragment$PaymentMethod$$SavedAccount instance,
    TRes Function(Fragment$PaymentMethod$$SavedAccount) then,
  ) = _CopyWithImpl$Fragment$PaymentMethod$$SavedAccount;

  factory CopyWith$Fragment$PaymentMethod$$SavedAccount.stub(TRes res) =
      _CopyWithStubImpl$Fragment$PaymentMethod$$SavedAccount;

  TRes call({
    String? id,
    String? name,
    bool? isDefault,
    Enum$ProviderBrand? providerBrand,
    String? $__typename,
    Enum$PaymentMode? mode,
    String? nullableId,
  });
}

class _CopyWithImpl$Fragment$PaymentMethod$$SavedAccount<TRes>
    implements CopyWith$Fragment$PaymentMethod$$SavedAccount<TRes> {
  _CopyWithImpl$Fragment$PaymentMethod$$SavedAccount(
    this._instance,
    this._then,
  );

  final Fragment$PaymentMethod$$SavedAccount _instance;

  final TRes Function(Fragment$PaymentMethod$$SavedAccount) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? id = _undefined,
    Object? name = _undefined,
    Object? isDefault = _undefined,
    Object? providerBrand = _undefined,
    Object? $__typename = _undefined,
    Object? mode = _undefined,
    Object? nullableId = _undefined,
  }) => _then(
    Fragment$PaymentMethod$$SavedAccount(
      id: id == _undefined || id == null ? _instance.id : (id as String),
      name: name == _undefined || name == null
          ? _instance.name
          : (name as String),
      isDefault: isDefault == _undefined || isDefault == null
          ? _instance.isDefault
          : (isDefault as bool),
      providerBrand: providerBrand == _undefined
          ? _instance.providerBrand
          : (providerBrand as Enum$ProviderBrand?),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
      mode: mode == _undefined || mode == null
          ? _instance.mode
          : (mode as Enum$PaymentMode),
      nullableId: nullableId == _undefined || nullableId == null
          ? _instance.nullableId
          : (nullableId as String),
    ),
  );
}

class _CopyWithStubImpl$Fragment$PaymentMethod$$SavedAccount<TRes>
    implements CopyWith$Fragment$PaymentMethod$$SavedAccount<TRes> {
  _CopyWithStubImpl$Fragment$PaymentMethod$$SavedAccount(this._res);

  TRes _res;

  call({
    String? id,
    String? name,
    bool? isDefault,
    Enum$ProviderBrand? providerBrand,
    String? $__typename,
    Enum$PaymentMode? mode,
    String? nullableId,
  }) => _res;
}

class Fragment$PaymentMethod$$OnlinePaymentMethod
    implements Fragment$OnlinePaymentMethod, Fragment$PaymentMethod {
  Fragment$PaymentMethod$$OnlinePaymentMethod({
    required this.id,
    required this.name,
    this.imageUrl,
    required this.linkMethod,
    this.$__typename = 'OnlinePaymentMethod',
    required this.mode,
    required this.nullableId,
  });

  factory Fragment$PaymentMethod$$OnlinePaymentMethod.fromJson(
    Map<String, dynamic> json,
  ) {
    final l$id = json['id'];
    final l$name = json['name'];
    final l$imageUrl = json['imageUrl'];
    final l$linkMethod = json['linkMethod'];
    final l$$__typename = json['__typename'];
    final l$mode = json['mode'];
    final l$nullableId = json['nullableId'];
    return Fragment$PaymentMethod$$OnlinePaymentMethod(
      id: (l$id as String),
      name: (l$name as String),
      imageUrl: (l$imageUrl as String?),
      linkMethod: fromJson$Enum$GatewayLinkMethod((l$linkMethod as String)),
      $__typename: (l$$__typename as String),
      mode: fromJson$Enum$PaymentMode((l$mode as String)),
      nullableId: (l$nullableId as String),
    );
  }

  final String id;

  final String name;

  final String? imageUrl;

  final Enum$GatewayLinkMethod linkMethod;

  final String $__typename;

  final Enum$PaymentMode mode;

  final String nullableId;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$id = id;
    _resultData['id'] = l$id;
    final l$name = name;
    _resultData['name'] = l$name;
    final l$imageUrl = imageUrl;
    _resultData['imageUrl'] = l$imageUrl;
    final l$linkMethod = linkMethod;
    _resultData['linkMethod'] = toJson$Enum$GatewayLinkMethod(l$linkMethod);
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    final l$mode = mode;
    _resultData['mode'] = toJson$Enum$PaymentMode(l$mode);
    final l$nullableId = nullableId;
    _resultData['nullableId'] = l$nullableId;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$id = id;
    final l$name = name;
    final l$imageUrl = imageUrl;
    final l$linkMethod = linkMethod;
    final l$$__typename = $__typename;
    final l$mode = mode;
    final l$nullableId = nullableId;
    return Object.hashAll([
      l$id,
      l$name,
      l$imageUrl,
      l$linkMethod,
      l$$__typename,
      l$mode,
      l$nullableId,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$PaymentMethod$$OnlinePaymentMethod ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$id = id;
    final lOther$id = other.id;
    if (l$id != lOther$id) {
      return false;
    }
    final l$name = name;
    final lOther$name = other.name;
    if (l$name != lOther$name) {
      return false;
    }
    final l$imageUrl = imageUrl;
    final lOther$imageUrl = other.imageUrl;
    if (l$imageUrl != lOther$imageUrl) {
      return false;
    }
    final l$linkMethod = linkMethod;
    final lOther$linkMethod = other.linkMethod;
    if (l$linkMethod != lOther$linkMethod) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    final l$mode = mode;
    final lOther$mode = other.mode;
    if (l$mode != lOther$mode) {
      return false;
    }
    final l$nullableId = nullableId;
    final lOther$nullableId = other.nullableId;
    if (l$nullableId != lOther$nullableId) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$PaymentMethod$$OnlinePaymentMethod
    on Fragment$PaymentMethod$$OnlinePaymentMethod {
  CopyWith$Fragment$PaymentMethod$$OnlinePaymentMethod<
    Fragment$PaymentMethod$$OnlinePaymentMethod
  >
  get copyWith =>
      CopyWith$Fragment$PaymentMethod$$OnlinePaymentMethod(this, (i) => i);
}

abstract class CopyWith$Fragment$PaymentMethod$$OnlinePaymentMethod<TRes> {
  factory CopyWith$Fragment$PaymentMethod$$OnlinePaymentMethod(
    Fragment$PaymentMethod$$OnlinePaymentMethod instance,
    TRes Function(Fragment$PaymentMethod$$OnlinePaymentMethod) then,
  ) = _CopyWithImpl$Fragment$PaymentMethod$$OnlinePaymentMethod;

  factory CopyWith$Fragment$PaymentMethod$$OnlinePaymentMethod.stub(TRes res) =
      _CopyWithStubImpl$Fragment$PaymentMethod$$OnlinePaymentMethod;

  TRes call({
    String? id,
    String? name,
    String? imageUrl,
    Enum$GatewayLinkMethod? linkMethod,
    String? $__typename,
    Enum$PaymentMode? mode,
    String? nullableId,
  });
}

class _CopyWithImpl$Fragment$PaymentMethod$$OnlinePaymentMethod<TRes>
    implements CopyWith$Fragment$PaymentMethod$$OnlinePaymentMethod<TRes> {
  _CopyWithImpl$Fragment$PaymentMethod$$OnlinePaymentMethod(
    this._instance,
    this._then,
  );

  final Fragment$PaymentMethod$$OnlinePaymentMethod _instance;

  final TRes Function(Fragment$PaymentMethod$$OnlinePaymentMethod) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? id = _undefined,
    Object? name = _undefined,
    Object? imageUrl = _undefined,
    Object? linkMethod = _undefined,
    Object? $__typename = _undefined,
    Object? mode = _undefined,
    Object? nullableId = _undefined,
  }) => _then(
    Fragment$PaymentMethod$$OnlinePaymentMethod(
      id: id == _undefined || id == null ? _instance.id : (id as String),
      name: name == _undefined || name == null
          ? _instance.name
          : (name as String),
      imageUrl: imageUrl == _undefined
          ? _instance.imageUrl
          : (imageUrl as String?),
      linkMethod: linkMethod == _undefined || linkMethod == null
          ? _instance.linkMethod
          : (linkMethod as Enum$GatewayLinkMethod),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
      mode: mode == _undefined || mode == null
          ? _instance.mode
          : (mode as Enum$PaymentMode),
      nullableId: nullableId == _undefined || nullableId == null
          ? _instance.nullableId
          : (nullableId as String),
    ),
  );
}

class _CopyWithStubImpl$Fragment$PaymentMethod$$OnlinePaymentMethod<TRes>
    implements CopyWith$Fragment$PaymentMethod$$OnlinePaymentMethod<TRes> {
  _CopyWithStubImpl$Fragment$PaymentMethod$$OnlinePaymentMethod(this._res);

  TRes _res;

  call({
    String? id,
    String? name,
    String? imageUrl,
    Enum$GatewayLinkMethod? linkMethod,
    String? $__typename,
    Enum$PaymentMode? mode,
    String? nullableId,
  }) => _res;
}

class Fragment$SavedAccount {
  Fragment$SavedAccount({
    required this.id,
    required this.name,
    required this.isDefault,
    this.providerBrand,
    this.$__typename = 'SavedAccount',
  });

  factory Fragment$SavedAccount.fromJson(Map<String, dynamic> json) {
    final l$id = json['id'];
    final l$name = json['name'];
    final l$isDefault = json['isDefault'];
    final l$providerBrand = json['providerBrand'];
    final l$$__typename = json['__typename'];
    return Fragment$SavedAccount(
      id: (l$id as String),
      name: (l$name as String),
      isDefault: (l$isDefault as bool),
      providerBrand: l$providerBrand == null
          ? null
          : fromJson$Enum$ProviderBrand((l$providerBrand as String)),
      $__typename: (l$$__typename as String),
    );
  }

  final String id;

  final String name;

  final bool isDefault;

  final Enum$ProviderBrand? providerBrand;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$id = id;
    _resultData['id'] = l$id;
    final l$name = name;
    _resultData['name'] = l$name;
    final l$isDefault = isDefault;
    _resultData['isDefault'] = l$isDefault;
    final l$providerBrand = providerBrand;
    _resultData['providerBrand'] = l$providerBrand == null
        ? null
        : toJson$Enum$ProviderBrand(l$providerBrand);
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$id = id;
    final l$name = name;
    final l$isDefault = isDefault;
    final l$providerBrand = providerBrand;
    final l$$__typename = $__typename;
    return Object.hashAll([
      l$id,
      l$name,
      l$isDefault,
      l$providerBrand,
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$SavedAccount || runtimeType != other.runtimeType) {
      return false;
    }
    final l$id = id;
    final lOther$id = other.id;
    if (l$id != lOther$id) {
      return false;
    }
    final l$name = name;
    final lOther$name = other.name;
    if (l$name != lOther$name) {
      return false;
    }
    final l$isDefault = isDefault;
    final lOther$isDefault = other.isDefault;
    if (l$isDefault != lOther$isDefault) {
      return false;
    }
    final l$providerBrand = providerBrand;
    final lOther$providerBrand = other.providerBrand;
    if (l$providerBrand != lOther$providerBrand) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$SavedAccount on Fragment$SavedAccount {
  CopyWith$Fragment$SavedAccount<Fragment$SavedAccount> get copyWith =>
      CopyWith$Fragment$SavedAccount(this, (i) => i);
}

abstract class CopyWith$Fragment$SavedAccount<TRes> {
  factory CopyWith$Fragment$SavedAccount(
    Fragment$SavedAccount instance,
    TRes Function(Fragment$SavedAccount) then,
  ) = _CopyWithImpl$Fragment$SavedAccount;

  factory CopyWith$Fragment$SavedAccount.stub(TRes res) =
      _CopyWithStubImpl$Fragment$SavedAccount;

  TRes call({
    String? id,
    String? name,
    bool? isDefault,
    Enum$ProviderBrand? providerBrand,
    String? $__typename,
  });
}

class _CopyWithImpl$Fragment$SavedAccount<TRes>
    implements CopyWith$Fragment$SavedAccount<TRes> {
  _CopyWithImpl$Fragment$SavedAccount(this._instance, this._then);

  final Fragment$SavedAccount _instance;

  final TRes Function(Fragment$SavedAccount) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? id = _undefined,
    Object? name = _undefined,
    Object? isDefault = _undefined,
    Object? providerBrand = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Fragment$SavedAccount(
      id: id == _undefined || id == null ? _instance.id : (id as String),
      name: name == _undefined || name == null
          ? _instance.name
          : (name as String),
      isDefault: isDefault == _undefined || isDefault == null
          ? _instance.isDefault
          : (isDefault as bool),
      providerBrand: providerBrand == _undefined
          ? _instance.providerBrand
          : (providerBrand as Enum$ProviderBrand?),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );
}

class _CopyWithStubImpl$Fragment$SavedAccount<TRes>
    implements CopyWith$Fragment$SavedAccount<TRes> {
  _CopyWithStubImpl$Fragment$SavedAccount(this._res);

  TRes _res;

  call({
    String? id,
    String? name,
    bool? isDefault,
    Enum$ProviderBrand? providerBrand,
    String? $__typename,
  }) => _res;
}

const fragmentDefinitionSavedAccount = FragmentDefinitionNode(
  name: NameNode(value: 'SavedAccount'),
  typeCondition: TypeConditionNode(
    on: NamedTypeNode(name: NameNode(value: 'SavedAccount'), isNonNull: false),
  ),
  directives: [],
  selectionSet: SelectionSetNode(
    selections: [
      FieldNode(
        name: NameNode(value: 'id'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'name'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'isDefault'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'providerBrand'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: '__typename'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
    ],
  ),
);
const documentNodeFragmentSavedAccount = DocumentNode(
  definitions: [fragmentDefinitionSavedAccount],
);

extension ClientExtension$Fragment$SavedAccount on graphql.GraphQLClient {
  void writeFragment$SavedAccount({
    required Fragment$SavedAccount data,
    required Map<String, dynamic> idFields,
    bool broadcast = true,
  }) => this.writeFragment(
    graphql.FragmentRequest(
      idFields: idFields,
      fragment: const graphql.Fragment(
        fragmentName: 'SavedAccount',
        document: documentNodeFragmentSavedAccount,
      ),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Fragment$SavedAccount? readFragment$SavedAccount({
    required Map<String, dynamic> idFields,
    bool optimistic = true,
  }) {
    final result = this.readFragment(
      graphql.FragmentRequest(
        idFields: idFields,
        fragment: const graphql.Fragment(
          fragmentName: 'SavedAccount',
          document: documentNodeFragmentSavedAccount,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Fragment$SavedAccount.fromJson(result);
  }
}

class Fragment$OnlinePaymentMethod {
  Fragment$OnlinePaymentMethod({
    required this.id,
    required this.name,
    this.imageUrl,
    required this.linkMethod,
    this.$__typename = 'OnlinePaymentMethod',
  });

  factory Fragment$OnlinePaymentMethod.fromJson(Map<String, dynamic> json) {
    final l$id = json['id'];
    final l$name = json['name'];
    final l$imageUrl = json['imageUrl'];
    final l$linkMethod = json['linkMethod'];
    final l$$__typename = json['__typename'];
    return Fragment$OnlinePaymentMethod(
      id: (l$id as String),
      name: (l$name as String),
      imageUrl: (l$imageUrl as String?),
      linkMethod: fromJson$Enum$GatewayLinkMethod((l$linkMethod as String)),
      $__typename: (l$$__typename as String),
    );
  }

  final String id;

  final String name;

  final String? imageUrl;

  final Enum$GatewayLinkMethod linkMethod;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$id = id;
    _resultData['id'] = l$id;
    final l$name = name;
    _resultData['name'] = l$name;
    final l$imageUrl = imageUrl;
    _resultData['imageUrl'] = l$imageUrl;
    final l$linkMethod = linkMethod;
    _resultData['linkMethod'] = toJson$Enum$GatewayLinkMethod(l$linkMethod);
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$id = id;
    final l$name = name;
    final l$imageUrl = imageUrl;
    final l$linkMethod = linkMethod;
    final l$$__typename = $__typename;
    return Object.hashAll([
      l$id,
      l$name,
      l$imageUrl,
      l$linkMethod,
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Fragment$OnlinePaymentMethod ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$id = id;
    final lOther$id = other.id;
    if (l$id != lOther$id) {
      return false;
    }
    final l$name = name;
    final lOther$name = other.name;
    if (l$name != lOther$name) {
      return false;
    }
    final l$imageUrl = imageUrl;
    final lOther$imageUrl = other.imageUrl;
    if (l$imageUrl != lOther$imageUrl) {
      return false;
    }
    final l$linkMethod = linkMethod;
    final lOther$linkMethod = other.linkMethod;
    if (l$linkMethod != lOther$linkMethod) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Fragment$OnlinePaymentMethod
    on Fragment$OnlinePaymentMethod {
  CopyWith$Fragment$OnlinePaymentMethod<Fragment$OnlinePaymentMethod>
  get copyWith => CopyWith$Fragment$OnlinePaymentMethod(this, (i) => i);
}

abstract class CopyWith$Fragment$OnlinePaymentMethod<TRes> {
  factory CopyWith$Fragment$OnlinePaymentMethod(
    Fragment$OnlinePaymentMethod instance,
    TRes Function(Fragment$OnlinePaymentMethod) then,
  ) = _CopyWithImpl$Fragment$OnlinePaymentMethod;

  factory CopyWith$Fragment$OnlinePaymentMethod.stub(TRes res) =
      _CopyWithStubImpl$Fragment$OnlinePaymentMethod;

  TRes call({
    String? id,
    String? name,
    String? imageUrl,
    Enum$GatewayLinkMethod? linkMethod,
    String? $__typename,
  });
}

class _CopyWithImpl$Fragment$OnlinePaymentMethod<TRes>
    implements CopyWith$Fragment$OnlinePaymentMethod<TRes> {
  _CopyWithImpl$Fragment$OnlinePaymentMethod(this._instance, this._then);

  final Fragment$OnlinePaymentMethod _instance;

  final TRes Function(Fragment$OnlinePaymentMethod) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? id = _undefined,
    Object? name = _undefined,
    Object? imageUrl = _undefined,
    Object? linkMethod = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Fragment$OnlinePaymentMethod(
      id: id == _undefined || id == null ? _instance.id : (id as String),
      name: name == _undefined || name == null
          ? _instance.name
          : (name as String),
      imageUrl: imageUrl == _undefined
          ? _instance.imageUrl
          : (imageUrl as String?),
      linkMethod: linkMethod == _undefined || linkMethod == null
          ? _instance.linkMethod
          : (linkMethod as Enum$GatewayLinkMethod),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );
}

class _CopyWithStubImpl$Fragment$OnlinePaymentMethod<TRes>
    implements CopyWith$Fragment$OnlinePaymentMethod<TRes> {
  _CopyWithStubImpl$Fragment$OnlinePaymentMethod(this._res);

  TRes _res;

  call({
    String? id,
    String? name,
    String? imageUrl,
    Enum$GatewayLinkMethod? linkMethod,
    String? $__typename,
  }) => _res;
}

const fragmentDefinitionOnlinePaymentMethod = FragmentDefinitionNode(
  name: NameNode(value: 'OnlinePaymentMethod'),
  typeCondition: TypeConditionNode(
    on: NamedTypeNode(
      name: NameNode(value: 'OnlinePaymentMethod'),
      isNonNull: false,
    ),
  ),
  directives: [],
  selectionSet: SelectionSetNode(
    selections: [
      FieldNode(
        name: NameNode(value: 'id'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'name'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'imageUrl'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: 'linkMethod'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
      FieldNode(
        name: NameNode(value: '__typename'),
        alias: null,
        arguments: [],
        directives: [],
        selectionSet: null,
      ),
    ],
  ),
);
const documentNodeFragmentOnlinePaymentMethod = DocumentNode(
  definitions: [fragmentDefinitionOnlinePaymentMethod],
);

extension ClientExtension$Fragment$OnlinePaymentMethod
    on graphql.GraphQLClient {
  void writeFragment$OnlinePaymentMethod({
    required Fragment$OnlinePaymentMethod data,
    required Map<String, dynamic> idFields,
    bool broadcast = true,
  }) => this.writeFragment(
    graphql.FragmentRequest(
      idFields: idFields,
      fragment: const graphql.Fragment(
        fragmentName: 'OnlinePaymentMethod',
        document: documentNodeFragmentOnlinePaymentMethod,
      ),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Fragment$OnlinePaymentMethod? readFragment$OnlinePaymentMethod({
    required Map<String, dynamic> idFields,
    bool optimistic = true,
  }) {
    final result = this.readFragment(
      graphql.FragmentRequest(
        idFields: idFields,
        fragment: const graphql.Fragment(
          fragmentName: 'OnlinePaymentMethod',
          document: documentNodeFragmentOnlinePaymentMethod,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null
        ? null
        : Fragment$OnlinePaymentMethod.fromJson(result);
  }
}
