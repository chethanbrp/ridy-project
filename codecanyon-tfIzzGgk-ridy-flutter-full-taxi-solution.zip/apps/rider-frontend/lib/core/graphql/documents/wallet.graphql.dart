import '../fragments/intent_result.fragment.graphql.dart';
import '../fragments/payment_method.fragment.graphql.dart';
import '../fragments/rider_transaction.fragment.graphql.dart';
import '../fragments/wallet.fragment.graphql.dart';
import '../schema.gql.dart';
import 'dart:async';
import 'package:gql/ast.dart';
import 'package:graphql/client.dart' as graphql;

class Query$Wallet {
  Query$Wallet({
    required this.riderTransactions,
    required this.riderWallets,
    required this.paymentMethods,
    this.$__typename = 'Query',
  });

  factory Query$Wallet.fromJson(Map<String, dynamic> json) {
    final l$riderTransactions = json['riderTransactions'];
    final l$riderWallets = json['riderWallets'];
    final l$paymentMethods = json['paymentMethods'];
    final l$$__typename = json['__typename'];
    return Query$Wallet(
      riderTransactions: (l$riderTransactions as List<dynamic>)
          .map(
            (e) =>
                Fragment$RiderTransaction.fromJson((e as Map<String, dynamic>)),
          )
          .toList(),
      riderWallets: (l$riderWallets as List<dynamic>)
          .map((e) => Fragment$Wallet.fromJson((e as Map<String, dynamic>)))
          .toList(),
      paymentMethods: (l$paymentMethods as List<dynamic>)
          .map(
            (e) => Fragment$PaymentMethod.fromJson((e as Map<String, dynamic>)),
          )
          .toList(),
      $__typename: (l$$__typename as String),
    );
  }

  final List<Fragment$RiderTransaction> riderTransactions;

  final List<Fragment$Wallet> riderWallets;

  final List<Fragment$PaymentMethod> paymentMethods;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$riderTransactions = riderTransactions;
    _resultData['riderTransactions'] = l$riderTransactions
        .map((e) => e.toJson())
        .toList();
    final l$riderWallets = riderWallets;
    _resultData['riderWallets'] = l$riderWallets
        .map((e) => e.toJson())
        .toList();
    final l$paymentMethods = paymentMethods;
    _resultData['paymentMethods'] = l$paymentMethods
        .map((e) => e.toJson())
        .toList();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$riderTransactions = riderTransactions;
    final l$riderWallets = riderWallets;
    final l$paymentMethods = paymentMethods;
    final l$$__typename = $__typename;
    return Object.hashAll([
      Object.hashAll(l$riderTransactions.map((v) => v)),
      Object.hashAll(l$riderWallets.map((v) => v)),
      Object.hashAll(l$paymentMethods.map((v) => v)),
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Query$Wallet || runtimeType != other.runtimeType) {
      return false;
    }
    final l$riderTransactions = riderTransactions;
    final lOther$riderTransactions = other.riderTransactions;
    if (l$riderTransactions.length != lOther$riderTransactions.length) {
      return false;
    }
    for (int i = 0; i < l$riderTransactions.length; i++) {
      final l$riderTransactions$entry = l$riderTransactions[i];
      final lOther$riderTransactions$entry = lOther$riderTransactions[i];
      if (l$riderTransactions$entry != lOther$riderTransactions$entry) {
        return false;
      }
    }
    final l$riderWallets = riderWallets;
    final lOther$riderWallets = other.riderWallets;
    if (l$riderWallets.length != lOther$riderWallets.length) {
      return false;
    }
    for (int i = 0; i < l$riderWallets.length; i++) {
      final l$riderWallets$entry = l$riderWallets[i];
      final lOther$riderWallets$entry = lOther$riderWallets[i];
      if (l$riderWallets$entry != lOther$riderWallets$entry) {
        return false;
      }
    }
    final l$paymentMethods = paymentMethods;
    final lOther$paymentMethods = other.paymentMethods;
    if (l$paymentMethods.length != lOther$paymentMethods.length) {
      return false;
    }
    for (int i = 0; i < l$paymentMethods.length; i++) {
      final l$paymentMethods$entry = l$paymentMethods[i];
      final lOther$paymentMethods$entry = lOther$paymentMethods[i];
      if (l$paymentMethods$entry != lOther$paymentMethods$entry) {
        return false;
      }
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Query$Wallet on Query$Wallet {
  CopyWith$Query$Wallet<Query$Wallet> get copyWith =>
      CopyWith$Query$Wallet(this, (i) => i);
}

abstract class CopyWith$Query$Wallet<TRes> {
  factory CopyWith$Query$Wallet(
    Query$Wallet instance,
    TRes Function(Query$Wallet) then,
  ) = _CopyWithImpl$Query$Wallet;

  factory CopyWith$Query$Wallet.stub(TRes res) = _CopyWithStubImpl$Query$Wallet;

  TRes call({
    List<Fragment$RiderTransaction>? riderTransactions,
    List<Fragment$Wallet>? riderWallets,
    List<Fragment$PaymentMethod>? paymentMethods,
    String? $__typename,
  });
  TRes riderTransactions(
    Iterable<Fragment$RiderTransaction> Function(
      Iterable<CopyWith$Fragment$RiderTransaction<Fragment$RiderTransaction>>,
    )
    _fn,
  );
  TRes riderWallets(
    Iterable<Fragment$Wallet> Function(
      Iterable<CopyWith$Fragment$Wallet<Fragment$Wallet>>,
    )
    _fn,
  );
  TRes paymentMethods(
    Iterable<Fragment$PaymentMethod> Function(
      Iterable<CopyWith$Fragment$PaymentMethod<Fragment$PaymentMethod>>,
    )
    _fn,
  );
}

class _CopyWithImpl$Query$Wallet<TRes> implements CopyWith$Query$Wallet<TRes> {
  _CopyWithImpl$Query$Wallet(this._instance, this._then);

  final Query$Wallet _instance;

  final TRes Function(Query$Wallet) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? riderTransactions = _undefined,
    Object? riderWallets = _undefined,
    Object? paymentMethods = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Query$Wallet(
      riderTransactions:
          riderTransactions == _undefined || riderTransactions == null
          ? _instance.riderTransactions
          : (riderTransactions as List<Fragment$RiderTransaction>),
      riderWallets: riderWallets == _undefined || riderWallets == null
          ? _instance.riderWallets
          : (riderWallets as List<Fragment$Wallet>),
      paymentMethods: paymentMethods == _undefined || paymentMethods == null
          ? _instance.paymentMethods
          : (paymentMethods as List<Fragment$PaymentMethod>),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  TRes riderTransactions(
    Iterable<Fragment$RiderTransaction> Function(
      Iterable<CopyWith$Fragment$RiderTransaction<Fragment$RiderTransaction>>,
    )
    _fn,
  ) => call(
    riderTransactions: _fn(
      _instance.riderTransactions.map(
        (e) => CopyWith$Fragment$RiderTransaction(e, (i) => i),
      ),
    ).toList(),
  );

  TRes riderWallets(
    Iterable<Fragment$Wallet> Function(
      Iterable<CopyWith$Fragment$Wallet<Fragment$Wallet>>,
    )
    _fn,
  ) => call(
    riderWallets: _fn(
      _instance.riderWallets.map((e) => CopyWith$Fragment$Wallet(e, (i) => i)),
    ).toList(),
  );

  TRes paymentMethods(
    Iterable<Fragment$PaymentMethod> Function(
      Iterable<CopyWith$Fragment$PaymentMethod<Fragment$PaymentMethod>>,
    )
    _fn,
  ) => call(
    paymentMethods: _fn(
      _instance.paymentMethods.map(
        (e) => CopyWith$Fragment$PaymentMethod(e, (i) => i),
      ),
    ).toList(),
  );
}

class _CopyWithStubImpl$Query$Wallet<TRes>
    implements CopyWith$Query$Wallet<TRes> {
  _CopyWithStubImpl$Query$Wallet(this._res);

  TRes _res;

  call({
    List<Fragment$RiderTransaction>? riderTransactions,
    List<Fragment$Wallet>? riderWallets,
    List<Fragment$PaymentMethod>? paymentMethods,
    String? $__typename,
  }) => _res;

  riderTransactions(_fn) => _res;

  riderWallets(_fn) => _res;

  paymentMethods(_fn) => _res;
}

const documentNodeQueryWallet = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.query,
      name: NameNode(value: 'Wallet'),
      variableDefinitions: [],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'riderTransactions'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FragmentSpreadNode(
                  name: NameNode(value: 'RiderTransaction'),
                  directives: [],
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: 'riderWallets'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FragmentSpreadNode(
                  name: NameNode(value: 'Wallet'),
                  directives: [],
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: 'paymentMethods'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FragmentSpreadNode(
                  name: NameNode(value: 'PaymentMethod'),
                  directives: [],
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
    fragmentDefinitionRiderTransaction,
    fragmentDefinitionWallet,
    fragmentDefinitionPaymentMethod,
    fragmentDefinitionSavedAccount,
    fragmentDefinitionOnlinePaymentMethod,
  ],
);
Query$Wallet _parserFn$Query$Wallet(Map<String, dynamic> data) =>
    Query$Wallet.fromJson(data);
typedef OnQueryComplete$Query$Wallet =
    FutureOr<void> Function(Map<String, dynamic>?, Query$Wallet?);

class Options$Query$Wallet extends graphql.QueryOptions<Query$Wallet> {
  Options$Query$Wallet({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$Wallet? typedOptimisticResult,
    Duration? pollInterval,
    graphql.Context? context,
    OnQueryComplete$Query$Wallet? onComplete,
    graphql.OnQueryError? onError,
  }) : onCompleteWithParsed = onComplete,
       super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         pollInterval: pollInterval,
         context: context,
         onComplete: onComplete == null
             ? null
             : (data) => onComplete(
                 data,
                 data == null ? null : _parserFn$Query$Wallet(data),
               ),
         onError: onError,
         document: documentNodeQueryWallet,
         parserFn: _parserFn$Query$Wallet,
       );

  final OnQueryComplete$Query$Wallet? onCompleteWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onComplete == null
        ? super.properties
        : super.properties.where((property) => property != onComplete),
    onCompleteWithParsed,
  ];
}

class WatchOptions$Query$Wallet
    extends graphql.WatchQueryOptions<Query$Wallet> {
  WatchOptions$Query$Wallet({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$Wallet? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeQueryWallet,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Query$Wallet,
       );
}

class FetchMoreOptions$Query$Wallet extends graphql.FetchMoreOptions {
  FetchMoreOptions$Query$Wallet({required graphql.UpdateQuery updateQuery})
    : super(updateQuery: updateQuery, document: documentNodeQueryWallet);
}

extension ClientExtension$Query$Wallet on graphql.GraphQLClient {
  Future<graphql.QueryResult<Query$Wallet>> query$Wallet([
    Options$Query$Wallet? options,
  ]) async => await this.query(options ?? Options$Query$Wallet());

  graphql.ObservableQuery<Query$Wallet> watchQuery$Wallet([
    WatchOptions$Query$Wallet? options,
  ]) => this.watchQuery(options ?? WatchOptions$Query$Wallet());

  void writeQuery$Wallet({required Query$Wallet data, bool broadcast = true}) =>
      this.writeQuery(
        graphql.Request(
          operation: graphql.Operation(document: documentNodeQueryWallet),
        ),
        data: data.toJson(),
        broadcast: broadcast,
      );

  Query$Wallet? readQuery$Wallet({bool optimistic = true}) {
    final result = this.readQuery(
      graphql.Request(
        operation: graphql.Operation(document: documentNodeQueryWallet),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Query$Wallet.fromJson(result);
  }
}

class Query$PaymentMethods {
  Query$PaymentMethods({
    required this.paymentMethods,
    this.$__typename = 'Query',
  });

  factory Query$PaymentMethods.fromJson(Map<String, dynamic> json) {
    final l$paymentMethods = json['paymentMethods'];
    final l$$__typename = json['__typename'];
    return Query$PaymentMethods(
      paymentMethods: (l$paymentMethods as List<dynamic>)
          .map(
            (e) => Fragment$PaymentMethod.fromJson((e as Map<String, dynamic>)),
          )
          .toList(),
      $__typename: (l$$__typename as String),
    );
  }

  final List<Fragment$PaymentMethod> paymentMethods;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$paymentMethods = paymentMethods;
    _resultData['paymentMethods'] = l$paymentMethods
        .map((e) => e.toJson())
        .toList();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$paymentMethods = paymentMethods;
    final l$$__typename = $__typename;
    return Object.hashAll([
      Object.hashAll(l$paymentMethods.map((v) => v)),
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Query$PaymentMethods || runtimeType != other.runtimeType) {
      return false;
    }
    final l$paymentMethods = paymentMethods;
    final lOther$paymentMethods = other.paymentMethods;
    if (l$paymentMethods.length != lOther$paymentMethods.length) {
      return false;
    }
    for (int i = 0; i < l$paymentMethods.length; i++) {
      final l$paymentMethods$entry = l$paymentMethods[i];
      final lOther$paymentMethods$entry = lOther$paymentMethods[i];
      if (l$paymentMethods$entry != lOther$paymentMethods$entry) {
        return false;
      }
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Query$PaymentMethods on Query$PaymentMethods {
  CopyWith$Query$PaymentMethods<Query$PaymentMethods> get copyWith =>
      CopyWith$Query$PaymentMethods(this, (i) => i);
}

abstract class CopyWith$Query$PaymentMethods<TRes> {
  factory CopyWith$Query$PaymentMethods(
    Query$PaymentMethods instance,
    TRes Function(Query$PaymentMethods) then,
  ) = _CopyWithImpl$Query$PaymentMethods;

  factory CopyWith$Query$PaymentMethods.stub(TRes res) =
      _CopyWithStubImpl$Query$PaymentMethods;

  TRes call({
    List<Fragment$PaymentMethod>? paymentMethods,
    String? $__typename,
  });
  TRes paymentMethods(
    Iterable<Fragment$PaymentMethod> Function(
      Iterable<CopyWith$Fragment$PaymentMethod<Fragment$PaymentMethod>>,
    )
    _fn,
  );
}

class _CopyWithImpl$Query$PaymentMethods<TRes>
    implements CopyWith$Query$PaymentMethods<TRes> {
  _CopyWithImpl$Query$PaymentMethods(this._instance, this._then);

  final Query$PaymentMethods _instance;

  final TRes Function(Query$PaymentMethods) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? paymentMethods = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Query$PaymentMethods(
      paymentMethods: paymentMethods == _undefined || paymentMethods == null
          ? _instance.paymentMethods
          : (paymentMethods as List<Fragment$PaymentMethod>),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  TRes paymentMethods(
    Iterable<Fragment$PaymentMethod> Function(
      Iterable<CopyWith$Fragment$PaymentMethod<Fragment$PaymentMethod>>,
    )
    _fn,
  ) => call(
    paymentMethods: _fn(
      _instance.paymentMethods.map(
        (e) => CopyWith$Fragment$PaymentMethod(e, (i) => i),
      ),
    ).toList(),
  );
}

class _CopyWithStubImpl$Query$PaymentMethods<TRes>
    implements CopyWith$Query$PaymentMethods<TRes> {
  _CopyWithStubImpl$Query$PaymentMethods(this._res);

  TRes _res;

  call({List<Fragment$PaymentMethod>? paymentMethods, String? $__typename}) =>
      _res;

  paymentMethods(_fn) => _res;
}

const documentNodeQueryPaymentMethods = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.query,
      name: NameNode(value: 'PaymentMethods'),
      variableDefinitions: [],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'paymentMethods'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FragmentSpreadNode(
                  name: NameNode(value: 'PaymentMethod'),
                  directives: [],
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
    fragmentDefinitionPaymentMethod,
    fragmentDefinitionSavedAccount,
    fragmentDefinitionOnlinePaymentMethod,
  ],
);
Query$PaymentMethods _parserFn$Query$PaymentMethods(
  Map<String, dynamic> data,
) => Query$PaymentMethods.fromJson(data);
typedef OnQueryComplete$Query$PaymentMethods =
    FutureOr<void> Function(Map<String, dynamic>?, Query$PaymentMethods?);

class Options$Query$PaymentMethods
    extends graphql.QueryOptions<Query$PaymentMethods> {
  Options$Query$PaymentMethods({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$PaymentMethods? typedOptimisticResult,
    Duration? pollInterval,
    graphql.Context? context,
    OnQueryComplete$Query$PaymentMethods? onComplete,
    graphql.OnQueryError? onError,
  }) : onCompleteWithParsed = onComplete,
       super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         pollInterval: pollInterval,
         context: context,
         onComplete: onComplete == null
             ? null
             : (data) => onComplete(
                 data,
                 data == null ? null : _parserFn$Query$PaymentMethods(data),
               ),
         onError: onError,
         document: documentNodeQueryPaymentMethods,
         parserFn: _parserFn$Query$PaymentMethods,
       );

  final OnQueryComplete$Query$PaymentMethods? onCompleteWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onComplete == null
        ? super.properties
        : super.properties.where((property) => property != onComplete),
    onCompleteWithParsed,
  ];
}

class WatchOptions$Query$PaymentMethods
    extends graphql.WatchQueryOptions<Query$PaymentMethods> {
  WatchOptions$Query$PaymentMethods({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$PaymentMethods? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeQueryPaymentMethods,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Query$PaymentMethods,
       );
}

class FetchMoreOptions$Query$PaymentMethods extends graphql.FetchMoreOptions {
  FetchMoreOptions$Query$PaymentMethods({
    required graphql.UpdateQuery updateQuery,
  }) : super(
         updateQuery: updateQuery,
         document: documentNodeQueryPaymentMethods,
       );
}

extension ClientExtension$Query$PaymentMethods on graphql.GraphQLClient {
  Future<graphql.QueryResult<Query$PaymentMethods>> query$PaymentMethods([
    Options$Query$PaymentMethods? options,
  ]) async => await this.query(options ?? Options$Query$PaymentMethods());

  graphql.ObservableQuery<Query$PaymentMethods> watchQuery$PaymentMethods([
    WatchOptions$Query$PaymentMethods? options,
  ]) => this.watchQuery(options ?? WatchOptions$Query$PaymentMethods());

  void writeQuery$PaymentMethods({
    required Query$PaymentMethods data,
    bool broadcast = true,
  }) => this.writeQuery(
    graphql.Request(
      operation: graphql.Operation(document: documentNodeQueryPaymentMethods),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Query$PaymentMethods? readQuery$PaymentMethods({bool optimistic = true}) {
    final result = this.readQuery(
      graphql.Request(
        operation: graphql.Operation(document: documentNodeQueryPaymentMethods),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Query$PaymentMethods.fromJson(result);
  }
}

class Variables$Mutation$GetSetupPaymentMethodLink {
  factory Variables$Mutation$GetSetupPaymentMethodLink({
    required String gatewayId,
  }) =>
      Variables$Mutation$GetSetupPaymentMethodLink._({r'gatewayId': gatewayId});

  Variables$Mutation$GetSetupPaymentMethodLink._(this._$data);

  factory Variables$Mutation$GetSetupPaymentMethodLink.fromJson(
    Map<String, dynamic> data,
  ) {
    final result$data = <String, dynamic>{};
    final l$gatewayId = data['gatewayId'];
    result$data['gatewayId'] = (l$gatewayId as String);
    return Variables$Mutation$GetSetupPaymentMethodLink._(result$data);
  }

  Map<String, dynamic> _$data;

  String get gatewayId => (_$data['gatewayId'] as String);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$gatewayId = gatewayId;
    result$data['gatewayId'] = l$gatewayId;
    return result$data;
  }

  CopyWith$Variables$Mutation$GetSetupPaymentMethodLink<
    Variables$Mutation$GetSetupPaymentMethodLink
  >
  get copyWith =>
      CopyWith$Variables$Mutation$GetSetupPaymentMethodLink(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Variables$Mutation$GetSetupPaymentMethodLink ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$gatewayId = gatewayId;
    final lOther$gatewayId = other.gatewayId;
    if (l$gatewayId != lOther$gatewayId) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$gatewayId = gatewayId;
    return Object.hashAll([l$gatewayId]);
  }
}

abstract class CopyWith$Variables$Mutation$GetSetupPaymentMethodLink<TRes> {
  factory CopyWith$Variables$Mutation$GetSetupPaymentMethodLink(
    Variables$Mutation$GetSetupPaymentMethodLink instance,
    TRes Function(Variables$Mutation$GetSetupPaymentMethodLink) then,
  ) = _CopyWithImpl$Variables$Mutation$GetSetupPaymentMethodLink;

  factory CopyWith$Variables$Mutation$GetSetupPaymentMethodLink.stub(TRes res) =
      _CopyWithStubImpl$Variables$Mutation$GetSetupPaymentMethodLink;

  TRes call({String? gatewayId});
}

class _CopyWithImpl$Variables$Mutation$GetSetupPaymentMethodLink<TRes>
    implements CopyWith$Variables$Mutation$GetSetupPaymentMethodLink<TRes> {
  _CopyWithImpl$Variables$Mutation$GetSetupPaymentMethodLink(
    this._instance,
    this._then,
  );

  final Variables$Mutation$GetSetupPaymentMethodLink _instance;

  final TRes Function(Variables$Mutation$GetSetupPaymentMethodLink) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? gatewayId = _undefined}) => _then(
    Variables$Mutation$GetSetupPaymentMethodLink._({
      ..._instance._$data,
      if (gatewayId != _undefined && gatewayId != null)
        'gatewayId': (gatewayId as String),
    }),
  );
}

class _CopyWithStubImpl$Variables$Mutation$GetSetupPaymentMethodLink<TRes>
    implements CopyWith$Variables$Mutation$GetSetupPaymentMethodLink<TRes> {
  _CopyWithStubImpl$Variables$Mutation$GetSetupPaymentMethodLink(this._res);

  TRes _res;

  call({String? gatewayId}) => _res;
}

class Mutation$GetSetupPaymentMethodLink {
  Mutation$GetSetupPaymentMethodLink({
    required this.setupPaymentMethod,
    this.$__typename = 'Mutation',
  });

  factory Mutation$GetSetupPaymentMethodLink.fromJson(
    Map<String, dynamic> json,
  ) {
    final l$setupPaymentMethod = json['setupPaymentMethod'];
    final l$$__typename = json['__typename'];
    return Mutation$GetSetupPaymentMethodLink(
      setupPaymentMethod:
          Mutation$GetSetupPaymentMethodLink$setupPaymentMethod.fromJson(
            (l$setupPaymentMethod as Map<String, dynamic>),
          ),
      $__typename: (l$$__typename as String),
    );
  }

  final Mutation$GetSetupPaymentMethodLink$setupPaymentMethod
  setupPaymentMethod;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$setupPaymentMethod = setupPaymentMethod;
    _resultData['setupPaymentMethod'] = l$setupPaymentMethod.toJson();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$setupPaymentMethod = setupPaymentMethod;
    final l$$__typename = $__typename;
    return Object.hashAll([l$setupPaymentMethod, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$GetSetupPaymentMethodLink ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$setupPaymentMethod = setupPaymentMethod;
    final lOther$setupPaymentMethod = other.setupPaymentMethod;
    if (l$setupPaymentMethod != lOther$setupPaymentMethod) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$GetSetupPaymentMethodLink
    on Mutation$GetSetupPaymentMethodLink {
  CopyWith$Mutation$GetSetupPaymentMethodLink<
    Mutation$GetSetupPaymentMethodLink
  >
  get copyWith => CopyWith$Mutation$GetSetupPaymentMethodLink(this, (i) => i);
}

abstract class CopyWith$Mutation$GetSetupPaymentMethodLink<TRes> {
  factory CopyWith$Mutation$GetSetupPaymentMethodLink(
    Mutation$GetSetupPaymentMethodLink instance,
    TRes Function(Mutation$GetSetupPaymentMethodLink) then,
  ) = _CopyWithImpl$Mutation$GetSetupPaymentMethodLink;

  factory CopyWith$Mutation$GetSetupPaymentMethodLink.stub(TRes res) =
      _CopyWithStubImpl$Mutation$GetSetupPaymentMethodLink;

  TRes call({
    Mutation$GetSetupPaymentMethodLink$setupPaymentMethod? setupPaymentMethod,
    String? $__typename,
  });
  CopyWith$Mutation$GetSetupPaymentMethodLink$setupPaymentMethod<TRes>
  get setupPaymentMethod;
}

class _CopyWithImpl$Mutation$GetSetupPaymentMethodLink<TRes>
    implements CopyWith$Mutation$GetSetupPaymentMethodLink<TRes> {
  _CopyWithImpl$Mutation$GetSetupPaymentMethodLink(this._instance, this._then);

  final Mutation$GetSetupPaymentMethodLink _instance;

  final TRes Function(Mutation$GetSetupPaymentMethodLink) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? setupPaymentMethod = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Mutation$GetSetupPaymentMethodLink(
      setupPaymentMethod:
          setupPaymentMethod == _undefined || setupPaymentMethod == null
          ? _instance.setupPaymentMethod
          : (setupPaymentMethod
                as Mutation$GetSetupPaymentMethodLink$setupPaymentMethod),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  CopyWith$Mutation$GetSetupPaymentMethodLink$setupPaymentMethod<TRes>
  get setupPaymentMethod {
    final local$setupPaymentMethod = _instance.setupPaymentMethod;
    return CopyWith$Mutation$GetSetupPaymentMethodLink$setupPaymentMethod(
      local$setupPaymentMethod,
      (e) => call(setupPaymentMethod: e),
    );
  }
}

class _CopyWithStubImpl$Mutation$GetSetupPaymentMethodLink<TRes>
    implements CopyWith$Mutation$GetSetupPaymentMethodLink<TRes> {
  _CopyWithStubImpl$Mutation$GetSetupPaymentMethodLink(this._res);

  TRes _res;

  call({
    Mutation$GetSetupPaymentMethodLink$setupPaymentMethod? setupPaymentMethod,
    String? $__typename,
  }) => _res;

  CopyWith$Mutation$GetSetupPaymentMethodLink$setupPaymentMethod<TRes>
  get setupPaymentMethod =>
      CopyWith$Mutation$GetSetupPaymentMethodLink$setupPaymentMethod.stub(_res);
}

const documentNodeMutationGetSetupPaymentMethodLink = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.mutation,
      name: NameNode(value: 'GetSetupPaymentMethodLink'),
      variableDefinitions: [
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'gatewayId')),
          type: NamedTypeNode(name: NameNode(value: 'ID'), isNonNull: true),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
      ],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'setupPaymentMethod'),
            alias: null,
            arguments: [
              ArgumentNode(
                name: NameNode(value: 'gatewayId'),
                value: VariableNode(name: NameNode(value: 'gatewayId')),
              ),
            ],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FieldNode(
                  name: NameNode(value: 'url'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
  ],
);
Mutation$GetSetupPaymentMethodLink _parserFn$Mutation$GetSetupPaymentMethodLink(
  Map<String, dynamic> data,
) => Mutation$GetSetupPaymentMethodLink.fromJson(data);
typedef OnMutationCompleted$Mutation$GetSetupPaymentMethodLink =
    FutureOr<void> Function(
      Map<String, dynamic>?,
      Mutation$GetSetupPaymentMethodLink?,
    );

class Options$Mutation$GetSetupPaymentMethodLink
    extends graphql.MutationOptions<Mutation$GetSetupPaymentMethodLink> {
  Options$Mutation$GetSetupPaymentMethodLink({
    String? operationName,
    required Variables$Mutation$GetSetupPaymentMethodLink variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$GetSetupPaymentMethodLink? typedOptimisticResult,
    graphql.Context? context,
    OnMutationCompleted$Mutation$GetSetupPaymentMethodLink? onCompleted,
    graphql.OnMutationUpdate<Mutation$GetSetupPaymentMethodLink>? update,
    graphql.OnError? onError,
  }) : onCompletedWithParsed = onCompleted,
       super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         onCompleted: onCompleted == null
             ? null
             : (data) => onCompleted(
                 data,
                 data == null
                     ? null
                     : _parserFn$Mutation$GetSetupPaymentMethodLink(data),
               ),
         update: update,
         onError: onError,
         document: documentNodeMutationGetSetupPaymentMethodLink,
         parserFn: _parserFn$Mutation$GetSetupPaymentMethodLink,
       );

  final OnMutationCompleted$Mutation$GetSetupPaymentMethodLink?
  onCompletedWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onCompleted == null
        ? super.properties
        : super.properties.where((property) => property != onCompleted),
    onCompletedWithParsed,
  ];
}

class WatchOptions$Mutation$GetSetupPaymentMethodLink
    extends graphql.WatchQueryOptions<Mutation$GetSetupPaymentMethodLink> {
  WatchOptions$Mutation$GetSetupPaymentMethodLink({
    String? operationName,
    required Variables$Mutation$GetSetupPaymentMethodLink variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$GetSetupPaymentMethodLink? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeMutationGetSetupPaymentMethodLink,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Mutation$GetSetupPaymentMethodLink,
       );
}

extension ClientExtension$Mutation$GetSetupPaymentMethodLink
    on graphql.GraphQLClient {
  Future<graphql.QueryResult<Mutation$GetSetupPaymentMethodLink>>
  mutate$GetSetupPaymentMethodLink(
    Options$Mutation$GetSetupPaymentMethodLink options,
  ) async => await this.mutate(options);

  graphql.ObservableQuery<Mutation$GetSetupPaymentMethodLink>
  watchMutation$GetSetupPaymentMethodLink(
    WatchOptions$Mutation$GetSetupPaymentMethodLink options,
  ) => this.watchMutation(options);
}

class Mutation$GetSetupPaymentMethodLink$setupPaymentMethod {
  Mutation$GetSetupPaymentMethodLink$setupPaymentMethod({
    this.url,
    this.$__typename = 'SetupPaymentMethod',
  });

  factory Mutation$GetSetupPaymentMethodLink$setupPaymentMethod.fromJson(
    Map<String, dynamic> json,
  ) {
    final l$url = json['url'];
    final l$$__typename = json['__typename'];
    return Mutation$GetSetupPaymentMethodLink$setupPaymentMethod(
      url: (l$url as String?),
      $__typename: (l$$__typename as String),
    );
  }

  final String? url;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$url = url;
    _resultData['url'] = l$url;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$url = url;
    final l$$__typename = $__typename;
    return Object.hashAll([l$url, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$GetSetupPaymentMethodLink$setupPaymentMethod ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$url = url;
    final lOther$url = other.url;
    if (l$url != lOther$url) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$GetSetupPaymentMethodLink$setupPaymentMethod
    on Mutation$GetSetupPaymentMethodLink$setupPaymentMethod {
  CopyWith$Mutation$GetSetupPaymentMethodLink$setupPaymentMethod<
    Mutation$GetSetupPaymentMethodLink$setupPaymentMethod
  >
  get copyWith =>
      CopyWith$Mutation$GetSetupPaymentMethodLink$setupPaymentMethod(
        this,
        (i) => i,
      );
}

abstract class CopyWith$Mutation$GetSetupPaymentMethodLink$setupPaymentMethod<
  TRes
> {
  factory CopyWith$Mutation$GetSetupPaymentMethodLink$setupPaymentMethod(
    Mutation$GetSetupPaymentMethodLink$setupPaymentMethod instance,
    TRes Function(Mutation$GetSetupPaymentMethodLink$setupPaymentMethod) then,
  ) = _CopyWithImpl$Mutation$GetSetupPaymentMethodLink$setupPaymentMethod;

  factory CopyWith$Mutation$GetSetupPaymentMethodLink$setupPaymentMethod.stub(
    TRes res,
  ) = _CopyWithStubImpl$Mutation$GetSetupPaymentMethodLink$setupPaymentMethod;

  TRes call({String? url, String? $__typename});
}

class _CopyWithImpl$Mutation$GetSetupPaymentMethodLink$setupPaymentMethod<TRes>
    implements
        CopyWith$Mutation$GetSetupPaymentMethodLink$setupPaymentMethod<TRes> {
  _CopyWithImpl$Mutation$GetSetupPaymentMethodLink$setupPaymentMethod(
    this._instance,
    this._then,
  );

  final Mutation$GetSetupPaymentMethodLink$setupPaymentMethod _instance;

  final TRes Function(Mutation$GetSetupPaymentMethodLink$setupPaymentMethod)
  _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? url = _undefined, Object? $__typename = _undefined}) =>
      _then(
        Mutation$GetSetupPaymentMethodLink$setupPaymentMethod(
          url: url == _undefined ? _instance.url : (url as String?),
          $__typename: $__typename == _undefined || $__typename == null
              ? _instance.$__typename
              : ($__typename as String),
        ),
      );
}

class _CopyWithStubImpl$Mutation$GetSetupPaymentMethodLink$setupPaymentMethod<
  TRes
>
    implements
        CopyWith$Mutation$GetSetupPaymentMethodLink$setupPaymentMethod<TRes> {
  _CopyWithStubImpl$Mutation$GetSetupPaymentMethodLink$setupPaymentMethod(
    this._res,
  );

  TRes _res;

  call({String? url, String? $__typename}) => _res;
}

class Variables$Mutation$RedeemGiftCard {
  factory Variables$Mutation$RedeemGiftCard({required String code}) =>
      Variables$Mutation$RedeemGiftCard._({r'code': code});

  Variables$Mutation$RedeemGiftCard._(this._$data);

  factory Variables$Mutation$RedeemGiftCard.fromJson(
    Map<String, dynamic> data,
  ) {
    final result$data = <String, dynamic>{};
    final l$code = data['code'];
    result$data['code'] = (l$code as String);
    return Variables$Mutation$RedeemGiftCard._(result$data);
  }

  Map<String, dynamic> _$data;

  String get code => (_$data['code'] as String);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$code = code;
    result$data['code'] = l$code;
    return result$data;
  }

  CopyWith$Variables$Mutation$RedeemGiftCard<Variables$Mutation$RedeemGiftCard>
  get copyWith => CopyWith$Variables$Mutation$RedeemGiftCard(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Variables$Mutation$RedeemGiftCard ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$code = code;
    final lOther$code = other.code;
    if (l$code != lOther$code) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$code = code;
    return Object.hashAll([l$code]);
  }
}

abstract class CopyWith$Variables$Mutation$RedeemGiftCard<TRes> {
  factory CopyWith$Variables$Mutation$RedeemGiftCard(
    Variables$Mutation$RedeemGiftCard instance,
    TRes Function(Variables$Mutation$RedeemGiftCard) then,
  ) = _CopyWithImpl$Variables$Mutation$RedeemGiftCard;

  factory CopyWith$Variables$Mutation$RedeemGiftCard.stub(TRes res) =
      _CopyWithStubImpl$Variables$Mutation$RedeemGiftCard;

  TRes call({String? code});
}

class _CopyWithImpl$Variables$Mutation$RedeemGiftCard<TRes>
    implements CopyWith$Variables$Mutation$RedeemGiftCard<TRes> {
  _CopyWithImpl$Variables$Mutation$RedeemGiftCard(this._instance, this._then);

  final Variables$Mutation$RedeemGiftCard _instance;

  final TRes Function(Variables$Mutation$RedeemGiftCard) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? code = _undefined}) => _then(
    Variables$Mutation$RedeemGiftCard._({
      ..._instance._$data,
      if (code != _undefined && code != null) 'code': (code as String),
    }),
  );
}

class _CopyWithStubImpl$Variables$Mutation$RedeemGiftCard<TRes>
    implements CopyWith$Variables$Mutation$RedeemGiftCard<TRes> {
  _CopyWithStubImpl$Variables$Mutation$RedeemGiftCard(this._res);

  TRes _res;

  call({String? code}) => _res;
}

class Mutation$RedeemGiftCard {
  Mutation$RedeemGiftCard({
    required this.redeemGiftCard,
    this.$__typename = 'Mutation',
  });

  factory Mutation$RedeemGiftCard.fromJson(Map<String, dynamic> json) {
    final l$redeemGiftCard = json['redeemGiftCard'];
    final l$$__typename = json['__typename'];
    return Mutation$RedeemGiftCard(
      redeemGiftCard: Mutation$RedeemGiftCard$redeemGiftCard.fromJson(
        (l$redeemGiftCard as Map<String, dynamic>),
      ),
      $__typename: (l$$__typename as String),
    );
  }

  final Mutation$RedeemGiftCard$redeemGiftCard redeemGiftCard;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$redeemGiftCard = redeemGiftCard;
    _resultData['redeemGiftCard'] = l$redeemGiftCard.toJson();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$redeemGiftCard = redeemGiftCard;
    final l$$__typename = $__typename;
    return Object.hashAll([l$redeemGiftCard, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$RedeemGiftCard || runtimeType != other.runtimeType) {
      return false;
    }
    final l$redeemGiftCard = redeemGiftCard;
    final lOther$redeemGiftCard = other.redeemGiftCard;
    if (l$redeemGiftCard != lOther$redeemGiftCard) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$RedeemGiftCard on Mutation$RedeemGiftCard {
  CopyWith$Mutation$RedeemGiftCard<Mutation$RedeemGiftCard> get copyWith =>
      CopyWith$Mutation$RedeemGiftCard(this, (i) => i);
}

abstract class CopyWith$Mutation$RedeemGiftCard<TRes> {
  factory CopyWith$Mutation$RedeemGiftCard(
    Mutation$RedeemGiftCard instance,
    TRes Function(Mutation$RedeemGiftCard) then,
  ) = _CopyWithImpl$Mutation$RedeemGiftCard;

  factory CopyWith$Mutation$RedeemGiftCard.stub(TRes res) =
      _CopyWithStubImpl$Mutation$RedeemGiftCard;

  TRes call({
    Mutation$RedeemGiftCard$redeemGiftCard? redeemGiftCard,
    String? $__typename,
  });
  CopyWith$Mutation$RedeemGiftCard$redeemGiftCard<TRes> get redeemGiftCard;
}

class _CopyWithImpl$Mutation$RedeemGiftCard<TRes>
    implements CopyWith$Mutation$RedeemGiftCard<TRes> {
  _CopyWithImpl$Mutation$RedeemGiftCard(this._instance, this._then);

  final Mutation$RedeemGiftCard _instance;

  final TRes Function(Mutation$RedeemGiftCard) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? redeemGiftCard = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Mutation$RedeemGiftCard(
      redeemGiftCard: redeemGiftCard == _undefined || redeemGiftCard == null
          ? _instance.redeemGiftCard
          : (redeemGiftCard as Mutation$RedeemGiftCard$redeemGiftCard),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  CopyWith$Mutation$RedeemGiftCard$redeemGiftCard<TRes> get redeemGiftCard {
    final local$redeemGiftCard = _instance.redeemGiftCard;
    return CopyWith$Mutation$RedeemGiftCard$redeemGiftCard(
      local$redeemGiftCard,
      (e) => call(redeemGiftCard: e),
    );
  }
}

class _CopyWithStubImpl$Mutation$RedeemGiftCard<TRes>
    implements CopyWith$Mutation$RedeemGiftCard<TRes> {
  _CopyWithStubImpl$Mutation$RedeemGiftCard(this._res);

  TRes _res;

  call({
    Mutation$RedeemGiftCard$redeemGiftCard? redeemGiftCard,
    String? $__typename,
  }) => _res;

  CopyWith$Mutation$RedeemGiftCard$redeemGiftCard<TRes> get redeemGiftCard =>
      CopyWith$Mutation$RedeemGiftCard$redeemGiftCard.stub(_res);
}

const documentNodeMutationRedeemGiftCard = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.mutation,
      name: NameNode(value: 'RedeemGiftCard'),
      variableDefinitions: [
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'code')),
          type: NamedTypeNode(name: NameNode(value: 'String'), isNonNull: true),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
      ],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'redeemGiftCard'),
            alias: null,
            arguments: [
              ArgumentNode(
                name: NameNode(value: 'code'),
                value: VariableNode(name: NameNode(value: 'code')),
              ),
            ],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FieldNode(
                  name: NameNode(value: 'id'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: 'amount'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: 'currency'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
  ],
);
Mutation$RedeemGiftCard _parserFn$Mutation$RedeemGiftCard(
  Map<String, dynamic> data,
) => Mutation$RedeemGiftCard.fromJson(data);
typedef OnMutationCompleted$Mutation$RedeemGiftCard =
    FutureOr<void> Function(Map<String, dynamic>?, Mutation$RedeemGiftCard?);

class Options$Mutation$RedeemGiftCard
    extends graphql.MutationOptions<Mutation$RedeemGiftCard> {
  Options$Mutation$RedeemGiftCard({
    String? operationName,
    required Variables$Mutation$RedeemGiftCard variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$RedeemGiftCard? typedOptimisticResult,
    graphql.Context? context,
    OnMutationCompleted$Mutation$RedeemGiftCard? onCompleted,
    graphql.OnMutationUpdate<Mutation$RedeemGiftCard>? update,
    graphql.OnError? onError,
  }) : onCompletedWithParsed = onCompleted,
       super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         onCompleted: onCompleted == null
             ? null
             : (data) => onCompleted(
                 data,
                 data == null ? null : _parserFn$Mutation$RedeemGiftCard(data),
               ),
         update: update,
         onError: onError,
         document: documentNodeMutationRedeemGiftCard,
         parserFn: _parserFn$Mutation$RedeemGiftCard,
       );

  final OnMutationCompleted$Mutation$RedeemGiftCard? onCompletedWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onCompleted == null
        ? super.properties
        : super.properties.where((property) => property != onCompleted),
    onCompletedWithParsed,
  ];
}

class WatchOptions$Mutation$RedeemGiftCard
    extends graphql.WatchQueryOptions<Mutation$RedeemGiftCard> {
  WatchOptions$Mutation$RedeemGiftCard({
    String? operationName,
    required Variables$Mutation$RedeemGiftCard variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$RedeemGiftCard? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeMutationRedeemGiftCard,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Mutation$RedeemGiftCard,
       );
}

extension ClientExtension$Mutation$RedeemGiftCard on graphql.GraphQLClient {
  Future<graphql.QueryResult<Mutation$RedeemGiftCard>> mutate$RedeemGiftCard(
    Options$Mutation$RedeemGiftCard options,
  ) async => await this.mutate(options);

  graphql.ObservableQuery<Mutation$RedeemGiftCard> watchMutation$RedeemGiftCard(
    WatchOptions$Mutation$RedeemGiftCard options,
  ) => this.watchMutation(options);
}

class Mutation$RedeemGiftCard$redeemGiftCard {
  Mutation$RedeemGiftCard$redeemGiftCard({
    required this.id,
    required this.amount,
    required this.currency,
    this.$__typename = 'GiftCard',
  });

  factory Mutation$RedeemGiftCard$redeemGiftCard.fromJson(
    Map<String, dynamic> json,
  ) {
    final l$id = json['id'];
    final l$amount = json['amount'];
    final l$currency = json['currency'];
    final l$$__typename = json['__typename'];
    return Mutation$RedeemGiftCard$redeemGiftCard(
      id: (l$id as String),
      amount: (l$amount as num).toDouble(),
      currency: (l$currency as String),
      $__typename: (l$$__typename as String),
    );
  }

  final String id;

  final double amount;

  final String currency;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$id = id;
    _resultData['id'] = l$id;
    final l$amount = amount;
    _resultData['amount'] = l$amount;
    final l$currency = currency;
    _resultData['currency'] = l$currency;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$id = id;
    final l$amount = amount;
    final l$currency = currency;
    final l$$__typename = $__typename;
    return Object.hashAll([l$id, l$amount, l$currency, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$RedeemGiftCard$redeemGiftCard ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$id = id;
    final lOther$id = other.id;
    if (l$id != lOther$id) {
      return false;
    }
    final l$amount = amount;
    final lOther$amount = other.amount;
    if (l$amount != lOther$amount) {
      return false;
    }
    final l$currency = currency;
    final lOther$currency = other.currency;
    if (l$currency != lOther$currency) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$RedeemGiftCard$redeemGiftCard
    on Mutation$RedeemGiftCard$redeemGiftCard {
  CopyWith$Mutation$RedeemGiftCard$redeemGiftCard<
    Mutation$RedeemGiftCard$redeemGiftCard
  >
  get copyWith =>
      CopyWith$Mutation$RedeemGiftCard$redeemGiftCard(this, (i) => i);
}

abstract class CopyWith$Mutation$RedeemGiftCard$redeemGiftCard<TRes> {
  factory CopyWith$Mutation$RedeemGiftCard$redeemGiftCard(
    Mutation$RedeemGiftCard$redeemGiftCard instance,
    TRes Function(Mutation$RedeemGiftCard$redeemGiftCard) then,
  ) = _CopyWithImpl$Mutation$RedeemGiftCard$redeemGiftCard;

  factory CopyWith$Mutation$RedeemGiftCard$redeemGiftCard.stub(TRes res) =
      _CopyWithStubImpl$Mutation$RedeemGiftCard$redeemGiftCard;

  TRes call({
    String? id,
    double? amount,
    String? currency,
    String? $__typename,
  });
}

class _CopyWithImpl$Mutation$RedeemGiftCard$redeemGiftCard<TRes>
    implements CopyWith$Mutation$RedeemGiftCard$redeemGiftCard<TRes> {
  _CopyWithImpl$Mutation$RedeemGiftCard$redeemGiftCard(
    this._instance,
    this._then,
  );

  final Mutation$RedeemGiftCard$redeemGiftCard _instance;

  final TRes Function(Mutation$RedeemGiftCard$redeemGiftCard) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? id = _undefined,
    Object? amount = _undefined,
    Object? currency = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Mutation$RedeemGiftCard$redeemGiftCard(
      id: id == _undefined || id == null ? _instance.id : (id as String),
      amount: amount == _undefined || amount == null
          ? _instance.amount
          : (amount as double),
      currency: currency == _undefined || currency == null
          ? _instance.currency
          : (currency as String),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );
}

class _CopyWithStubImpl$Mutation$RedeemGiftCard$redeemGiftCard<TRes>
    implements CopyWith$Mutation$RedeemGiftCard$redeemGiftCard<TRes> {
  _CopyWithStubImpl$Mutation$RedeemGiftCard$redeemGiftCard(this._res);

  TRes _res;

  call({String? id, double? amount, String? currency, String? $__typename}) =>
      _res;
}

class Variables$Mutation$MarkAsDefault {
  factory Variables$Mutation$MarkAsDefault({required String id}) =>
      Variables$Mutation$MarkAsDefault._({r'id': id});

  Variables$Mutation$MarkAsDefault._(this._$data);

  factory Variables$Mutation$MarkAsDefault.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$id = data['id'];
    result$data['id'] = (l$id as String);
    return Variables$Mutation$MarkAsDefault._(result$data);
  }

  Map<String, dynamic> _$data;

  String get id => (_$data['id'] as String);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$id = id;
    result$data['id'] = l$id;
    return result$data;
  }

  CopyWith$Variables$Mutation$MarkAsDefault<Variables$Mutation$MarkAsDefault>
  get copyWith => CopyWith$Variables$Mutation$MarkAsDefault(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Variables$Mutation$MarkAsDefault ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$id = id;
    final lOther$id = other.id;
    if (l$id != lOther$id) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$id = id;
    return Object.hashAll([l$id]);
  }
}

abstract class CopyWith$Variables$Mutation$MarkAsDefault<TRes> {
  factory CopyWith$Variables$Mutation$MarkAsDefault(
    Variables$Mutation$MarkAsDefault instance,
    TRes Function(Variables$Mutation$MarkAsDefault) then,
  ) = _CopyWithImpl$Variables$Mutation$MarkAsDefault;

  factory CopyWith$Variables$Mutation$MarkAsDefault.stub(TRes res) =
      _CopyWithStubImpl$Variables$Mutation$MarkAsDefault;

  TRes call({String? id});
}

class _CopyWithImpl$Variables$Mutation$MarkAsDefault<TRes>
    implements CopyWith$Variables$Mutation$MarkAsDefault<TRes> {
  _CopyWithImpl$Variables$Mutation$MarkAsDefault(this._instance, this._then);

  final Variables$Mutation$MarkAsDefault _instance;

  final TRes Function(Variables$Mutation$MarkAsDefault) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? id = _undefined}) => _then(
    Variables$Mutation$MarkAsDefault._({
      ..._instance._$data,
      if (id != _undefined && id != null) 'id': (id as String),
    }),
  );
}

class _CopyWithStubImpl$Variables$Mutation$MarkAsDefault<TRes>
    implements CopyWith$Variables$Mutation$MarkAsDefault<TRes> {
  _CopyWithStubImpl$Variables$Mutation$MarkAsDefault(this._res);

  TRes _res;

  call({String? id}) => _res;
}

class Mutation$MarkAsDefault {
  Mutation$MarkAsDefault({
    required this.markPaymentMethodAsDefault,
    this.$__typename = 'Mutation',
  });

  factory Mutation$MarkAsDefault.fromJson(Map<String, dynamic> json) {
    final l$markPaymentMethodAsDefault = json['markPaymentMethodAsDefault'];
    final l$$__typename = json['__typename'];
    return Mutation$MarkAsDefault(
      markPaymentMethodAsDefault:
          (l$markPaymentMethodAsDefault as List<dynamic>)
              .map(
                (e) => Fragment$PaymentMethod.fromJson(
                  (e as Map<String, dynamic>),
                ),
              )
              .toList(),
      $__typename: (l$$__typename as String),
    );
  }

  final List<Fragment$PaymentMethod> markPaymentMethodAsDefault;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$markPaymentMethodAsDefault = markPaymentMethodAsDefault;
    _resultData['markPaymentMethodAsDefault'] = l$markPaymentMethodAsDefault
        .map((e) => e.toJson())
        .toList();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$markPaymentMethodAsDefault = markPaymentMethodAsDefault;
    final l$$__typename = $__typename;
    return Object.hashAll([
      Object.hashAll(l$markPaymentMethodAsDefault.map((v) => v)),
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$MarkAsDefault || runtimeType != other.runtimeType) {
      return false;
    }
    final l$markPaymentMethodAsDefault = markPaymentMethodAsDefault;
    final lOther$markPaymentMethodAsDefault = other.markPaymentMethodAsDefault;
    if (l$markPaymentMethodAsDefault.length !=
        lOther$markPaymentMethodAsDefault.length) {
      return false;
    }
    for (int i = 0; i < l$markPaymentMethodAsDefault.length; i++) {
      final l$markPaymentMethodAsDefault$entry =
          l$markPaymentMethodAsDefault[i];
      final lOther$markPaymentMethodAsDefault$entry =
          lOther$markPaymentMethodAsDefault[i];
      if (l$markPaymentMethodAsDefault$entry !=
          lOther$markPaymentMethodAsDefault$entry) {
        return false;
      }
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$MarkAsDefault on Mutation$MarkAsDefault {
  CopyWith$Mutation$MarkAsDefault<Mutation$MarkAsDefault> get copyWith =>
      CopyWith$Mutation$MarkAsDefault(this, (i) => i);
}

abstract class CopyWith$Mutation$MarkAsDefault<TRes> {
  factory CopyWith$Mutation$MarkAsDefault(
    Mutation$MarkAsDefault instance,
    TRes Function(Mutation$MarkAsDefault) then,
  ) = _CopyWithImpl$Mutation$MarkAsDefault;

  factory CopyWith$Mutation$MarkAsDefault.stub(TRes res) =
      _CopyWithStubImpl$Mutation$MarkAsDefault;

  TRes call({
    List<Fragment$PaymentMethod>? markPaymentMethodAsDefault,
    String? $__typename,
  });
  TRes markPaymentMethodAsDefault(
    Iterable<Fragment$PaymentMethod> Function(
      Iterable<CopyWith$Fragment$PaymentMethod<Fragment$PaymentMethod>>,
    )
    _fn,
  );
}

class _CopyWithImpl$Mutation$MarkAsDefault<TRes>
    implements CopyWith$Mutation$MarkAsDefault<TRes> {
  _CopyWithImpl$Mutation$MarkAsDefault(this._instance, this._then);

  final Mutation$MarkAsDefault _instance;

  final TRes Function(Mutation$MarkAsDefault) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? markPaymentMethodAsDefault = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Mutation$MarkAsDefault(
      markPaymentMethodAsDefault:
          markPaymentMethodAsDefault == _undefined ||
              markPaymentMethodAsDefault == null
          ? _instance.markPaymentMethodAsDefault
          : (markPaymentMethodAsDefault as List<Fragment$PaymentMethod>),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  TRes markPaymentMethodAsDefault(
    Iterable<Fragment$PaymentMethod> Function(
      Iterable<CopyWith$Fragment$PaymentMethod<Fragment$PaymentMethod>>,
    )
    _fn,
  ) => call(
    markPaymentMethodAsDefault: _fn(
      _instance.markPaymentMethodAsDefault.map(
        (e) => CopyWith$Fragment$PaymentMethod(e, (i) => i),
      ),
    ).toList(),
  );
}

class _CopyWithStubImpl$Mutation$MarkAsDefault<TRes>
    implements CopyWith$Mutation$MarkAsDefault<TRes> {
  _CopyWithStubImpl$Mutation$MarkAsDefault(this._res);

  TRes _res;

  call({
    List<Fragment$PaymentMethod>? markPaymentMethodAsDefault,
    String? $__typename,
  }) => _res;

  markPaymentMethodAsDefault(_fn) => _res;
}

const documentNodeMutationMarkAsDefault = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.mutation,
      name: NameNode(value: 'MarkAsDefault'),
      variableDefinitions: [
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'id')),
          type: NamedTypeNode(name: NameNode(value: 'ID'), isNonNull: true),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
      ],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'markPaymentMethodAsDefault'),
            alias: null,
            arguments: [
              ArgumentNode(
                name: NameNode(value: 'id'),
                value: VariableNode(name: NameNode(value: 'id')),
              ),
            ],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FragmentSpreadNode(
                  name: NameNode(value: 'PaymentMethod'),
                  directives: [],
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
    fragmentDefinitionPaymentMethod,
    fragmentDefinitionSavedAccount,
    fragmentDefinitionOnlinePaymentMethod,
  ],
);
Mutation$MarkAsDefault _parserFn$Mutation$MarkAsDefault(
  Map<String, dynamic> data,
) => Mutation$MarkAsDefault.fromJson(data);
typedef OnMutationCompleted$Mutation$MarkAsDefault =
    FutureOr<void> Function(Map<String, dynamic>?, Mutation$MarkAsDefault?);

class Options$Mutation$MarkAsDefault
    extends graphql.MutationOptions<Mutation$MarkAsDefault> {
  Options$Mutation$MarkAsDefault({
    String? operationName,
    required Variables$Mutation$MarkAsDefault variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$MarkAsDefault? typedOptimisticResult,
    graphql.Context? context,
    OnMutationCompleted$Mutation$MarkAsDefault? onCompleted,
    graphql.OnMutationUpdate<Mutation$MarkAsDefault>? update,
    graphql.OnError? onError,
  }) : onCompletedWithParsed = onCompleted,
       super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         onCompleted: onCompleted == null
             ? null
             : (data) => onCompleted(
                 data,
                 data == null ? null : _parserFn$Mutation$MarkAsDefault(data),
               ),
         update: update,
         onError: onError,
         document: documentNodeMutationMarkAsDefault,
         parserFn: _parserFn$Mutation$MarkAsDefault,
       );

  final OnMutationCompleted$Mutation$MarkAsDefault? onCompletedWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onCompleted == null
        ? super.properties
        : super.properties.where((property) => property != onCompleted),
    onCompletedWithParsed,
  ];
}

class WatchOptions$Mutation$MarkAsDefault
    extends graphql.WatchQueryOptions<Mutation$MarkAsDefault> {
  WatchOptions$Mutation$MarkAsDefault({
    String? operationName,
    required Variables$Mutation$MarkAsDefault variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$MarkAsDefault? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeMutationMarkAsDefault,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Mutation$MarkAsDefault,
       );
}

extension ClientExtension$Mutation$MarkAsDefault on graphql.GraphQLClient {
  Future<graphql.QueryResult<Mutation$MarkAsDefault>> mutate$MarkAsDefault(
    Options$Mutation$MarkAsDefault options,
  ) async => await this.mutate(options);

  graphql.ObservableQuery<Mutation$MarkAsDefault> watchMutation$MarkAsDefault(
    WatchOptions$Mutation$MarkAsDefault options,
  ) => this.watchMutation(options);
}

class Variables$Mutation$TopUpWallet {
  factory Variables$Mutation$TopUpWallet({
    required Input$TopUpWalletInput input,
    required bool canPreauthorize,
  }) => Variables$Mutation$TopUpWallet._({
    r'input': input,
    r'canPreauthorize': canPreauthorize,
  });

  Variables$Mutation$TopUpWallet._(this._$data);

  factory Variables$Mutation$TopUpWallet.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$input = data['input'];
    result$data['input'] = Input$TopUpWalletInput.fromJson(
      (l$input as Map<String, dynamic>),
    );
    final l$canPreauthorize = data['canPreauthorize'];
    result$data['canPreauthorize'] = (l$canPreauthorize as bool);
    return Variables$Mutation$TopUpWallet._(result$data);
  }

  Map<String, dynamic> _$data;

  Input$TopUpWalletInput get input =>
      (_$data['input'] as Input$TopUpWalletInput);

  bool get canPreauthorize => (_$data['canPreauthorize'] as bool);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$input = input;
    result$data['input'] = l$input.toJson();
    final l$canPreauthorize = canPreauthorize;
    result$data['canPreauthorize'] = l$canPreauthorize;
    return result$data;
  }

  CopyWith$Variables$Mutation$TopUpWallet<Variables$Mutation$TopUpWallet>
  get copyWith => CopyWith$Variables$Mutation$TopUpWallet(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Variables$Mutation$TopUpWallet ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$input = input;
    final lOther$input = other.input;
    if (l$input != lOther$input) {
      return false;
    }
    final l$canPreauthorize = canPreauthorize;
    final lOther$canPreauthorize = other.canPreauthorize;
    if (l$canPreauthorize != lOther$canPreauthorize) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$input = input;
    final l$canPreauthorize = canPreauthorize;
    return Object.hashAll([l$input, l$canPreauthorize]);
  }
}

abstract class CopyWith$Variables$Mutation$TopUpWallet<TRes> {
  factory CopyWith$Variables$Mutation$TopUpWallet(
    Variables$Mutation$TopUpWallet instance,
    TRes Function(Variables$Mutation$TopUpWallet) then,
  ) = _CopyWithImpl$Variables$Mutation$TopUpWallet;

  factory CopyWith$Variables$Mutation$TopUpWallet.stub(TRes res) =
      _CopyWithStubImpl$Variables$Mutation$TopUpWallet;

  TRes call({Input$TopUpWalletInput? input, bool? canPreauthorize});
}

class _CopyWithImpl$Variables$Mutation$TopUpWallet<TRes>
    implements CopyWith$Variables$Mutation$TopUpWallet<TRes> {
  _CopyWithImpl$Variables$Mutation$TopUpWallet(this._instance, this._then);

  final Variables$Mutation$TopUpWallet _instance;

  final TRes Function(Variables$Mutation$TopUpWallet) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? input = _undefined,
    Object? canPreauthorize = _undefined,
  }) => _then(
    Variables$Mutation$TopUpWallet._({
      ..._instance._$data,
      if (input != _undefined && input != null)
        'input': (input as Input$TopUpWalletInput),
      if (canPreauthorize != _undefined && canPreauthorize != null)
        'canPreauthorize': (canPreauthorize as bool),
    }),
  );
}

class _CopyWithStubImpl$Variables$Mutation$TopUpWallet<TRes>
    implements CopyWith$Variables$Mutation$TopUpWallet<TRes> {
  _CopyWithStubImpl$Variables$Mutation$TopUpWallet(this._res);

  TRes _res;

  call({Input$TopUpWalletInput? input, bool? canPreauthorize}) => _res;
}

class Mutation$TopUpWallet {
  Mutation$TopUpWallet({
    required this.topUpWallet,
    this.$__typename = 'Mutation',
  });

  factory Mutation$TopUpWallet.fromJson(Map<String, dynamic> json) {
    final l$topUpWallet = json['topUpWallet'];
    final l$$__typename = json['__typename'];
    return Mutation$TopUpWallet(
      topUpWallet: Fragment$IntentResult.fromJson(
        (l$topUpWallet as Map<String, dynamic>),
      ),
      $__typename: (l$$__typename as String),
    );
  }

  final Fragment$IntentResult topUpWallet;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$topUpWallet = topUpWallet;
    _resultData['topUpWallet'] = l$topUpWallet.toJson();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$topUpWallet = topUpWallet;
    final l$$__typename = $__typename;
    return Object.hashAll([l$topUpWallet, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$TopUpWallet || runtimeType != other.runtimeType) {
      return false;
    }
    final l$topUpWallet = topUpWallet;
    final lOther$topUpWallet = other.topUpWallet;
    if (l$topUpWallet != lOther$topUpWallet) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$TopUpWallet on Mutation$TopUpWallet {
  CopyWith$Mutation$TopUpWallet<Mutation$TopUpWallet> get copyWith =>
      CopyWith$Mutation$TopUpWallet(this, (i) => i);
}

abstract class CopyWith$Mutation$TopUpWallet<TRes> {
  factory CopyWith$Mutation$TopUpWallet(
    Mutation$TopUpWallet instance,
    TRes Function(Mutation$TopUpWallet) then,
  ) = _CopyWithImpl$Mutation$TopUpWallet;

  factory CopyWith$Mutation$TopUpWallet.stub(TRes res) =
      _CopyWithStubImpl$Mutation$TopUpWallet;

  TRes call({Fragment$IntentResult? topUpWallet, String? $__typename});
  CopyWith$Fragment$IntentResult<TRes> get topUpWallet;
}

class _CopyWithImpl$Mutation$TopUpWallet<TRes>
    implements CopyWith$Mutation$TopUpWallet<TRes> {
  _CopyWithImpl$Mutation$TopUpWallet(this._instance, this._then);

  final Mutation$TopUpWallet _instance;

  final TRes Function(Mutation$TopUpWallet) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? topUpWallet = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Mutation$TopUpWallet(
      topUpWallet: topUpWallet == _undefined || topUpWallet == null
          ? _instance.topUpWallet
          : (topUpWallet as Fragment$IntentResult),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  CopyWith$Fragment$IntentResult<TRes> get topUpWallet {
    final local$topUpWallet = _instance.topUpWallet;
    return CopyWith$Fragment$IntentResult(
      local$topUpWallet,
      (e) => call(topUpWallet: e),
    );
  }
}

class _CopyWithStubImpl$Mutation$TopUpWallet<TRes>
    implements CopyWith$Mutation$TopUpWallet<TRes> {
  _CopyWithStubImpl$Mutation$TopUpWallet(this._res);

  TRes _res;

  call({Fragment$IntentResult? topUpWallet, String? $__typename}) => _res;

  CopyWith$Fragment$IntentResult<TRes> get topUpWallet =>
      CopyWith$Fragment$IntentResult.stub(_res);
}

const documentNodeMutationTopUpWallet = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.mutation,
      name: NameNode(value: 'TopUpWallet'),
      variableDefinitions: [
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'input')),
          type: NamedTypeNode(
            name: NameNode(value: 'TopUpWalletInput'),
            isNonNull: true,
          ),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'canPreauthorize')),
          type: NamedTypeNode(
            name: NameNode(value: 'Boolean'),
            isNonNull: true,
          ),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
      ],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'topUpWallet'),
            alias: null,
            arguments: [
              ArgumentNode(
                name: NameNode(value: 'input'),
                value: VariableNode(name: NameNode(value: 'input')),
              ),
              ArgumentNode(
                name: NameNode(value: 'shouldPreauth'),
                value: VariableNode(name: NameNode(value: 'canPreauthorize')),
              ),
            ],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FragmentSpreadNode(
                  name: NameNode(value: 'IntentResult'),
                  directives: [],
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
    fragmentDefinitionIntentResult,
  ],
);
Mutation$TopUpWallet _parserFn$Mutation$TopUpWallet(
  Map<String, dynamic> data,
) => Mutation$TopUpWallet.fromJson(data);
typedef OnMutationCompleted$Mutation$TopUpWallet =
    FutureOr<void> Function(Map<String, dynamic>?, Mutation$TopUpWallet?);

class Options$Mutation$TopUpWallet
    extends graphql.MutationOptions<Mutation$TopUpWallet> {
  Options$Mutation$TopUpWallet({
    String? operationName,
    required Variables$Mutation$TopUpWallet variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$TopUpWallet? typedOptimisticResult,
    graphql.Context? context,
    OnMutationCompleted$Mutation$TopUpWallet? onCompleted,
    graphql.OnMutationUpdate<Mutation$TopUpWallet>? update,
    graphql.OnError? onError,
  }) : onCompletedWithParsed = onCompleted,
       super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         onCompleted: onCompleted == null
             ? null
             : (data) => onCompleted(
                 data,
                 data == null ? null : _parserFn$Mutation$TopUpWallet(data),
               ),
         update: update,
         onError: onError,
         document: documentNodeMutationTopUpWallet,
         parserFn: _parserFn$Mutation$TopUpWallet,
       );

  final OnMutationCompleted$Mutation$TopUpWallet? onCompletedWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onCompleted == null
        ? super.properties
        : super.properties.where((property) => property != onCompleted),
    onCompletedWithParsed,
  ];
}

class WatchOptions$Mutation$TopUpWallet
    extends graphql.WatchQueryOptions<Mutation$TopUpWallet> {
  WatchOptions$Mutation$TopUpWallet({
    String? operationName,
    required Variables$Mutation$TopUpWallet variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$TopUpWallet? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeMutationTopUpWallet,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Mutation$TopUpWallet,
       );
}

extension ClientExtension$Mutation$TopUpWallet on graphql.GraphQLClient {
  Future<graphql.QueryResult<Mutation$TopUpWallet>> mutate$TopUpWallet(
    Options$Mutation$TopUpWallet options,
  ) async => await this.mutate(options);

  graphql.ObservableQuery<Mutation$TopUpWallet> watchMutation$TopUpWallet(
    WatchOptions$Mutation$TopUpWallet options,
  ) => this.watchMutation(options);
}

class Variables$Mutation$DeleteSavedPaymentMethod {
  factory Variables$Mutation$DeleteSavedPaymentMethod({required String id}) =>
      Variables$Mutation$DeleteSavedPaymentMethod._({r'id': id});

  Variables$Mutation$DeleteSavedPaymentMethod._(this._$data);

  factory Variables$Mutation$DeleteSavedPaymentMethod.fromJson(
    Map<String, dynamic> data,
  ) {
    final result$data = <String, dynamic>{};
    final l$id = data['id'];
    result$data['id'] = (l$id as String);
    return Variables$Mutation$DeleteSavedPaymentMethod._(result$data);
  }

  Map<String, dynamic> _$data;

  String get id => (_$data['id'] as String);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$id = id;
    result$data['id'] = l$id;
    return result$data;
  }

  CopyWith$Variables$Mutation$DeleteSavedPaymentMethod<
    Variables$Mutation$DeleteSavedPaymentMethod
  >
  get copyWith =>
      CopyWith$Variables$Mutation$DeleteSavedPaymentMethod(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Variables$Mutation$DeleteSavedPaymentMethod ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$id = id;
    final lOther$id = other.id;
    if (l$id != lOther$id) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$id = id;
    return Object.hashAll([l$id]);
  }
}

abstract class CopyWith$Variables$Mutation$DeleteSavedPaymentMethod<TRes> {
  factory CopyWith$Variables$Mutation$DeleteSavedPaymentMethod(
    Variables$Mutation$DeleteSavedPaymentMethod instance,
    TRes Function(Variables$Mutation$DeleteSavedPaymentMethod) then,
  ) = _CopyWithImpl$Variables$Mutation$DeleteSavedPaymentMethod;

  factory CopyWith$Variables$Mutation$DeleteSavedPaymentMethod.stub(TRes res) =
      _CopyWithStubImpl$Variables$Mutation$DeleteSavedPaymentMethod;

  TRes call({String? id});
}

class _CopyWithImpl$Variables$Mutation$DeleteSavedPaymentMethod<TRes>
    implements CopyWith$Variables$Mutation$DeleteSavedPaymentMethod<TRes> {
  _CopyWithImpl$Variables$Mutation$DeleteSavedPaymentMethod(
    this._instance,
    this._then,
  );

  final Variables$Mutation$DeleteSavedPaymentMethod _instance;

  final TRes Function(Variables$Mutation$DeleteSavedPaymentMethod) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? id = _undefined}) => _then(
    Variables$Mutation$DeleteSavedPaymentMethod._({
      ..._instance._$data,
      if (id != _undefined && id != null) 'id': (id as String),
    }),
  );
}

class _CopyWithStubImpl$Variables$Mutation$DeleteSavedPaymentMethod<TRes>
    implements CopyWith$Variables$Mutation$DeleteSavedPaymentMethod<TRes> {
  _CopyWithStubImpl$Variables$Mutation$DeleteSavedPaymentMethod(this._res);

  TRes _res;

  call({String? id}) => _res;
}

class Mutation$DeleteSavedPaymentMethod {
  Mutation$DeleteSavedPaymentMethod({
    required this.deleteSavedPaymentMethod,
    this.$__typename = 'Mutation',
  });

  factory Mutation$DeleteSavedPaymentMethod.fromJson(
    Map<String, dynamic> json,
  ) {
    final l$deleteSavedPaymentMethod = json['deleteSavedPaymentMethod'];
    final l$$__typename = json['__typename'];
    return Mutation$DeleteSavedPaymentMethod(
      deleteSavedPaymentMethod: (l$deleteSavedPaymentMethod as bool),
      $__typename: (l$$__typename as String),
    );
  }

  final bool deleteSavedPaymentMethod;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$deleteSavedPaymentMethod = deleteSavedPaymentMethod;
    _resultData['deleteSavedPaymentMethod'] = l$deleteSavedPaymentMethod;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$deleteSavedPaymentMethod = deleteSavedPaymentMethod;
    final l$$__typename = $__typename;
    return Object.hashAll([l$deleteSavedPaymentMethod, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$DeleteSavedPaymentMethod ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$deleteSavedPaymentMethod = deleteSavedPaymentMethod;
    final lOther$deleteSavedPaymentMethod = other.deleteSavedPaymentMethod;
    if (l$deleteSavedPaymentMethod != lOther$deleteSavedPaymentMethod) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$DeleteSavedPaymentMethod
    on Mutation$DeleteSavedPaymentMethod {
  CopyWith$Mutation$DeleteSavedPaymentMethod<Mutation$DeleteSavedPaymentMethod>
  get copyWith => CopyWith$Mutation$DeleteSavedPaymentMethod(this, (i) => i);
}

abstract class CopyWith$Mutation$DeleteSavedPaymentMethod<TRes> {
  factory CopyWith$Mutation$DeleteSavedPaymentMethod(
    Mutation$DeleteSavedPaymentMethod instance,
    TRes Function(Mutation$DeleteSavedPaymentMethod) then,
  ) = _CopyWithImpl$Mutation$DeleteSavedPaymentMethod;

  factory CopyWith$Mutation$DeleteSavedPaymentMethod.stub(TRes res) =
      _CopyWithStubImpl$Mutation$DeleteSavedPaymentMethod;

  TRes call({bool? deleteSavedPaymentMethod, String? $__typename});
}

class _CopyWithImpl$Mutation$DeleteSavedPaymentMethod<TRes>
    implements CopyWith$Mutation$DeleteSavedPaymentMethod<TRes> {
  _CopyWithImpl$Mutation$DeleteSavedPaymentMethod(this._instance, this._then);

  final Mutation$DeleteSavedPaymentMethod _instance;

  final TRes Function(Mutation$DeleteSavedPaymentMethod) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? deleteSavedPaymentMethod = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Mutation$DeleteSavedPaymentMethod(
      deleteSavedPaymentMethod:
          deleteSavedPaymentMethod == _undefined ||
              deleteSavedPaymentMethod == null
          ? _instance.deleteSavedPaymentMethod
          : (deleteSavedPaymentMethod as bool),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );
}

class _CopyWithStubImpl$Mutation$DeleteSavedPaymentMethod<TRes>
    implements CopyWith$Mutation$DeleteSavedPaymentMethod<TRes> {
  _CopyWithStubImpl$Mutation$DeleteSavedPaymentMethod(this._res);

  TRes _res;

  call({bool? deleteSavedPaymentMethod, String? $__typename}) => _res;
}

const documentNodeMutationDeleteSavedPaymentMethod = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.mutation,
      name: NameNode(value: 'DeleteSavedPaymentMethod'),
      variableDefinitions: [
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'id')),
          type: NamedTypeNode(name: NameNode(value: 'ID'), isNonNull: true),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
      ],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'deleteSavedPaymentMethod'),
            alias: null,
            arguments: [
              ArgumentNode(
                name: NameNode(value: 'id'),
                value: VariableNode(name: NameNode(value: 'id')),
              ),
            ],
            directives: [],
            selectionSet: null,
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
  ],
);
Mutation$DeleteSavedPaymentMethod _parserFn$Mutation$DeleteSavedPaymentMethod(
  Map<String, dynamic> data,
) => Mutation$DeleteSavedPaymentMethod.fromJson(data);
typedef OnMutationCompleted$Mutation$DeleteSavedPaymentMethod =
    FutureOr<void> Function(
      Map<String, dynamic>?,
      Mutation$DeleteSavedPaymentMethod?,
    );

class Options$Mutation$DeleteSavedPaymentMethod
    extends graphql.MutationOptions<Mutation$DeleteSavedPaymentMethod> {
  Options$Mutation$DeleteSavedPaymentMethod({
    String? operationName,
    required Variables$Mutation$DeleteSavedPaymentMethod variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$DeleteSavedPaymentMethod? typedOptimisticResult,
    graphql.Context? context,
    OnMutationCompleted$Mutation$DeleteSavedPaymentMethod? onCompleted,
    graphql.OnMutationUpdate<Mutation$DeleteSavedPaymentMethod>? update,
    graphql.OnError? onError,
  }) : onCompletedWithParsed = onCompleted,
       super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         onCompleted: onCompleted == null
             ? null
             : (data) => onCompleted(
                 data,
                 data == null
                     ? null
                     : _parserFn$Mutation$DeleteSavedPaymentMethod(data),
               ),
         update: update,
         onError: onError,
         document: documentNodeMutationDeleteSavedPaymentMethod,
         parserFn: _parserFn$Mutation$DeleteSavedPaymentMethod,
       );

  final OnMutationCompleted$Mutation$DeleteSavedPaymentMethod?
  onCompletedWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onCompleted == null
        ? super.properties
        : super.properties.where((property) => property != onCompleted),
    onCompletedWithParsed,
  ];
}

class WatchOptions$Mutation$DeleteSavedPaymentMethod
    extends graphql.WatchQueryOptions<Mutation$DeleteSavedPaymentMethod> {
  WatchOptions$Mutation$DeleteSavedPaymentMethod({
    String? operationName,
    required Variables$Mutation$DeleteSavedPaymentMethod variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$DeleteSavedPaymentMethod? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeMutationDeleteSavedPaymentMethod,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Mutation$DeleteSavedPaymentMethod,
       );
}

extension ClientExtension$Mutation$DeleteSavedPaymentMethod
    on graphql.GraphQLClient {
  Future<graphql.QueryResult<Mutation$DeleteSavedPaymentMethod>>
  mutate$DeleteSavedPaymentMethod(
    Options$Mutation$DeleteSavedPaymentMethod options,
  ) async => await this.mutate(options);

  graphql.ObservableQuery<Mutation$DeleteSavedPaymentMethod>
  watchMutation$DeleteSavedPaymentMethod(
    WatchOptions$Mutation$DeleteSavedPaymentMethod options,
  ) => this.watchMutation(options);
}
