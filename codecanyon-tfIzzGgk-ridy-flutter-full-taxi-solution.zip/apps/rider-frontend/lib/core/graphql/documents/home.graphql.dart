import '../fragments/active_order.fragment.graphql.dart';
import '../fragments/chat_message.fragment.graphql.dart';
import '../fragments/driver.fragment.graphql.dart';
import '../fragments/ephemeral_message.fragment.graphql.dart';
import '../fragments/favorite_location.fragment.graphql.dart';
import '../fragments/payment_method.fragment.graphql.dart';
import '../fragments/phone_number.fragment.graphql.dart';
import '../fragments/point.fragment.graphql.dart';
import '../schema.gql.dart';
import 'dart:async';
import 'package:gql/ast.dart';
import 'package:graphql/client.dart' as graphql;

class Query$CurrentOrder {
  Query$CurrentOrder({required this.activeOrders, this.$__typename = 'Query'});

  factory Query$CurrentOrder.fromJson(Map<String, dynamic> json) {
    final l$activeOrders = json['activeOrders'];
    final l$$__typename = json['__typename'];
    return Query$CurrentOrder(
      activeOrders: (l$activeOrders as List<dynamic>)
          .map(
            (e) => Fragment$ActiveOrder.fromJson((e as Map<String, dynamic>)),
          )
          .toList(),
      $__typename: (l$$__typename as String),
    );
  }

  final List<Fragment$ActiveOrder> activeOrders;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$activeOrders = activeOrders;
    _resultData['activeOrders'] = l$activeOrders
        .map((e) => e.toJson())
        .toList();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$activeOrders = activeOrders;
    final l$$__typename = $__typename;
    return Object.hashAll([
      Object.hashAll(l$activeOrders.map((v) => v)),
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Query$CurrentOrder || runtimeType != other.runtimeType) {
      return false;
    }
    final l$activeOrders = activeOrders;
    final lOther$activeOrders = other.activeOrders;
    if (l$activeOrders.length != lOther$activeOrders.length) {
      return false;
    }
    for (int i = 0; i < l$activeOrders.length; i++) {
      final l$activeOrders$entry = l$activeOrders[i];
      final lOther$activeOrders$entry = lOther$activeOrders[i];
      if (l$activeOrders$entry != lOther$activeOrders$entry) {
        return false;
      }
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Query$CurrentOrder on Query$CurrentOrder {
  CopyWith$Query$CurrentOrder<Query$CurrentOrder> get copyWith =>
      CopyWith$Query$CurrentOrder(this, (i) => i);
}

abstract class CopyWith$Query$CurrentOrder<TRes> {
  factory CopyWith$Query$CurrentOrder(
    Query$CurrentOrder instance,
    TRes Function(Query$CurrentOrder) then,
  ) = _CopyWithImpl$Query$CurrentOrder;

  factory CopyWith$Query$CurrentOrder.stub(TRes res) =
      _CopyWithStubImpl$Query$CurrentOrder;

  TRes call({List<Fragment$ActiveOrder>? activeOrders, String? $__typename});
  TRes activeOrders(
    Iterable<Fragment$ActiveOrder> Function(
      Iterable<CopyWith$Fragment$ActiveOrder<Fragment$ActiveOrder>>,
    )
    _fn,
  );
}

class _CopyWithImpl$Query$CurrentOrder<TRes>
    implements CopyWith$Query$CurrentOrder<TRes> {
  _CopyWithImpl$Query$CurrentOrder(this._instance, this._then);

  final Query$CurrentOrder _instance;

  final TRes Function(Query$CurrentOrder) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? activeOrders = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Query$CurrentOrder(
      activeOrders: activeOrders == _undefined || activeOrders == null
          ? _instance.activeOrders
          : (activeOrders as List<Fragment$ActiveOrder>),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  TRes activeOrders(
    Iterable<Fragment$ActiveOrder> Function(
      Iterable<CopyWith$Fragment$ActiveOrder<Fragment$ActiveOrder>>,
    )
    _fn,
  ) => call(
    activeOrders: _fn(
      _instance.activeOrders.map(
        (e) => CopyWith$Fragment$ActiveOrder(e, (i) => i),
      ),
    ).toList(),
  );
}

class _CopyWithStubImpl$Query$CurrentOrder<TRes>
    implements CopyWith$Query$CurrentOrder<TRes> {
  _CopyWithStubImpl$Query$CurrentOrder(this._res);

  TRes _res;

  call({List<Fragment$ActiveOrder>? activeOrders, String? $__typename}) => _res;

  activeOrders(_fn) => _res;
}

const documentNodeQueryCurrentOrder = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.query,
      name: NameNode(value: 'CurrentOrder'),
      variableDefinitions: [],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'activeOrders'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FragmentSpreadNode(
                  name: NameNode(value: 'ActiveOrder'),
                  directives: [],
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
    fragmentDefinitionActiveOrder,
    fragmentDefinitionCoordinate,
    fragmentDefinitionWaypoint,
    fragmentDefinitionRideWaypoint,
    fragmentDefinitionDeliveryWaypoint,
    fragmentDefinitionPhoneNumber,
    fragmentDefinitionShopWaypoint,
    fragmentDefinitionActiveOrderDriver,
    fragmentDefinitionPaymentMethod,
    fragmentDefinitionSavedAccount,
    fragmentDefinitionOnlinePaymentMethod,
    fragmentDefinitionChatMessage,
  ],
);
Query$CurrentOrder _parserFn$Query$CurrentOrder(Map<String, dynamic> data) =>
    Query$CurrentOrder.fromJson(data);
typedef OnQueryComplete$Query$CurrentOrder =
    FutureOr<void> Function(Map<String, dynamic>?, Query$CurrentOrder?);

class Options$Query$CurrentOrder
    extends graphql.QueryOptions<Query$CurrentOrder> {
  Options$Query$CurrentOrder({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$CurrentOrder? typedOptimisticResult,
    Duration? pollInterval,
    graphql.Context? context,
    OnQueryComplete$Query$CurrentOrder? onComplete,
    graphql.OnQueryError? onError,
  }) : onCompleteWithParsed = onComplete,
       super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         pollInterval: pollInterval,
         context: context,
         onComplete: onComplete == null
             ? null
             : (data) => onComplete(
                 data,
                 data == null ? null : _parserFn$Query$CurrentOrder(data),
               ),
         onError: onError,
         document: documentNodeQueryCurrentOrder,
         parserFn: _parserFn$Query$CurrentOrder,
       );

  final OnQueryComplete$Query$CurrentOrder? onCompleteWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onComplete == null
        ? super.properties
        : super.properties.where((property) => property != onComplete),
    onCompleteWithParsed,
  ];
}

class WatchOptions$Query$CurrentOrder
    extends graphql.WatchQueryOptions<Query$CurrentOrder> {
  WatchOptions$Query$CurrentOrder({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$CurrentOrder? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeQueryCurrentOrder,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Query$CurrentOrder,
       );
}

class FetchMoreOptions$Query$CurrentOrder extends graphql.FetchMoreOptions {
  FetchMoreOptions$Query$CurrentOrder({
    required graphql.UpdateQuery updateQuery,
  }) : super(updateQuery: updateQuery, document: documentNodeQueryCurrentOrder);
}

extension ClientExtension$Query$CurrentOrder on graphql.GraphQLClient {
  Future<graphql.QueryResult<Query$CurrentOrder>> query$CurrentOrder([
    Options$Query$CurrentOrder? options,
  ]) async => await this.query(options ?? Options$Query$CurrentOrder());

  graphql.ObservableQuery<Query$CurrentOrder> watchQuery$CurrentOrder([
    WatchOptions$Query$CurrentOrder? options,
  ]) => this.watchQuery(options ?? WatchOptions$Query$CurrentOrder());

  void writeQuery$CurrentOrder({
    required Query$CurrentOrder data,
    bool broadcast = true,
  }) => this.writeQuery(
    graphql.Request(
      operation: graphql.Operation(document: documentNodeQueryCurrentOrder),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Query$CurrentOrder? readQuery$CurrentOrder({bool optimistic = true}) {
    final result = this.readQuery(
      graphql.Request(
        operation: graphql.Operation(document: documentNodeQueryCurrentOrder),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Query$CurrentOrder.fromJson(result);
  }
}

class Query$EphemeralMessages {
  Query$EphemeralMessages({
    required this.ephemeralMessages,
    this.$__typename = 'Query',
  });

  factory Query$EphemeralMessages.fromJson(Map<String, dynamic> json) {
    final l$ephemeralMessages = json['ephemeralMessages'];
    final l$$__typename = json['__typename'];
    return Query$EphemeralMessages(
      ephemeralMessages: (l$ephemeralMessages as List<dynamic>)
          .map(
            (e) =>
                Fragment$EphemeralMessage.fromJson((e as Map<String, dynamic>)),
          )
          .toList(),
      $__typename: (l$$__typename as String),
    );
  }

  final List<Fragment$EphemeralMessage> ephemeralMessages;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$ephemeralMessages = ephemeralMessages;
    _resultData['ephemeralMessages'] = l$ephemeralMessages
        .map((e) => e.toJson())
        .toList();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$ephemeralMessages = ephemeralMessages;
    final l$$__typename = $__typename;
    return Object.hashAll([
      Object.hashAll(l$ephemeralMessages.map((v) => v)),
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Query$EphemeralMessages || runtimeType != other.runtimeType) {
      return false;
    }
    final l$ephemeralMessages = ephemeralMessages;
    final lOther$ephemeralMessages = other.ephemeralMessages;
    if (l$ephemeralMessages.length != lOther$ephemeralMessages.length) {
      return false;
    }
    for (int i = 0; i < l$ephemeralMessages.length; i++) {
      final l$ephemeralMessages$entry = l$ephemeralMessages[i];
      final lOther$ephemeralMessages$entry = lOther$ephemeralMessages[i];
      if (l$ephemeralMessages$entry != lOther$ephemeralMessages$entry) {
        return false;
      }
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Query$EphemeralMessages on Query$EphemeralMessages {
  CopyWith$Query$EphemeralMessages<Query$EphemeralMessages> get copyWith =>
      CopyWith$Query$EphemeralMessages(this, (i) => i);
}

abstract class CopyWith$Query$EphemeralMessages<TRes> {
  factory CopyWith$Query$EphemeralMessages(
    Query$EphemeralMessages instance,
    TRes Function(Query$EphemeralMessages) then,
  ) = _CopyWithImpl$Query$EphemeralMessages;

  factory CopyWith$Query$EphemeralMessages.stub(TRes res) =
      _CopyWithStubImpl$Query$EphemeralMessages;

  TRes call({
    List<Fragment$EphemeralMessage>? ephemeralMessages,
    String? $__typename,
  });
  TRes ephemeralMessages(
    Iterable<Fragment$EphemeralMessage> Function(
      Iterable<CopyWith$Fragment$EphemeralMessage<Fragment$EphemeralMessage>>,
    )
    _fn,
  );
}

class _CopyWithImpl$Query$EphemeralMessages<TRes>
    implements CopyWith$Query$EphemeralMessages<TRes> {
  _CopyWithImpl$Query$EphemeralMessages(this._instance, this._then);

  final Query$EphemeralMessages _instance;

  final TRes Function(Query$EphemeralMessages) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? ephemeralMessages = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Query$EphemeralMessages(
      ephemeralMessages:
          ephemeralMessages == _undefined || ephemeralMessages == null
          ? _instance.ephemeralMessages
          : (ephemeralMessages as List<Fragment$EphemeralMessage>),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  TRes ephemeralMessages(
    Iterable<Fragment$EphemeralMessage> Function(
      Iterable<CopyWith$Fragment$EphemeralMessage<Fragment$EphemeralMessage>>,
    )
    _fn,
  ) => call(
    ephemeralMessages: _fn(
      _instance.ephemeralMessages.map(
        (e) => CopyWith$Fragment$EphemeralMessage(e, (i) => i),
      ),
    ).toList(),
  );
}

class _CopyWithStubImpl$Query$EphemeralMessages<TRes>
    implements CopyWith$Query$EphemeralMessages<TRes> {
  _CopyWithStubImpl$Query$EphemeralMessages(this._res);

  TRes _res;

  call({
    List<Fragment$EphemeralMessage>? ephemeralMessages,
    String? $__typename,
  }) => _res;

  ephemeralMessages(_fn) => _res;
}

const documentNodeQueryEphemeralMessages = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.query,
      name: NameNode(value: 'EphemeralMessages'),
      variableDefinitions: [],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'ephemeralMessages'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FragmentSpreadNode(
                  name: NameNode(value: 'EphemeralMessage'),
                  directives: [],
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
    fragmentDefinitionEphemeralMessage,
  ],
);
Query$EphemeralMessages _parserFn$Query$EphemeralMessages(
  Map<String, dynamic> data,
) => Query$EphemeralMessages.fromJson(data);
typedef OnQueryComplete$Query$EphemeralMessages =
    FutureOr<void> Function(Map<String, dynamic>?, Query$EphemeralMessages?);

class Options$Query$EphemeralMessages
    extends graphql.QueryOptions<Query$EphemeralMessages> {
  Options$Query$EphemeralMessages({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$EphemeralMessages? typedOptimisticResult,
    Duration? pollInterval,
    graphql.Context? context,
    OnQueryComplete$Query$EphemeralMessages? onComplete,
    graphql.OnQueryError? onError,
  }) : onCompleteWithParsed = onComplete,
       super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         pollInterval: pollInterval,
         context: context,
         onComplete: onComplete == null
             ? null
             : (data) => onComplete(
                 data,
                 data == null ? null : _parserFn$Query$EphemeralMessages(data),
               ),
         onError: onError,
         document: documentNodeQueryEphemeralMessages,
         parserFn: _parserFn$Query$EphemeralMessages,
       );

  final OnQueryComplete$Query$EphemeralMessages? onCompleteWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onComplete == null
        ? super.properties
        : super.properties.where((property) => property != onComplete),
    onCompleteWithParsed,
  ];
}

class WatchOptions$Query$EphemeralMessages
    extends graphql.WatchQueryOptions<Query$EphemeralMessages> {
  WatchOptions$Query$EphemeralMessages({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$EphemeralMessages? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeQueryEphemeralMessages,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Query$EphemeralMessages,
       );
}

class FetchMoreOptions$Query$EphemeralMessages
    extends graphql.FetchMoreOptions {
  FetchMoreOptions$Query$EphemeralMessages({
    required graphql.UpdateQuery updateQuery,
  }) : super(
         updateQuery: updateQuery,
         document: documentNodeQueryEphemeralMessages,
       );
}

extension ClientExtension$Query$EphemeralMessages on graphql.GraphQLClient {
  Future<graphql.QueryResult<Query$EphemeralMessages>> query$EphemeralMessages([
    Options$Query$EphemeralMessages? options,
  ]) async => await this.query(options ?? Options$Query$EphemeralMessages());

  graphql.ObservableQuery<Query$EphemeralMessages>
  watchQuery$EphemeralMessages([
    WatchOptions$Query$EphemeralMessages? options,
  ]) => this.watchQuery(options ?? WatchOptions$Query$EphemeralMessages());

  void writeQuery$EphemeralMessages({
    required Query$EphemeralMessages data,
    bool broadcast = true,
  }) => this.writeQuery(
    graphql.Request(
      operation: graphql.Operation(
        document: documentNodeQueryEphemeralMessages,
      ),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Query$EphemeralMessages? readQuery$EphemeralMessages({
    bool optimistic = true,
  }) {
    final result = this.readQuery(
      graphql.Request(
        operation: graphql.Operation(
          document: documentNodeQueryEphemeralMessages,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Query$EphemeralMessages.fromJson(result);
  }
}

class Variables$Query$DriversAround {
  factory Variables$Query$DriversAround({required Input$PointInput center}) =>
      Variables$Query$DriversAround._({r'center': center});

  Variables$Query$DriversAround._(this._$data);

  factory Variables$Query$DriversAround.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$center = data['center'];
    result$data['center'] = Input$PointInput.fromJson(
      (l$center as Map<String, dynamic>),
    );
    return Variables$Query$DriversAround._(result$data);
  }

  Map<String, dynamic> _$data;

  Input$PointInput get center => (_$data['center'] as Input$PointInput);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$center = center;
    result$data['center'] = l$center.toJson();
    return result$data;
  }

  CopyWith$Variables$Query$DriversAround<Variables$Query$DriversAround>
  get copyWith => CopyWith$Variables$Query$DriversAround(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Variables$Query$DriversAround ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$center = center;
    final lOther$center = other.center;
    if (l$center != lOther$center) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$center = center;
    return Object.hashAll([l$center]);
  }
}

abstract class CopyWith$Variables$Query$DriversAround<TRes> {
  factory CopyWith$Variables$Query$DriversAround(
    Variables$Query$DriversAround instance,
    TRes Function(Variables$Query$DriversAround) then,
  ) = _CopyWithImpl$Variables$Query$DriversAround;

  factory CopyWith$Variables$Query$DriversAround.stub(TRes res) =
      _CopyWithStubImpl$Variables$Query$DriversAround;

  TRes call({Input$PointInput? center});
}

class _CopyWithImpl$Variables$Query$DriversAround<TRes>
    implements CopyWith$Variables$Query$DriversAround<TRes> {
  _CopyWithImpl$Variables$Query$DriversAround(this._instance, this._then);

  final Variables$Query$DriversAround _instance;

  final TRes Function(Variables$Query$DriversAround) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? center = _undefined}) => _then(
    Variables$Query$DriversAround._({
      ..._instance._$data,
      if (center != _undefined && center != null)
        'center': (center as Input$PointInput),
    }),
  );
}

class _CopyWithStubImpl$Variables$Query$DriversAround<TRes>
    implements CopyWith$Variables$Query$DriversAround<TRes> {
  _CopyWithStubImpl$Variables$Query$DriversAround(this._res);

  TRes _res;

  call({Input$PointInput? center}) => _res;
}

class Query$DriversAround {
  Query$DriversAround({
    required this.driversAround,
    this.$__typename = 'Query',
  });

  factory Query$DriversAround.fromJson(Map<String, dynamic> json) {
    final l$driversAround = json['driversAround'];
    final l$$__typename = json['__typename'];
    return Query$DriversAround(
      driversAround: (l$driversAround as List<dynamic>)
          .map((e) => Fragment$Coordinate.fromJson((e as Map<String, dynamic>)))
          .toList(),
      $__typename: (l$$__typename as String),
    );
  }

  final List<Fragment$Coordinate> driversAround;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$driversAround = driversAround;
    _resultData['driversAround'] = l$driversAround
        .map((e) => e.toJson())
        .toList();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$driversAround = driversAround;
    final l$$__typename = $__typename;
    return Object.hashAll([
      Object.hashAll(l$driversAround.map((v) => v)),
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Query$DriversAround || runtimeType != other.runtimeType) {
      return false;
    }
    final l$driversAround = driversAround;
    final lOther$driversAround = other.driversAround;
    if (l$driversAround.length != lOther$driversAround.length) {
      return false;
    }
    for (int i = 0; i < l$driversAround.length; i++) {
      final l$driversAround$entry = l$driversAround[i];
      final lOther$driversAround$entry = lOther$driversAround[i];
      if (l$driversAround$entry != lOther$driversAround$entry) {
        return false;
      }
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Query$DriversAround on Query$DriversAround {
  CopyWith$Query$DriversAround<Query$DriversAround> get copyWith =>
      CopyWith$Query$DriversAround(this, (i) => i);
}

abstract class CopyWith$Query$DriversAround<TRes> {
  factory CopyWith$Query$DriversAround(
    Query$DriversAround instance,
    TRes Function(Query$DriversAround) then,
  ) = _CopyWithImpl$Query$DriversAround;

  factory CopyWith$Query$DriversAround.stub(TRes res) =
      _CopyWithStubImpl$Query$DriversAround;

  TRes call({List<Fragment$Coordinate>? driversAround, String? $__typename});
  TRes driversAround(
    Iterable<Fragment$Coordinate> Function(
      Iterable<CopyWith$Fragment$Coordinate<Fragment$Coordinate>>,
    )
    _fn,
  );
}

class _CopyWithImpl$Query$DriversAround<TRes>
    implements CopyWith$Query$DriversAround<TRes> {
  _CopyWithImpl$Query$DriversAround(this._instance, this._then);

  final Query$DriversAround _instance;

  final TRes Function(Query$DriversAround) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? driversAround = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Query$DriversAround(
      driversAround: driversAround == _undefined || driversAround == null
          ? _instance.driversAround
          : (driversAround as List<Fragment$Coordinate>),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  TRes driversAround(
    Iterable<Fragment$Coordinate> Function(
      Iterable<CopyWith$Fragment$Coordinate<Fragment$Coordinate>>,
    )
    _fn,
  ) => call(
    driversAround: _fn(
      _instance.driversAround.map(
        (e) => CopyWith$Fragment$Coordinate(e, (i) => i),
      ),
    ).toList(),
  );
}

class _CopyWithStubImpl$Query$DriversAround<TRes>
    implements CopyWith$Query$DriversAround<TRes> {
  _CopyWithStubImpl$Query$DriversAround(this._res);

  TRes _res;

  call({List<Fragment$Coordinate>? driversAround, String? $__typename}) => _res;

  driversAround(_fn) => _res;
}

const documentNodeQueryDriversAround = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.query,
      name: NameNode(value: 'DriversAround'),
      variableDefinitions: [
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'center')),
          type: NamedTypeNode(
            name: NameNode(value: 'PointInput'),
            isNonNull: true,
          ),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
      ],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'driversAround'),
            alias: null,
            arguments: [
              ArgumentNode(
                name: NameNode(value: 'center'),
                value: VariableNode(name: NameNode(value: 'center')),
              ),
            ],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FragmentSpreadNode(
                  name: NameNode(value: 'Coordinate'),
                  directives: [],
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
    fragmentDefinitionCoordinate,
  ],
);
Query$DriversAround _parserFn$Query$DriversAround(Map<String, dynamic> data) =>
    Query$DriversAround.fromJson(data);
typedef OnQueryComplete$Query$DriversAround =
    FutureOr<void> Function(Map<String, dynamic>?, Query$DriversAround?);

class Options$Query$DriversAround
    extends graphql.QueryOptions<Query$DriversAround> {
  Options$Query$DriversAround({
    String? operationName,
    required Variables$Query$DriversAround variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$DriversAround? typedOptimisticResult,
    Duration? pollInterval,
    graphql.Context? context,
    OnQueryComplete$Query$DriversAround? onComplete,
    graphql.OnQueryError? onError,
  }) : onCompleteWithParsed = onComplete,
       super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         pollInterval: pollInterval,
         context: context,
         onComplete: onComplete == null
             ? null
             : (data) => onComplete(
                 data,
                 data == null ? null : _parserFn$Query$DriversAround(data),
               ),
         onError: onError,
         document: documentNodeQueryDriversAround,
         parserFn: _parserFn$Query$DriversAround,
       );

  final OnQueryComplete$Query$DriversAround? onCompleteWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onComplete == null
        ? super.properties
        : super.properties.where((property) => property != onComplete),
    onCompleteWithParsed,
  ];
}

class WatchOptions$Query$DriversAround
    extends graphql.WatchQueryOptions<Query$DriversAround> {
  WatchOptions$Query$DriversAround({
    String? operationName,
    required Variables$Query$DriversAround variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$DriversAround? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeQueryDriversAround,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Query$DriversAround,
       );
}

class FetchMoreOptions$Query$DriversAround extends graphql.FetchMoreOptions {
  FetchMoreOptions$Query$DriversAround({
    required graphql.UpdateQuery updateQuery,
    required Variables$Query$DriversAround variables,
  }) : super(
         updateQuery: updateQuery,
         variables: variables.toJson(),
         document: documentNodeQueryDriversAround,
       );
}

extension ClientExtension$Query$DriversAround on graphql.GraphQLClient {
  Future<graphql.QueryResult<Query$DriversAround>> query$DriversAround(
    Options$Query$DriversAround options,
  ) async => await this.query(options);

  graphql.ObservableQuery<Query$DriversAround> watchQuery$DriversAround(
    WatchOptions$Query$DriversAround options,
  ) => this.watchQuery(options);

  void writeQuery$DriversAround({
    required Query$DriversAround data,
    required Variables$Query$DriversAround variables,
    bool broadcast = true,
  }) => this.writeQuery(
    graphql.Request(
      operation: graphql.Operation(document: documentNodeQueryDriversAround),
      variables: variables.toJson(),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Query$DriversAround? readQuery$DriversAround({
    required Variables$Query$DriversAround variables,
    bool optimistic = true,
  }) {
    final result = this.readQuery(
      graphql.Request(
        operation: graphql.Operation(document: documentNodeQueryDriversAround),
        variables: variables.toJson(),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Query$DriversAround.fromJson(result);
  }
}

class Query$DestinationSuggesions {
  Query$DestinationSuggesions({
    required this.favoriteLocations,
    required this.recentDestinations,
    this.$__typename = 'Query',
  });

  factory Query$DestinationSuggesions.fromJson(Map<String, dynamic> json) {
    final l$favoriteLocations = json['favoriteLocations'];
    final l$recentDestinations = json['recentDestinations'];
    final l$$__typename = json['__typename'];
    return Query$DestinationSuggesions(
      favoriteLocations: (l$favoriteLocations as List<dynamic>)
          .map(
            (e) =>
                Fragment$FavoriteLocation.fromJson((e as Map<String, dynamic>)),
          )
          .toList(),
      recentDestinations: (l$recentDestinations as List<dynamic>)
          .map((e) => Fragment$Place.fromJson((e as Map<String, dynamic>)))
          .toList(),
      $__typename: (l$$__typename as String),
    );
  }

  final List<Fragment$FavoriteLocation> favoriteLocations;

  final List<Fragment$Place> recentDestinations;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$favoriteLocations = favoriteLocations;
    _resultData['favoriteLocations'] = l$favoriteLocations
        .map((e) => e.toJson())
        .toList();
    final l$recentDestinations = recentDestinations;
    _resultData['recentDestinations'] = l$recentDestinations
        .map((e) => e.toJson())
        .toList();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$favoriteLocations = favoriteLocations;
    final l$recentDestinations = recentDestinations;
    final l$$__typename = $__typename;
    return Object.hashAll([
      Object.hashAll(l$favoriteLocations.map((v) => v)),
      Object.hashAll(l$recentDestinations.map((v) => v)),
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Query$DestinationSuggesions ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$favoriteLocations = favoriteLocations;
    final lOther$favoriteLocations = other.favoriteLocations;
    if (l$favoriteLocations.length != lOther$favoriteLocations.length) {
      return false;
    }
    for (int i = 0; i < l$favoriteLocations.length; i++) {
      final l$favoriteLocations$entry = l$favoriteLocations[i];
      final lOther$favoriteLocations$entry = lOther$favoriteLocations[i];
      if (l$favoriteLocations$entry != lOther$favoriteLocations$entry) {
        return false;
      }
    }
    final l$recentDestinations = recentDestinations;
    final lOther$recentDestinations = other.recentDestinations;
    if (l$recentDestinations.length != lOther$recentDestinations.length) {
      return false;
    }
    for (int i = 0; i < l$recentDestinations.length; i++) {
      final l$recentDestinations$entry = l$recentDestinations[i];
      final lOther$recentDestinations$entry = lOther$recentDestinations[i];
      if (l$recentDestinations$entry != lOther$recentDestinations$entry) {
        return false;
      }
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Query$DestinationSuggesions
    on Query$DestinationSuggesions {
  CopyWith$Query$DestinationSuggesions<Query$DestinationSuggesions>
  get copyWith => CopyWith$Query$DestinationSuggesions(this, (i) => i);
}

abstract class CopyWith$Query$DestinationSuggesions<TRes> {
  factory CopyWith$Query$DestinationSuggesions(
    Query$DestinationSuggesions instance,
    TRes Function(Query$DestinationSuggesions) then,
  ) = _CopyWithImpl$Query$DestinationSuggesions;

  factory CopyWith$Query$DestinationSuggesions.stub(TRes res) =
      _CopyWithStubImpl$Query$DestinationSuggesions;

  TRes call({
    List<Fragment$FavoriteLocation>? favoriteLocations,
    List<Fragment$Place>? recentDestinations,
    String? $__typename,
  });
  TRes favoriteLocations(
    Iterable<Fragment$FavoriteLocation> Function(
      Iterable<CopyWith$Fragment$FavoriteLocation<Fragment$FavoriteLocation>>,
    )
    _fn,
  );
  TRes recentDestinations(
    Iterable<Fragment$Place> Function(
      Iterable<CopyWith$Fragment$Place<Fragment$Place>>,
    )
    _fn,
  );
}

class _CopyWithImpl$Query$DestinationSuggesions<TRes>
    implements CopyWith$Query$DestinationSuggesions<TRes> {
  _CopyWithImpl$Query$DestinationSuggesions(this._instance, this._then);

  final Query$DestinationSuggesions _instance;

  final TRes Function(Query$DestinationSuggesions) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? favoriteLocations = _undefined,
    Object? recentDestinations = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Query$DestinationSuggesions(
      favoriteLocations:
          favoriteLocations == _undefined || favoriteLocations == null
          ? _instance.favoriteLocations
          : (favoriteLocations as List<Fragment$FavoriteLocation>),
      recentDestinations:
          recentDestinations == _undefined || recentDestinations == null
          ? _instance.recentDestinations
          : (recentDestinations as List<Fragment$Place>),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  TRes favoriteLocations(
    Iterable<Fragment$FavoriteLocation> Function(
      Iterable<CopyWith$Fragment$FavoriteLocation<Fragment$FavoriteLocation>>,
    )
    _fn,
  ) => call(
    favoriteLocations: _fn(
      _instance.favoriteLocations.map(
        (e) => CopyWith$Fragment$FavoriteLocation(e, (i) => i),
      ),
    ).toList(),
  );

  TRes recentDestinations(
    Iterable<Fragment$Place> Function(
      Iterable<CopyWith$Fragment$Place<Fragment$Place>>,
    )
    _fn,
  ) => call(
    recentDestinations: _fn(
      _instance.recentDestinations.map(
        (e) => CopyWith$Fragment$Place(e, (i) => i),
      ),
    ).toList(),
  );
}

class _CopyWithStubImpl$Query$DestinationSuggesions<TRes>
    implements CopyWith$Query$DestinationSuggesions<TRes> {
  _CopyWithStubImpl$Query$DestinationSuggesions(this._res);

  TRes _res;

  call({
    List<Fragment$FavoriteLocation>? favoriteLocations,
    List<Fragment$Place>? recentDestinations,
    String? $__typename,
  }) => _res;

  favoriteLocations(_fn) => _res;

  recentDestinations(_fn) => _res;
}

const documentNodeQueryDestinationSuggesions = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.query,
      name: NameNode(value: 'DestinationSuggesions'),
      variableDefinitions: [],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'favoriteLocations'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FragmentSpreadNode(
                  name: NameNode(value: 'FavoriteLocation'),
                  directives: [],
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: 'recentDestinations'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FragmentSpreadNode(
                  name: NameNode(value: 'Place'),
                  directives: [],
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
    fragmentDefinitionFavoriteLocation,
    fragmentDefinitionPhoneNumber,
    fragmentDefinitionCoordinate,
    fragmentDefinitionPlace,
  ],
);
Query$DestinationSuggesions _parserFn$Query$DestinationSuggesions(
  Map<String, dynamic> data,
) => Query$DestinationSuggesions.fromJson(data);
typedef OnQueryComplete$Query$DestinationSuggesions =
    FutureOr<void> Function(
      Map<String, dynamic>?,
      Query$DestinationSuggesions?,
    );

class Options$Query$DestinationSuggesions
    extends graphql.QueryOptions<Query$DestinationSuggesions> {
  Options$Query$DestinationSuggesions({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$DestinationSuggesions? typedOptimisticResult,
    Duration? pollInterval,
    graphql.Context? context,
    OnQueryComplete$Query$DestinationSuggesions? onComplete,
    graphql.OnQueryError? onError,
  }) : onCompleteWithParsed = onComplete,
       super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         pollInterval: pollInterval,
         context: context,
         onComplete: onComplete == null
             ? null
             : (data) => onComplete(
                 data,
                 data == null
                     ? null
                     : _parserFn$Query$DestinationSuggesions(data),
               ),
         onError: onError,
         document: documentNodeQueryDestinationSuggesions,
         parserFn: _parserFn$Query$DestinationSuggesions,
       );

  final OnQueryComplete$Query$DestinationSuggesions? onCompleteWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onComplete == null
        ? super.properties
        : super.properties.where((property) => property != onComplete),
    onCompleteWithParsed,
  ];
}

class WatchOptions$Query$DestinationSuggesions
    extends graphql.WatchQueryOptions<Query$DestinationSuggesions> {
  WatchOptions$Query$DestinationSuggesions({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$DestinationSuggesions? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeQueryDestinationSuggesions,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Query$DestinationSuggesions,
       );
}

class FetchMoreOptions$Query$DestinationSuggesions
    extends graphql.FetchMoreOptions {
  FetchMoreOptions$Query$DestinationSuggesions({
    required graphql.UpdateQuery updateQuery,
  }) : super(
         updateQuery: updateQuery,
         document: documentNodeQueryDestinationSuggesions,
       );
}

extension ClientExtension$Query$DestinationSuggesions on graphql.GraphQLClient {
  Future<graphql.QueryResult<Query$DestinationSuggesions>>
  query$DestinationSuggesions([
    Options$Query$DestinationSuggesions? options,
  ]) async =>
      await this.query(options ?? Options$Query$DestinationSuggesions());

  graphql.ObservableQuery<Query$DestinationSuggesions>
  watchQuery$DestinationSuggesions([
    WatchOptions$Query$DestinationSuggesions? options,
  ]) => this.watchQuery(options ?? WatchOptions$Query$DestinationSuggesions());

  void writeQuery$DestinationSuggesions({
    required Query$DestinationSuggesions data,
    bool broadcast = true,
  }) => this.writeQuery(
    graphql.Request(
      operation: graphql.Operation(
        document: documentNodeQueryDestinationSuggesions,
      ),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Query$DestinationSuggesions? readQuery$DestinationSuggesions({
    bool optimistic = true,
  }) {
    final result = this.readQuery(
      graphql.Request(
        operation: graphql.Operation(
          document: documentNodeQueryDestinationSuggesions,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Query$DestinationSuggesions.fromJson(result);
  }
}

class Variables$Mutation$UpdateFcmToken {
  factory Variables$Mutation$UpdateFcmToken({required String token}) =>
      Variables$Mutation$UpdateFcmToken._({r'token': token});

  Variables$Mutation$UpdateFcmToken._(this._$data);

  factory Variables$Mutation$UpdateFcmToken.fromJson(
    Map<String, dynamic> data,
  ) {
    final result$data = <String, dynamic>{};
    final l$token = data['token'];
    result$data['token'] = (l$token as String);
    return Variables$Mutation$UpdateFcmToken._(result$data);
  }

  Map<String, dynamic> _$data;

  String get token => (_$data['token'] as String);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$token = token;
    result$data['token'] = l$token;
    return result$data;
  }

  CopyWith$Variables$Mutation$UpdateFcmToken<Variables$Mutation$UpdateFcmToken>
  get copyWith => CopyWith$Variables$Mutation$UpdateFcmToken(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Variables$Mutation$UpdateFcmToken ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$token = token;
    final lOther$token = other.token;
    if (l$token != lOther$token) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$token = token;
    return Object.hashAll([l$token]);
  }
}

abstract class CopyWith$Variables$Mutation$UpdateFcmToken<TRes> {
  factory CopyWith$Variables$Mutation$UpdateFcmToken(
    Variables$Mutation$UpdateFcmToken instance,
    TRes Function(Variables$Mutation$UpdateFcmToken) then,
  ) = _CopyWithImpl$Variables$Mutation$UpdateFcmToken;

  factory CopyWith$Variables$Mutation$UpdateFcmToken.stub(TRes res) =
      _CopyWithStubImpl$Variables$Mutation$UpdateFcmToken;

  TRes call({String? token});
}

class _CopyWithImpl$Variables$Mutation$UpdateFcmToken<TRes>
    implements CopyWith$Variables$Mutation$UpdateFcmToken<TRes> {
  _CopyWithImpl$Variables$Mutation$UpdateFcmToken(this._instance, this._then);

  final Variables$Mutation$UpdateFcmToken _instance;

  final TRes Function(Variables$Mutation$UpdateFcmToken) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? token = _undefined}) => _then(
    Variables$Mutation$UpdateFcmToken._({
      ..._instance._$data,
      if (token != _undefined && token != null) 'token': (token as String),
    }),
  );
}

class _CopyWithStubImpl$Variables$Mutation$UpdateFcmToken<TRes>
    implements CopyWith$Variables$Mutation$UpdateFcmToken<TRes> {
  _CopyWithStubImpl$Variables$Mutation$UpdateFcmToken(this._res);

  TRes _res;

  call({String? token}) => _res;
}

class Mutation$UpdateFcmToken {
  Mutation$UpdateFcmToken({
    required this.updateFcmToken,
    this.$__typename = 'Mutation',
  });

  factory Mutation$UpdateFcmToken.fromJson(Map<String, dynamic> json) {
    final l$updateFcmToken = json['updateFcmToken'];
    final l$$__typename = json['__typename'];
    return Mutation$UpdateFcmToken(
      updateFcmToken: (l$updateFcmToken as bool),
      $__typename: (l$$__typename as String),
    );
  }

  final bool updateFcmToken;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$updateFcmToken = updateFcmToken;
    _resultData['updateFcmToken'] = l$updateFcmToken;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$updateFcmToken = updateFcmToken;
    final l$$__typename = $__typename;
    return Object.hashAll([l$updateFcmToken, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$UpdateFcmToken || runtimeType != other.runtimeType) {
      return false;
    }
    final l$updateFcmToken = updateFcmToken;
    final lOther$updateFcmToken = other.updateFcmToken;
    if (l$updateFcmToken != lOther$updateFcmToken) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$UpdateFcmToken on Mutation$UpdateFcmToken {
  CopyWith$Mutation$UpdateFcmToken<Mutation$UpdateFcmToken> get copyWith =>
      CopyWith$Mutation$UpdateFcmToken(this, (i) => i);
}

abstract class CopyWith$Mutation$UpdateFcmToken<TRes> {
  factory CopyWith$Mutation$UpdateFcmToken(
    Mutation$UpdateFcmToken instance,
    TRes Function(Mutation$UpdateFcmToken) then,
  ) = _CopyWithImpl$Mutation$UpdateFcmToken;

  factory CopyWith$Mutation$UpdateFcmToken.stub(TRes res) =
      _CopyWithStubImpl$Mutation$UpdateFcmToken;

  TRes call({bool? updateFcmToken, String? $__typename});
}

class _CopyWithImpl$Mutation$UpdateFcmToken<TRes>
    implements CopyWith$Mutation$UpdateFcmToken<TRes> {
  _CopyWithImpl$Mutation$UpdateFcmToken(this._instance, this._then);

  final Mutation$UpdateFcmToken _instance;

  final TRes Function(Mutation$UpdateFcmToken) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? updateFcmToken = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Mutation$UpdateFcmToken(
      updateFcmToken: updateFcmToken == _undefined || updateFcmToken == null
          ? _instance.updateFcmToken
          : (updateFcmToken as bool),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );
}

class _CopyWithStubImpl$Mutation$UpdateFcmToken<TRes>
    implements CopyWith$Mutation$UpdateFcmToken<TRes> {
  _CopyWithStubImpl$Mutation$UpdateFcmToken(this._res);

  TRes _res;

  call({bool? updateFcmToken, String? $__typename}) => _res;
}

const documentNodeMutationUpdateFcmToken = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.mutation,
      name: NameNode(value: 'UpdateFcmToken'),
      variableDefinitions: [
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'token')),
          type: NamedTypeNode(name: NameNode(value: 'String'), isNonNull: true),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
      ],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'updateFcmToken'),
            alias: null,
            arguments: [
              ArgumentNode(
                name: NameNode(value: 'fcmToken'),
                value: VariableNode(name: NameNode(value: 'token')),
              ),
            ],
            directives: [],
            selectionSet: null,
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
  ],
);
Mutation$UpdateFcmToken _parserFn$Mutation$UpdateFcmToken(
  Map<String, dynamic> data,
) => Mutation$UpdateFcmToken.fromJson(data);
typedef OnMutationCompleted$Mutation$UpdateFcmToken =
    FutureOr<void> Function(Map<String, dynamic>?, Mutation$UpdateFcmToken?);

class Options$Mutation$UpdateFcmToken
    extends graphql.MutationOptions<Mutation$UpdateFcmToken> {
  Options$Mutation$UpdateFcmToken({
    String? operationName,
    required Variables$Mutation$UpdateFcmToken variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$UpdateFcmToken? typedOptimisticResult,
    graphql.Context? context,
    OnMutationCompleted$Mutation$UpdateFcmToken? onCompleted,
    graphql.OnMutationUpdate<Mutation$UpdateFcmToken>? update,
    graphql.OnError? onError,
  }) : onCompletedWithParsed = onCompleted,
       super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         onCompleted: onCompleted == null
             ? null
             : (data) => onCompleted(
                 data,
                 data == null ? null : _parserFn$Mutation$UpdateFcmToken(data),
               ),
         update: update,
         onError: onError,
         document: documentNodeMutationUpdateFcmToken,
         parserFn: _parserFn$Mutation$UpdateFcmToken,
       );

  final OnMutationCompleted$Mutation$UpdateFcmToken? onCompletedWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onCompleted == null
        ? super.properties
        : super.properties.where((property) => property != onCompleted),
    onCompletedWithParsed,
  ];
}

class WatchOptions$Mutation$UpdateFcmToken
    extends graphql.WatchQueryOptions<Mutation$UpdateFcmToken> {
  WatchOptions$Mutation$UpdateFcmToken({
    String? operationName,
    required Variables$Mutation$UpdateFcmToken variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$UpdateFcmToken? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeMutationUpdateFcmToken,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Mutation$UpdateFcmToken,
       );
}

extension ClientExtension$Mutation$UpdateFcmToken on graphql.GraphQLClient {
  Future<graphql.QueryResult<Mutation$UpdateFcmToken>> mutate$UpdateFcmToken(
    Options$Mutation$UpdateFcmToken options,
  ) async => await this.mutate(options);

  graphql.ObservableQuery<Mutation$UpdateFcmToken> watchMutation$UpdateFcmToken(
    WatchOptions$Mutation$UpdateFcmToken options,
  ) => this.watchMutation(options);
}

class Variables$Mutation$SendMessage {
  factory Variables$Mutation$SendMessage({
    required String message,
    required String orderId,
  }) => Variables$Mutation$SendMessage._({
    r'message': message,
    r'orderId': orderId,
  });

  Variables$Mutation$SendMessage._(this._$data);

  factory Variables$Mutation$SendMessage.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$message = data['message'];
    result$data['message'] = (l$message as String);
    final l$orderId = data['orderId'];
    result$data['orderId'] = (l$orderId as String);
    return Variables$Mutation$SendMessage._(result$data);
  }

  Map<String, dynamic> _$data;

  String get message => (_$data['message'] as String);

  String get orderId => (_$data['orderId'] as String);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$message = message;
    result$data['message'] = l$message;
    final l$orderId = orderId;
    result$data['orderId'] = l$orderId;
    return result$data;
  }

  CopyWith$Variables$Mutation$SendMessage<Variables$Mutation$SendMessage>
  get copyWith => CopyWith$Variables$Mutation$SendMessage(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Variables$Mutation$SendMessage ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$message = message;
    final lOther$message = other.message;
    if (l$message != lOther$message) {
      return false;
    }
    final l$orderId = orderId;
    final lOther$orderId = other.orderId;
    if (l$orderId != lOther$orderId) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$message = message;
    final l$orderId = orderId;
    return Object.hashAll([l$message, l$orderId]);
  }
}

abstract class CopyWith$Variables$Mutation$SendMessage<TRes> {
  factory CopyWith$Variables$Mutation$SendMessage(
    Variables$Mutation$SendMessage instance,
    TRes Function(Variables$Mutation$SendMessage) then,
  ) = _CopyWithImpl$Variables$Mutation$SendMessage;

  factory CopyWith$Variables$Mutation$SendMessage.stub(TRes res) =
      _CopyWithStubImpl$Variables$Mutation$SendMessage;

  TRes call({String? message, String? orderId});
}

class _CopyWithImpl$Variables$Mutation$SendMessage<TRes>
    implements CopyWith$Variables$Mutation$SendMessage<TRes> {
  _CopyWithImpl$Variables$Mutation$SendMessage(this._instance, this._then);

  final Variables$Mutation$SendMessage _instance;

  final TRes Function(Variables$Mutation$SendMessage) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? message = _undefined, Object? orderId = _undefined}) =>
      _then(
        Variables$Mutation$SendMessage._({
          ..._instance._$data,
          if (message != _undefined && message != null)
            'message': (message as String),
          if (orderId != _undefined && orderId != null)
            'orderId': (orderId as String),
        }),
      );
}

class _CopyWithStubImpl$Variables$Mutation$SendMessage<TRes>
    implements CopyWith$Variables$Mutation$SendMessage<TRes> {
  _CopyWithStubImpl$Variables$Mutation$SendMessage(this._res);

  TRes _res;

  call({String? message, String? orderId}) => _res;
}

class Mutation$SendMessage {
  Mutation$SendMessage({
    required this.sendChatMessage,
    this.$__typename = 'Mutation',
  });

  factory Mutation$SendMessage.fromJson(Map<String, dynamic> json) {
    final l$sendChatMessage = json['sendChatMessage'];
    final l$$__typename = json['__typename'];
    return Mutation$SendMessage(
      sendChatMessage: Fragment$ChatMessage.fromJson(
        (l$sendChatMessage as Map<String, dynamic>),
      ),
      $__typename: (l$$__typename as String),
    );
  }

  final Fragment$ChatMessage sendChatMessage;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$sendChatMessage = sendChatMessage;
    _resultData['sendChatMessage'] = l$sendChatMessage.toJson();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$sendChatMessage = sendChatMessage;
    final l$$__typename = $__typename;
    return Object.hashAll([l$sendChatMessage, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$SendMessage || runtimeType != other.runtimeType) {
      return false;
    }
    final l$sendChatMessage = sendChatMessage;
    final lOther$sendChatMessage = other.sendChatMessage;
    if (l$sendChatMessage != lOther$sendChatMessage) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$SendMessage on Mutation$SendMessage {
  CopyWith$Mutation$SendMessage<Mutation$SendMessage> get copyWith =>
      CopyWith$Mutation$SendMessage(this, (i) => i);
}

abstract class CopyWith$Mutation$SendMessage<TRes> {
  factory CopyWith$Mutation$SendMessage(
    Mutation$SendMessage instance,
    TRes Function(Mutation$SendMessage) then,
  ) = _CopyWithImpl$Mutation$SendMessage;

  factory CopyWith$Mutation$SendMessage.stub(TRes res) =
      _CopyWithStubImpl$Mutation$SendMessage;

  TRes call({Fragment$ChatMessage? sendChatMessage, String? $__typename});
  CopyWith$Fragment$ChatMessage<TRes> get sendChatMessage;
}

class _CopyWithImpl$Mutation$SendMessage<TRes>
    implements CopyWith$Mutation$SendMessage<TRes> {
  _CopyWithImpl$Mutation$SendMessage(this._instance, this._then);

  final Mutation$SendMessage _instance;

  final TRes Function(Mutation$SendMessage) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? sendChatMessage = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Mutation$SendMessage(
      sendChatMessage: sendChatMessage == _undefined || sendChatMessage == null
          ? _instance.sendChatMessage
          : (sendChatMessage as Fragment$ChatMessage),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  CopyWith$Fragment$ChatMessage<TRes> get sendChatMessage {
    final local$sendChatMessage = _instance.sendChatMessage;
    return CopyWith$Fragment$ChatMessage(
      local$sendChatMessage,
      (e) => call(sendChatMessage: e),
    );
  }
}

class _CopyWithStubImpl$Mutation$SendMessage<TRes>
    implements CopyWith$Mutation$SendMessage<TRes> {
  _CopyWithStubImpl$Mutation$SendMessage(this._res);

  TRes _res;

  call({Fragment$ChatMessage? sendChatMessage, String? $__typename}) => _res;

  CopyWith$Fragment$ChatMessage<TRes> get sendChatMessage =>
      CopyWith$Fragment$ChatMessage.stub(_res);
}

const documentNodeMutationSendMessage = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.mutation,
      name: NameNode(value: 'SendMessage'),
      variableDefinitions: [
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'message')),
          type: NamedTypeNode(name: NameNode(value: 'String'), isNonNull: true),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'orderId')),
          type: NamedTypeNode(name: NameNode(value: 'ID'), isNonNull: true),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
      ],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'sendChatMessage'),
            alias: null,
            arguments: [
              ArgumentNode(
                name: NameNode(value: 'orderId'),
                value: VariableNode(name: NameNode(value: 'orderId')),
              ),
              ArgumentNode(
                name: NameNode(value: 'message'),
                value: VariableNode(name: NameNode(value: 'message')),
              ),
            ],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FragmentSpreadNode(
                  name: NameNode(value: 'ChatMessage'),
                  directives: [],
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
    fragmentDefinitionChatMessage,
  ],
);
Mutation$SendMessage _parserFn$Mutation$SendMessage(
  Map<String, dynamic> data,
) => Mutation$SendMessage.fromJson(data);
typedef OnMutationCompleted$Mutation$SendMessage =
    FutureOr<void> Function(Map<String, dynamic>?, Mutation$SendMessage?);

class Options$Mutation$SendMessage
    extends graphql.MutationOptions<Mutation$SendMessage> {
  Options$Mutation$SendMessage({
    String? operationName,
    required Variables$Mutation$SendMessage variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$SendMessage? typedOptimisticResult,
    graphql.Context? context,
    OnMutationCompleted$Mutation$SendMessage? onCompleted,
    graphql.OnMutationUpdate<Mutation$SendMessage>? update,
    graphql.OnError? onError,
  }) : onCompletedWithParsed = onCompleted,
       super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         onCompleted: onCompleted == null
             ? null
             : (data) => onCompleted(
                 data,
                 data == null ? null : _parserFn$Mutation$SendMessage(data),
               ),
         update: update,
         onError: onError,
         document: documentNodeMutationSendMessage,
         parserFn: _parserFn$Mutation$SendMessage,
       );

  final OnMutationCompleted$Mutation$SendMessage? onCompletedWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onCompleted == null
        ? super.properties
        : super.properties.where((property) => property != onCompleted),
    onCompletedWithParsed,
  ];
}

class WatchOptions$Mutation$SendMessage
    extends graphql.WatchQueryOptions<Mutation$SendMessage> {
  WatchOptions$Mutation$SendMessage({
    String? operationName,
    required Variables$Mutation$SendMessage variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$SendMessage? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeMutationSendMessage,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Mutation$SendMessage,
       );
}

extension ClientExtension$Mutation$SendMessage on graphql.GraphQLClient {
  Future<graphql.QueryResult<Mutation$SendMessage>> mutate$SendMessage(
    Options$Mutation$SendMessage options,
  ) async => await this.mutate(options);

  graphql.ObservableQuery<Mutation$SendMessage> watchMutation$SendMessage(
    WatchOptions$Mutation$SendMessage options,
  ) => this.watchMutation(options);
}

class Variables$Mutation$SendSOS {
  factory Variables$Mutation$SendSOS({required String orderId}) =>
      Variables$Mutation$SendSOS._({r'orderId': orderId});

  Variables$Mutation$SendSOS._(this._$data);

  factory Variables$Mutation$SendSOS.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$orderId = data['orderId'];
    result$data['orderId'] = (l$orderId as String);
    return Variables$Mutation$SendSOS._(result$data);
  }

  Map<String, dynamic> _$data;

  String get orderId => (_$data['orderId'] as String);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$orderId = orderId;
    result$data['orderId'] = l$orderId;
    return result$data;
  }

  CopyWith$Variables$Mutation$SendSOS<Variables$Mutation$SendSOS>
  get copyWith => CopyWith$Variables$Mutation$SendSOS(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Variables$Mutation$SendSOS ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$orderId = orderId;
    final lOther$orderId = other.orderId;
    if (l$orderId != lOther$orderId) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$orderId = orderId;
    return Object.hashAll([l$orderId]);
  }
}

abstract class CopyWith$Variables$Mutation$SendSOS<TRes> {
  factory CopyWith$Variables$Mutation$SendSOS(
    Variables$Mutation$SendSOS instance,
    TRes Function(Variables$Mutation$SendSOS) then,
  ) = _CopyWithImpl$Variables$Mutation$SendSOS;

  factory CopyWith$Variables$Mutation$SendSOS.stub(TRes res) =
      _CopyWithStubImpl$Variables$Mutation$SendSOS;

  TRes call({String? orderId});
}

class _CopyWithImpl$Variables$Mutation$SendSOS<TRes>
    implements CopyWith$Variables$Mutation$SendSOS<TRes> {
  _CopyWithImpl$Variables$Mutation$SendSOS(this._instance, this._then);

  final Variables$Mutation$SendSOS _instance;

  final TRes Function(Variables$Mutation$SendSOS) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? orderId = _undefined}) => _then(
    Variables$Mutation$SendSOS._({
      ..._instance._$data,
      if (orderId != _undefined && orderId != null)
        'orderId': (orderId as String),
    }),
  );
}

class _CopyWithStubImpl$Variables$Mutation$SendSOS<TRes>
    implements CopyWith$Variables$Mutation$SendSOS<TRes> {
  _CopyWithStubImpl$Variables$Mutation$SendSOS(this._res);

  TRes _res;

  call({String? orderId}) => _res;
}

class Mutation$SendSOS {
  Mutation$SendSOS({required this.sosSignal, this.$__typename = 'Mutation'});

  factory Mutation$SendSOS.fromJson(Map<String, dynamic> json) {
    final l$sosSignal = json['sosSignal'];
    final l$$__typename = json['__typename'];
    return Mutation$SendSOS(
      sosSignal: Mutation$SendSOS$sosSignal.fromJson(
        (l$sosSignal as Map<String, dynamic>),
      ),
      $__typename: (l$$__typename as String),
    );
  }

  final Mutation$SendSOS$sosSignal sosSignal;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$sosSignal = sosSignal;
    _resultData['sosSignal'] = l$sosSignal.toJson();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$sosSignal = sosSignal;
    final l$$__typename = $__typename;
    return Object.hashAll([l$sosSignal, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$SendSOS || runtimeType != other.runtimeType) {
      return false;
    }
    final l$sosSignal = sosSignal;
    final lOther$sosSignal = other.sosSignal;
    if (l$sosSignal != lOther$sosSignal) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$SendSOS on Mutation$SendSOS {
  CopyWith$Mutation$SendSOS<Mutation$SendSOS> get copyWith =>
      CopyWith$Mutation$SendSOS(this, (i) => i);
}

abstract class CopyWith$Mutation$SendSOS<TRes> {
  factory CopyWith$Mutation$SendSOS(
    Mutation$SendSOS instance,
    TRes Function(Mutation$SendSOS) then,
  ) = _CopyWithImpl$Mutation$SendSOS;

  factory CopyWith$Mutation$SendSOS.stub(TRes res) =
      _CopyWithStubImpl$Mutation$SendSOS;

  TRes call({Mutation$SendSOS$sosSignal? sosSignal, String? $__typename});
  CopyWith$Mutation$SendSOS$sosSignal<TRes> get sosSignal;
}

class _CopyWithImpl$Mutation$SendSOS<TRes>
    implements CopyWith$Mutation$SendSOS<TRes> {
  _CopyWithImpl$Mutation$SendSOS(this._instance, this._then);

  final Mutation$SendSOS _instance;

  final TRes Function(Mutation$SendSOS) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? sosSignal = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Mutation$SendSOS(
      sosSignal: sosSignal == _undefined || sosSignal == null
          ? _instance.sosSignal
          : (sosSignal as Mutation$SendSOS$sosSignal),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  CopyWith$Mutation$SendSOS$sosSignal<TRes> get sosSignal {
    final local$sosSignal = _instance.sosSignal;
    return CopyWith$Mutation$SendSOS$sosSignal(
      local$sosSignal,
      (e) => call(sosSignal: e),
    );
  }
}

class _CopyWithStubImpl$Mutation$SendSOS<TRes>
    implements CopyWith$Mutation$SendSOS<TRes> {
  _CopyWithStubImpl$Mutation$SendSOS(this._res);

  TRes _res;

  call({Mutation$SendSOS$sosSignal? sosSignal, String? $__typename}) => _res;

  CopyWith$Mutation$SendSOS$sosSignal<TRes> get sosSignal =>
      CopyWith$Mutation$SendSOS$sosSignal.stub(_res);
}

const documentNodeMutationSendSOS = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.mutation,
      name: NameNode(value: 'SendSOS'),
      variableDefinitions: [
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'orderId')),
          type: NamedTypeNode(name: NameNode(value: 'ID'), isNonNull: true),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
      ],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'sosSignal'),
            alias: null,
            arguments: [
              ArgumentNode(
                name: NameNode(value: 'orderId'),
                value: VariableNode(name: NameNode(value: 'orderId')),
              ),
            ],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FieldNode(
                  name: NameNode(value: 'id'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
  ],
);
Mutation$SendSOS _parserFn$Mutation$SendSOS(Map<String, dynamic> data) =>
    Mutation$SendSOS.fromJson(data);
typedef OnMutationCompleted$Mutation$SendSOS =
    FutureOr<void> Function(Map<String, dynamic>?, Mutation$SendSOS?);

class Options$Mutation$SendSOS
    extends graphql.MutationOptions<Mutation$SendSOS> {
  Options$Mutation$SendSOS({
    String? operationName,
    required Variables$Mutation$SendSOS variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$SendSOS? typedOptimisticResult,
    graphql.Context? context,
    OnMutationCompleted$Mutation$SendSOS? onCompleted,
    graphql.OnMutationUpdate<Mutation$SendSOS>? update,
    graphql.OnError? onError,
  }) : onCompletedWithParsed = onCompleted,
       super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         onCompleted: onCompleted == null
             ? null
             : (data) => onCompleted(
                 data,
                 data == null ? null : _parserFn$Mutation$SendSOS(data),
               ),
         update: update,
         onError: onError,
         document: documentNodeMutationSendSOS,
         parserFn: _parserFn$Mutation$SendSOS,
       );

  final OnMutationCompleted$Mutation$SendSOS? onCompletedWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onCompleted == null
        ? super.properties
        : super.properties.where((property) => property != onCompleted),
    onCompletedWithParsed,
  ];
}

class WatchOptions$Mutation$SendSOS
    extends graphql.WatchQueryOptions<Mutation$SendSOS> {
  WatchOptions$Mutation$SendSOS({
    String? operationName,
    required Variables$Mutation$SendSOS variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$SendSOS? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeMutationSendSOS,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Mutation$SendSOS,
       );
}

extension ClientExtension$Mutation$SendSOS on graphql.GraphQLClient {
  Future<graphql.QueryResult<Mutation$SendSOS>> mutate$SendSOS(
    Options$Mutation$SendSOS options,
  ) async => await this.mutate(options);

  graphql.ObservableQuery<Mutation$SendSOS> watchMutation$SendSOS(
    WatchOptions$Mutation$SendSOS options,
  ) => this.watchMutation(options);
}

class Mutation$SendSOS$sosSignal {
  Mutation$SendSOS$sosSignal({required this.id, this.$__typename = 'SOS'});

  factory Mutation$SendSOS$sosSignal.fromJson(Map<String, dynamic> json) {
    final l$id = json['id'];
    final l$$__typename = json['__typename'];
    return Mutation$SendSOS$sosSignal(
      id: (l$id as String),
      $__typename: (l$$__typename as String),
    );
  }

  final String id;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$id = id;
    _resultData['id'] = l$id;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$id = id;
    final l$$__typename = $__typename;
    return Object.hashAll([l$id, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$SendSOS$sosSignal ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$id = id;
    final lOther$id = other.id;
    if (l$id != lOther$id) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$SendSOS$sosSignal
    on Mutation$SendSOS$sosSignal {
  CopyWith$Mutation$SendSOS$sosSignal<Mutation$SendSOS$sosSignal>
  get copyWith => CopyWith$Mutation$SendSOS$sosSignal(this, (i) => i);
}

abstract class CopyWith$Mutation$SendSOS$sosSignal<TRes> {
  factory CopyWith$Mutation$SendSOS$sosSignal(
    Mutation$SendSOS$sosSignal instance,
    TRes Function(Mutation$SendSOS$sosSignal) then,
  ) = _CopyWithImpl$Mutation$SendSOS$sosSignal;

  factory CopyWith$Mutation$SendSOS$sosSignal.stub(TRes res) =
      _CopyWithStubImpl$Mutation$SendSOS$sosSignal;

  TRes call({String? id, String? $__typename});
}

class _CopyWithImpl$Mutation$SendSOS$sosSignal<TRes>
    implements CopyWith$Mutation$SendSOS$sosSignal<TRes> {
  _CopyWithImpl$Mutation$SendSOS$sosSignal(this._instance, this._then);

  final Mutation$SendSOS$sosSignal _instance;

  final TRes Function(Mutation$SendSOS$sosSignal) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? id = _undefined, Object? $__typename = _undefined}) =>
      _then(
        Mutation$SendSOS$sosSignal(
          id: id == _undefined || id == null ? _instance.id : (id as String),
          $__typename: $__typename == _undefined || $__typename == null
              ? _instance.$__typename
              : ($__typename as String),
        ),
      );
}

class _CopyWithStubImpl$Mutation$SendSOS$sosSignal<TRes>
    implements CopyWith$Mutation$SendSOS$sosSignal<TRes> {
  _CopyWithStubImpl$Mutation$SendSOS$sosSignal(this._res);

  TRes _res;

  call({String? id, String? $__typename}) => _res;
}

class Subscription$OrderUpdateSubsctipion {
  Subscription$OrderUpdateSubsctipion({required this.activeOrderUpdated});

  factory Subscription$OrderUpdateSubsctipion.fromJson(
    Map<String, dynamic> json,
  ) {
    final l$activeOrderUpdated = json['activeOrderUpdated'];
    return Subscription$OrderUpdateSubsctipion(
      activeOrderUpdated:
          Subscription$OrderUpdateSubsctipion$activeOrderUpdated.fromJson(
            (l$activeOrderUpdated as Map<String, dynamic>),
          ),
    );
  }

  final Subscription$OrderUpdateSubsctipion$activeOrderUpdated
  activeOrderUpdated;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$activeOrderUpdated = activeOrderUpdated;
    _resultData['activeOrderUpdated'] = l$activeOrderUpdated.toJson();
    return _resultData;
  }

  @override
  int get hashCode {
    final l$activeOrderUpdated = activeOrderUpdated;
    return Object.hashAll([l$activeOrderUpdated]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Subscription$OrderUpdateSubsctipion ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$activeOrderUpdated = activeOrderUpdated;
    final lOther$activeOrderUpdated = other.activeOrderUpdated;
    if (l$activeOrderUpdated != lOther$activeOrderUpdated) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Subscription$OrderUpdateSubsctipion
    on Subscription$OrderUpdateSubsctipion {
  CopyWith$Subscription$OrderUpdateSubsctipion<
    Subscription$OrderUpdateSubsctipion
  >
  get copyWith => CopyWith$Subscription$OrderUpdateSubsctipion(this, (i) => i);
}

abstract class CopyWith$Subscription$OrderUpdateSubsctipion<TRes> {
  factory CopyWith$Subscription$OrderUpdateSubsctipion(
    Subscription$OrderUpdateSubsctipion instance,
    TRes Function(Subscription$OrderUpdateSubsctipion) then,
  ) = _CopyWithImpl$Subscription$OrderUpdateSubsctipion;

  factory CopyWith$Subscription$OrderUpdateSubsctipion.stub(TRes res) =
      _CopyWithStubImpl$Subscription$OrderUpdateSubsctipion;

  TRes call({
    Subscription$OrderUpdateSubsctipion$activeOrderUpdated? activeOrderUpdated,
  });
  CopyWith$Subscription$OrderUpdateSubsctipion$activeOrderUpdated<TRes>
  get activeOrderUpdated;
}

class _CopyWithImpl$Subscription$OrderUpdateSubsctipion<TRes>
    implements CopyWith$Subscription$OrderUpdateSubsctipion<TRes> {
  _CopyWithImpl$Subscription$OrderUpdateSubsctipion(this._instance, this._then);

  final Subscription$OrderUpdateSubsctipion _instance;

  final TRes Function(Subscription$OrderUpdateSubsctipion) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? activeOrderUpdated = _undefined}) => _then(
    Subscription$OrderUpdateSubsctipion(
      activeOrderUpdated:
          activeOrderUpdated == _undefined || activeOrderUpdated == null
          ? _instance.activeOrderUpdated
          : (activeOrderUpdated
                as Subscription$OrderUpdateSubsctipion$activeOrderUpdated),
    ),
  );

  CopyWith$Subscription$OrderUpdateSubsctipion$activeOrderUpdated<TRes>
  get activeOrderUpdated {
    final local$activeOrderUpdated = _instance.activeOrderUpdated;
    return CopyWith$Subscription$OrderUpdateSubsctipion$activeOrderUpdated(
      local$activeOrderUpdated,
      (e) => call(activeOrderUpdated: e),
    );
  }
}

class _CopyWithStubImpl$Subscription$OrderUpdateSubsctipion<TRes>
    implements CopyWith$Subscription$OrderUpdateSubsctipion<TRes> {
  _CopyWithStubImpl$Subscription$OrderUpdateSubsctipion(this._res);

  TRes _res;

  call({
    Subscription$OrderUpdateSubsctipion$activeOrderUpdated? activeOrderUpdated,
  }) => _res;

  CopyWith$Subscription$OrderUpdateSubsctipion$activeOrderUpdated<TRes>
  get activeOrderUpdated =>
      CopyWith$Subscription$OrderUpdateSubsctipion$activeOrderUpdated.stub(
        _res,
      );
}

const documentNodeSubscriptionOrderUpdateSubsctipion = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.subscription,
      name: NameNode(value: 'OrderUpdateSubsctipion'),
      variableDefinitions: [],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'activeOrderUpdated'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FieldNode(
                  name: NameNode(value: 'type'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: 'orderId'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: 'message'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: SelectionSetNode(
                    selections: [
                      FragmentSpreadNode(
                        name: NameNode(value: 'ChatMessage'),
                        directives: [],
                      ),
                      FieldNode(
                        name: NameNode(value: '__typename'),
                        alias: null,
                        arguments: [],
                        directives: [],
                        selectionSet: null,
                      ),
                    ],
                  ),
                ),
                FieldNode(
                  name: NameNode(value: 'status'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: 'unreadMessagesCount'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: 'directions'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: SelectionSetNode(
                    selections: [
                      FragmentSpreadNode(
                        name: NameNode(value: 'Coordinate'),
                        directives: [],
                      ),
                      FieldNode(
                        name: NameNode(value: '__typename'),
                        alias: null,
                        arguments: [],
                        directives: [],
                        selectionSet: null,
                      ),
                    ],
                  ),
                ),
                FieldNode(
                  name: NameNode(value: 'driverLocation'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: SelectionSetNode(
                    selections: [
                      FragmentSpreadNode(
                        name: NameNode(value: 'Coordinate'),
                        directives: [],
                      ),
                      FieldNode(
                        name: NameNode(value: '__typename'),
                        alias: null,
                        arguments: [],
                        directives: [],
                        selectionSet: null,
                      ),
                    ],
                  ),
                ),
                FieldNode(
                  name: NameNode(value: 'driver'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: SelectionSetNode(
                    selections: [
                      FragmentSpreadNode(
                        name: NameNode(value: 'ActiveOrderDriver'),
                        directives: [],
                      ),
                      FieldNode(
                        name: NameNode(value: '__typename'),
                        alias: null,
                        arguments: [],
                        directives: [],
                        selectionSet: null,
                      ),
                    ],
                  ),
                ),
                FieldNode(
                  name: NameNode(value: 'nextDestination'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: SelectionSetNode(
                    selections: [
                      FragmentSpreadNode(
                        name: NameNode(value: 'Waypoint'),
                        directives: [],
                      ),
                      FieldNode(
                        name: NameNode(value: '__typename'),
                        alias: null,
                        arguments: [],
                        directives: [],
                        selectionSet: null,
                      ),
                    ],
                  ),
                ),
                FieldNode(
                  name: NameNode(value: 'driverLocation'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: SelectionSetNode(
                    selections: [
                      FragmentSpreadNode(
                        name: NameNode(value: 'Coordinate'),
                        directives: [],
                      ),
                      FieldNode(
                        name: NameNode(value: '__typename'),
                        alias: null,
                        arguments: [],
                        directives: [],
                        selectionSet: null,
                      ),
                    ],
                  ),
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
        ],
      ),
    ),
    fragmentDefinitionChatMessage,
    fragmentDefinitionCoordinate,
    fragmentDefinitionActiveOrderDriver,
    fragmentDefinitionWaypoint,
    fragmentDefinitionRideWaypoint,
    fragmentDefinitionDeliveryWaypoint,
    fragmentDefinitionPhoneNumber,
    fragmentDefinitionShopWaypoint,
  ],
);
Subscription$OrderUpdateSubsctipion
_parserFn$Subscription$OrderUpdateSubsctipion(Map<String, dynamic> data) =>
    Subscription$OrderUpdateSubsctipion.fromJson(data);

class Options$Subscription$OrderUpdateSubsctipion
    extends graphql.SubscriptionOptions<Subscription$OrderUpdateSubsctipion> {
  Options$Subscription$OrderUpdateSubsctipion({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Subscription$OrderUpdateSubsctipion? typedOptimisticResult,
    graphql.Context? context,
  }) : super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeSubscriptionOrderUpdateSubsctipion,
         parserFn: _parserFn$Subscription$OrderUpdateSubsctipion,
       );
}

class WatchOptions$Subscription$OrderUpdateSubsctipion
    extends graphql.WatchQueryOptions<Subscription$OrderUpdateSubsctipion> {
  WatchOptions$Subscription$OrderUpdateSubsctipion({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Subscription$OrderUpdateSubsctipion? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeSubscriptionOrderUpdateSubsctipion,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Subscription$OrderUpdateSubsctipion,
       );
}

class FetchMoreOptions$Subscription$OrderUpdateSubsctipion
    extends graphql.FetchMoreOptions {
  FetchMoreOptions$Subscription$OrderUpdateSubsctipion({
    required graphql.UpdateQuery updateQuery,
  }) : super(
         updateQuery: updateQuery,
         document: documentNodeSubscriptionOrderUpdateSubsctipion,
       );
}

extension ClientExtension$Subscription$OrderUpdateSubsctipion
    on graphql.GraphQLClient {
  Stream<graphql.QueryResult<Subscription$OrderUpdateSubsctipion>>
  subscribe$OrderUpdateSubsctipion([
    Options$Subscription$OrderUpdateSubsctipion? options,
  ]) =>
      this.subscribe(options ?? Options$Subscription$OrderUpdateSubsctipion());

  graphql.ObservableQuery<Subscription$OrderUpdateSubsctipion>
  watchSubscription$OrderUpdateSubsctipion([
    WatchOptions$Subscription$OrderUpdateSubsctipion? options,
  ]) => this.watchQuery(
    options ?? WatchOptions$Subscription$OrderUpdateSubsctipion(),
  );
}

class Subscription$OrderUpdateSubsctipion$activeOrderUpdated {
  Subscription$OrderUpdateSubsctipion$activeOrderUpdated({
    required this.type,
    required this.orderId,
    this.message,
    this.status,
    this.unreadMessagesCount,
    this.directions,
    this.driverLocation,
    this.driver,
    this.nextDestination,
    this.$__typename = 'RiderActiveOrderUpdate',
  });

  factory Subscription$OrderUpdateSubsctipion$activeOrderUpdated.fromJson(
    Map<String, dynamic> json,
  ) {
    final l$type = json['type'];
    final l$orderId = json['orderId'];
    final l$message = json['message'];
    final l$status = json['status'];
    final l$unreadMessagesCount = json['unreadMessagesCount'];
    final l$directions = json['directions'];
    final l$driverLocation = json['driverLocation'];
    final l$driver = json['driver'];
    final l$nextDestination = json['nextDestination'];
    final l$$__typename = json['__typename'];
    return Subscription$OrderUpdateSubsctipion$activeOrderUpdated(
      type: fromJson$Enum$RiderOrderUpdateType((l$type as String)),
      orderId: (l$orderId as String),
      message: l$message == null
          ? null
          : Fragment$ChatMessage.fromJson((l$message as Map<String, dynamic>)),
      status: l$status == null
          ? null
          : fromJson$Enum$OrderStatus((l$status as String)),
      unreadMessagesCount: (l$unreadMessagesCount as int?),
      directions: (l$directions as List<dynamic>?)
          ?.map(
            (e) => Fragment$Coordinate.fromJson((e as Map<String, dynamic>)),
          )
          .toList(),
      driverLocation: l$driverLocation == null
          ? null
          : Fragment$Coordinate.fromJson(
              (l$driverLocation as Map<String, dynamic>),
            ),
      driver: l$driver == null
          ? null
          : Fragment$ActiveOrderDriver.fromJson(
              (l$driver as Map<String, dynamic>),
            ),
      nextDestination: l$nextDestination == null
          ? null
          : Fragment$Waypoint.fromJson(
              (l$nextDestination as Map<String, dynamic>),
            ),
      $__typename: (l$$__typename as String),
    );
  }

  final Enum$RiderOrderUpdateType type;

  final String orderId;

  final Fragment$ChatMessage? message;

  final Enum$OrderStatus? status;

  final int? unreadMessagesCount;

  final List<Fragment$Coordinate>? directions;

  final Fragment$Coordinate? driverLocation;

  final Fragment$ActiveOrderDriver? driver;

  final Fragment$Waypoint? nextDestination;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$type = type;
    _resultData['type'] = toJson$Enum$RiderOrderUpdateType(l$type);
    final l$orderId = orderId;
    _resultData['orderId'] = l$orderId;
    final l$message = message;
    _resultData['message'] = l$message?.toJson();
    final l$status = status;
    _resultData['status'] = l$status == null
        ? null
        : toJson$Enum$OrderStatus(l$status);
    final l$unreadMessagesCount = unreadMessagesCount;
    _resultData['unreadMessagesCount'] = l$unreadMessagesCount;
    final l$directions = directions;
    _resultData['directions'] = l$directions?.map((e) => e.toJson()).toList();
    final l$driverLocation = driverLocation;
    _resultData['driverLocation'] = l$driverLocation?.toJson();
    final l$driver = driver;
    _resultData['driver'] = l$driver?.toJson();
    final l$nextDestination = nextDestination;
    _resultData['nextDestination'] = l$nextDestination?.toJson();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$type = type;
    final l$orderId = orderId;
    final l$message = message;
    final l$status = status;
    final l$unreadMessagesCount = unreadMessagesCount;
    final l$directions = directions;
    final l$driverLocation = driverLocation;
    final l$driver = driver;
    final l$nextDestination = nextDestination;
    final l$$__typename = $__typename;
    return Object.hashAll([
      l$type,
      l$orderId,
      l$message,
      l$status,
      l$unreadMessagesCount,
      l$directions == null ? null : Object.hashAll(l$directions.map((v) => v)),
      l$driverLocation,
      l$driver,
      l$nextDestination,
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Subscription$OrderUpdateSubsctipion$activeOrderUpdated ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$type = type;
    final lOther$type = other.type;
    if (l$type != lOther$type) {
      return false;
    }
    final l$orderId = orderId;
    final lOther$orderId = other.orderId;
    if (l$orderId != lOther$orderId) {
      return false;
    }
    final l$message = message;
    final lOther$message = other.message;
    if (l$message != lOther$message) {
      return false;
    }
    final l$status = status;
    final lOther$status = other.status;
    if (l$status != lOther$status) {
      return false;
    }
    final l$unreadMessagesCount = unreadMessagesCount;
    final lOther$unreadMessagesCount = other.unreadMessagesCount;
    if (l$unreadMessagesCount != lOther$unreadMessagesCount) {
      return false;
    }
    final l$directions = directions;
    final lOther$directions = other.directions;
    if (l$directions != null && lOther$directions != null) {
      if (l$directions.length != lOther$directions.length) {
        return false;
      }
      for (int i = 0; i < l$directions.length; i++) {
        final l$directions$entry = l$directions[i];
        final lOther$directions$entry = lOther$directions[i];
        if (l$directions$entry != lOther$directions$entry) {
          return false;
        }
      }
    } else if (l$directions != lOther$directions) {
      return false;
    }
    final l$driverLocation = driverLocation;
    final lOther$driverLocation = other.driverLocation;
    if (l$driverLocation != lOther$driverLocation) {
      return false;
    }
    final l$driver = driver;
    final lOther$driver = other.driver;
    if (l$driver != lOther$driver) {
      return false;
    }
    final l$nextDestination = nextDestination;
    final lOther$nextDestination = other.nextDestination;
    if (l$nextDestination != lOther$nextDestination) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Subscription$OrderUpdateSubsctipion$activeOrderUpdated
    on Subscription$OrderUpdateSubsctipion$activeOrderUpdated {
  CopyWith$Subscription$OrderUpdateSubsctipion$activeOrderUpdated<
    Subscription$OrderUpdateSubsctipion$activeOrderUpdated
  >
  get copyWith =>
      CopyWith$Subscription$OrderUpdateSubsctipion$activeOrderUpdated(
        this,
        (i) => i,
      );
}

abstract class CopyWith$Subscription$OrderUpdateSubsctipion$activeOrderUpdated<
  TRes
> {
  factory CopyWith$Subscription$OrderUpdateSubsctipion$activeOrderUpdated(
    Subscription$OrderUpdateSubsctipion$activeOrderUpdated instance,
    TRes Function(Subscription$OrderUpdateSubsctipion$activeOrderUpdated) then,
  ) = _CopyWithImpl$Subscription$OrderUpdateSubsctipion$activeOrderUpdated;

  factory CopyWith$Subscription$OrderUpdateSubsctipion$activeOrderUpdated.stub(
    TRes res,
  ) = _CopyWithStubImpl$Subscription$OrderUpdateSubsctipion$activeOrderUpdated;

  TRes call({
    Enum$RiderOrderUpdateType? type,
    String? orderId,
    Fragment$ChatMessage? message,
    Enum$OrderStatus? status,
    int? unreadMessagesCount,
    List<Fragment$Coordinate>? directions,
    Fragment$Coordinate? driverLocation,
    Fragment$ActiveOrderDriver? driver,
    Fragment$Waypoint? nextDestination,
    String? $__typename,
  });
  CopyWith$Fragment$ChatMessage<TRes> get message;
  TRes directions(
    Iterable<Fragment$Coordinate>? Function(
      Iterable<CopyWith$Fragment$Coordinate<Fragment$Coordinate>>?,
    )
    _fn,
  );
  CopyWith$Fragment$Coordinate<TRes> get driverLocation;
  CopyWith$Fragment$ActiveOrderDriver<TRes> get driver;
  CopyWith$Fragment$Waypoint<TRes> get nextDestination;
}

class _CopyWithImpl$Subscription$OrderUpdateSubsctipion$activeOrderUpdated<TRes>
    implements
        CopyWith$Subscription$OrderUpdateSubsctipion$activeOrderUpdated<TRes> {
  _CopyWithImpl$Subscription$OrderUpdateSubsctipion$activeOrderUpdated(
    this._instance,
    this._then,
  );

  final Subscription$OrderUpdateSubsctipion$activeOrderUpdated _instance;

  final TRes Function(Subscription$OrderUpdateSubsctipion$activeOrderUpdated)
  _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? type = _undefined,
    Object? orderId = _undefined,
    Object? message = _undefined,
    Object? status = _undefined,
    Object? unreadMessagesCount = _undefined,
    Object? directions = _undefined,
    Object? driverLocation = _undefined,
    Object? driver = _undefined,
    Object? nextDestination = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Subscription$OrderUpdateSubsctipion$activeOrderUpdated(
      type: type == _undefined || type == null
          ? _instance.type
          : (type as Enum$RiderOrderUpdateType),
      orderId: orderId == _undefined || orderId == null
          ? _instance.orderId
          : (orderId as String),
      message: message == _undefined
          ? _instance.message
          : (message as Fragment$ChatMessage?),
      status: status == _undefined
          ? _instance.status
          : (status as Enum$OrderStatus?),
      unreadMessagesCount: unreadMessagesCount == _undefined
          ? _instance.unreadMessagesCount
          : (unreadMessagesCount as int?),
      directions: directions == _undefined
          ? _instance.directions
          : (directions as List<Fragment$Coordinate>?),
      driverLocation: driverLocation == _undefined
          ? _instance.driverLocation
          : (driverLocation as Fragment$Coordinate?),
      driver: driver == _undefined
          ? _instance.driver
          : (driver as Fragment$ActiveOrderDriver?),
      nextDestination: nextDestination == _undefined
          ? _instance.nextDestination
          : (nextDestination as Fragment$Waypoint?),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  CopyWith$Fragment$ChatMessage<TRes> get message {
    final local$message = _instance.message;
    return local$message == null
        ? CopyWith$Fragment$ChatMessage.stub(_then(_instance))
        : CopyWith$Fragment$ChatMessage(local$message, (e) => call(message: e));
  }

  TRes directions(
    Iterable<Fragment$Coordinate>? Function(
      Iterable<CopyWith$Fragment$Coordinate<Fragment$Coordinate>>?,
    )
    _fn,
  ) => call(
    directions: _fn(
      _instance.directions?.map(
        (e) => CopyWith$Fragment$Coordinate(e, (i) => i),
      ),
    )?.toList(),
  );

  CopyWith$Fragment$Coordinate<TRes> get driverLocation {
    final local$driverLocation = _instance.driverLocation;
    return local$driverLocation == null
        ? CopyWith$Fragment$Coordinate.stub(_then(_instance))
        : CopyWith$Fragment$Coordinate(
            local$driverLocation,
            (e) => call(driverLocation: e),
          );
  }

  CopyWith$Fragment$ActiveOrderDriver<TRes> get driver {
    final local$driver = _instance.driver;
    return local$driver == null
        ? CopyWith$Fragment$ActiveOrderDriver.stub(_then(_instance))
        : CopyWith$Fragment$ActiveOrderDriver(
            local$driver,
            (e) => call(driver: e),
          );
  }

  CopyWith$Fragment$Waypoint<TRes> get nextDestination {
    final local$nextDestination = _instance.nextDestination;
    return local$nextDestination == null
        ? CopyWith$Fragment$Waypoint.stub(_then(_instance))
        : CopyWith$Fragment$Waypoint(
            local$nextDestination,
            (e) => call(nextDestination: e),
          );
  }
}

class _CopyWithStubImpl$Subscription$OrderUpdateSubsctipion$activeOrderUpdated<
  TRes
>
    implements
        CopyWith$Subscription$OrderUpdateSubsctipion$activeOrderUpdated<TRes> {
  _CopyWithStubImpl$Subscription$OrderUpdateSubsctipion$activeOrderUpdated(
    this._res,
  );

  TRes _res;

  call({
    Enum$RiderOrderUpdateType? type,
    String? orderId,
    Fragment$ChatMessage? message,
    Enum$OrderStatus? status,
    int? unreadMessagesCount,
    List<Fragment$Coordinate>? directions,
    Fragment$Coordinate? driverLocation,
    Fragment$ActiveOrderDriver? driver,
    Fragment$Waypoint? nextDestination,
    String? $__typename,
  }) => _res;

  CopyWith$Fragment$ChatMessage<TRes> get message =>
      CopyWith$Fragment$ChatMessage.stub(_res);

  directions(_fn) => _res;

  CopyWith$Fragment$Coordinate<TRes> get driverLocation =>
      CopyWith$Fragment$Coordinate.stub(_res);

  CopyWith$Fragment$ActiveOrderDriver<TRes> get driver =>
      CopyWith$Fragment$ActiveOrderDriver.stub(_res);

  CopyWith$Fragment$Waypoint<TRes> get nextDestination =>
      CopyWith$Fragment$Waypoint.stub(_res);
}
