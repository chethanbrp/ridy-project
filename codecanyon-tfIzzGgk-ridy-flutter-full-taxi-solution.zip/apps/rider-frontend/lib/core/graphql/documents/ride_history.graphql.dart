import '../fragments/driver.fragment.graphql.dart';
import '../fragments/past_order.fragment.graphql.dart';
import '../fragments/payment_method.fragment.graphql.dart';
import '../fragments/phone_number.fragment.graphql.dart';
import '../fragments/point.fragment.graphql.dart';
import '../schema.gql.dart';
import 'dart:async';
import 'package:gql/ast.dart';
import 'package:graphql/client.dart' as graphql;

class Query$RideHistory {
  Query$RideHistory({required this.pastOrders, this.$__typename = 'Query'});

  factory Query$RideHistory.fromJson(Map<String, dynamic> json) {
    final l$pastOrders = json['pastOrders'];
    final l$$__typename = json['__typename'];
    return Query$RideHistory(
      pastOrders: (l$pastOrders as List<dynamic>)
          .map((e) => Fragment$PastOrder.fromJson((e as Map<String, dynamic>)))
          .toList(),
      $__typename: (l$$__typename as String),
    );
  }

  final List<Fragment$PastOrder> pastOrders;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$pastOrders = pastOrders;
    _resultData['pastOrders'] = l$pastOrders.map((e) => e.toJson()).toList();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$pastOrders = pastOrders;
    final l$$__typename = $__typename;
    return Object.hashAll([
      Object.hashAll(l$pastOrders.map((v) => v)),
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Query$RideHistory || runtimeType != other.runtimeType) {
      return false;
    }
    final l$pastOrders = pastOrders;
    final lOther$pastOrders = other.pastOrders;
    if (l$pastOrders.length != lOther$pastOrders.length) {
      return false;
    }
    for (int i = 0; i < l$pastOrders.length; i++) {
      final l$pastOrders$entry = l$pastOrders[i];
      final lOther$pastOrders$entry = lOther$pastOrders[i];
      if (l$pastOrders$entry != lOther$pastOrders$entry) {
        return false;
      }
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Query$RideHistory on Query$RideHistory {
  CopyWith$Query$RideHistory<Query$RideHistory> get copyWith =>
      CopyWith$Query$RideHistory(this, (i) => i);
}

abstract class CopyWith$Query$RideHistory<TRes> {
  factory CopyWith$Query$RideHistory(
    Query$RideHistory instance,
    TRes Function(Query$RideHistory) then,
  ) = _CopyWithImpl$Query$RideHistory;

  factory CopyWith$Query$RideHistory.stub(TRes res) =
      _CopyWithStubImpl$Query$RideHistory;

  TRes call({List<Fragment$PastOrder>? pastOrders, String? $__typename});
  TRes pastOrders(
    Iterable<Fragment$PastOrder> Function(
      Iterable<CopyWith$Fragment$PastOrder<Fragment$PastOrder>>,
    )
    _fn,
  );
}

class _CopyWithImpl$Query$RideHistory<TRes>
    implements CopyWith$Query$RideHistory<TRes> {
  _CopyWithImpl$Query$RideHistory(this._instance, this._then);

  final Query$RideHistory _instance;

  final TRes Function(Query$RideHistory) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? pastOrders = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Query$RideHistory(
      pastOrders: pastOrders == _undefined || pastOrders == null
          ? _instance.pastOrders
          : (pastOrders as List<Fragment$PastOrder>),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  TRes pastOrders(
    Iterable<Fragment$PastOrder> Function(
      Iterable<CopyWith$Fragment$PastOrder<Fragment$PastOrder>>,
    )
    _fn,
  ) => call(
    pastOrders: _fn(
      _instance.pastOrders.map((e) => CopyWith$Fragment$PastOrder(e, (i) => i)),
    ).toList(),
  );
}

class _CopyWithStubImpl$Query$RideHistory<TRes>
    implements CopyWith$Query$RideHistory<TRes> {
  _CopyWithStubImpl$Query$RideHistory(this._res);

  TRes _res;

  call({List<Fragment$PastOrder>? pastOrders, String? $__typename}) => _res;

  pastOrders(_fn) => _res;
}

const documentNodeQueryRideHistory = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.query,
      name: NameNode(value: 'RideHistory'),
      variableDefinitions: [],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'pastOrders'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FragmentSpreadNode(
                  name: NameNode(value: 'PastOrder'),
                  directives: [],
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
    fragmentDefinitionPastOrder,
    fragmentDefinitionCoordinate,
    fragmentDefinitionPastOrderDriver,
    fragmentDefinitionPaymentMethod,
    fragmentDefinitionSavedAccount,
    fragmentDefinitionOnlinePaymentMethod,
    fragmentDefinitionWaypoint,
    fragmentDefinitionRideWaypoint,
    fragmentDefinitionDeliveryWaypoint,
    fragmentDefinitionPhoneNumber,
    fragmentDefinitionShopWaypoint,
  ],
);
Query$RideHistory _parserFn$Query$RideHistory(Map<String, dynamic> data) =>
    Query$RideHistory.fromJson(data);
typedef OnQueryComplete$Query$RideHistory =
    FutureOr<void> Function(Map<String, dynamic>?, Query$RideHistory?);

class Options$Query$RideHistory
    extends graphql.QueryOptions<Query$RideHistory> {
  Options$Query$RideHistory({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$RideHistory? typedOptimisticResult,
    Duration? pollInterval,
    graphql.Context? context,
    OnQueryComplete$Query$RideHistory? onComplete,
    graphql.OnQueryError? onError,
  }) : onCompleteWithParsed = onComplete,
       super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         pollInterval: pollInterval,
         context: context,
         onComplete: onComplete == null
             ? null
             : (data) => onComplete(
                 data,
                 data == null ? null : _parserFn$Query$RideHistory(data),
               ),
         onError: onError,
         document: documentNodeQueryRideHistory,
         parserFn: _parserFn$Query$RideHistory,
       );

  final OnQueryComplete$Query$RideHistory? onCompleteWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onComplete == null
        ? super.properties
        : super.properties.where((property) => property != onComplete),
    onCompleteWithParsed,
  ];
}

class WatchOptions$Query$RideHistory
    extends graphql.WatchQueryOptions<Query$RideHistory> {
  WatchOptions$Query$RideHistory({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$RideHistory? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeQueryRideHistory,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Query$RideHistory,
       );
}

class FetchMoreOptions$Query$RideHistory extends graphql.FetchMoreOptions {
  FetchMoreOptions$Query$RideHistory({required graphql.UpdateQuery updateQuery})
    : super(updateQuery: updateQuery, document: documentNodeQueryRideHistory);
}

extension ClientExtension$Query$RideHistory on graphql.GraphQLClient {
  Future<graphql.QueryResult<Query$RideHistory>> query$RideHistory([
    Options$Query$RideHistory? options,
  ]) async => await this.query(options ?? Options$Query$RideHistory());

  graphql.ObservableQuery<Query$RideHistory> watchQuery$RideHistory([
    WatchOptions$Query$RideHistory? options,
  ]) => this.watchQuery(options ?? WatchOptions$Query$RideHistory());

  void writeQuery$RideHistory({
    required Query$RideHistory data,
    bool broadcast = true,
  }) => this.writeQuery(
    graphql.Request(
      operation: graphql.Operation(document: documentNodeQueryRideHistory),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Query$RideHistory? readQuery$RideHistory({bool optimistic = true}) {
    final result = this.readQuery(
      graphql.Request(
        operation: graphql.Operation(document: documentNodeQueryRideHistory),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Query$RideHistory.fromJson(result);
  }
}

class Variables$Mutation$SubmitIssue {
  factory Variables$Mutation$SubmitIssue({
    required Input$ComplaintInput input,
  }) => Variables$Mutation$SubmitIssue._({r'input': input});

  Variables$Mutation$SubmitIssue._(this._$data);

  factory Variables$Mutation$SubmitIssue.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$input = data['input'];
    result$data['input'] = Input$ComplaintInput.fromJson(
      (l$input as Map<String, dynamic>),
    );
    return Variables$Mutation$SubmitIssue._(result$data);
  }

  Map<String, dynamic> _$data;

  Input$ComplaintInput get input => (_$data['input'] as Input$ComplaintInput);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$input = input;
    result$data['input'] = l$input.toJson();
    return result$data;
  }

  CopyWith$Variables$Mutation$SubmitIssue<Variables$Mutation$SubmitIssue>
  get copyWith => CopyWith$Variables$Mutation$SubmitIssue(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Variables$Mutation$SubmitIssue ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$input = input;
    final lOther$input = other.input;
    if (l$input != lOther$input) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$input = input;
    return Object.hashAll([l$input]);
  }
}

abstract class CopyWith$Variables$Mutation$SubmitIssue<TRes> {
  factory CopyWith$Variables$Mutation$SubmitIssue(
    Variables$Mutation$SubmitIssue instance,
    TRes Function(Variables$Mutation$SubmitIssue) then,
  ) = _CopyWithImpl$Variables$Mutation$SubmitIssue;

  factory CopyWith$Variables$Mutation$SubmitIssue.stub(TRes res) =
      _CopyWithStubImpl$Variables$Mutation$SubmitIssue;

  TRes call({Input$ComplaintInput? input});
}

class _CopyWithImpl$Variables$Mutation$SubmitIssue<TRes>
    implements CopyWith$Variables$Mutation$SubmitIssue<TRes> {
  _CopyWithImpl$Variables$Mutation$SubmitIssue(this._instance, this._then);

  final Variables$Mutation$SubmitIssue _instance;

  final TRes Function(Variables$Mutation$SubmitIssue) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? input = _undefined}) => _then(
    Variables$Mutation$SubmitIssue._({
      ..._instance._$data,
      if (input != _undefined && input != null)
        'input': (input as Input$ComplaintInput),
    }),
  );
}

class _CopyWithStubImpl$Variables$Mutation$SubmitIssue<TRes>
    implements CopyWith$Variables$Mutation$SubmitIssue<TRes> {
  _CopyWithStubImpl$Variables$Mutation$SubmitIssue(this._res);

  TRes _res;

  call({Input$ComplaintInput? input}) => _res;
}

class Mutation$SubmitIssue {
  Mutation$SubmitIssue({
    required this.createComplaint,
    this.$__typename = 'Mutation',
  });

  factory Mutation$SubmitIssue.fromJson(Map<String, dynamic> json) {
    final l$createComplaint = json['createComplaint'];
    final l$$__typename = json['__typename'];
    return Mutation$SubmitIssue(
      createComplaint: Mutation$SubmitIssue$createComplaint.fromJson(
        (l$createComplaint as Map<String, dynamic>),
      ),
      $__typename: (l$$__typename as String),
    );
  }

  final Mutation$SubmitIssue$createComplaint createComplaint;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$createComplaint = createComplaint;
    _resultData['createComplaint'] = l$createComplaint.toJson();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$createComplaint = createComplaint;
    final l$$__typename = $__typename;
    return Object.hashAll([l$createComplaint, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$SubmitIssue || runtimeType != other.runtimeType) {
      return false;
    }
    final l$createComplaint = createComplaint;
    final lOther$createComplaint = other.createComplaint;
    if (l$createComplaint != lOther$createComplaint) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$SubmitIssue on Mutation$SubmitIssue {
  CopyWith$Mutation$SubmitIssue<Mutation$SubmitIssue> get copyWith =>
      CopyWith$Mutation$SubmitIssue(this, (i) => i);
}

abstract class CopyWith$Mutation$SubmitIssue<TRes> {
  factory CopyWith$Mutation$SubmitIssue(
    Mutation$SubmitIssue instance,
    TRes Function(Mutation$SubmitIssue) then,
  ) = _CopyWithImpl$Mutation$SubmitIssue;

  factory CopyWith$Mutation$SubmitIssue.stub(TRes res) =
      _CopyWithStubImpl$Mutation$SubmitIssue;

  TRes call({
    Mutation$SubmitIssue$createComplaint? createComplaint,
    String? $__typename,
  });
  CopyWith$Mutation$SubmitIssue$createComplaint<TRes> get createComplaint;
}

class _CopyWithImpl$Mutation$SubmitIssue<TRes>
    implements CopyWith$Mutation$SubmitIssue<TRes> {
  _CopyWithImpl$Mutation$SubmitIssue(this._instance, this._then);

  final Mutation$SubmitIssue _instance;

  final TRes Function(Mutation$SubmitIssue) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? createComplaint = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Mutation$SubmitIssue(
      createComplaint: createComplaint == _undefined || createComplaint == null
          ? _instance.createComplaint
          : (createComplaint as Mutation$SubmitIssue$createComplaint),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  CopyWith$Mutation$SubmitIssue$createComplaint<TRes> get createComplaint {
    final local$createComplaint = _instance.createComplaint;
    return CopyWith$Mutation$SubmitIssue$createComplaint(
      local$createComplaint,
      (e) => call(createComplaint: e),
    );
  }
}

class _CopyWithStubImpl$Mutation$SubmitIssue<TRes>
    implements CopyWith$Mutation$SubmitIssue<TRes> {
  _CopyWithStubImpl$Mutation$SubmitIssue(this._res);

  TRes _res;

  call({
    Mutation$SubmitIssue$createComplaint? createComplaint,
    String? $__typename,
  }) => _res;

  CopyWith$Mutation$SubmitIssue$createComplaint<TRes> get createComplaint =>
      CopyWith$Mutation$SubmitIssue$createComplaint.stub(_res);
}

const documentNodeMutationSubmitIssue = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.mutation,
      name: NameNode(value: 'SubmitIssue'),
      variableDefinitions: [
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'input')),
          type: NamedTypeNode(
            name: NameNode(value: 'ComplaintInput'),
            isNonNull: true,
          ),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
      ],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'createComplaint'),
            alias: null,
            arguments: [
              ArgumentNode(
                name: NameNode(value: 'input'),
                value: VariableNode(name: NameNode(value: 'input')),
              ),
            ],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FieldNode(
                  name: NameNode(value: 'id'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
  ],
);
Mutation$SubmitIssue _parserFn$Mutation$SubmitIssue(
  Map<String, dynamic> data,
) => Mutation$SubmitIssue.fromJson(data);
typedef OnMutationCompleted$Mutation$SubmitIssue =
    FutureOr<void> Function(Map<String, dynamic>?, Mutation$SubmitIssue?);

class Options$Mutation$SubmitIssue
    extends graphql.MutationOptions<Mutation$SubmitIssue> {
  Options$Mutation$SubmitIssue({
    String? operationName,
    required Variables$Mutation$SubmitIssue variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$SubmitIssue? typedOptimisticResult,
    graphql.Context? context,
    OnMutationCompleted$Mutation$SubmitIssue? onCompleted,
    graphql.OnMutationUpdate<Mutation$SubmitIssue>? update,
    graphql.OnError? onError,
  }) : onCompletedWithParsed = onCompleted,
       super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         onCompleted: onCompleted == null
             ? null
             : (data) => onCompleted(
                 data,
                 data == null ? null : _parserFn$Mutation$SubmitIssue(data),
               ),
         update: update,
         onError: onError,
         document: documentNodeMutationSubmitIssue,
         parserFn: _parserFn$Mutation$SubmitIssue,
       );

  final OnMutationCompleted$Mutation$SubmitIssue? onCompletedWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onCompleted == null
        ? super.properties
        : super.properties.where((property) => property != onCompleted),
    onCompletedWithParsed,
  ];
}

class WatchOptions$Mutation$SubmitIssue
    extends graphql.WatchQueryOptions<Mutation$SubmitIssue> {
  WatchOptions$Mutation$SubmitIssue({
    String? operationName,
    required Variables$Mutation$SubmitIssue variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$SubmitIssue? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeMutationSubmitIssue,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Mutation$SubmitIssue,
       );
}

extension ClientExtension$Mutation$SubmitIssue on graphql.GraphQLClient {
  Future<graphql.QueryResult<Mutation$SubmitIssue>> mutate$SubmitIssue(
    Options$Mutation$SubmitIssue options,
  ) async => await this.mutate(options);

  graphql.ObservableQuery<Mutation$SubmitIssue> watchMutation$SubmitIssue(
    WatchOptions$Mutation$SubmitIssue options,
  ) => this.watchMutation(options);
}

class Mutation$SubmitIssue$createComplaint {
  Mutation$SubmitIssue$createComplaint({
    required this.id,
    this.$__typename = 'Complaint',
  });

  factory Mutation$SubmitIssue$createComplaint.fromJson(
    Map<String, dynamic> json,
  ) {
    final l$id = json['id'];
    final l$$__typename = json['__typename'];
    return Mutation$SubmitIssue$createComplaint(
      id: (l$id as String),
      $__typename: (l$$__typename as String),
    );
  }

  final String id;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$id = id;
    _resultData['id'] = l$id;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$id = id;
    final l$$__typename = $__typename;
    return Object.hashAll([l$id, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$SubmitIssue$createComplaint ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$id = id;
    final lOther$id = other.id;
    if (l$id != lOther$id) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$SubmitIssue$createComplaint
    on Mutation$SubmitIssue$createComplaint {
  CopyWith$Mutation$SubmitIssue$createComplaint<
    Mutation$SubmitIssue$createComplaint
  >
  get copyWith => CopyWith$Mutation$SubmitIssue$createComplaint(this, (i) => i);
}

abstract class CopyWith$Mutation$SubmitIssue$createComplaint<TRes> {
  factory CopyWith$Mutation$SubmitIssue$createComplaint(
    Mutation$SubmitIssue$createComplaint instance,
    TRes Function(Mutation$SubmitIssue$createComplaint) then,
  ) = _CopyWithImpl$Mutation$SubmitIssue$createComplaint;

  factory CopyWith$Mutation$SubmitIssue$createComplaint.stub(TRes res) =
      _CopyWithStubImpl$Mutation$SubmitIssue$createComplaint;

  TRes call({String? id, String? $__typename});
}

class _CopyWithImpl$Mutation$SubmitIssue$createComplaint<TRes>
    implements CopyWith$Mutation$SubmitIssue$createComplaint<TRes> {
  _CopyWithImpl$Mutation$SubmitIssue$createComplaint(
    this._instance,
    this._then,
  );

  final Mutation$SubmitIssue$createComplaint _instance;

  final TRes Function(Mutation$SubmitIssue$createComplaint) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? id = _undefined, Object? $__typename = _undefined}) =>
      _then(
        Mutation$SubmitIssue$createComplaint(
          id: id == _undefined || id == null ? _instance.id : (id as String),
          $__typename: $__typename == _undefined || $__typename == null
              ? _instance.$__typename
              : ($__typename as String),
        ),
      );
}

class _CopyWithStubImpl$Mutation$SubmitIssue$createComplaint<TRes>
    implements CopyWith$Mutation$SubmitIssue$createComplaint<TRes> {
  _CopyWithStubImpl$Mutation$SubmitIssue$createComplaint(this._res);

  TRes _res;

  call({String? id, String? $__typename}) => _res;
}
