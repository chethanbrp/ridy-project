import '../fragments/favorite_driver.fragment.graphql.dart';
import '../fragments/profile.fragment.graphql.dart';
import '../schema.gql.dart';
import 'dart:async';
import 'package:gql/ast.dart';
import 'package:graphql/client.dart' as graphql;

class Query$Profile {
  Query$Profile({required this.me, this.$__typename = 'Query'});

  factory Query$Profile.fromJson(Map<String, dynamic> json) {
    final l$me = json['me'];
    final l$$__typename = json['__typename'];
    return Query$Profile(
      me: Fragment$Profile.fromJson((l$me as Map<String, dynamic>)),
      $__typename: (l$$__typename as String),
    );
  }

  final Fragment$Profile me;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$me = me;
    _resultData['me'] = l$me.toJson();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$me = me;
    final l$$__typename = $__typename;
    return Object.hashAll([l$me, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Query$Profile || runtimeType != other.runtimeType) {
      return false;
    }
    final l$me = me;
    final lOther$me = other.me;
    if (l$me != lOther$me) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Query$Profile on Query$Profile {
  CopyWith$Query$Profile<Query$Profile> get copyWith =>
      CopyWith$Query$Profile(this, (i) => i);
}

abstract class CopyWith$Query$Profile<TRes> {
  factory CopyWith$Query$Profile(
    Query$Profile instance,
    TRes Function(Query$Profile) then,
  ) = _CopyWithImpl$Query$Profile;

  factory CopyWith$Query$Profile.stub(TRes res) =
      _CopyWithStubImpl$Query$Profile;

  TRes call({Fragment$Profile? me, String? $__typename});
  CopyWith$Fragment$Profile<TRes> get me;
}

class _CopyWithImpl$Query$Profile<TRes>
    implements CopyWith$Query$Profile<TRes> {
  _CopyWithImpl$Query$Profile(this._instance, this._then);

  final Query$Profile _instance;

  final TRes Function(Query$Profile) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? me = _undefined, Object? $__typename = _undefined}) =>
      _then(
        Query$Profile(
          me: me == _undefined || me == null
              ? _instance.me
              : (me as Fragment$Profile),
          $__typename: $__typename == _undefined || $__typename == null
              ? _instance.$__typename
              : ($__typename as String),
        ),
      );

  CopyWith$Fragment$Profile<TRes> get me {
    final local$me = _instance.me;
    return CopyWith$Fragment$Profile(local$me, (e) => call(me: e));
  }
}

class _CopyWithStubImpl$Query$Profile<TRes>
    implements CopyWith$Query$Profile<TRes> {
  _CopyWithStubImpl$Query$Profile(this._res);

  TRes _res;

  call({Fragment$Profile? me, String? $__typename}) => _res;

  CopyWith$Fragment$Profile<TRes> get me =>
      CopyWith$Fragment$Profile.stub(_res);
}

const documentNodeQueryProfile = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.query,
      name: NameNode(value: 'Profile'),
      variableDefinitions: [],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'me'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FragmentSpreadNode(
                  name: NameNode(value: 'Profile'),
                  directives: [],
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
    fragmentDefinitionProfile,
  ],
);
Query$Profile _parserFn$Query$Profile(Map<String, dynamic> data) =>
    Query$Profile.fromJson(data);
typedef OnQueryComplete$Query$Profile =
    FutureOr<void> Function(Map<String, dynamic>?, Query$Profile?);

class Options$Query$Profile extends graphql.QueryOptions<Query$Profile> {
  Options$Query$Profile({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$Profile? typedOptimisticResult,
    Duration? pollInterval,
    graphql.Context? context,
    OnQueryComplete$Query$Profile? onComplete,
    graphql.OnQueryError? onError,
  }) : onCompleteWithParsed = onComplete,
       super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         pollInterval: pollInterval,
         context: context,
         onComplete: onComplete == null
             ? null
             : (data) => onComplete(
                 data,
                 data == null ? null : _parserFn$Query$Profile(data),
               ),
         onError: onError,
         document: documentNodeQueryProfile,
         parserFn: _parserFn$Query$Profile,
       );

  final OnQueryComplete$Query$Profile? onCompleteWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onComplete == null
        ? super.properties
        : super.properties.where((property) => property != onComplete),
    onCompleteWithParsed,
  ];
}

class WatchOptions$Query$Profile
    extends graphql.WatchQueryOptions<Query$Profile> {
  WatchOptions$Query$Profile({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$Profile? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeQueryProfile,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Query$Profile,
       );
}

class FetchMoreOptions$Query$Profile extends graphql.FetchMoreOptions {
  FetchMoreOptions$Query$Profile({required graphql.UpdateQuery updateQuery})
    : super(updateQuery: updateQuery, document: documentNodeQueryProfile);
}

extension ClientExtension$Query$Profile on graphql.GraphQLClient {
  Future<graphql.QueryResult<Query$Profile>> query$Profile([
    Options$Query$Profile? options,
  ]) async => await this.query(options ?? Options$Query$Profile());

  graphql.ObservableQuery<Query$Profile> watchQuery$Profile([
    WatchOptions$Query$Profile? options,
  ]) => this.watchQuery(options ?? WatchOptions$Query$Profile());

  void writeQuery$Profile({
    required Query$Profile data,
    bool broadcast = true,
  }) => this.writeQuery(
    graphql.Request(
      operation: graphql.Operation(document: documentNodeQueryProfile),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Query$Profile? readQuery$Profile({bool optimistic = true}) {
    final result = this.readQuery(
      graphql.Request(
        operation: graphql.Operation(document: documentNodeQueryProfile),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Query$Profile.fromJson(result);
  }
}

class Query$ProfileAggregations {
  Query$ProfileAggregations({
    required this.myStatistics,
    this.$__typename = 'Query',
  });

  factory Query$ProfileAggregations.fromJson(Map<String, dynamic> json) {
    final l$myStatistics = json['myStatistics'];
    final l$$__typename = json['__typename'];
    return Query$ProfileAggregations(
      myStatistics: Query$ProfileAggregations$myStatistics.fromJson(
        (l$myStatistics as Map<String, dynamic>),
      ),
      $__typename: (l$$__typename as String),
    );
  }

  final Query$ProfileAggregations$myStatistics myStatistics;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$myStatistics = myStatistics;
    _resultData['myStatistics'] = l$myStatistics.toJson();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$myStatistics = myStatistics;
    final l$$__typename = $__typename;
    return Object.hashAll([l$myStatistics, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Query$ProfileAggregations ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$myStatistics = myStatistics;
    final lOther$myStatistics = other.myStatistics;
    if (l$myStatistics != lOther$myStatistics) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Query$ProfileAggregations
    on Query$ProfileAggregations {
  CopyWith$Query$ProfileAggregations<Query$ProfileAggregations> get copyWith =>
      CopyWith$Query$ProfileAggregations(this, (i) => i);
}

abstract class CopyWith$Query$ProfileAggregations<TRes> {
  factory CopyWith$Query$ProfileAggregations(
    Query$ProfileAggregations instance,
    TRes Function(Query$ProfileAggregations) then,
  ) = _CopyWithImpl$Query$ProfileAggregations;

  factory CopyWith$Query$ProfileAggregations.stub(TRes res) =
      _CopyWithStubImpl$Query$ProfileAggregations;

  TRes call({
    Query$ProfileAggregations$myStatistics? myStatistics,
    String? $__typename,
  });
  CopyWith$Query$ProfileAggregations$myStatistics<TRes> get myStatistics;
}

class _CopyWithImpl$Query$ProfileAggregations<TRes>
    implements CopyWith$Query$ProfileAggregations<TRes> {
  _CopyWithImpl$Query$ProfileAggregations(this._instance, this._then);

  final Query$ProfileAggregations _instance;

  final TRes Function(Query$ProfileAggregations) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? myStatistics = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Query$ProfileAggregations(
      myStatistics: myStatistics == _undefined || myStatistics == null
          ? _instance.myStatistics
          : (myStatistics as Query$ProfileAggregations$myStatistics),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  CopyWith$Query$ProfileAggregations$myStatistics<TRes> get myStatistics {
    final local$myStatistics = _instance.myStatistics;
    return CopyWith$Query$ProfileAggregations$myStatistics(
      local$myStatistics,
      (e) => call(myStatistics: e),
    );
  }
}

class _CopyWithStubImpl$Query$ProfileAggregations<TRes>
    implements CopyWith$Query$ProfileAggregations<TRes> {
  _CopyWithStubImpl$Query$ProfileAggregations(this._res);

  TRes _res;

  call({
    Query$ProfileAggregations$myStatistics? myStatistics,
    String? $__typename,
  }) => _res;

  CopyWith$Query$ProfileAggregations$myStatistics<TRes> get myStatistics =>
      CopyWith$Query$ProfileAggregations$myStatistics.stub(_res);
}

const documentNodeQueryProfileAggregations = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.query,
      name: NameNode(value: 'ProfileAggregations'),
      variableDefinitions: [],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'myStatistics'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FieldNode(
                  name: NameNode(value: 'totalRides'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: 'canceledRides'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: 'completedRides'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: 'favoriteDriversCount'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: 'distanceTraveled'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
  ],
);
Query$ProfileAggregations _parserFn$Query$ProfileAggregations(
  Map<String, dynamic> data,
) => Query$ProfileAggregations.fromJson(data);
typedef OnQueryComplete$Query$ProfileAggregations =
    FutureOr<void> Function(Map<String, dynamic>?, Query$ProfileAggregations?);

class Options$Query$ProfileAggregations
    extends graphql.QueryOptions<Query$ProfileAggregations> {
  Options$Query$ProfileAggregations({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$ProfileAggregations? typedOptimisticResult,
    Duration? pollInterval,
    graphql.Context? context,
    OnQueryComplete$Query$ProfileAggregations? onComplete,
    graphql.OnQueryError? onError,
  }) : onCompleteWithParsed = onComplete,
       super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         pollInterval: pollInterval,
         context: context,
         onComplete: onComplete == null
             ? null
             : (data) => onComplete(
                 data,
                 data == null
                     ? null
                     : _parserFn$Query$ProfileAggregations(data),
               ),
         onError: onError,
         document: documentNodeQueryProfileAggregations,
         parserFn: _parserFn$Query$ProfileAggregations,
       );

  final OnQueryComplete$Query$ProfileAggregations? onCompleteWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onComplete == null
        ? super.properties
        : super.properties.where((property) => property != onComplete),
    onCompleteWithParsed,
  ];
}

class WatchOptions$Query$ProfileAggregations
    extends graphql.WatchQueryOptions<Query$ProfileAggregations> {
  WatchOptions$Query$ProfileAggregations({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$ProfileAggregations? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeQueryProfileAggregations,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Query$ProfileAggregations,
       );
}

class FetchMoreOptions$Query$ProfileAggregations
    extends graphql.FetchMoreOptions {
  FetchMoreOptions$Query$ProfileAggregations({
    required graphql.UpdateQuery updateQuery,
  }) : super(
         updateQuery: updateQuery,
         document: documentNodeQueryProfileAggregations,
       );
}

extension ClientExtension$Query$ProfileAggregations on graphql.GraphQLClient {
  Future<graphql.QueryResult<Query$ProfileAggregations>>
  query$ProfileAggregations([
    Options$Query$ProfileAggregations? options,
  ]) async => await this.query(options ?? Options$Query$ProfileAggregations());

  graphql.ObservableQuery<Query$ProfileAggregations>
  watchQuery$ProfileAggregations([
    WatchOptions$Query$ProfileAggregations? options,
  ]) => this.watchQuery(options ?? WatchOptions$Query$ProfileAggregations());

  void writeQuery$ProfileAggregations({
    required Query$ProfileAggregations data,
    bool broadcast = true,
  }) => this.writeQuery(
    graphql.Request(
      operation: graphql.Operation(
        document: documentNodeQueryProfileAggregations,
      ),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Query$ProfileAggregations? readQuery$ProfileAggregations({
    bool optimistic = true,
  }) {
    final result = this.readQuery(
      graphql.Request(
        operation: graphql.Operation(
          document: documentNodeQueryProfileAggregations,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Query$ProfileAggregations.fromJson(result);
  }
}

class Query$ProfileAggregations$myStatistics {
  Query$ProfileAggregations$myStatistics({
    required this.totalRides,
    required this.canceledRides,
    required this.completedRides,
    required this.favoriteDriversCount,
    required this.distanceTraveled,
    this.$__typename = 'RiderStatistics',
  });

  factory Query$ProfileAggregations$myStatistics.fromJson(
    Map<String, dynamic> json,
  ) {
    final l$totalRides = json['totalRides'];
    final l$canceledRides = json['canceledRides'];
    final l$completedRides = json['completedRides'];
    final l$favoriteDriversCount = json['favoriteDriversCount'];
    final l$distanceTraveled = json['distanceTraveled'];
    final l$$__typename = json['__typename'];
    return Query$ProfileAggregations$myStatistics(
      totalRides: (l$totalRides as int),
      canceledRides: (l$canceledRides as int),
      completedRides: (l$completedRides as int),
      favoriteDriversCount: (l$favoriteDriversCount as int),
      distanceTraveled: (l$distanceTraveled as int),
      $__typename: (l$$__typename as String),
    );
  }

  final int totalRides;

  final int canceledRides;

  final int completedRides;

  final int favoriteDriversCount;

  final int distanceTraveled;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$totalRides = totalRides;
    _resultData['totalRides'] = l$totalRides;
    final l$canceledRides = canceledRides;
    _resultData['canceledRides'] = l$canceledRides;
    final l$completedRides = completedRides;
    _resultData['completedRides'] = l$completedRides;
    final l$favoriteDriversCount = favoriteDriversCount;
    _resultData['favoriteDriversCount'] = l$favoriteDriversCount;
    final l$distanceTraveled = distanceTraveled;
    _resultData['distanceTraveled'] = l$distanceTraveled;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$totalRides = totalRides;
    final l$canceledRides = canceledRides;
    final l$completedRides = completedRides;
    final l$favoriteDriversCount = favoriteDriversCount;
    final l$distanceTraveled = distanceTraveled;
    final l$$__typename = $__typename;
    return Object.hashAll([
      l$totalRides,
      l$canceledRides,
      l$completedRides,
      l$favoriteDriversCount,
      l$distanceTraveled,
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Query$ProfileAggregations$myStatistics ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$totalRides = totalRides;
    final lOther$totalRides = other.totalRides;
    if (l$totalRides != lOther$totalRides) {
      return false;
    }
    final l$canceledRides = canceledRides;
    final lOther$canceledRides = other.canceledRides;
    if (l$canceledRides != lOther$canceledRides) {
      return false;
    }
    final l$completedRides = completedRides;
    final lOther$completedRides = other.completedRides;
    if (l$completedRides != lOther$completedRides) {
      return false;
    }
    final l$favoriteDriversCount = favoriteDriversCount;
    final lOther$favoriteDriversCount = other.favoriteDriversCount;
    if (l$favoriteDriversCount != lOther$favoriteDriversCount) {
      return false;
    }
    final l$distanceTraveled = distanceTraveled;
    final lOther$distanceTraveled = other.distanceTraveled;
    if (l$distanceTraveled != lOther$distanceTraveled) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Query$ProfileAggregations$myStatistics
    on Query$ProfileAggregations$myStatistics {
  CopyWith$Query$ProfileAggregations$myStatistics<
    Query$ProfileAggregations$myStatistics
  >
  get copyWith =>
      CopyWith$Query$ProfileAggregations$myStatistics(this, (i) => i);
}

abstract class CopyWith$Query$ProfileAggregations$myStatistics<TRes> {
  factory CopyWith$Query$ProfileAggregations$myStatistics(
    Query$ProfileAggregations$myStatistics instance,
    TRes Function(Query$ProfileAggregations$myStatistics) then,
  ) = _CopyWithImpl$Query$ProfileAggregations$myStatistics;

  factory CopyWith$Query$ProfileAggregations$myStatistics.stub(TRes res) =
      _CopyWithStubImpl$Query$ProfileAggregations$myStatistics;

  TRes call({
    int? totalRides,
    int? canceledRides,
    int? completedRides,
    int? favoriteDriversCount,
    int? distanceTraveled,
    String? $__typename,
  });
}

class _CopyWithImpl$Query$ProfileAggregations$myStatistics<TRes>
    implements CopyWith$Query$ProfileAggregations$myStatistics<TRes> {
  _CopyWithImpl$Query$ProfileAggregations$myStatistics(
    this._instance,
    this._then,
  );

  final Query$ProfileAggregations$myStatistics _instance;

  final TRes Function(Query$ProfileAggregations$myStatistics) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? totalRides = _undefined,
    Object? canceledRides = _undefined,
    Object? completedRides = _undefined,
    Object? favoriteDriversCount = _undefined,
    Object? distanceTraveled = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Query$ProfileAggregations$myStatistics(
      totalRides: totalRides == _undefined || totalRides == null
          ? _instance.totalRides
          : (totalRides as int),
      canceledRides: canceledRides == _undefined || canceledRides == null
          ? _instance.canceledRides
          : (canceledRides as int),
      completedRides: completedRides == _undefined || completedRides == null
          ? _instance.completedRides
          : (completedRides as int),
      favoriteDriversCount:
          favoriteDriversCount == _undefined || favoriteDriversCount == null
          ? _instance.favoriteDriversCount
          : (favoriteDriversCount as int),
      distanceTraveled:
          distanceTraveled == _undefined || distanceTraveled == null
          ? _instance.distanceTraveled
          : (distanceTraveled as int),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );
}

class _CopyWithStubImpl$Query$ProfileAggregations$myStatistics<TRes>
    implements CopyWith$Query$ProfileAggregations$myStatistics<TRes> {
  _CopyWithStubImpl$Query$ProfileAggregations$myStatistics(this._res);

  TRes _res;

  call({
    int? totalRides,
    int? canceledRides,
    int? completedRides,
    int? favoriteDriversCount,
    int? distanceTraveled,
    String? $__typename,
  }) => _res;
}

class Query$FavoriteDrivers {
  Query$FavoriteDrivers({
    required this.favoriteDrivers,
    this.$__typename = 'Query',
  });

  factory Query$FavoriteDrivers.fromJson(Map<String, dynamic> json) {
    final l$favoriteDrivers = json['favoriteDrivers'];
    final l$$__typename = json['__typename'];
    return Query$FavoriteDrivers(
      favoriteDrivers: (l$favoriteDrivers as List<dynamic>)
          .map(
            (e) =>
                Fragment$FavoriteDriver.fromJson((e as Map<String, dynamic>)),
          )
          .toList(),
      $__typename: (l$$__typename as String),
    );
  }

  final List<Fragment$FavoriteDriver> favoriteDrivers;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$favoriteDrivers = favoriteDrivers;
    _resultData['favoriteDrivers'] = l$favoriteDrivers
        .map((e) => e.toJson())
        .toList();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$favoriteDrivers = favoriteDrivers;
    final l$$__typename = $__typename;
    return Object.hashAll([
      Object.hashAll(l$favoriteDrivers.map((v) => v)),
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Query$FavoriteDrivers || runtimeType != other.runtimeType) {
      return false;
    }
    final l$favoriteDrivers = favoriteDrivers;
    final lOther$favoriteDrivers = other.favoriteDrivers;
    if (l$favoriteDrivers.length != lOther$favoriteDrivers.length) {
      return false;
    }
    for (int i = 0; i < l$favoriteDrivers.length; i++) {
      final l$favoriteDrivers$entry = l$favoriteDrivers[i];
      final lOther$favoriteDrivers$entry = lOther$favoriteDrivers[i];
      if (l$favoriteDrivers$entry != lOther$favoriteDrivers$entry) {
        return false;
      }
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Query$FavoriteDrivers on Query$FavoriteDrivers {
  CopyWith$Query$FavoriteDrivers<Query$FavoriteDrivers> get copyWith =>
      CopyWith$Query$FavoriteDrivers(this, (i) => i);
}

abstract class CopyWith$Query$FavoriteDrivers<TRes> {
  factory CopyWith$Query$FavoriteDrivers(
    Query$FavoriteDrivers instance,
    TRes Function(Query$FavoriteDrivers) then,
  ) = _CopyWithImpl$Query$FavoriteDrivers;

  factory CopyWith$Query$FavoriteDrivers.stub(TRes res) =
      _CopyWithStubImpl$Query$FavoriteDrivers;

  TRes call({
    List<Fragment$FavoriteDriver>? favoriteDrivers,
    String? $__typename,
  });
  TRes favoriteDrivers(
    Iterable<Fragment$FavoriteDriver> Function(
      Iterable<CopyWith$Fragment$FavoriteDriver<Fragment$FavoriteDriver>>,
    )
    _fn,
  );
}

class _CopyWithImpl$Query$FavoriteDrivers<TRes>
    implements CopyWith$Query$FavoriteDrivers<TRes> {
  _CopyWithImpl$Query$FavoriteDrivers(this._instance, this._then);

  final Query$FavoriteDrivers _instance;

  final TRes Function(Query$FavoriteDrivers) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? favoriteDrivers = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Query$FavoriteDrivers(
      favoriteDrivers: favoriteDrivers == _undefined || favoriteDrivers == null
          ? _instance.favoriteDrivers
          : (favoriteDrivers as List<Fragment$FavoriteDriver>),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  TRes favoriteDrivers(
    Iterable<Fragment$FavoriteDriver> Function(
      Iterable<CopyWith$Fragment$FavoriteDriver<Fragment$FavoriteDriver>>,
    )
    _fn,
  ) => call(
    favoriteDrivers: _fn(
      _instance.favoriteDrivers.map(
        (e) => CopyWith$Fragment$FavoriteDriver(e, (i) => i),
      ),
    ).toList(),
  );
}

class _CopyWithStubImpl$Query$FavoriteDrivers<TRes>
    implements CopyWith$Query$FavoriteDrivers<TRes> {
  _CopyWithStubImpl$Query$FavoriteDrivers(this._res);

  TRes _res;

  call({List<Fragment$FavoriteDriver>? favoriteDrivers, String? $__typename}) =>
      _res;

  favoriteDrivers(_fn) => _res;
}

const documentNodeQueryFavoriteDrivers = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.query,
      name: NameNode(value: 'FavoriteDrivers'),
      variableDefinitions: [],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'favoriteDrivers'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FragmentSpreadNode(
                  name: NameNode(value: 'FavoriteDriver'),
                  directives: [],
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
    fragmentDefinitionFavoriteDriver,
  ],
);
Query$FavoriteDrivers _parserFn$Query$FavoriteDrivers(
  Map<String, dynamic> data,
) => Query$FavoriteDrivers.fromJson(data);
typedef OnQueryComplete$Query$FavoriteDrivers =
    FutureOr<void> Function(Map<String, dynamic>?, Query$FavoriteDrivers?);

class Options$Query$FavoriteDrivers
    extends graphql.QueryOptions<Query$FavoriteDrivers> {
  Options$Query$FavoriteDrivers({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$FavoriteDrivers? typedOptimisticResult,
    Duration? pollInterval,
    graphql.Context? context,
    OnQueryComplete$Query$FavoriteDrivers? onComplete,
    graphql.OnQueryError? onError,
  }) : onCompleteWithParsed = onComplete,
       super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         pollInterval: pollInterval,
         context: context,
         onComplete: onComplete == null
             ? null
             : (data) => onComplete(
                 data,
                 data == null ? null : _parserFn$Query$FavoriteDrivers(data),
               ),
         onError: onError,
         document: documentNodeQueryFavoriteDrivers,
         parserFn: _parserFn$Query$FavoriteDrivers,
       );

  final OnQueryComplete$Query$FavoriteDrivers? onCompleteWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onComplete == null
        ? super.properties
        : super.properties.where((property) => property != onComplete),
    onCompleteWithParsed,
  ];
}

class WatchOptions$Query$FavoriteDrivers
    extends graphql.WatchQueryOptions<Query$FavoriteDrivers> {
  WatchOptions$Query$FavoriteDrivers({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$FavoriteDrivers? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeQueryFavoriteDrivers,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Query$FavoriteDrivers,
       );
}

class FetchMoreOptions$Query$FavoriteDrivers extends graphql.FetchMoreOptions {
  FetchMoreOptions$Query$FavoriteDrivers({
    required graphql.UpdateQuery updateQuery,
  }) : super(
         updateQuery: updateQuery,
         document: documentNodeQueryFavoriteDrivers,
       );
}

extension ClientExtension$Query$FavoriteDrivers on graphql.GraphQLClient {
  Future<graphql.QueryResult<Query$FavoriteDrivers>> query$FavoriteDrivers([
    Options$Query$FavoriteDrivers? options,
  ]) async => await this.query(options ?? Options$Query$FavoriteDrivers());

  graphql.ObservableQuery<Query$FavoriteDrivers> watchQuery$FavoriteDrivers([
    WatchOptions$Query$FavoriteDrivers? options,
  ]) => this.watchQuery(options ?? WatchOptions$Query$FavoriteDrivers());

  void writeQuery$FavoriteDrivers({
    required Query$FavoriteDrivers data,
    bool broadcast = true,
  }) => this.writeQuery(
    graphql.Request(
      operation: graphql.Operation(document: documentNodeQueryFavoriteDrivers),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Query$FavoriteDrivers? readQuery$FavoriteDrivers({bool optimistic = true}) {
    final result = this.readQuery(
      graphql.Request(
        operation: graphql.Operation(
          document: documentNodeQueryFavoriteDrivers,
        ),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Query$FavoriteDrivers.fromJson(result);
  }
}

class Variables$Mutation$UpdateProfile {
  factory Variables$Mutation$UpdateProfile({
    required Input$UpdateRiderInput input,
  }) => Variables$Mutation$UpdateProfile._({r'input': input});

  Variables$Mutation$UpdateProfile._(this._$data);

  factory Variables$Mutation$UpdateProfile.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$input = data['input'];
    result$data['input'] = Input$UpdateRiderInput.fromJson(
      (l$input as Map<String, dynamic>),
    );
    return Variables$Mutation$UpdateProfile._(result$data);
  }

  Map<String, dynamic> _$data;

  Input$UpdateRiderInput get input =>
      (_$data['input'] as Input$UpdateRiderInput);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$input = input;
    result$data['input'] = l$input.toJson();
    return result$data;
  }

  CopyWith$Variables$Mutation$UpdateProfile<Variables$Mutation$UpdateProfile>
  get copyWith => CopyWith$Variables$Mutation$UpdateProfile(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Variables$Mutation$UpdateProfile ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$input = input;
    final lOther$input = other.input;
    if (l$input != lOther$input) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$input = input;
    return Object.hashAll([l$input]);
  }
}

abstract class CopyWith$Variables$Mutation$UpdateProfile<TRes> {
  factory CopyWith$Variables$Mutation$UpdateProfile(
    Variables$Mutation$UpdateProfile instance,
    TRes Function(Variables$Mutation$UpdateProfile) then,
  ) = _CopyWithImpl$Variables$Mutation$UpdateProfile;

  factory CopyWith$Variables$Mutation$UpdateProfile.stub(TRes res) =
      _CopyWithStubImpl$Variables$Mutation$UpdateProfile;

  TRes call({Input$UpdateRiderInput? input});
}

class _CopyWithImpl$Variables$Mutation$UpdateProfile<TRes>
    implements CopyWith$Variables$Mutation$UpdateProfile<TRes> {
  _CopyWithImpl$Variables$Mutation$UpdateProfile(this._instance, this._then);

  final Variables$Mutation$UpdateProfile _instance;

  final TRes Function(Variables$Mutation$UpdateProfile) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? input = _undefined}) => _then(
    Variables$Mutation$UpdateProfile._({
      ..._instance._$data,
      if (input != _undefined && input != null)
        'input': (input as Input$UpdateRiderInput),
    }),
  );
}

class _CopyWithStubImpl$Variables$Mutation$UpdateProfile<TRes>
    implements CopyWith$Variables$Mutation$UpdateProfile<TRes> {
  _CopyWithStubImpl$Variables$Mutation$UpdateProfile(this._res);

  TRes _res;

  call({Input$UpdateRiderInput? input}) => _res;
}

class Mutation$UpdateProfile {
  Mutation$UpdateProfile({
    required this.updateProfile,
    this.$__typename = 'Mutation',
  });

  factory Mutation$UpdateProfile.fromJson(Map<String, dynamic> json) {
    final l$updateProfile = json['updateProfile'];
    final l$$__typename = json['__typename'];
    return Mutation$UpdateProfile(
      updateProfile: Fragment$Profile.fromJson(
        (l$updateProfile as Map<String, dynamic>),
      ),
      $__typename: (l$$__typename as String),
    );
  }

  final Fragment$Profile updateProfile;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$updateProfile = updateProfile;
    _resultData['updateProfile'] = l$updateProfile.toJson();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$updateProfile = updateProfile;
    final l$$__typename = $__typename;
    return Object.hashAll([l$updateProfile, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$UpdateProfile || runtimeType != other.runtimeType) {
      return false;
    }
    final l$updateProfile = updateProfile;
    final lOther$updateProfile = other.updateProfile;
    if (l$updateProfile != lOther$updateProfile) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$UpdateProfile on Mutation$UpdateProfile {
  CopyWith$Mutation$UpdateProfile<Mutation$UpdateProfile> get copyWith =>
      CopyWith$Mutation$UpdateProfile(this, (i) => i);
}

abstract class CopyWith$Mutation$UpdateProfile<TRes> {
  factory CopyWith$Mutation$UpdateProfile(
    Mutation$UpdateProfile instance,
    TRes Function(Mutation$UpdateProfile) then,
  ) = _CopyWithImpl$Mutation$UpdateProfile;

  factory CopyWith$Mutation$UpdateProfile.stub(TRes res) =
      _CopyWithStubImpl$Mutation$UpdateProfile;

  TRes call({Fragment$Profile? updateProfile, String? $__typename});
  CopyWith$Fragment$Profile<TRes> get updateProfile;
}

class _CopyWithImpl$Mutation$UpdateProfile<TRes>
    implements CopyWith$Mutation$UpdateProfile<TRes> {
  _CopyWithImpl$Mutation$UpdateProfile(this._instance, this._then);

  final Mutation$UpdateProfile _instance;

  final TRes Function(Mutation$UpdateProfile) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? updateProfile = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Mutation$UpdateProfile(
      updateProfile: updateProfile == _undefined || updateProfile == null
          ? _instance.updateProfile
          : (updateProfile as Fragment$Profile),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  CopyWith$Fragment$Profile<TRes> get updateProfile {
    final local$updateProfile = _instance.updateProfile;
    return CopyWith$Fragment$Profile(
      local$updateProfile,
      (e) => call(updateProfile: e),
    );
  }
}

class _CopyWithStubImpl$Mutation$UpdateProfile<TRes>
    implements CopyWith$Mutation$UpdateProfile<TRes> {
  _CopyWithStubImpl$Mutation$UpdateProfile(this._res);

  TRes _res;

  call({Fragment$Profile? updateProfile, String? $__typename}) => _res;

  CopyWith$Fragment$Profile<TRes> get updateProfile =>
      CopyWith$Fragment$Profile.stub(_res);
}

const documentNodeMutationUpdateProfile = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.mutation,
      name: NameNode(value: 'UpdateProfile'),
      variableDefinitions: [
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'input')),
          type: NamedTypeNode(
            name: NameNode(value: 'UpdateRiderInput'),
            isNonNull: true,
          ),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
      ],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'updateProfile'),
            alias: null,
            arguments: [
              ArgumentNode(
                name: NameNode(value: 'input'),
                value: VariableNode(name: NameNode(value: 'input')),
              ),
            ],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FragmentSpreadNode(
                  name: NameNode(value: 'Profile'),
                  directives: [],
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
    fragmentDefinitionProfile,
  ],
);
Mutation$UpdateProfile _parserFn$Mutation$UpdateProfile(
  Map<String, dynamic> data,
) => Mutation$UpdateProfile.fromJson(data);
typedef OnMutationCompleted$Mutation$UpdateProfile =
    FutureOr<void> Function(Map<String, dynamic>?, Mutation$UpdateProfile?);

class Options$Mutation$UpdateProfile
    extends graphql.MutationOptions<Mutation$UpdateProfile> {
  Options$Mutation$UpdateProfile({
    String? operationName,
    required Variables$Mutation$UpdateProfile variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$UpdateProfile? typedOptimisticResult,
    graphql.Context? context,
    OnMutationCompleted$Mutation$UpdateProfile? onCompleted,
    graphql.OnMutationUpdate<Mutation$UpdateProfile>? update,
    graphql.OnError? onError,
  }) : onCompletedWithParsed = onCompleted,
       super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         onCompleted: onCompleted == null
             ? null
             : (data) => onCompleted(
                 data,
                 data == null ? null : _parserFn$Mutation$UpdateProfile(data),
               ),
         update: update,
         onError: onError,
         document: documentNodeMutationUpdateProfile,
         parserFn: _parserFn$Mutation$UpdateProfile,
       );

  final OnMutationCompleted$Mutation$UpdateProfile? onCompletedWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onCompleted == null
        ? super.properties
        : super.properties.where((property) => property != onCompleted),
    onCompletedWithParsed,
  ];
}

class WatchOptions$Mutation$UpdateProfile
    extends graphql.WatchQueryOptions<Mutation$UpdateProfile> {
  WatchOptions$Mutation$UpdateProfile({
    String? operationName,
    required Variables$Mutation$UpdateProfile variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$UpdateProfile? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeMutationUpdateProfile,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Mutation$UpdateProfile,
       );
}

extension ClientExtension$Mutation$UpdateProfile on graphql.GraphQLClient {
  Future<graphql.QueryResult<Mutation$UpdateProfile>> mutate$UpdateProfile(
    Options$Mutation$UpdateProfile options,
  ) async => await this.mutate(options);

  graphql.ObservableQuery<Mutation$UpdateProfile> watchMutation$UpdateProfile(
    WatchOptions$Mutation$UpdateProfile options,
  ) => this.watchMutation(options);
}

class Variables$Mutation$DeleteFavoriteDriver {
  factory Variables$Mutation$DeleteFavoriteDriver({required String driverId}) =>
      Variables$Mutation$DeleteFavoriteDriver._({r'driverId': driverId});

  Variables$Mutation$DeleteFavoriteDriver._(this._$data);

  factory Variables$Mutation$DeleteFavoriteDriver.fromJson(
    Map<String, dynamic> data,
  ) {
    final result$data = <String, dynamic>{};
    final l$driverId = data['driverId'];
    result$data['driverId'] = (l$driverId as String);
    return Variables$Mutation$DeleteFavoriteDriver._(result$data);
  }

  Map<String, dynamic> _$data;

  String get driverId => (_$data['driverId'] as String);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$driverId = driverId;
    result$data['driverId'] = l$driverId;
    return result$data;
  }

  CopyWith$Variables$Mutation$DeleteFavoriteDriver<
    Variables$Mutation$DeleteFavoriteDriver
  >
  get copyWith =>
      CopyWith$Variables$Mutation$DeleteFavoriteDriver(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Variables$Mutation$DeleteFavoriteDriver ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$driverId = driverId;
    final lOther$driverId = other.driverId;
    if (l$driverId != lOther$driverId) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$driverId = driverId;
    return Object.hashAll([l$driverId]);
  }
}

abstract class CopyWith$Variables$Mutation$DeleteFavoriteDriver<TRes> {
  factory CopyWith$Variables$Mutation$DeleteFavoriteDriver(
    Variables$Mutation$DeleteFavoriteDriver instance,
    TRes Function(Variables$Mutation$DeleteFavoriteDriver) then,
  ) = _CopyWithImpl$Variables$Mutation$DeleteFavoriteDriver;

  factory CopyWith$Variables$Mutation$DeleteFavoriteDriver.stub(TRes res) =
      _CopyWithStubImpl$Variables$Mutation$DeleteFavoriteDriver;

  TRes call({String? driverId});
}

class _CopyWithImpl$Variables$Mutation$DeleteFavoriteDriver<TRes>
    implements CopyWith$Variables$Mutation$DeleteFavoriteDriver<TRes> {
  _CopyWithImpl$Variables$Mutation$DeleteFavoriteDriver(
    this._instance,
    this._then,
  );

  final Variables$Mutation$DeleteFavoriteDriver _instance;

  final TRes Function(Variables$Mutation$DeleteFavoriteDriver) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? driverId = _undefined}) => _then(
    Variables$Mutation$DeleteFavoriteDriver._({
      ..._instance._$data,
      if (driverId != _undefined && driverId != null)
        'driverId': (driverId as String),
    }),
  );
}

class _CopyWithStubImpl$Variables$Mutation$DeleteFavoriteDriver<TRes>
    implements CopyWith$Variables$Mutation$DeleteFavoriteDriver<TRes> {
  _CopyWithStubImpl$Variables$Mutation$DeleteFavoriteDriver(this._res);

  TRes _res;

  call({String? driverId}) => _res;
}

class Mutation$DeleteFavoriteDriver {
  Mutation$DeleteFavoriteDriver({
    required this.deleteFavoriteDriver,
    this.$__typename = 'Mutation',
  });

  factory Mutation$DeleteFavoriteDriver.fromJson(Map<String, dynamic> json) {
    final l$deleteFavoriteDriver = json['deleteFavoriteDriver'];
    final l$$__typename = json['__typename'];
    return Mutation$DeleteFavoriteDriver(
      deleteFavoriteDriver: (l$deleteFavoriteDriver as bool),
      $__typename: (l$$__typename as String),
    );
  }

  final bool deleteFavoriteDriver;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$deleteFavoriteDriver = deleteFavoriteDriver;
    _resultData['deleteFavoriteDriver'] = l$deleteFavoriteDriver;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$deleteFavoriteDriver = deleteFavoriteDriver;
    final l$$__typename = $__typename;
    return Object.hashAll([l$deleteFavoriteDriver, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$DeleteFavoriteDriver ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$deleteFavoriteDriver = deleteFavoriteDriver;
    final lOther$deleteFavoriteDriver = other.deleteFavoriteDriver;
    if (l$deleteFavoriteDriver != lOther$deleteFavoriteDriver) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$DeleteFavoriteDriver
    on Mutation$DeleteFavoriteDriver {
  CopyWith$Mutation$DeleteFavoriteDriver<Mutation$DeleteFavoriteDriver>
  get copyWith => CopyWith$Mutation$DeleteFavoriteDriver(this, (i) => i);
}

abstract class CopyWith$Mutation$DeleteFavoriteDriver<TRes> {
  factory CopyWith$Mutation$DeleteFavoriteDriver(
    Mutation$DeleteFavoriteDriver instance,
    TRes Function(Mutation$DeleteFavoriteDriver) then,
  ) = _CopyWithImpl$Mutation$DeleteFavoriteDriver;

  factory CopyWith$Mutation$DeleteFavoriteDriver.stub(TRes res) =
      _CopyWithStubImpl$Mutation$DeleteFavoriteDriver;

  TRes call({bool? deleteFavoriteDriver, String? $__typename});
}

class _CopyWithImpl$Mutation$DeleteFavoriteDriver<TRes>
    implements CopyWith$Mutation$DeleteFavoriteDriver<TRes> {
  _CopyWithImpl$Mutation$DeleteFavoriteDriver(this._instance, this._then);

  final Mutation$DeleteFavoriteDriver _instance;

  final TRes Function(Mutation$DeleteFavoriteDriver) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? deleteFavoriteDriver = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Mutation$DeleteFavoriteDriver(
      deleteFavoriteDriver:
          deleteFavoriteDriver == _undefined || deleteFavoriteDriver == null
          ? _instance.deleteFavoriteDriver
          : (deleteFavoriteDriver as bool),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );
}

class _CopyWithStubImpl$Mutation$DeleteFavoriteDriver<TRes>
    implements CopyWith$Mutation$DeleteFavoriteDriver<TRes> {
  _CopyWithStubImpl$Mutation$DeleteFavoriteDriver(this._res);

  TRes _res;

  call({bool? deleteFavoriteDriver, String? $__typename}) => _res;
}

const documentNodeMutationDeleteFavoriteDriver = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.mutation,
      name: NameNode(value: 'DeleteFavoriteDriver'),
      variableDefinitions: [
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'driverId')),
          type: NamedTypeNode(name: NameNode(value: 'ID'), isNonNull: true),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
      ],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'deleteFavoriteDriver'),
            alias: null,
            arguments: [
              ArgumentNode(
                name: NameNode(value: 'driverId'),
                value: VariableNode(name: NameNode(value: 'driverId')),
              ),
            ],
            directives: [],
            selectionSet: null,
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
  ],
);
Mutation$DeleteFavoriteDriver _parserFn$Mutation$DeleteFavoriteDriver(
  Map<String, dynamic> data,
) => Mutation$DeleteFavoriteDriver.fromJson(data);
typedef OnMutationCompleted$Mutation$DeleteFavoriteDriver =
    FutureOr<void> Function(
      Map<String, dynamic>?,
      Mutation$DeleteFavoriteDriver?,
    );

class Options$Mutation$DeleteFavoriteDriver
    extends graphql.MutationOptions<Mutation$DeleteFavoriteDriver> {
  Options$Mutation$DeleteFavoriteDriver({
    String? operationName,
    required Variables$Mutation$DeleteFavoriteDriver variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$DeleteFavoriteDriver? typedOptimisticResult,
    graphql.Context? context,
    OnMutationCompleted$Mutation$DeleteFavoriteDriver? onCompleted,
    graphql.OnMutationUpdate<Mutation$DeleteFavoriteDriver>? update,
    graphql.OnError? onError,
  }) : onCompletedWithParsed = onCompleted,
       super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         onCompleted: onCompleted == null
             ? null
             : (data) => onCompleted(
                 data,
                 data == null
                     ? null
                     : _parserFn$Mutation$DeleteFavoriteDriver(data),
               ),
         update: update,
         onError: onError,
         document: documentNodeMutationDeleteFavoriteDriver,
         parserFn: _parserFn$Mutation$DeleteFavoriteDriver,
       );

  final OnMutationCompleted$Mutation$DeleteFavoriteDriver?
  onCompletedWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onCompleted == null
        ? super.properties
        : super.properties.where((property) => property != onCompleted),
    onCompletedWithParsed,
  ];
}

class WatchOptions$Mutation$DeleteFavoriteDriver
    extends graphql.WatchQueryOptions<Mutation$DeleteFavoriteDriver> {
  WatchOptions$Mutation$DeleteFavoriteDriver({
    String? operationName,
    required Variables$Mutation$DeleteFavoriteDriver variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$DeleteFavoriteDriver? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeMutationDeleteFavoriteDriver,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Mutation$DeleteFavoriteDriver,
       );
}

extension ClientExtension$Mutation$DeleteFavoriteDriver
    on graphql.GraphQLClient {
  Future<graphql.QueryResult<Mutation$DeleteFavoriteDriver>>
  mutate$DeleteFavoriteDriver(
    Options$Mutation$DeleteFavoriteDriver options,
  ) async => await this.mutate(options);

  graphql.ObservableQuery<Mutation$DeleteFavoriteDriver>
  watchMutation$DeleteFavoriteDriver(
    WatchOptions$Mutation$DeleteFavoriteDriver options,
  ) => this.watchMutation(options);
}

class Mutation$DeleteAccount {
  Mutation$DeleteAccount({
    required this.deleteUser,
    this.$__typename = 'Mutation',
  });

  factory Mutation$DeleteAccount.fromJson(Map<String, dynamic> json) {
    final l$deleteUser = json['deleteUser'];
    final l$$__typename = json['__typename'];
    return Mutation$DeleteAccount(
      deleteUser: Mutation$DeleteAccount$deleteUser.fromJson(
        (l$deleteUser as Map<String, dynamic>),
      ),
      $__typename: (l$$__typename as String),
    );
  }

  final Mutation$DeleteAccount$deleteUser deleteUser;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$deleteUser = deleteUser;
    _resultData['deleteUser'] = l$deleteUser.toJson();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$deleteUser = deleteUser;
    final l$$__typename = $__typename;
    return Object.hashAll([l$deleteUser, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$DeleteAccount || runtimeType != other.runtimeType) {
      return false;
    }
    final l$deleteUser = deleteUser;
    final lOther$deleteUser = other.deleteUser;
    if (l$deleteUser != lOther$deleteUser) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$DeleteAccount on Mutation$DeleteAccount {
  CopyWith$Mutation$DeleteAccount<Mutation$DeleteAccount> get copyWith =>
      CopyWith$Mutation$DeleteAccount(this, (i) => i);
}

abstract class CopyWith$Mutation$DeleteAccount<TRes> {
  factory CopyWith$Mutation$DeleteAccount(
    Mutation$DeleteAccount instance,
    TRes Function(Mutation$DeleteAccount) then,
  ) = _CopyWithImpl$Mutation$DeleteAccount;

  factory CopyWith$Mutation$DeleteAccount.stub(TRes res) =
      _CopyWithStubImpl$Mutation$DeleteAccount;

  TRes call({
    Mutation$DeleteAccount$deleteUser? deleteUser,
    String? $__typename,
  });
  CopyWith$Mutation$DeleteAccount$deleteUser<TRes> get deleteUser;
}

class _CopyWithImpl$Mutation$DeleteAccount<TRes>
    implements CopyWith$Mutation$DeleteAccount<TRes> {
  _CopyWithImpl$Mutation$DeleteAccount(this._instance, this._then);

  final Mutation$DeleteAccount _instance;

  final TRes Function(Mutation$DeleteAccount) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? deleteUser = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Mutation$DeleteAccount(
      deleteUser: deleteUser == _undefined || deleteUser == null
          ? _instance.deleteUser
          : (deleteUser as Mutation$DeleteAccount$deleteUser),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  CopyWith$Mutation$DeleteAccount$deleteUser<TRes> get deleteUser {
    final local$deleteUser = _instance.deleteUser;
    return CopyWith$Mutation$DeleteAccount$deleteUser(
      local$deleteUser,
      (e) => call(deleteUser: e),
    );
  }
}

class _CopyWithStubImpl$Mutation$DeleteAccount<TRes>
    implements CopyWith$Mutation$DeleteAccount<TRes> {
  _CopyWithStubImpl$Mutation$DeleteAccount(this._res);

  TRes _res;

  call({Mutation$DeleteAccount$deleteUser? deleteUser, String? $__typename}) =>
      _res;

  CopyWith$Mutation$DeleteAccount$deleteUser<TRes> get deleteUser =>
      CopyWith$Mutation$DeleteAccount$deleteUser.stub(_res);
}

const documentNodeMutationDeleteAccount = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.mutation,
      name: NameNode(value: 'DeleteAccount'),
      variableDefinitions: [],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'deleteUser'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FieldNode(
                  name: NameNode(value: 'id'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
  ],
);
Mutation$DeleteAccount _parserFn$Mutation$DeleteAccount(
  Map<String, dynamic> data,
) => Mutation$DeleteAccount.fromJson(data);
typedef OnMutationCompleted$Mutation$DeleteAccount =
    FutureOr<void> Function(Map<String, dynamic>?, Mutation$DeleteAccount?);

class Options$Mutation$DeleteAccount
    extends graphql.MutationOptions<Mutation$DeleteAccount> {
  Options$Mutation$DeleteAccount({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$DeleteAccount? typedOptimisticResult,
    graphql.Context? context,
    OnMutationCompleted$Mutation$DeleteAccount? onCompleted,
    graphql.OnMutationUpdate<Mutation$DeleteAccount>? update,
    graphql.OnError? onError,
  }) : onCompletedWithParsed = onCompleted,
       super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         onCompleted: onCompleted == null
             ? null
             : (data) => onCompleted(
                 data,
                 data == null ? null : _parserFn$Mutation$DeleteAccount(data),
               ),
         update: update,
         onError: onError,
         document: documentNodeMutationDeleteAccount,
         parserFn: _parserFn$Mutation$DeleteAccount,
       );

  final OnMutationCompleted$Mutation$DeleteAccount? onCompletedWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onCompleted == null
        ? super.properties
        : super.properties.where((property) => property != onCompleted),
    onCompletedWithParsed,
  ];
}

class WatchOptions$Mutation$DeleteAccount
    extends graphql.WatchQueryOptions<Mutation$DeleteAccount> {
  WatchOptions$Mutation$DeleteAccount({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$DeleteAccount? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeMutationDeleteAccount,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Mutation$DeleteAccount,
       );
}

extension ClientExtension$Mutation$DeleteAccount on graphql.GraphQLClient {
  Future<graphql.QueryResult<Mutation$DeleteAccount>> mutate$DeleteAccount([
    Options$Mutation$DeleteAccount? options,
  ]) async => await this.mutate(options ?? Options$Mutation$DeleteAccount());

  graphql.ObservableQuery<Mutation$DeleteAccount> watchMutation$DeleteAccount([
    WatchOptions$Mutation$DeleteAccount? options,
  ]) => this.watchMutation(options ?? WatchOptions$Mutation$DeleteAccount());
}

class Mutation$DeleteAccount$deleteUser {
  Mutation$DeleteAccount$deleteUser({
    required this.id,
    this.$__typename = 'Rider',
  });

  factory Mutation$DeleteAccount$deleteUser.fromJson(
    Map<String, dynamic> json,
  ) {
    final l$id = json['id'];
    final l$$__typename = json['__typename'];
    return Mutation$DeleteAccount$deleteUser(
      id: (l$id as String),
      $__typename: (l$$__typename as String),
    );
  }

  final String id;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$id = id;
    _resultData['id'] = l$id;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$id = id;
    final l$$__typename = $__typename;
    return Object.hashAll([l$id, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$DeleteAccount$deleteUser ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$id = id;
    final lOther$id = other.id;
    if (l$id != lOther$id) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$DeleteAccount$deleteUser
    on Mutation$DeleteAccount$deleteUser {
  CopyWith$Mutation$DeleteAccount$deleteUser<Mutation$DeleteAccount$deleteUser>
  get copyWith => CopyWith$Mutation$DeleteAccount$deleteUser(this, (i) => i);
}

abstract class CopyWith$Mutation$DeleteAccount$deleteUser<TRes> {
  factory CopyWith$Mutation$DeleteAccount$deleteUser(
    Mutation$DeleteAccount$deleteUser instance,
    TRes Function(Mutation$DeleteAccount$deleteUser) then,
  ) = _CopyWithImpl$Mutation$DeleteAccount$deleteUser;

  factory CopyWith$Mutation$DeleteAccount$deleteUser.stub(TRes res) =
      _CopyWithStubImpl$Mutation$DeleteAccount$deleteUser;

  TRes call({String? id, String? $__typename});
}

class _CopyWithImpl$Mutation$DeleteAccount$deleteUser<TRes>
    implements CopyWith$Mutation$DeleteAccount$deleteUser<TRes> {
  _CopyWithImpl$Mutation$DeleteAccount$deleteUser(this._instance, this._then);

  final Mutation$DeleteAccount$deleteUser _instance;

  final TRes Function(Mutation$DeleteAccount$deleteUser) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? id = _undefined, Object? $__typename = _undefined}) =>
      _then(
        Mutation$DeleteAccount$deleteUser(
          id: id == _undefined || id == null ? _instance.id : (id as String),
          $__typename: $__typename == _undefined || $__typename == null
              ? _instance.$__typename
              : ($__typename as String),
        ),
      );
}

class _CopyWithStubImpl$Mutation$DeleteAccount$deleteUser<TRes>
    implements CopyWith$Mutation$DeleteAccount$deleteUser<TRes> {
  _CopyWithStubImpl$Mutation$DeleteAccount$deleteUser(this._res);

  TRes _res;

  call({String? id, String? $__typename}) => _res;
}
