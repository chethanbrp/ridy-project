import '../fragments/active_order.fragment.graphql.dart';
import '../fragments/cancel_reaons.fragment.graphql.dart';
import '../fragments/chat_message.fragment.graphql.dart';
import '../fragments/driver.fragment.graphql.dart';
import '../fragments/payment_method.fragment.graphql.dart';
import '../fragments/phone_number.fragment.graphql.dart';
import '../fragments/point.fragment.graphql.dart';
import '../schema.gql.dart';
import 'dart:async';
import 'package:gql/ast.dart';
import 'package:graphql/client.dart' as graphql;

class Query$ActiveOrders {
  Query$ActiveOrders({required this.activeOrders, this.$__typename = 'Query'});

  factory Query$ActiveOrders.fromJson(Map<String, dynamic> json) {
    final l$activeOrders = json['activeOrders'];
    final l$$__typename = json['__typename'];
    return Query$ActiveOrders(
      activeOrders: (l$activeOrders as List<dynamic>)
          .map(
            (e) => Fragment$ActiveOrder.fromJson((e as Map<String, dynamic>)),
          )
          .toList(),
      $__typename: (l$$__typename as String),
    );
  }

  final List<Fragment$ActiveOrder> activeOrders;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$activeOrders = activeOrders;
    _resultData['activeOrders'] = l$activeOrders
        .map((e) => e.toJson())
        .toList();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$activeOrders = activeOrders;
    final l$$__typename = $__typename;
    return Object.hashAll([
      Object.hashAll(l$activeOrders.map((v) => v)),
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Query$ActiveOrders || runtimeType != other.runtimeType) {
      return false;
    }
    final l$activeOrders = activeOrders;
    final lOther$activeOrders = other.activeOrders;
    if (l$activeOrders.length != lOther$activeOrders.length) {
      return false;
    }
    for (int i = 0; i < l$activeOrders.length; i++) {
      final l$activeOrders$entry = l$activeOrders[i];
      final lOther$activeOrders$entry = lOther$activeOrders[i];
      if (l$activeOrders$entry != lOther$activeOrders$entry) {
        return false;
      }
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Query$ActiveOrders on Query$ActiveOrders {
  CopyWith$Query$ActiveOrders<Query$ActiveOrders> get copyWith =>
      CopyWith$Query$ActiveOrders(this, (i) => i);
}

abstract class CopyWith$Query$ActiveOrders<TRes> {
  factory CopyWith$Query$ActiveOrders(
    Query$ActiveOrders instance,
    TRes Function(Query$ActiveOrders) then,
  ) = _CopyWithImpl$Query$ActiveOrders;

  factory CopyWith$Query$ActiveOrders.stub(TRes res) =
      _CopyWithStubImpl$Query$ActiveOrders;

  TRes call({List<Fragment$ActiveOrder>? activeOrders, String? $__typename});
  TRes activeOrders(
    Iterable<Fragment$ActiveOrder> Function(
      Iterable<CopyWith$Fragment$ActiveOrder<Fragment$ActiveOrder>>,
    )
    _fn,
  );
}

class _CopyWithImpl$Query$ActiveOrders<TRes>
    implements CopyWith$Query$ActiveOrders<TRes> {
  _CopyWithImpl$Query$ActiveOrders(this._instance, this._then);

  final Query$ActiveOrders _instance;

  final TRes Function(Query$ActiveOrders) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? activeOrders = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Query$ActiveOrders(
      activeOrders: activeOrders == _undefined || activeOrders == null
          ? _instance.activeOrders
          : (activeOrders as List<Fragment$ActiveOrder>),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  TRes activeOrders(
    Iterable<Fragment$ActiveOrder> Function(
      Iterable<CopyWith$Fragment$ActiveOrder<Fragment$ActiveOrder>>,
    )
    _fn,
  ) => call(
    activeOrders: _fn(
      _instance.activeOrders.map(
        (e) => CopyWith$Fragment$ActiveOrder(e, (i) => i),
      ),
    ).toList(),
  );
}

class _CopyWithStubImpl$Query$ActiveOrders<TRes>
    implements CopyWith$Query$ActiveOrders<TRes> {
  _CopyWithStubImpl$Query$ActiveOrders(this._res);

  TRes _res;

  call({List<Fragment$ActiveOrder>? activeOrders, String? $__typename}) => _res;

  activeOrders(_fn) => _res;
}

const documentNodeQueryActiveOrders = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.query,
      name: NameNode(value: 'ActiveOrders'),
      variableDefinitions: [],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'activeOrders'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FragmentSpreadNode(
                  name: NameNode(value: 'ActiveOrder'),
                  directives: [],
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
    fragmentDefinitionActiveOrder,
    fragmentDefinitionCoordinate,
    fragmentDefinitionWaypoint,
    fragmentDefinitionRideWaypoint,
    fragmentDefinitionDeliveryWaypoint,
    fragmentDefinitionPhoneNumber,
    fragmentDefinitionShopWaypoint,
    fragmentDefinitionActiveOrderDriver,
    fragmentDefinitionPaymentMethod,
    fragmentDefinitionSavedAccount,
    fragmentDefinitionOnlinePaymentMethod,
    fragmentDefinitionChatMessage,
  ],
);
Query$ActiveOrders _parserFn$Query$ActiveOrders(Map<String, dynamic> data) =>
    Query$ActiveOrders.fromJson(data);
typedef OnQueryComplete$Query$ActiveOrders =
    FutureOr<void> Function(Map<String, dynamic>?, Query$ActiveOrders?);

class Options$Query$ActiveOrders
    extends graphql.QueryOptions<Query$ActiveOrders> {
  Options$Query$ActiveOrders({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$ActiveOrders? typedOptimisticResult,
    Duration? pollInterval,
    graphql.Context? context,
    OnQueryComplete$Query$ActiveOrders? onComplete,
    graphql.OnQueryError? onError,
  }) : onCompleteWithParsed = onComplete,
       super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         pollInterval: pollInterval,
         context: context,
         onComplete: onComplete == null
             ? null
             : (data) => onComplete(
                 data,
                 data == null ? null : _parserFn$Query$ActiveOrders(data),
               ),
         onError: onError,
         document: documentNodeQueryActiveOrders,
         parserFn: _parserFn$Query$ActiveOrders,
       );

  final OnQueryComplete$Query$ActiveOrders? onCompleteWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onComplete == null
        ? super.properties
        : super.properties.where((property) => property != onComplete),
    onCompleteWithParsed,
  ];
}

class WatchOptions$Query$ActiveOrders
    extends graphql.WatchQueryOptions<Query$ActiveOrders> {
  WatchOptions$Query$ActiveOrders({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$ActiveOrders? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeQueryActiveOrders,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Query$ActiveOrders,
       );
}

class FetchMoreOptions$Query$ActiveOrders extends graphql.FetchMoreOptions {
  FetchMoreOptions$Query$ActiveOrders({
    required graphql.UpdateQuery updateQuery,
  }) : super(updateQuery: updateQuery, document: documentNodeQueryActiveOrders);
}

extension ClientExtension$Query$ActiveOrders on graphql.GraphQLClient {
  Future<graphql.QueryResult<Query$ActiveOrders>> query$ActiveOrders([
    Options$Query$ActiveOrders? options,
  ]) async => await this.query(options ?? Options$Query$ActiveOrders());

  graphql.ObservableQuery<Query$ActiveOrders> watchQuery$ActiveOrders([
    WatchOptions$Query$ActiveOrders? options,
  ]) => this.watchQuery(options ?? WatchOptions$Query$ActiveOrders());

  void writeQuery$ActiveOrders({
    required Query$ActiveOrders data,
    bool broadcast = true,
  }) => this.writeQuery(
    graphql.Request(
      operation: graphql.Operation(document: documentNodeQueryActiveOrders),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Query$ActiveOrders? readQuery$ActiveOrders({bool optimistic = true}) {
    final result = this.readQuery(
      graphql.Request(
        operation: graphql.Operation(document: documentNodeQueryActiveOrders),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Query$ActiveOrders.fromJson(result);
  }
}

class Variables$Mutation$CreateOrder {
  factory Variables$Mutation$CreateOrder({
    required Input$CreateOrderInput input,
  }) => Variables$Mutation$CreateOrder._({r'input': input});

  Variables$Mutation$CreateOrder._(this._$data);

  factory Variables$Mutation$CreateOrder.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$input = data['input'];
    result$data['input'] = Input$CreateOrderInput.fromJson(
      (l$input as Map<String, dynamic>),
    );
    return Variables$Mutation$CreateOrder._(result$data);
  }

  Map<String, dynamic> _$data;

  Input$CreateOrderInput get input =>
      (_$data['input'] as Input$CreateOrderInput);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$input = input;
    result$data['input'] = l$input.toJson();
    return result$data;
  }

  CopyWith$Variables$Mutation$CreateOrder<Variables$Mutation$CreateOrder>
  get copyWith => CopyWith$Variables$Mutation$CreateOrder(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Variables$Mutation$CreateOrder ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$input = input;
    final lOther$input = other.input;
    if (l$input != lOther$input) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$input = input;
    return Object.hashAll([l$input]);
  }
}

abstract class CopyWith$Variables$Mutation$CreateOrder<TRes> {
  factory CopyWith$Variables$Mutation$CreateOrder(
    Variables$Mutation$CreateOrder instance,
    TRes Function(Variables$Mutation$CreateOrder) then,
  ) = _CopyWithImpl$Variables$Mutation$CreateOrder;

  factory CopyWith$Variables$Mutation$CreateOrder.stub(TRes res) =
      _CopyWithStubImpl$Variables$Mutation$CreateOrder;

  TRes call({Input$CreateOrderInput? input});
}

class _CopyWithImpl$Variables$Mutation$CreateOrder<TRes>
    implements CopyWith$Variables$Mutation$CreateOrder<TRes> {
  _CopyWithImpl$Variables$Mutation$CreateOrder(this._instance, this._then);

  final Variables$Mutation$CreateOrder _instance;

  final TRes Function(Variables$Mutation$CreateOrder) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? input = _undefined}) => _then(
    Variables$Mutation$CreateOrder._({
      ..._instance._$data,
      if (input != _undefined && input != null)
        'input': (input as Input$CreateOrderInput),
    }),
  );
}

class _CopyWithStubImpl$Variables$Mutation$CreateOrder<TRes>
    implements CopyWith$Variables$Mutation$CreateOrder<TRes> {
  _CopyWithStubImpl$Variables$Mutation$CreateOrder(this._res);

  TRes _res;

  call({Input$CreateOrderInput? input}) => _res;
}

class Mutation$CreateOrder {
  Mutation$CreateOrder({
    required this.createOrder,
    this.$__typename = 'Mutation',
  });

  factory Mutation$CreateOrder.fromJson(Map<String, dynamic> json) {
    final l$createOrder = json['createOrder'];
    final l$$__typename = json['__typename'];
    return Mutation$CreateOrder(
      createOrder: (l$createOrder as List<dynamic>)
          .map(
            (e) => Fragment$ActiveOrder.fromJson((e as Map<String, dynamic>)),
          )
          .toList(),
      $__typename: (l$$__typename as String),
    );
  }

  final List<Fragment$ActiveOrder> createOrder;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$createOrder = createOrder;
    _resultData['createOrder'] = l$createOrder.map((e) => e.toJson()).toList();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$createOrder = createOrder;
    final l$$__typename = $__typename;
    return Object.hashAll([
      Object.hashAll(l$createOrder.map((v) => v)),
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$CreateOrder || runtimeType != other.runtimeType) {
      return false;
    }
    final l$createOrder = createOrder;
    final lOther$createOrder = other.createOrder;
    if (l$createOrder.length != lOther$createOrder.length) {
      return false;
    }
    for (int i = 0; i < l$createOrder.length; i++) {
      final l$createOrder$entry = l$createOrder[i];
      final lOther$createOrder$entry = lOther$createOrder[i];
      if (l$createOrder$entry != lOther$createOrder$entry) {
        return false;
      }
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$CreateOrder on Mutation$CreateOrder {
  CopyWith$Mutation$CreateOrder<Mutation$CreateOrder> get copyWith =>
      CopyWith$Mutation$CreateOrder(this, (i) => i);
}

abstract class CopyWith$Mutation$CreateOrder<TRes> {
  factory CopyWith$Mutation$CreateOrder(
    Mutation$CreateOrder instance,
    TRes Function(Mutation$CreateOrder) then,
  ) = _CopyWithImpl$Mutation$CreateOrder;

  factory CopyWith$Mutation$CreateOrder.stub(TRes res) =
      _CopyWithStubImpl$Mutation$CreateOrder;

  TRes call({List<Fragment$ActiveOrder>? createOrder, String? $__typename});
  TRes createOrder(
    Iterable<Fragment$ActiveOrder> Function(
      Iterable<CopyWith$Fragment$ActiveOrder<Fragment$ActiveOrder>>,
    )
    _fn,
  );
}

class _CopyWithImpl$Mutation$CreateOrder<TRes>
    implements CopyWith$Mutation$CreateOrder<TRes> {
  _CopyWithImpl$Mutation$CreateOrder(this._instance, this._then);

  final Mutation$CreateOrder _instance;

  final TRes Function(Mutation$CreateOrder) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? createOrder = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Mutation$CreateOrder(
      createOrder: createOrder == _undefined || createOrder == null
          ? _instance.createOrder
          : (createOrder as List<Fragment$ActiveOrder>),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  TRes createOrder(
    Iterable<Fragment$ActiveOrder> Function(
      Iterable<CopyWith$Fragment$ActiveOrder<Fragment$ActiveOrder>>,
    )
    _fn,
  ) => call(
    createOrder: _fn(
      _instance.createOrder.map(
        (e) => CopyWith$Fragment$ActiveOrder(e, (i) => i),
      ),
    ).toList(),
  );
}

class _CopyWithStubImpl$Mutation$CreateOrder<TRes>
    implements CopyWith$Mutation$CreateOrder<TRes> {
  _CopyWithStubImpl$Mutation$CreateOrder(this._res);

  TRes _res;

  call({List<Fragment$ActiveOrder>? createOrder, String? $__typename}) => _res;

  createOrder(_fn) => _res;
}

const documentNodeMutationCreateOrder = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.mutation,
      name: NameNode(value: 'CreateOrder'),
      variableDefinitions: [
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'input')),
          type: NamedTypeNode(
            name: NameNode(value: 'CreateOrderInput'),
            isNonNull: true,
          ),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
      ],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'createOrder'),
            alias: null,
            arguments: [
              ArgumentNode(
                name: NameNode(value: 'input'),
                value: VariableNode(name: NameNode(value: 'input')),
              ),
            ],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FragmentSpreadNode(
                  name: NameNode(value: 'ActiveOrder'),
                  directives: [],
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
    fragmentDefinitionActiveOrder,
    fragmentDefinitionCoordinate,
    fragmentDefinitionWaypoint,
    fragmentDefinitionRideWaypoint,
    fragmentDefinitionDeliveryWaypoint,
    fragmentDefinitionPhoneNumber,
    fragmentDefinitionShopWaypoint,
    fragmentDefinitionActiveOrderDriver,
    fragmentDefinitionPaymentMethod,
    fragmentDefinitionSavedAccount,
    fragmentDefinitionOnlinePaymentMethod,
    fragmentDefinitionChatMessage,
  ],
);
Mutation$CreateOrder _parserFn$Mutation$CreateOrder(
  Map<String, dynamic> data,
) => Mutation$CreateOrder.fromJson(data);
typedef OnMutationCompleted$Mutation$CreateOrder =
    FutureOr<void> Function(Map<String, dynamic>?, Mutation$CreateOrder?);

class Options$Mutation$CreateOrder
    extends graphql.MutationOptions<Mutation$CreateOrder> {
  Options$Mutation$CreateOrder({
    String? operationName,
    required Variables$Mutation$CreateOrder variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$CreateOrder? typedOptimisticResult,
    graphql.Context? context,
    OnMutationCompleted$Mutation$CreateOrder? onCompleted,
    graphql.OnMutationUpdate<Mutation$CreateOrder>? update,
    graphql.OnError? onError,
  }) : onCompletedWithParsed = onCompleted,
       super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         onCompleted: onCompleted == null
             ? null
             : (data) => onCompleted(
                 data,
                 data == null ? null : _parserFn$Mutation$CreateOrder(data),
               ),
         update: update,
         onError: onError,
         document: documentNodeMutationCreateOrder,
         parserFn: _parserFn$Mutation$CreateOrder,
       );

  final OnMutationCompleted$Mutation$CreateOrder? onCompletedWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onCompleted == null
        ? super.properties
        : super.properties.where((property) => property != onCompleted),
    onCompletedWithParsed,
  ];
}

class WatchOptions$Mutation$CreateOrder
    extends graphql.WatchQueryOptions<Mutation$CreateOrder> {
  WatchOptions$Mutation$CreateOrder({
    String? operationName,
    required Variables$Mutation$CreateOrder variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$CreateOrder? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeMutationCreateOrder,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Mutation$CreateOrder,
       );
}

extension ClientExtension$Mutation$CreateOrder on graphql.GraphQLClient {
  Future<graphql.QueryResult<Mutation$CreateOrder>> mutate$CreateOrder(
    Options$Mutation$CreateOrder options,
  ) async => await this.mutate(options);

  graphql.ObservableQuery<Mutation$CreateOrder> watchMutation$CreateOrder(
    WatchOptions$Mutation$CreateOrder options,
  ) => this.watchMutation(options);
}

class Variables$Mutation$CancelOrder {
  factory Variables$Mutation$CancelOrder({
    required String orderId,
    String? cancelReasonId,
    String? cancelReasonNote,
  }) => Variables$Mutation$CancelOrder._({
    r'orderId': orderId,
    if (cancelReasonId != null) r'cancelReasonId': cancelReasonId,
    if (cancelReasonNote != null) r'cancelReasonNote': cancelReasonNote,
  });

  Variables$Mutation$CancelOrder._(this._$data);

  factory Variables$Mutation$CancelOrder.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$orderId = data['orderId'];
    result$data['orderId'] = (l$orderId as String);
    if (data.containsKey('cancelReasonId')) {
      final l$cancelReasonId = data['cancelReasonId'];
      result$data['cancelReasonId'] = (l$cancelReasonId as String?);
    }
    if (data.containsKey('cancelReasonNote')) {
      final l$cancelReasonNote = data['cancelReasonNote'];
      result$data['cancelReasonNote'] = (l$cancelReasonNote as String?);
    }
    return Variables$Mutation$CancelOrder._(result$data);
  }

  Map<String, dynamic> _$data;

  String get orderId => (_$data['orderId'] as String);

  String? get cancelReasonId => (_$data['cancelReasonId'] as String?);

  String? get cancelReasonNote => (_$data['cancelReasonNote'] as String?);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$orderId = orderId;
    result$data['orderId'] = l$orderId;
    if (_$data.containsKey('cancelReasonId')) {
      final l$cancelReasonId = cancelReasonId;
      result$data['cancelReasonId'] = l$cancelReasonId;
    }
    if (_$data.containsKey('cancelReasonNote')) {
      final l$cancelReasonNote = cancelReasonNote;
      result$data['cancelReasonNote'] = l$cancelReasonNote;
    }
    return result$data;
  }

  CopyWith$Variables$Mutation$CancelOrder<Variables$Mutation$CancelOrder>
  get copyWith => CopyWith$Variables$Mutation$CancelOrder(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Variables$Mutation$CancelOrder ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$orderId = orderId;
    final lOther$orderId = other.orderId;
    if (l$orderId != lOther$orderId) {
      return false;
    }
    final l$cancelReasonId = cancelReasonId;
    final lOther$cancelReasonId = other.cancelReasonId;
    if (_$data.containsKey('cancelReasonId') !=
        other._$data.containsKey('cancelReasonId')) {
      return false;
    }
    if (l$cancelReasonId != lOther$cancelReasonId) {
      return false;
    }
    final l$cancelReasonNote = cancelReasonNote;
    final lOther$cancelReasonNote = other.cancelReasonNote;
    if (_$data.containsKey('cancelReasonNote') !=
        other._$data.containsKey('cancelReasonNote')) {
      return false;
    }
    if (l$cancelReasonNote != lOther$cancelReasonNote) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$orderId = orderId;
    final l$cancelReasonId = cancelReasonId;
    final l$cancelReasonNote = cancelReasonNote;
    return Object.hashAll([
      l$orderId,
      _$data.containsKey('cancelReasonId') ? l$cancelReasonId : const {},
      _$data.containsKey('cancelReasonNote') ? l$cancelReasonNote : const {},
    ]);
  }
}

abstract class CopyWith$Variables$Mutation$CancelOrder<TRes> {
  factory CopyWith$Variables$Mutation$CancelOrder(
    Variables$Mutation$CancelOrder instance,
    TRes Function(Variables$Mutation$CancelOrder) then,
  ) = _CopyWithImpl$Variables$Mutation$CancelOrder;

  factory CopyWith$Variables$Mutation$CancelOrder.stub(TRes res) =
      _CopyWithStubImpl$Variables$Mutation$CancelOrder;

  TRes call({
    String? orderId,
    String? cancelReasonId,
    String? cancelReasonNote,
  });
}

class _CopyWithImpl$Variables$Mutation$CancelOrder<TRes>
    implements CopyWith$Variables$Mutation$CancelOrder<TRes> {
  _CopyWithImpl$Variables$Mutation$CancelOrder(this._instance, this._then);

  final Variables$Mutation$CancelOrder _instance;

  final TRes Function(Variables$Mutation$CancelOrder) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? orderId = _undefined,
    Object? cancelReasonId = _undefined,
    Object? cancelReasonNote = _undefined,
  }) => _then(
    Variables$Mutation$CancelOrder._({
      ..._instance._$data,
      if (orderId != _undefined && orderId != null)
        'orderId': (orderId as String),
      if (cancelReasonId != _undefined)
        'cancelReasonId': (cancelReasonId as String?),
      if (cancelReasonNote != _undefined)
        'cancelReasonNote': (cancelReasonNote as String?),
    }),
  );
}

class _CopyWithStubImpl$Variables$Mutation$CancelOrder<TRes>
    implements CopyWith$Variables$Mutation$CancelOrder<TRes> {
  _CopyWithStubImpl$Variables$Mutation$CancelOrder(this._res);

  TRes _res;

  call({String? orderId, String? cancelReasonId, String? cancelReasonNote}) =>
      _res;
}

class Mutation$CancelOrder {
  Mutation$CancelOrder({
    required this.cancelOrder,
    this.$__typename = 'Mutation',
  });

  factory Mutation$CancelOrder.fromJson(Map<String, dynamic> json) {
    final l$cancelOrder = json['cancelOrder'];
    final l$$__typename = json['__typename'];
    return Mutation$CancelOrder(
      cancelOrder: (l$cancelOrder as bool),
      $__typename: (l$$__typename as String),
    );
  }

  final bool cancelOrder;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$cancelOrder = cancelOrder;
    _resultData['cancelOrder'] = l$cancelOrder;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$cancelOrder = cancelOrder;
    final l$$__typename = $__typename;
    return Object.hashAll([l$cancelOrder, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$CancelOrder || runtimeType != other.runtimeType) {
      return false;
    }
    final l$cancelOrder = cancelOrder;
    final lOther$cancelOrder = other.cancelOrder;
    if (l$cancelOrder != lOther$cancelOrder) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$CancelOrder on Mutation$CancelOrder {
  CopyWith$Mutation$CancelOrder<Mutation$CancelOrder> get copyWith =>
      CopyWith$Mutation$CancelOrder(this, (i) => i);
}

abstract class CopyWith$Mutation$CancelOrder<TRes> {
  factory CopyWith$Mutation$CancelOrder(
    Mutation$CancelOrder instance,
    TRes Function(Mutation$CancelOrder) then,
  ) = _CopyWithImpl$Mutation$CancelOrder;

  factory CopyWith$Mutation$CancelOrder.stub(TRes res) =
      _CopyWithStubImpl$Mutation$CancelOrder;

  TRes call({bool? cancelOrder, String? $__typename});
}

class _CopyWithImpl$Mutation$CancelOrder<TRes>
    implements CopyWith$Mutation$CancelOrder<TRes> {
  _CopyWithImpl$Mutation$CancelOrder(this._instance, this._then);

  final Mutation$CancelOrder _instance;

  final TRes Function(Mutation$CancelOrder) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? cancelOrder = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Mutation$CancelOrder(
      cancelOrder: cancelOrder == _undefined || cancelOrder == null
          ? _instance.cancelOrder
          : (cancelOrder as bool),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );
}

class _CopyWithStubImpl$Mutation$CancelOrder<TRes>
    implements CopyWith$Mutation$CancelOrder<TRes> {
  _CopyWithStubImpl$Mutation$CancelOrder(this._res);

  TRes _res;

  call({bool? cancelOrder, String? $__typename}) => _res;
}

const documentNodeMutationCancelOrder = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.mutation,
      name: NameNode(value: 'CancelOrder'),
      variableDefinitions: [
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'orderId')),
          type: NamedTypeNode(name: NameNode(value: 'ID'), isNonNull: true),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'cancelReasonId')),
          type: NamedTypeNode(name: NameNode(value: 'ID'), isNonNull: false),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'cancelReasonNote')),
          type: NamedTypeNode(
            name: NameNode(value: 'String'),
            isNonNull: false,
          ),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
      ],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'cancelOrder'),
            alias: null,
            arguments: [
              ArgumentNode(
                name: NameNode(value: 'orderId'),
                value: VariableNode(name: NameNode(value: 'orderId')),
              ),
              ArgumentNode(
                name: NameNode(value: 'cancelReasonId'),
                value: VariableNode(name: NameNode(value: 'cancelReasonId')),
              ),
              ArgumentNode(
                name: NameNode(value: 'cancelReasonNote'),
                value: VariableNode(name: NameNode(value: 'cancelReasonNote')),
              ),
            ],
            directives: [],
            selectionSet: null,
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
  ],
);
Mutation$CancelOrder _parserFn$Mutation$CancelOrder(
  Map<String, dynamic> data,
) => Mutation$CancelOrder.fromJson(data);
typedef OnMutationCompleted$Mutation$CancelOrder =
    FutureOr<void> Function(Map<String, dynamic>?, Mutation$CancelOrder?);

class Options$Mutation$CancelOrder
    extends graphql.MutationOptions<Mutation$CancelOrder> {
  Options$Mutation$CancelOrder({
    String? operationName,
    required Variables$Mutation$CancelOrder variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$CancelOrder? typedOptimisticResult,
    graphql.Context? context,
    OnMutationCompleted$Mutation$CancelOrder? onCompleted,
    graphql.OnMutationUpdate<Mutation$CancelOrder>? update,
    graphql.OnError? onError,
  }) : onCompletedWithParsed = onCompleted,
       super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         onCompleted: onCompleted == null
             ? null
             : (data) => onCompleted(
                 data,
                 data == null ? null : _parserFn$Mutation$CancelOrder(data),
               ),
         update: update,
         onError: onError,
         document: documentNodeMutationCancelOrder,
         parserFn: _parserFn$Mutation$CancelOrder,
       );

  final OnMutationCompleted$Mutation$CancelOrder? onCompletedWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onCompleted == null
        ? super.properties
        : super.properties.where((property) => property != onCompleted),
    onCompletedWithParsed,
  ];
}

class WatchOptions$Mutation$CancelOrder
    extends graphql.WatchQueryOptions<Mutation$CancelOrder> {
  WatchOptions$Mutation$CancelOrder({
    String? operationName,
    required Variables$Mutation$CancelOrder variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$CancelOrder? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeMutationCancelOrder,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Mutation$CancelOrder,
       );
}

extension ClientExtension$Mutation$CancelOrder on graphql.GraphQLClient {
  Future<graphql.QueryResult<Mutation$CancelOrder>> mutate$CancelOrder(
    Options$Mutation$CancelOrder options,
  ) async => await this.mutate(options);

  graphql.ObservableQuery<Mutation$CancelOrder> watchMutation$CancelOrder(
    WatchOptions$Mutation$CancelOrder options,
  ) => this.watchMutation(options);
}

class Variables$Mutation$UpdateLastSeenMessagesAt {
  factory Variables$Mutation$UpdateLastSeenMessagesAt({
    required String orderId,
  }) => Variables$Mutation$UpdateLastSeenMessagesAt._({r'orderId': orderId});

  Variables$Mutation$UpdateLastSeenMessagesAt._(this._$data);

  factory Variables$Mutation$UpdateLastSeenMessagesAt.fromJson(
    Map<String, dynamic> data,
  ) {
    final result$data = <String, dynamic>{};
    final l$orderId = data['orderId'];
    result$data['orderId'] = (l$orderId as String);
    return Variables$Mutation$UpdateLastSeenMessagesAt._(result$data);
  }

  Map<String, dynamic> _$data;

  String get orderId => (_$data['orderId'] as String);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$orderId = orderId;
    result$data['orderId'] = l$orderId;
    return result$data;
  }

  CopyWith$Variables$Mutation$UpdateLastSeenMessagesAt<
    Variables$Mutation$UpdateLastSeenMessagesAt
  >
  get copyWith =>
      CopyWith$Variables$Mutation$UpdateLastSeenMessagesAt(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Variables$Mutation$UpdateLastSeenMessagesAt ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$orderId = orderId;
    final lOther$orderId = other.orderId;
    if (l$orderId != lOther$orderId) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$orderId = orderId;
    return Object.hashAll([l$orderId]);
  }
}

abstract class CopyWith$Variables$Mutation$UpdateLastSeenMessagesAt<TRes> {
  factory CopyWith$Variables$Mutation$UpdateLastSeenMessagesAt(
    Variables$Mutation$UpdateLastSeenMessagesAt instance,
    TRes Function(Variables$Mutation$UpdateLastSeenMessagesAt) then,
  ) = _CopyWithImpl$Variables$Mutation$UpdateLastSeenMessagesAt;

  factory CopyWith$Variables$Mutation$UpdateLastSeenMessagesAt.stub(TRes res) =
      _CopyWithStubImpl$Variables$Mutation$UpdateLastSeenMessagesAt;

  TRes call({String? orderId});
}

class _CopyWithImpl$Variables$Mutation$UpdateLastSeenMessagesAt<TRes>
    implements CopyWith$Variables$Mutation$UpdateLastSeenMessagesAt<TRes> {
  _CopyWithImpl$Variables$Mutation$UpdateLastSeenMessagesAt(
    this._instance,
    this._then,
  );

  final Variables$Mutation$UpdateLastSeenMessagesAt _instance;

  final TRes Function(Variables$Mutation$UpdateLastSeenMessagesAt) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? orderId = _undefined}) => _then(
    Variables$Mutation$UpdateLastSeenMessagesAt._({
      ..._instance._$data,
      if (orderId != _undefined && orderId != null)
        'orderId': (orderId as String),
    }),
  );
}

class _CopyWithStubImpl$Variables$Mutation$UpdateLastSeenMessagesAt<TRes>
    implements CopyWith$Variables$Mutation$UpdateLastSeenMessagesAt<TRes> {
  _CopyWithStubImpl$Variables$Mutation$UpdateLastSeenMessagesAt(this._res);

  TRes _res;

  call({String? orderId}) => _res;
}

class Mutation$UpdateLastSeenMessagesAt {
  Mutation$UpdateLastSeenMessagesAt({
    required this.updateLastSeenMessagesAt,
    this.$__typename = 'Mutation',
  });

  factory Mutation$UpdateLastSeenMessagesAt.fromJson(
    Map<String, dynamic> json,
  ) {
    final l$updateLastSeenMessagesAt = json['updateLastSeenMessagesAt'];
    final l$$__typename = json['__typename'];
    return Mutation$UpdateLastSeenMessagesAt(
      updateLastSeenMessagesAt: (l$updateLastSeenMessagesAt as bool),
      $__typename: (l$$__typename as String),
    );
  }

  final bool updateLastSeenMessagesAt;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$updateLastSeenMessagesAt = updateLastSeenMessagesAt;
    _resultData['updateLastSeenMessagesAt'] = l$updateLastSeenMessagesAt;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$updateLastSeenMessagesAt = updateLastSeenMessagesAt;
    final l$$__typename = $__typename;
    return Object.hashAll([l$updateLastSeenMessagesAt, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$UpdateLastSeenMessagesAt ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$updateLastSeenMessagesAt = updateLastSeenMessagesAt;
    final lOther$updateLastSeenMessagesAt = other.updateLastSeenMessagesAt;
    if (l$updateLastSeenMessagesAt != lOther$updateLastSeenMessagesAt) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$UpdateLastSeenMessagesAt
    on Mutation$UpdateLastSeenMessagesAt {
  CopyWith$Mutation$UpdateLastSeenMessagesAt<Mutation$UpdateLastSeenMessagesAt>
  get copyWith => CopyWith$Mutation$UpdateLastSeenMessagesAt(this, (i) => i);
}

abstract class CopyWith$Mutation$UpdateLastSeenMessagesAt<TRes> {
  factory CopyWith$Mutation$UpdateLastSeenMessagesAt(
    Mutation$UpdateLastSeenMessagesAt instance,
    TRes Function(Mutation$UpdateLastSeenMessagesAt) then,
  ) = _CopyWithImpl$Mutation$UpdateLastSeenMessagesAt;

  factory CopyWith$Mutation$UpdateLastSeenMessagesAt.stub(TRes res) =
      _CopyWithStubImpl$Mutation$UpdateLastSeenMessagesAt;

  TRes call({bool? updateLastSeenMessagesAt, String? $__typename});
}

class _CopyWithImpl$Mutation$UpdateLastSeenMessagesAt<TRes>
    implements CopyWith$Mutation$UpdateLastSeenMessagesAt<TRes> {
  _CopyWithImpl$Mutation$UpdateLastSeenMessagesAt(this._instance, this._then);

  final Mutation$UpdateLastSeenMessagesAt _instance;

  final TRes Function(Mutation$UpdateLastSeenMessagesAt) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? updateLastSeenMessagesAt = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Mutation$UpdateLastSeenMessagesAt(
      updateLastSeenMessagesAt:
          updateLastSeenMessagesAt == _undefined ||
              updateLastSeenMessagesAt == null
          ? _instance.updateLastSeenMessagesAt
          : (updateLastSeenMessagesAt as bool),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );
}

class _CopyWithStubImpl$Mutation$UpdateLastSeenMessagesAt<TRes>
    implements CopyWith$Mutation$UpdateLastSeenMessagesAt<TRes> {
  _CopyWithStubImpl$Mutation$UpdateLastSeenMessagesAt(this._res);

  TRes _res;

  call({bool? updateLastSeenMessagesAt, String? $__typename}) => _res;
}

const documentNodeMutationUpdateLastSeenMessagesAt = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.mutation,
      name: NameNode(value: 'UpdateLastSeenMessagesAt'),
      variableDefinitions: [
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'orderId')),
          type: NamedTypeNode(name: NameNode(value: 'ID'), isNonNull: true),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
      ],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'updateLastSeenMessagesAt'),
            alias: null,
            arguments: [
              ArgumentNode(
                name: NameNode(value: 'orderId'),
                value: VariableNode(name: NameNode(value: 'orderId')),
              ),
            ],
            directives: [],
            selectionSet: null,
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
  ],
);
Mutation$UpdateLastSeenMessagesAt _parserFn$Mutation$UpdateLastSeenMessagesAt(
  Map<String, dynamic> data,
) => Mutation$UpdateLastSeenMessagesAt.fromJson(data);
typedef OnMutationCompleted$Mutation$UpdateLastSeenMessagesAt =
    FutureOr<void> Function(
      Map<String, dynamic>?,
      Mutation$UpdateLastSeenMessagesAt?,
    );

class Options$Mutation$UpdateLastSeenMessagesAt
    extends graphql.MutationOptions<Mutation$UpdateLastSeenMessagesAt> {
  Options$Mutation$UpdateLastSeenMessagesAt({
    String? operationName,
    required Variables$Mutation$UpdateLastSeenMessagesAt variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$UpdateLastSeenMessagesAt? typedOptimisticResult,
    graphql.Context? context,
    OnMutationCompleted$Mutation$UpdateLastSeenMessagesAt? onCompleted,
    graphql.OnMutationUpdate<Mutation$UpdateLastSeenMessagesAt>? update,
    graphql.OnError? onError,
  }) : onCompletedWithParsed = onCompleted,
       super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         onCompleted: onCompleted == null
             ? null
             : (data) => onCompleted(
                 data,
                 data == null
                     ? null
                     : _parserFn$Mutation$UpdateLastSeenMessagesAt(data),
               ),
         update: update,
         onError: onError,
         document: documentNodeMutationUpdateLastSeenMessagesAt,
         parserFn: _parserFn$Mutation$UpdateLastSeenMessagesAt,
       );

  final OnMutationCompleted$Mutation$UpdateLastSeenMessagesAt?
  onCompletedWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onCompleted == null
        ? super.properties
        : super.properties.where((property) => property != onCompleted),
    onCompletedWithParsed,
  ];
}

class WatchOptions$Mutation$UpdateLastSeenMessagesAt
    extends graphql.WatchQueryOptions<Mutation$UpdateLastSeenMessagesAt> {
  WatchOptions$Mutation$UpdateLastSeenMessagesAt({
    String? operationName,
    required Variables$Mutation$UpdateLastSeenMessagesAt variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$UpdateLastSeenMessagesAt? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeMutationUpdateLastSeenMessagesAt,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Mutation$UpdateLastSeenMessagesAt,
       );
}

extension ClientExtension$Mutation$UpdateLastSeenMessagesAt
    on graphql.GraphQLClient {
  Future<graphql.QueryResult<Mutation$UpdateLastSeenMessagesAt>>
  mutate$UpdateLastSeenMessagesAt(
    Options$Mutation$UpdateLastSeenMessagesAt options,
  ) async => await this.mutate(options);

  graphql.ObservableQuery<Mutation$UpdateLastSeenMessagesAt>
  watchMutation$UpdateLastSeenMessagesAt(
    WatchOptions$Mutation$UpdateLastSeenMessagesAt options,
  ) => this.watchMutation(options);
}

class Variables$Mutation$updateOrderWaitTime {
  factory Variables$Mutation$updateOrderWaitTime({
    required String orderId,
    required int waitTime,
  }) => Variables$Mutation$updateOrderWaitTime._({
    r'orderId': orderId,
    r'waitTime': waitTime,
  });

  Variables$Mutation$updateOrderWaitTime._(this._$data);

  factory Variables$Mutation$updateOrderWaitTime.fromJson(
    Map<String, dynamic> data,
  ) {
    final result$data = <String, dynamic>{};
    final l$orderId = data['orderId'];
    result$data['orderId'] = (l$orderId as String);
    final l$waitTime = data['waitTime'];
    result$data['waitTime'] = (l$waitTime as int);
    return Variables$Mutation$updateOrderWaitTime._(result$data);
  }

  Map<String, dynamic> _$data;

  String get orderId => (_$data['orderId'] as String);

  int get waitTime => (_$data['waitTime'] as int);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$orderId = orderId;
    result$data['orderId'] = l$orderId;
    final l$waitTime = waitTime;
    result$data['waitTime'] = l$waitTime;
    return result$data;
  }

  CopyWith$Variables$Mutation$updateOrderWaitTime<
    Variables$Mutation$updateOrderWaitTime
  >
  get copyWith =>
      CopyWith$Variables$Mutation$updateOrderWaitTime(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Variables$Mutation$updateOrderWaitTime ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$orderId = orderId;
    final lOther$orderId = other.orderId;
    if (l$orderId != lOther$orderId) {
      return false;
    }
    final l$waitTime = waitTime;
    final lOther$waitTime = other.waitTime;
    if (l$waitTime != lOther$waitTime) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$orderId = orderId;
    final l$waitTime = waitTime;
    return Object.hashAll([l$orderId, l$waitTime]);
  }
}

abstract class CopyWith$Variables$Mutation$updateOrderWaitTime<TRes> {
  factory CopyWith$Variables$Mutation$updateOrderWaitTime(
    Variables$Mutation$updateOrderWaitTime instance,
    TRes Function(Variables$Mutation$updateOrderWaitTime) then,
  ) = _CopyWithImpl$Variables$Mutation$updateOrderWaitTime;

  factory CopyWith$Variables$Mutation$updateOrderWaitTime.stub(TRes res) =
      _CopyWithStubImpl$Variables$Mutation$updateOrderWaitTime;

  TRes call({String? orderId, int? waitTime});
}

class _CopyWithImpl$Variables$Mutation$updateOrderWaitTime<TRes>
    implements CopyWith$Variables$Mutation$updateOrderWaitTime<TRes> {
  _CopyWithImpl$Variables$Mutation$updateOrderWaitTime(
    this._instance,
    this._then,
  );

  final Variables$Mutation$updateOrderWaitTime _instance;

  final TRes Function(Variables$Mutation$updateOrderWaitTime) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? orderId = _undefined, Object? waitTime = _undefined}) =>
      _then(
        Variables$Mutation$updateOrderWaitTime._({
          ..._instance._$data,
          if (orderId != _undefined && orderId != null)
            'orderId': (orderId as String),
          if (waitTime != _undefined && waitTime != null)
            'waitTime': (waitTime as int),
        }),
      );
}

class _CopyWithStubImpl$Variables$Mutation$updateOrderWaitTime<TRes>
    implements CopyWith$Variables$Mutation$updateOrderWaitTime<TRes> {
  _CopyWithStubImpl$Variables$Mutation$updateOrderWaitTime(this._res);

  TRes _res;

  call({String? orderId, int? waitTime}) => _res;
}

class Mutation$updateOrderWaitTime {
  Mutation$updateOrderWaitTime({
    required this.updateOrderWaitTime,
    this.$__typename = 'Mutation',
  });

  factory Mutation$updateOrderWaitTime.fromJson(Map<String, dynamic> json) {
    final l$updateOrderWaitTime = json['updateOrderWaitTime'];
    final l$$__typename = json['__typename'];
    return Mutation$updateOrderWaitTime(
      updateOrderWaitTime:
          Mutation$updateOrderWaitTime$updateOrderWaitTime.fromJson(
            (l$updateOrderWaitTime as Map<String, dynamic>),
          ),
      $__typename: (l$$__typename as String),
    );
  }

  final Mutation$updateOrderWaitTime$updateOrderWaitTime updateOrderWaitTime;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$updateOrderWaitTime = updateOrderWaitTime;
    _resultData['updateOrderWaitTime'] = l$updateOrderWaitTime.toJson();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$updateOrderWaitTime = updateOrderWaitTime;
    final l$$__typename = $__typename;
    return Object.hashAll([l$updateOrderWaitTime, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$updateOrderWaitTime ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$updateOrderWaitTime = updateOrderWaitTime;
    final lOther$updateOrderWaitTime = other.updateOrderWaitTime;
    if (l$updateOrderWaitTime != lOther$updateOrderWaitTime) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$updateOrderWaitTime
    on Mutation$updateOrderWaitTime {
  CopyWith$Mutation$updateOrderWaitTime<Mutation$updateOrderWaitTime>
  get copyWith => CopyWith$Mutation$updateOrderWaitTime(this, (i) => i);
}

abstract class CopyWith$Mutation$updateOrderWaitTime<TRes> {
  factory CopyWith$Mutation$updateOrderWaitTime(
    Mutation$updateOrderWaitTime instance,
    TRes Function(Mutation$updateOrderWaitTime) then,
  ) = _CopyWithImpl$Mutation$updateOrderWaitTime;

  factory CopyWith$Mutation$updateOrderWaitTime.stub(TRes res) =
      _CopyWithStubImpl$Mutation$updateOrderWaitTime;

  TRes call({
    Mutation$updateOrderWaitTime$updateOrderWaitTime? updateOrderWaitTime,
    String? $__typename,
  });
  CopyWith$Mutation$updateOrderWaitTime$updateOrderWaitTime<TRes>
  get updateOrderWaitTime;
}

class _CopyWithImpl$Mutation$updateOrderWaitTime<TRes>
    implements CopyWith$Mutation$updateOrderWaitTime<TRes> {
  _CopyWithImpl$Mutation$updateOrderWaitTime(this._instance, this._then);

  final Mutation$updateOrderWaitTime _instance;

  final TRes Function(Mutation$updateOrderWaitTime) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? updateOrderWaitTime = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Mutation$updateOrderWaitTime(
      updateOrderWaitTime:
          updateOrderWaitTime == _undefined || updateOrderWaitTime == null
          ? _instance.updateOrderWaitTime
          : (updateOrderWaitTime
                as Mutation$updateOrderWaitTime$updateOrderWaitTime),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  CopyWith$Mutation$updateOrderWaitTime$updateOrderWaitTime<TRes>
  get updateOrderWaitTime {
    final local$updateOrderWaitTime = _instance.updateOrderWaitTime;
    return CopyWith$Mutation$updateOrderWaitTime$updateOrderWaitTime(
      local$updateOrderWaitTime,
      (e) => call(updateOrderWaitTime: e),
    );
  }
}

class _CopyWithStubImpl$Mutation$updateOrderWaitTime<TRes>
    implements CopyWith$Mutation$updateOrderWaitTime<TRes> {
  _CopyWithStubImpl$Mutation$updateOrderWaitTime(this._res);

  TRes _res;

  call({
    Mutation$updateOrderWaitTime$updateOrderWaitTime? updateOrderWaitTime,
    String? $__typename,
  }) => _res;

  CopyWith$Mutation$updateOrderWaitTime$updateOrderWaitTime<TRes>
  get updateOrderWaitTime =>
      CopyWith$Mutation$updateOrderWaitTime$updateOrderWaitTime.stub(_res);
}

const documentNodeMutationupdateOrderWaitTime = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.mutation,
      name: NameNode(value: 'updateOrderWaitTime'),
      variableDefinitions: [
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'orderId')),
          type: NamedTypeNode(name: NameNode(value: 'ID'), isNonNull: true),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'waitTime')),
          type: NamedTypeNode(name: NameNode(value: 'Int'), isNonNull: true),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
      ],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'updateOrderWaitTime'),
            alias: null,
            arguments: [
              ArgumentNode(
                name: NameNode(value: 'orderId'),
                value: VariableNode(name: NameNode(value: 'orderId')),
              ),
              ArgumentNode(
                name: NameNode(value: 'waitTime'),
                value: VariableNode(name: NameNode(value: 'waitTime')),
              ),
            ],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FieldNode(
                  name: NameNode(value: 'totalCost'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: 'waitTime'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
  ],
);
Mutation$updateOrderWaitTime _parserFn$Mutation$updateOrderWaitTime(
  Map<String, dynamic> data,
) => Mutation$updateOrderWaitTime.fromJson(data);
typedef OnMutationCompleted$Mutation$updateOrderWaitTime =
    FutureOr<void> Function(
      Map<String, dynamic>?,
      Mutation$updateOrderWaitTime?,
    );

class Options$Mutation$updateOrderWaitTime
    extends graphql.MutationOptions<Mutation$updateOrderWaitTime> {
  Options$Mutation$updateOrderWaitTime({
    String? operationName,
    required Variables$Mutation$updateOrderWaitTime variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$updateOrderWaitTime? typedOptimisticResult,
    graphql.Context? context,
    OnMutationCompleted$Mutation$updateOrderWaitTime? onCompleted,
    graphql.OnMutationUpdate<Mutation$updateOrderWaitTime>? update,
    graphql.OnError? onError,
  }) : onCompletedWithParsed = onCompleted,
       super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         onCompleted: onCompleted == null
             ? null
             : (data) => onCompleted(
                 data,
                 data == null
                     ? null
                     : _parserFn$Mutation$updateOrderWaitTime(data),
               ),
         update: update,
         onError: onError,
         document: documentNodeMutationupdateOrderWaitTime,
         parserFn: _parserFn$Mutation$updateOrderWaitTime,
       );

  final OnMutationCompleted$Mutation$updateOrderWaitTime? onCompletedWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onCompleted == null
        ? super.properties
        : super.properties.where((property) => property != onCompleted),
    onCompletedWithParsed,
  ];
}

class WatchOptions$Mutation$updateOrderWaitTime
    extends graphql.WatchQueryOptions<Mutation$updateOrderWaitTime> {
  WatchOptions$Mutation$updateOrderWaitTime({
    String? operationName,
    required Variables$Mutation$updateOrderWaitTime variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$updateOrderWaitTime? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeMutationupdateOrderWaitTime,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Mutation$updateOrderWaitTime,
       );
}

extension ClientExtension$Mutation$updateOrderWaitTime
    on graphql.GraphQLClient {
  Future<graphql.QueryResult<Mutation$updateOrderWaitTime>>
  mutate$updateOrderWaitTime(
    Options$Mutation$updateOrderWaitTime options,
  ) async => await this.mutate(options);

  graphql.ObservableQuery<Mutation$updateOrderWaitTime>
  watchMutation$updateOrderWaitTime(
    WatchOptions$Mutation$updateOrderWaitTime options,
  ) => this.watchMutation(options);
}

class Mutation$updateOrderWaitTime$updateOrderWaitTime {
  Mutation$updateOrderWaitTime$updateOrderWaitTime({
    required this.totalCost,
    this.waitTime,
    this.$__typename = 'UpdateOrderWaitTimeResponse',
  });

  factory Mutation$updateOrderWaitTime$updateOrderWaitTime.fromJson(
    Map<String, dynamic> json,
  ) {
    final l$totalCost = json['totalCost'];
    final l$waitTime = json['waitTime'];
    final l$$__typename = json['__typename'];
    return Mutation$updateOrderWaitTime$updateOrderWaitTime(
      totalCost: (l$totalCost as num).toDouble(),
      waitTime: (l$waitTime as int?),
      $__typename: (l$$__typename as String),
    );
  }

  final double totalCost;

  final int? waitTime;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$totalCost = totalCost;
    _resultData['totalCost'] = l$totalCost;
    final l$waitTime = waitTime;
    _resultData['waitTime'] = l$waitTime;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$totalCost = totalCost;
    final l$waitTime = waitTime;
    final l$$__typename = $__typename;
    return Object.hashAll([l$totalCost, l$waitTime, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$updateOrderWaitTime$updateOrderWaitTime ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$totalCost = totalCost;
    final lOther$totalCost = other.totalCost;
    if (l$totalCost != lOther$totalCost) {
      return false;
    }
    final l$waitTime = waitTime;
    final lOther$waitTime = other.waitTime;
    if (l$waitTime != lOther$waitTime) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$updateOrderWaitTime$updateOrderWaitTime
    on Mutation$updateOrderWaitTime$updateOrderWaitTime {
  CopyWith$Mutation$updateOrderWaitTime$updateOrderWaitTime<
    Mutation$updateOrderWaitTime$updateOrderWaitTime
  >
  get copyWith =>
      CopyWith$Mutation$updateOrderWaitTime$updateOrderWaitTime(this, (i) => i);
}

abstract class CopyWith$Mutation$updateOrderWaitTime$updateOrderWaitTime<TRes> {
  factory CopyWith$Mutation$updateOrderWaitTime$updateOrderWaitTime(
    Mutation$updateOrderWaitTime$updateOrderWaitTime instance,
    TRes Function(Mutation$updateOrderWaitTime$updateOrderWaitTime) then,
  ) = _CopyWithImpl$Mutation$updateOrderWaitTime$updateOrderWaitTime;

  factory CopyWith$Mutation$updateOrderWaitTime$updateOrderWaitTime.stub(
    TRes res,
  ) = _CopyWithStubImpl$Mutation$updateOrderWaitTime$updateOrderWaitTime;

  TRes call({double? totalCost, int? waitTime, String? $__typename});
}

class _CopyWithImpl$Mutation$updateOrderWaitTime$updateOrderWaitTime<TRes>
    implements CopyWith$Mutation$updateOrderWaitTime$updateOrderWaitTime<TRes> {
  _CopyWithImpl$Mutation$updateOrderWaitTime$updateOrderWaitTime(
    this._instance,
    this._then,
  );

  final Mutation$updateOrderWaitTime$updateOrderWaitTime _instance;

  final TRes Function(Mutation$updateOrderWaitTime$updateOrderWaitTime) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? totalCost = _undefined,
    Object? waitTime = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Mutation$updateOrderWaitTime$updateOrderWaitTime(
      totalCost: totalCost == _undefined || totalCost == null
          ? _instance.totalCost
          : (totalCost as double),
      waitTime: waitTime == _undefined
          ? _instance.waitTime
          : (waitTime as int?),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );
}

class _CopyWithStubImpl$Mutation$updateOrderWaitTime$updateOrderWaitTime<TRes>
    implements CopyWith$Mutation$updateOrderWaitTime$updateOrderWaitTime<TRes> {
  _CopyWithStubImpl$Mutation$updateOrderWaitTime$updateOrderWaitTime(this._res);

  TRes _res;

  call({double? totalCost, int? waitTime, String? $__typename}) => _res;
}

class Variables$Query$verifyCouponCode {
  factory Variables$Query$verifyCouponCode({required String code}) =>
      Variables$Query$verifyCouponCode._({r'code': code});

  Variables$Query$verifyCouponCode._(this._$data);

  factory Variables$Query$verifyCouponCode.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$code = data['code'];
    result$data['code'] = (l$code as String);
    return Variables$Query$verifyCouponCode._(result$data);
  }

  Map<String, dynamic> _$data;

  String get code => (_$data['code'] as String);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$code = code;
    result$data['code'] = l$code;
    return result$data;
  }

  CopyWith$Variables$Query$verifyCouponCode<Variables$Query$verifyCouponCode>
  get copyWith => CopyWith$Variables$Query$verifyCouponCode(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Variables$Query$verifyCouponCode ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$code = code;
    final lOther$code = other.code;
    if (l$code != lOther$code) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$code = code;
    return Object.hashAll([l$code]);
  }
}

abstract class CopyWith$Variables$Query$verifyCouponCode<TRes> {
  factory CopyWith$Variables$Query$verifyCouponCode(
    Variables$Query$verifyCouponCode instance,
    TRes Function(Variables$Query$verifyCouponCode) then,
  ) = _CopyWithImpl$Variables$Query$verifyCouponCode;

  factory CopyWith$Variables$Query$verifyCouponCode.stub(TRes res) =
      _CopyWithStubImpl$Variables$Query$verifyCouponCode;

  TRes call({String? code});
}

class _CopyWithImpl$Variables$Query$verifyCouponCode<TRes>
    implements CopyWith$Variables$Query$verifyCouponCode<TRes> {
  _CopyWithImpl$Variables$Query$verifyCouponCode(this._instance, this._then);

  final Variables$Query$verifyCouponCode _instance;

  final TRes Function(Variables$Query$verifyCouponCode) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? code = _undefined}) => _then(
    Variables$Query$verifyCouponCode._({
      ..._instance._$data,
      if (code != _undefined && code != null) 'code': (code as String),
    }),
  );
}

class _CopyWithStubImpl$Variables$Query$verifyCouponCode<TRes>
    implements CopyWith$Variables$Query$verifyCouponCode<TRes> {
  _CopyWithStubImpl$Variables$Query$verifyCouponCode(this._res);

  TRes _res;

  call({String? code}) => _res;
}

class Query$verifyCouponCode {
  Query$verifyCouponCode({this.couponInfo, this.$__typename = 'Query'});

  factory Query$verifyCouponCode.fromJson(Map<String, dynamic> json) {
    final l$couponInfo = json['couponInfo'];
    final l$$__typename = json['__typename'];
    return Query$verifyCouponCode(
      couponInfo: l$couponInfo == null
          ? null
          : Query$verifyCouponCode$couponInfo.fromJson(
              (l$couponInfo as Map<String, dynamic>),
            ),
      $__typename: (l$$__typename as String),
    );
  }

  final Query$verifyCouponCode$couponInfo? couponInfo;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$couponInfo = couponInfo;
    _resultData['couponInfo'] = l$couponInfo?.toJson();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$couponInfo = couponInfo;
    final l$$__typename = $__typename;
    return Object.hashAll([l$couponInfo, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Query$verifyCouponCode || runtimeType != other.runtimeType) {
      return false;
    }
    final l$couponInfo = couponInfo;
    final lOther$couponInfo = other.couponInfo;
    if (l$couponInfo != lOther$couponInfo) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Query$verifyCouponCode on Query$verifyCouponCode {
  CopyWith$Query$verifyCouponCode<Query$verifyCouponCode> get copyWith =>
      CopyWith$Query$verifyCouponCode(this, (i) => i);
}

abstract class CopyWith$Query$verifyCouponCode<TRes> {
  factory CopyWith$Query$verifyCouponCode(
    Query$verifyCouponCode instance,
    TRes Function(Query$verifyCouponCode) then,
  ) = _CopyWithImpl$Query$verifyCouponCode;

  factory CopyWith$Query$verifyCouponCode.stub(TRes res) =
      _CopyWithStubImpl$Query$verifyCouponCode;

  TRes call({
    Query$verifyCouponCode$couponInfo? couponInfo,
    String? $__typename,
  });
  CopyWith$Query$verifyCouponCode$couponInfo<TRes> get couponInfo;
}

class _CopyWithImpl$Query$verifyCouponCode<TRes>
    implements CopyWith$Query$verifyCouponCode<TRes> {
  _CopyWithImpl$Query$verifyCouponCode(this._instance, this._then);

  final Query$verifyCouponCode _instance;

  final TRes Function(Query$verifyCouponCode) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? couponInfo = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Query$verifyCouponCode(
      couponInfo: couponInfo == _undefined
          ? _instance.couponInfo
          : (couponInfo as Query$verifyCouponCode$couponInfo?),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  CopyWith$Query$verifyCouponCode$couponInfo<TRes> get couponInfo {
    final local$couponInfo = _instance.couponInfo;
    return local$couponInfo == null
        ? CopyWith$Query$verifyCouponCode$couponInfo.stub(_then(_instance))
        : CopyWith$Query$verifyCouponCode$couponInfo(
            local$couponInfo,
            (e) => call(couponInfo: e),
          );
  }
}

class _CopyWithStubImpl$Query$verifyCouponCode<TRes>
    implements CopyWith$Query$verifyCouponCode<TRes> {
  _CopyWithStubImpl$Query$verifyCouponCode(this._res);

  TRes _res;

  call({Query$verifyCouponCode$couponInfo? couponInfo, String? $__typename}) =>
      _res;

  CopyWith$Query$verifyCouponCode$couponInfo<TRes> get couponInfo =>
      CopyWith$Query$verifyCouponCode$couponInfo.stub(_res);
}

const documentNodeQueryverifyCouponCode = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.query,
      name: NameNode(value: 'verifyCouponCode'),
      variableDefinitions: [
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'code')),
          type: NamedTypeNode(name: NameNode(value: 'String'), isNonNull: true),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
      ],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'couponInfo'),
            alias: null,
            arguments: [
              ArgumentNode(
                name: NameNode(value: 'code'),
                value: VariableNode(name: NameNode(value: 'code')),
              ),
            ],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FieldNode(
                  name: NameNode(value: 'description'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: 'title'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
  ],
);
Query$verifyCouponCode _parserFn$Query$verifyCouponCode(
  Map<String, dynamic> data,
) => Query$verifyCouponCode.fromJson(data);
typedef OnQueryComplete$Query$verifyCouponCode =
    FutureOr<void> Function(Map<String, dynamic>?, Query$verifyCouponCode?);

class Options$Query$verifyCouponCode
    extends graphql.QueryOptions<Query$verifyCouponCode> {
  Options$Query$verifyCouponCode({
    String? operationName,
    required Variables$Query$verifyCouponCode variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$verifyCouponCode? typedOptimisticResult,
    Duration? pollInterval,
    graphql.Context? context,
    OnQueryComplete$Query$verifyCouponCode? onComplete,
    graphql.OnQueryError? onError,
  }) : onCompleteWithParsed = onComplete,
       super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         pollInterval: pollInterval,
         context: context,
         onComplete: onComplete == null
             ? null
             : (data) => onComplete(
                 data,
                 data == null ? null : _parserFn$Query$verifyCouponCode(data),
               ),
         onError: onError,
         document: documentNodeQueryverifyCouponCode,
         parserFn: _parserFn$Query$verifyCouponCode,
       );

  final OnQueryComplete$Query$verifyCouponCode? onCompleteWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onComplete == null
        ? super.properties
        : super.properties.where((property) => property != onComplete),
    onCompleteWithParsed,
  ];
}

class WatchOptions$Query$verifyCouponCode
    extends graphql.WatchQueryOptions<Query$verifyCouponCode> {
  WatchOptions$Query$verifyCouponCode({
    String? operationName,
    required Variables$Query$verifyCouponCode variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$verifyCouponCode? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeQueryverifyCouponCode,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Query$verifyCouponCode,
       );
}

class FetchMoreOptions$Query$verifyCouponCode extends graphql.FetchMoreOptions {
  FetchMoreOptions$Query$verifyCouponCode({
    required graphql.UpdateQuery updateQuery,
    required Variables$Query$verifyCouponCode variables,
  }) : super(
         updateQuery: updateQuery,
         variables: variables.toJson(),
         document: documentNodeQueryverifyCouponCode,
       );
}

extension ClientExtension$Query$verifyCouponCode on graphql.GraphQLClient {
  Future<graphql.QueryResult<Query$verifyCouponCode>> query$verifyCouponCode(
    Options$Query$verifyCouponCode options,
  ) async => await this.query(options);

  graphql.ObservableQuery<Query$verifyCouponCode> watchQuery$verifyCouponCode(
    WatchOptions$Query$verifyCouponCode options,
  ) => this.watchQuery(options);

  void writeQuery$verifyCouponCode({
    required Query$verifyCouponCode data,
    required Variables$Query$verifyCouponCode variables,
    bool broadcast = true,
  }) => this.writeQuery(
    graphql.Request(
      operation: graphql.Operation(document: documentNodeQueryverifyCouponCode),
      variables: variables.toJson(),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Query$verifyCouponCode? readQuery$verifyCouponCode({
    required Variables$Query$verifyCouponCode variables,
    bool optimistic = true,
  }) {
    final result = this.readQuery(
      graphql.Request(
        operation: graphql.Operation(
          document: documentNodeQueryverifyCouponCode,
        ),
        variables: variables.toJson(),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Query$verifyCouponCode.fromJson(result);
  }
}

class Query$verifyCouponCode$couponInfo {
  Query$verifyCouponCode$couponInfo({
    this.description,
    required this.title,
    this.$__typename = 'Coupon',
  });

  factory Query$verifyCouponCode$couponInfo.fromJson(
    Map<String, dynamic> json,
  ) {
    final l$description = json['description'];
    final l$title = json['title'];
    final l$$__typename = json['__typename'];
    return Query$verifyCouponCode$couponInfo(
      description: (l$description as String?),
      title: (l$title as String),
      $__typename: (l$$__typename as String),
    );
  }

  final String? description;

  final String title;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$description = description;
    _resultData['description'] = l$description;
    final l$title = title;
    _resultData['title'] = l$title;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$description = description;
    final l$title = title;
    final l$$__typename = $__typename;
    return Object.hashAll([l$description, l$title, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Query$verifyCouponCode$couponInfo ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$description = description;
    final lOther$description = other.description;
    if (l$description != lOther$description) {
      return false;
    }
    final l$title = title;
    final lOther$title = other.title;
    if (l$title != lOther$title) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Query$verifyCouponCode$couponInfo
    on Query$verifyCouponCode$couponInfo {
  CopyWith$Query$verifyCouponCode$couponInfo<Query$verifyCouponCode$couponInfo>
  get copyWith => CopyWith$Query$verifyCouponCode$couponInfo(this, (i) => i);
}

abstract class CopyWith$Query$verifyCouponCode$couponInfo<TRes> {
  factory CopyWith$Query$verifyCouponCode$couponInfo(
    Query$verifyCouponCode$couponInfo instance,
    TRes Function(Query$verifyCouponCode$couponInfo) then,
  ) = _CopyWithImpl$Query$verifyCouponCode$couponInfo;

  factory CopyWith$Query$verifyCouponCode$couponInfo.stub(TRes res) =
      _CopyWithStubImpl$Query$verifyCouponCode$couponInfo;

  TRes call({String? description, String? title, String? $__typename});
}

class _CopyWithImpl$Query$verifyCouponCode$couponInfo<TRes>
    implements CopyWith$Query$verifyCouponCode$couponInfo<TRes> {
  _CopyWithImpl$Query$verifyCouponCode$couponInfo(this._instance, this._then);

  final Query$verifyCouponCode$couponInfo _instance;

  final TRes Function(Query$verifyCouponCode$couponInfo) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? description = _undefined,
    Object? title = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Query$verifyCouponCode$couponInfo(
      description: description == _undefined
          ? _instance.description
          : (description as String?),
      title: title == _undefined || title == null
          ? _instance.title
          : (title as String),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );
}

class _CopyWithStubImpl$Query$verifyCouponCode$couponInfo<TRes>
    implements CopyWith$Query$verifyCouponCode$couponInfo<TRes> {
  _CopyWithStubImpl$Query$verifyCouponCode$couponInfo(this._res);

  TRes _res;

  call({String? description, String? title, String? $__typename}) => _res;
}

class Variables$Mutation$applyCoupon {
  factory Variables$Mutation$applyCoupon({
    required String orderId,
    required String code,
  }) => Variables$Mutation$applyCoupon._({r'orderId': orderId, r'code': code});

  Variables$Mutation$applyCoupon._(this._$data);

  factory Variables$Mutation$applyCoupon.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$orderId = data['orderId'];
    result$data['orderId'] = (l$orderId as String);
    final l$code = data['code'];
    result$data['code'] = (l$code as String);
    return Variables$Mutation$applyCoupon._(result$data);
  }

  Map<String, dynamic> _$data;

  String get orderId => (_$data['orderId'] as String);

  String get code => (_$data['code'] as String);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$orderId = orderId;
    result$data['orderId'] = l$orderId;
    final l$code = code;
    result$data['code'] = l$code;
    return result$data;
  }

  CopyWith$Variables$Mutation$applyCoupon<Variables$Mutation$applyCoupon>
  get copyWith => CopyWith$Variables$Mutation$applyCoupon(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Variables$Mutation$applyCoupon ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$orderId = orderId;
    final lOther$orderId = other.orderId;
    if (l$orderId != lOther$orderId) {
      return false;
    }
    final l$code = code;
    final lOther$code = other.code;
    if (l$code != lOther$code) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$orderId = orderId;
    final l$code = code;
    return Object.hashAll([l$orderId, l$code]);
  }
}

abstract class CopyWith$Variables$Mutation$applyCoupon<TRes> {
  factory CopyWith$Variables$Mutation$applyCoupon(
    Variables$Mutation$applyCoupon instance,
    TRes Function(Variables$Mutation$applyCoupon) then,
  ) = _CopyWithImpl$Variables$Mutation$applyCoupon;

  factory CopyWith$Variables$Mutation$applyCoupon.stub(TRes res) =
      _CopyWithStubImpl$Variables$Mutation$applyCoupon;

  TRes call({String? orderId, String? code});
}

class _CopyWithImpl$Variables$Mutation$applyCoupon<TRes>
    implements CopyWith$Variables$Mutation$applyCoupon<TRes> {
  _CopyWithImpl$Variables$Mutation$applyCoupon(this._instance, this._then);

  final Variables$Mutation$applyCoupon _instance;

  final TRes Function(Variables$Mutation$applyCoupon) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? orderId = _undefined, Object? code = _undefined}) => _then(
    Variables$Mutation$applyCoupon._({
      ..._instance._$data,
      if (orderId != _undefined && orderId != null)
        'orderId': (orderId as String),
      if (code != _undefined && code != null) 'code': (code as String),
    }),
  );
}

class _CopyWithStubImpl$Variables$Mutation$applyCoupon<TRes>
    implements CopyWith$Variables$Mutation$applyCoupon<TRes> {
  _CopyWithStubImpl$Variables$Mutation$applyCoupon(this._res);

  TRes _res;

  call({String? orderId, String? code}) => _res;
}

class Mutation$applyCoupon {
  Mutation$applyCoupon({
    required this.applyCoupon,
    this.$__typename = 'Mutation',
  });

  factory Mutation$applyCoupon.fromJson(Map<String, dynamic> json) {
    final l$applyCoupon = json['applyCoupon'];
    final l$$__typename = json['__typename'];
    return Mutation$applyCoupon(
      applyCoupon: Mutation$applyCoupon$applyCoupon.fromJson(
        (l$applyCoupon as Map<String, dynamic>),
      ),
      $__typename: (l$$__typename as String),
    );
  }

  final Mutation$applyCoupon$applyCoupon applyCoupon;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$applyCoupon = applyCoupon;
    _resultData['applyCoupon'] = l$applyCoupon.toJson();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$applyCoupon = applyCoupon;
    final l$$__typename = $__typename;
    return Object.hashAll([l$applyCoupon, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$applyCoupon || runtimeType != other.runtimeType) {
      return false;
    }
    final l$applyCoupon = applyCoupon;
    final lOther$applyCoupon = other.applyCoupon;
    if (l$applyCoupon != lOther$applyCoupon) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$applyCoupon on Mutation$applyCoupon {
  CopyWith$Mutation$applyCoupon<Mutation$applyCoupon> get copyWith =>
      CopyWith$Mutation$applyCoupon(this, (i) => i);
}

abstract class CopyWith$Mutation$applyCoupon<TRes> {
  factory CopyWith$Mutation$applyCoupon(
    Mutation$applyCoupon instance,
    TRes Function(Mutation$applyCoupon) then,
  ) = _CopyWithImpl$Mutation$applyCoupon;

  factory CopyWith$Mutation$applyCoupon.stub(TRes res) =
      _CopyWithStubImpl$Mutation$applyCoupon;

  TRes call({
    Mutation$applyCoupon$applyCoupon? applyCoupon,
    String? $__typename,
  });
  CopyWith$Mutation$applyCoupon$applyCoupon<TRes> get applyCoupon;
}

class _CopyWithImpl$Mutation$applyCoupon<TRes>
    implements CopyWith$Mutation$applyCoupon<TRes> {
  _CopyWithImpl$Mutation$applyCoupon(this._instance, this._then);

  final Mutation$applyCoupon _instance;

  final TRes Function(Mutation$applyCoupon) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? applyCoupon = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Mutation$applyCoupon(
      applyCoupon: applyCoupon == _undefined || applyCoupon == null
          ? _instance.applyCoupon
          : (applyCoupon as Mutation$applyCoupon$applyCoupon),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  CopyWith$Mutation$applyCoupon$applyCoupon<TRes> get applyCoupon {
    final local$applyCoupon = _instance.applyCoupon;
    return CopyWith$Mutation$applyCoupon$applyCoupon(
      local$applyCoupon,
      (e) => call(applyCoupon: e),
    );
  }
}

class _CopyWithStubImpl$Mutation$applyCoupon<TRes>
    implements CopyWith$Mutation$applyCoupon<TRes> {
  _CopyWithStubImpl$Mutation$applyCoupon(this._res);

  TRes _res;

  call({Mutation$applyCoupon$applyCoupon? applyCoupon, String? $__typename}) =>
      _res;

  CopyWith$Mutation$applyCoupon$applyCoupon<TRes> get applyCoupon =>
      CopyWith$Mutation$applyCoupon$applyCoupon.stub(_res);
}

const documentNodeMutationapplyCoupon = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.mutation,
      name: NameNode(value: 'applyCoupon'),
      variableDefinitions: [
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'orderId')),
          type: NamedTypeNode(name: NameNode(value: 'ID'), isNonNull: true),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
        VariableDefinitionNode(
          variable: VariableNode(name: NameNode(value: 'code')),
          type: NamedTypeNode(name: NameNode(value: 'String'), isNonNull: true),
          defaultValue: DefaultValueNode(value: null),
          directives: [],
        ),
      ],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'applyCoupon'),
            alias: null,
            arguments: [
              ArgumentNode(
                name: NameNode(value: 'orderId'),
                value: VariableNode(name: NameNode(value: 'orderId')),
              ),
              ArgumentNode(
                name: NameNode(value: 'couponCode'),
                value: VariableNode(name: NameNode(value: 'code')),
              ),
            ],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FieldNode(
                  name: NameNode(value: 'couponDiscount'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: 'totalCost'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
  ],
);
Mutation$applyCoupon _parserFn$Mutation$applyCoupon(
  Map<String, dynamic> data,
) => Mutation$applyCoupon.fromJson(data);
typedef OnMutationCompleted$Mutation$applyCoupon =
    FutureOr<void> Function(Map<String, dynamic>?, Mutation$applyCoupon?);

class Options$Mutation$applyCoupon
    extends graphql.MutationOptions<Mutation$applyCoupon> {
  Options$Mutation$applyCoupon({
    String? operationName,
    required Variables$Mutation$applyCoupon variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$applyCoupon? typedOptimisticResult,
    graphql.Context? context,
    OnMutationCompleted$Mutation$applyCoupon? onCompleted,
    graphql.OnMutationUpdate<Mutation$applyCoupon>? update,
    graphql.OnError? onError,
  }) : onCompletedWithParsed = onCompleted,
       super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         onCompleted: onCompleted == null
             ? null
             : (data) => onCompleted(
                 data,
                 data == null ? null : _parserFn$Mutation$applyCoupon(data),
               ),
         update: update,
         onError: onError,
         document: documentNodeMutationapplyCoupon,
         parserFn: _parserFn$Mutation$applyCoupon,
       );

  final OnMutationCompleted$Mutation$applyCoupon? onCompletedWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onCompleted == null
        ? super.properties
        : super.properties.where((property) => property != onCompleted),
    onCompletedWithParsed,
  ];
}

class WatchOptions$Mutation$applyCoupon
    extends graphql.WatchQueryOptions<Mutation$applyCoupon> {
  WatchOptions$Mutation$applyCoupon({
    String? operationName,
    required Variables$Mutation$applyCoupon variables,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Mutation$applyCoupon? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         variables: variables.toJson(),
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeMutationapplyCoupon,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Mutation$applyCoupon,
       );
}

extension ClientExtension$Mutation$applyCoupon on graphql.GraphQLClient {
  Future<graphql.QueryResult<Mutation$applyCoupon>> mutate$applyCoupon(
    Options$Mutation$applyCoupon options,
  ) async => await this.mutate(options);

  graphql.ObservableQuery<Mutation$applyCoupon> watchMutation$applyCoupon(
    WatchOptions$Mutation$applyCoupon options,
  ) => this.watchMutation(options);
}

class Mutation$applyCoupon$applyCoupon {
  Mutation$applyCoupon$applyCoupon({
    required this.couponDiscount,
    required this.totalCost,
    this.$__typename = 'ApplyCouponResponse',
  });

  factory Mutation$applyCoupon$applyCoupon.fromJson(Map<String, dynamic> json) {
    final l$couponDiscount = json['couponDiscount'];
    final l$totalCost = json['totalCost'];
    final l$$__typename = json['__typename'];
    return Mutation$applyCoupon$applyCoupon(
      couponDiscount: (l$couponDiscount as num).toDouble(),
      totalCost: (l$totalCost as num).toDouble(),
      $__typename: (l$$__typename as String),
    );
  }

  final double couponDiscount;

  final double totalCost;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$couponDiscount = couponDiscount;
    _resultData['couponDiscount'] = l$couponDiscount;
    final l$totalCost = totalCost;
    _resultData['totalCost'] = l$totalCost;
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$couponDiscount = couponDiscount;
    final l$totalCost = totalCost;
    final l$$__typename = $__typename;
    return Object.hashAll([l$couponDiscount, l$totalCost, l$$__typename]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Mutation$applyCoupon$applyCoupon ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$couponDiscount = couponDiscount;
    final lOther$couponDiscount = other.couponDiscount;
    if (l$couponDiscount != lOther$couponDiscount) {
      return false;
    }
    final l$totalCost = totalCost;
    final lOther$totalCost = other.totalCost;
    if (l$totalCost != lOther$totalCost) {
      return false;
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Mutation$applyCoupon$applyCoupon
    on Mutation$applyCoupon$applyCoupon {
  CopyWith$Mutation$applyCoupon$applyCoupon<Mutation$applyCoupon$applyCoupon>
  get copyWith => CopyWith$Mutation$applyCoupon$applyCoupon(this, (i) => i);
}

abstract class CopyWith$Mutation$applyCoupon$applyCoupon<TRes> {
  factory CopyWith$Mutation$applyCoupon$applyCoupon(
    Mutation$applyCoupon$applyCoupon instance,
    TRes Function(Mutation$applyCoupon$applyCoupon) then,
  ) = _CopyWithImpl$Mutation$applyCoupon$applyCoupon;

  factory CopyWith$Mutation$applyCoupon$applyCoupon.stub(TRes res) =
      _CopyWithStubImpl$Mutation$applyCoupon$applyCoupon;

  TRes call({double? couponDiscount, double? totalCost, String? $__typename});
}

class _CopyWithImpl$Mutation$applyCoupon$applyCoupon<TRes>
    implements CopyWith$Mutation$applyCoupon$applyCoupon<TRes> {
  _CopyWithImpl$Mutation$applyCoupon$applyCoupon(this._instance, this._then);

  final Mutation$applyCoupon$applyCoupon _instance;

  final TRes Function(Mutation$applyCoupon$applyCoupon) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? couponDiscount = _undefined,
    Object? totalCost = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Mutation$applyCoupon$applyCoupon(
      couponDiscount: couponDiscount == _undefined || couponDiscount == null
          ? _instance.couponDiscount
          : (couponDiscount as double),
      totalCost: totalCost == _undefined || totalCost == null
          ? _instance.totalCost
          : (totalCost as double),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );
}

class _CopyWithStubImpl$Mutation$applyCoupon$applyCoupon<TRes>
    implements CopyWith$Mutation$applyCoupon$applyCoupon<TRes> {
  _CopyWithStubImpl$Mutation$applyCoupon$applyCoupon(this._res);

  TRes _res;

  call({double? couponDiscount, double? totalCost, String? $__typename}) =>
      _res;
}

class Query$CancelReasons {
  Query$CancelReasons({
    required this.cancelReasons,
    this.$__typename = 'Query',
  });

  factory Query$CancelReasons.fromJson(Map<String, dynamic> json) {
    final l$cancelReasons = json['cancelReasons'];
    final l$$__typename = json['__typename'];
    return Query$CancelReasons(
      cancelReasons: (l$cancelReasons as List<dynamic>)
          .map(
            (e) => Fragment$cancelReason.fromJson((e as Map<String, dynamic>)),
          )
          .toList(),
      $__typename: (l$$__typename as String),
    );
  }

  final List<Fragment$cancelReason> cancelReasons;

  final String $__typename;

  Map<String, dynamic> toJson() {
    final _resultData = <String, dynamic>{};
    final l$cancelReasons = cancelReasons;
    _resultData['cancelReasons'] = l$cancelReasons
        .map((e) => e.toJson())
        .toList();
    final l$$__typename = $__typename;
    _resultData['__typename'] = l$$__typename;
    return _resultData;
  }

  @override
  int get hashCode {
    final l$cancelReasons = cancelReasons;
    final l$$__typename = $__typename;
    return Object.hashAll([
      Object.hashAll(l$cancelReasons.map((v) => v)),
      l$$__typename,
    ]);
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Query$CancelReasons || runtimeType != other.runtimeType) {
      return false;
    }
    final l$cancelReasons = cancelReasons;
    final lOther$cancelReasons = other.cancelReasons;
    if (l$cancelReasons.length != lOther$cancelReasons.length) {
      return false;
    }
    for (int i = 0; i < l$cancelReasons.length; i++) {
      final l$cancelReasons$entry = l$cancelReasons[i];
      final lOther$cancelReasons$entry = lOther$cancelReasons[i];
      if (l$cancelReasons$entry != lOther$cancelReasons$entry) {
        return false;
      }
    }
    final l$$__typename = $__typename;
    final lOther$$__typename = other.$__typename;
    if (l$$__typename != lOther$$__typename) {
      return false;
    }
    return true;
  }
}

extension UtilityExtension$Query$CancelReasons on Query$CancelReasons {
  CopyWith$Query$CancelReasons<Query$CancelReasons> get copyWith =>
      CopyWith$Query$CancelReasons(this, (i) => i);
}

abstract class CopyWith$Query$CancelReasons<TRes> {
  factory CopyWith$Query$CancelReasons(
    Query$CancelReasons instance,
    TRes Function(Query$CancelReasons) then,
  ) = _CopyWithImpl$Query$CancelReasons;

  factory CopyWith$Query$CancelReasons.stub(TRes res) =
      _CopyWithStubImpl$Query$CancelReasons;

  TRes call({List<Fragment$cancelReason>? cancelReasons, String? $__typename});
  TRes cancelReasons(
    Iterable<Fragment$cancelReason> Function(
      Iterable<CopyWith$Fragment$cancelReason<Fragment$cancelReason>>,
    )
    _fn,
  );
}

class _CopyWithImpl$Query$CancelReasons<TRes>
    implements CopyWith$Query$CancelReasons<TRes> {
  _CopyWithImpl$Query$CancelReasons(this._instance, this._then);

  final Query$CancelReasons _instance;

  final TRes Function(Query$CancelReasons) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? cancelReasons = _undefined,
    Object? $__typename = _undefined,
  }) => _then(
    Query$CancelReasons(
      cancelReasons: cancelReasons == _undefined || cancelReasons == null
          ? _instance.cancelReasons
          : (cancelReasons as List<Fragment$cancelReason>),
      $__typename: $__typename == _undefined || $__typename == null
          ? _instance.$__typename
          : ($__typename as String),
    ),
  );

  TRes cancelReasons(
    Iterable<Fragment$cancelReason> Function(
      Iterable<CopyWith$Fragment$cancelReason<Fragment$cancelReason>>,
    )
    _fn,
  ) => call(
    cancelReasons: _fn(
      _instance.cancelReasons.map(
        (e) => CopyWith$Fragment$cancelReason(e, (i) => i),
      ),
    ).toList(),
  );
}

class _CopyWithStubImpl$Query$CancelReasons<TRes>
    implements CopyWith$Query$CancelReasons<TRes> {
  _CopyWithStubImpl$Query$CancelReasons(this._res);

  TRes _res;

  call({List<Fragment$cancelReason>? cancelReasons, String? $__typename}) =>
      _res;

  cancelReasons(_fn) => _res;
}

const documentNodeQueryCancelReasons = DocumentNode(
  definitions: [
    OperationDefinitionNode(
      type: OperationType.query,
      name: NameNode(value: 'CancelReasons'),
      variableDefinitions: [],
      directives: [],
      selectionSet: SelectionSetNode(
        selections: [
          FieldNode(
            name: NameNode(value: 'cancelReasons'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: SelectionSetNode(
              selections: [
                FragmentSpreadNode(
                  name: NameNode(value: 'cancelReason'),
                  directives: [],
                ),
                FieldNode(
                  name: NameNode(value: '__typename'),
                  alias: null,
                  arguments: [],
                  directives: [],
                  selectionSet: null,
                ),
              ],
            ),
          ),
          FieldNode(
            name: NameNode(value: '__typename'),
            alias: null,
            arguments: [],
            directives: [],
            selectionSet: null,
          ),
        ],
      ),
    ),
    fragmentDefinitioncancelReason,
  ],
);
Query$CancelReasons _parserFn$Query$CancelReasons(Map<String, dynamic> data) =>
    Query$CancelReasons.fromJson(data);
typedef OnQueryComplete$Query$CancelReasons =
    FutureOr<void> Function(Map<String, dynamic>?, Query$CancelReasons?);

class Options$Query$CancelReasons
    extends graphql.QueryOptions<Query$CancelReasons> {
  Options$Query$CancelReasons({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$CancelReasons? typedOptimisticResult,
    Duration? pollInterval,
    graphql.Context? context,
    OnQueryComplete$Query$CancelReasons? onComplete,
    graphql.OnQueryError? onError,
  }) : onCompleteWithParsed = onComplete,
       super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         pollInterval: pollInterval,
         context: context,
         onComplete: onComplete == null
             ? null
             : (data) => onComplete(
                 data,
                 data == null ? null : _parserFn$Query$CancelReasons(data),
               ),
         onError: onError,
         document: documentNodeQueryCancelReasons,
         parserFn: _parserFn$Query$CancelReasons,
       );

  final OnQueryComplete$Query$CancelReasons? onCompleteWithParsed;

  @override
  List<Object?> get properties => [
    ...super.onComplete == null
        ? super.properties
        : super.properties.where((property) => property != onComplete),
    onCompleteWithParsed,
  ];
}

class WatchOptions$Query$CancelReasons
    extends graphql.WatchQueryOptions<Query$CancelReasons> {
  WatchOptions$Query$CancelReasons({
    String? operationName,
    graphql.FetchPolicy? fetchPolicy,
    graphql.ErrorPolicy? errorPolicy,
    graphql.CacheRereadPolicy? cacheRereadPolicy,
    Object? optimisticResult,
    Query$CancelReasons? typedOptimisticResult,
    graphql.Context? context,
    Duration? pollInterval,
    bool? eagerlyFetchResults,
    bool carryForwardDataOnException = true,
    bool fetchResults = false,
  }) : super(
         operationName: operationName,
         fetchPolicy: fetchPolicy,
         errorPolicy: errorPolicy,
         cacheRereadPolicy: cacheRereadPolicy,
         optimisticResult: optimisticResult ?? typedOptimisticResult?.toJson(),
         context: context,
         document: documentNodeQueryCancelReasons,
         pollInterval: pollInterval,
         eagerlyFetchResults: eagerlyFetchResults,
         carryForwardDataOnException: carryForwardDataOnException,
         fetchResults: fetchResults,
         parserFn: _parserFn$Query$CancelReasons,
       );
}

class FetchMoreOptions$Query$CancelReasons extends graphql.FetchMoreOptions {
  FetchMoreOptions$Query$CancelReasons({
    required graphql.UpdateQuery updateQuery,
  }) : super(
         updateQuery: updateQuery,
         document: documentNodeQueryCancelReasons,
       );
}

extension ClientExtension$Query$CancelReasons on graphql.GraphQLClient {
  Future<graphql.QueryResult<Query$CancelReasons>> query$CancelReasons([
    Options$Query$CancelReasons? options,
  ]) async => await this.query(options ?? Options$Query$CancelReasons());

  graphql.ObservableQuery<Query$CancelReasons> watchQuery$CancelReasons([
    WatchOptions$Query$CancelReasons? options,
  ]) => this.watchQuery(options ?? WatchOptions$Query$CancelReasons());

  void writeQuery$CancelReasons({
    required Query$CancelReasons data,
    bool broadcast = true,
  }) => this.writeQuery(
    graphql.Request(
      operation: graphql.Operation(document: documentNodeQueryCancelReasons),
    ),
    data: data.toJson(),
    broadcast: broadcast,
  );

  Query$CancelReasons? readQuery$CancelReasons({bool optimistic = true}) {
    final result = this.readQuery(
      graphql.Request(
        operation: graphql.Operation(document: documentNodeQueryCancelReasons),
      ),
      optimistic: optimistic,
    );
    return result == null ? null : Query$CancelReasons.fromJson(result);
  }
}
