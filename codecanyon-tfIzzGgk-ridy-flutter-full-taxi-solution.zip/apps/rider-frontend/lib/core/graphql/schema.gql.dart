class Input$PointInput {
  factory Input$PointInput({
    required double lat,
    required double lng,
    int? heading,
  }) => Input$PointInput._({
    r'lat': lat,
    r'lng': lng,
    if (heading != null) r'heading': heading,
  });

  Input$PointInput._(this._$data);

  factory Input$PointInput.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$lat = data['lat'];
    result$data['lat'] = (l$lat as num).toDouble();
    final l$lng = data['lng'];
    result$data['lng'] = (l$lng as num).toDouble();
    if (data.containsKey('heading')) {
      final l$heading = data['heading'];
      result$data['heading'] = (l$heading as int?);
    }
    return Input$PointInput._(result$data);
  }

  Map<String, dynamic> _$data;

  double get lat => (_$data['lat'] as double);

  double get lng => (_$data['lng'] as double);

  int? get heading => (_$data['heading'] as int?);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$lat = lat;
    result$data['lat'] = l$lat;
    final l$lng = lng;
    result$data['lng'] = l$lng;
    if (_$data.containsKey('heading')) {
      final l$heading = heading;
      result$data['heading'] = l$heading;
    }
    return result$data;
  }

  CopyWith$Input$PointInput<Input$PointInput> get copyWith =>
      CopyWith$Input$PointInput(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Input$PointInput || runtimeType != other.runtimeType) {
      return false;
    }
    final l$lat = lat;
    final lOther$lat = other.lat;
    if (l$lat != lOther$lat) {
      return false;
    }
    final l$lng = lng;
    final lOther$lng = other.lng;
    if (l$lng != lOther$lng) {
      return false;
    }
    final l$heading = heading;
    final lOther$heading = other.heading;
    if (_$data.containsKey('heading') != other._$data.containsKey('heading')) {
      return false;
    }
    if (l$heading != lOther$heading) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$lat = lat;
    final l$lng = lng;
    final l$heading = heading;
    return Object.hashAll([
      l$lat,
      l$lng,
      _$data.containsKey('heading') ? l$heading : const {},
    ]);
  }
}

abstract class CopyWith$Input$PointInput<TRes> {
  factory CopyWith$Input$PointInput(
    Input$PointInput instance,
    TRes Function(Input$PointInput) then,
  ) = _CopyWithImpl$Input$PointInput;

  factory CopyWith$Input$PointInput.stub(TRes res) =
      _CopyWithStubImpl$Input$PointInput;

  TRes call({double? lat, double? lng, int? heading});
}

class _CopyWithImpl$Input$PointInput<TRes>
    implements CopyWith$Input$PointInput<TRes> {
  _CopyWithImpl$Input$PointInput(this._instance, this._then);

  final Input$PointInput _instance;

  final TRes Function(Input$PointInput) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? lat = _undefined,
    Object? lng = _undefined,
    Object? heading = _undefined,
  }) => _then(
    Input$PointInput._({
      ..._instance._$data,
      if (lat != _undefined && lat != null) 'lat': (lat as double),
      if (lng != _undefined && lng != null) 'lng': (lng as double),
      if (heading != _undefined) 'heading': (heading as int?),
    }),
  );
}

class _CopyWithStubImpl$Input$PointInput<TRes>
    implements CopyWith$Input$PointInput<TRes> {
  _CopyWithStubImpl$Input$PointInput(this._res);

  TRes _res;

  call({double? lat, double? lng, int? heading}) => _res;
}

class Input$AppConfigInfoInput {
  factory Input$AppConfigInfoInput({
    String? logo,
    String? name,
    Enum$AppColorScheme? color,
  }) => Input$AppConfigInfoInput._({
    if (logo != null) r'logo': logo,
    if (name != null) r'name': name,
    if (color != null) r'color': color,
  });

  Input$AppConfigInfoInput._(this._$data);

  factory Input$AppConfigInfoInput.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    if (data.containsKey('logo')) {
      final l$logo = data['logo'];
      result$data['logo'] = (l$logo as String?);
    }
    if (data.containsKey('name')) {
      final l$name = data['name'];
      result$data['name'] = (l$name as String?);
    }
    if (data.containsKey('color')) {
      final l$color = data['color'];
      result$data['color'] = l$color == null
          ? null
          : fromJson$Enum$AppColorScheme((l$color as String));
    }
    return Input$AppConfigInfoInput._(result$data);
  }

  Map<String, dynamic> _$data;

  String? get logo => (_$data['logo'] as String?);

  String? get name => (_$data['name'] as String?);

  Enum$AppColorScheme? get color => (_$data['color'] as Enum$AppColorScheme?);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    if (_$data.containsKey('logo')) {
      final l$logo = logo;
      result$data['logo'] = l$logo;
    }
    if (_$data.containsKey('name')) {
      final l$name = name;
      result$data['name'] = l$name;
    }
    if (_$data.containsKey('color')) {
      final l$color = color;
      result$data['color'] = l$color == null
          ? null
          : toJson$Enum$AppColorScheme(l$color);
    }
    return result$data;
  }

  CopyWith$Input$AppConfigInfoInput<Input$AppConfigInfoInput> get copyWith =>
      CopyWith$Input$AppConfigInfoInput(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Input$AppConfigInfoInput ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$logo = logo;
    final lOther$logo = other.logo;
    if (_$data.containsKey('logo') != other._$data.containsKey('logo')) {
      return false;
    }
    if (l$logo != lOther$logo) {
      return false;
    }
    final l$name = name;
    final lOther$name = other.name;
    if (_$data.containsKey('name') != other._$data.containsKey('name')) {
      return false;
    }
    if (l$name != lOther$name) {
      return false;
    }
    final l$color = color;
    final lOther$color = other.color;
    if (_$data.containsKey('color') != other._$data.containsKey('color')) {
      return false;
    }
    if (l$color != lOther$color) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$logo = logo;
    final l$name = name;
    final l$color = color;
    return Object.hashAll([
      _$data.containsKey('logo') ? l$logo : const {},
      _$data.containsKey('name') ? l$name : const {},
      _$data.containsKey('color') ? l$color : const {},
    ]);
  }
}

abstract class CopyWith$Input$AppConfigInfoInput<TRes> {
  factory CopyWith$Input$AppConfigInfoInput(
    Input$AppConfigInfoInput instance,
    TRes Function(Input$AppConfigInfoInput) then,
  ) = _CopyWithImpl$Input$AppConfigInfoInput;

  factory CopyWith$Input$AppConfigInfoInput.stub(TRes res) =
      _CopyWithStubImpl$Input$AppConfigInfoInput;

  TRes call({String? logo, String? name, Enum$AppColorScheme? color});
}

class _CopyWithImpl$Input$AppConfigInfoInput<TRes>
    implements CopyWith$Input$AppConfigInfoInput<TRes> {
  _CopyWithImpl$Input$AppConfigInfoInput(this._instance, this._then);

  final Input$AppConfigInfoInput _instance;

  final TRes Function(Input$AppConfigInfoInput) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? logo = _undefined,
    Object? name = _undefined,
    Object? color = _undefined,
  }) => _then(
    Input$AppConfigInfoInput._({
      ..._instance._$data,
      if (logo != _undefined) 'logo': (logo as String?),
      if (name != _undefined) 'name': (name as String?),
      if (color != _undefined) 'color': (color as Enum$AppColorScheme?),
    }),
  );
}

class _CopyWithStubImpl$Input$AppConfigInfoInput<TRes>
    implements CopyWith$Input$AppConfigInfoInput<TRes> {
  _CopyWithStubImpl$Input$AppConfigInfoInput(this._res);

  TRes _res;

  call({String? logo, String? name, Enum$AppColorScheme? color}) => _res;
}

class Input$OpeningHoursInput {
  factory Input$OpeningHoursInput({
    required String open,
    required String close,
  }) => Input$OpeningHoursInput._({r'open': open, r'close': close});

  Input$OpeningHoursInput._(this._$data);

  factory Input$OpeningHoursInput.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$open = data['open'];
    result$data['open'] = (l$open as String);
    final l$close = data['close'];
    result$data['close'] = (l$close as String);
    return Input$OpeningHoursInput._(result$data);
  }

  Map<String, dynamic> _$data;

  String get open => (_$data['open'] as String);

  String get close => (_$data['close'] as String);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$open = open;
    result$data['open'] = l$open;
    final l$close = close;
    result$data['close'] = l$close;
    return result$data;
  }

  CopyWith$Input$OpeningHoursInput<Input$OpeningHoursInput> get copyWith =>
      CopyWith$Input$OpeningHoursInput(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Input$OpeningHoursInput || runtimeType != other.runtimeType) {
      return false;
    }
    final l$open = open;
    final lOther$open = other.open;
    if (l$open != lOther$open) {
      return false;
    }
    final l$close = close;
    final lOther$close = other.close;
    if (l$close != lOther$close) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$open = open;
    final l$close = close;
    return Object.hashAll([l$open, l$close]);
  }
}

abstract class CopyWith$Input$OpeningHoursInput<TRes> {
  factory CopyWith$Input$OpeningHoursInput(
    Input$OpeningHoursInput instance,
    TRes Function(Input$OpeningHoursInput) then,
  ) = _CopyWithImpl$Input$OpeningHoursInput;

  factory CopyWith$Input$OpeningHoursInput.stub(TRes res) =
      _CopyWithStubImpl$Input$OpeningHoursInput;

  TRes call({String? open, String? close});
}

class _CopyWithImpl$Input$OpeningHoursInput<TRes>
    implements CopyWith$Input$OpeningHoursInput<TRes> {
  _CopyWithImpl$Input$OpeningHoursInput(this._instance, this._then);

  final Input$OpeningHoursInput _instance;

  final TRes Function(Input$OpeningHoursInput) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? open = _undefined, Object? close = _undefined}) => _then(
    Input$OpeningHoursInput._({
      ..._instance._$data,
      if (open != _undefined && open != null) 'open': (open as String),
      if (close != _undefined && close != null) 'close': (close as String),
    }),
  );
}

class _CopyWithStubImpl$Input$OpeningHoursInput<TRes>
    implements CopyWith$Input$OpeningHoursInput<TRes> {
  _CopyWithStubImpl$Input$OpeningHoursInput(this._res);

  TRes _res;

  call({String? open, String? close}) => _res;
}

class Input$PhoneNumberInput {
  factory Input$PhoneNumberInput({
    required String countryCode,
    required String number,
  }) => Input$PhoneNumberInput._({
    r'countryCode': countryCode,
    r'number': number,
  });

  Input$PhoneNumberInput._(this._$data);

  factory Input$PhoneNumberInput.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$countryCode = data['countryCode'];
    result$data['countryCode'] = (l$countryCode as String);
    final l$number = data['number'];
    result$data['number'] = (l$number as String);
    return Input$PhoneNumberInput._(result$data);
  }

  Map<String, dynamic> _$data;

  String get countryCode => (_$data['countryCode'] as String);

  String get number => (_$data['number'] as String);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$countryCode = countryCode;
    result$data['countryCode'] = l$countryCode;
    final l$number = number;
    result$data['number'] = l$number;
    return result$data;
  }

  CopyWith$Input$PhoneNumberInput<Input$PhoneNumberInput> get copyWith =>
      CopyWith$Input$PhoneNumberInput(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Input$PhoneNumberInput || runtimeType != other.runtimeType) {
      return false;
    }
    final l$countryCode = countryCode;
    final lOther$countryCode = other.countryCode;
    if (l$countryCode != lOther$countryCode) {
      return false;
    }
    final l$number = number;
    final lOther$number = other.number;
    if (l$number != lOther$number) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$countryCode = countryCode;
    final l$number = number;
    return Object.hashAll([l$countryCode, l$number]);
  }
}

abstract class CopyWith$Input$PhoneNumberInput<TRes> {
  factory CopyWith$Input$PhoneNumberInput(
    Input$PhoneNumberInput instance,
    TRes Function(Input$PhoneNumberInput) then,
  ) = _CopyWithImpl$Input$PhoneNumberInput;

  factory CopyWith$Input$PhoneNumberInput.stub(TRes res) =
      _CopyWithStubImpl$Input$PhoneNumberInput;

  TRes call({String? countryCode, String? number});
}

class _CopyWithImpl$Input$PhoneNumberInput<TRes>
    implements CopyWith$Input$PhoneNumberInput<TRes> {
  _CopyWithImpl$Input$PhoneNumberInput(this._instance, this._then);

  final Input$PhoneNumberInput _instance;

  final TRes Function(Input$PhoneNumberInput) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? countryCode = _undefined, Object? number = _undefined}) =>
      _then(
        Input$PhoneNumberInput._({
          ..._instance._$data,
          if (countryCode != _undefined && countryCode != null)
            'countryCode': (countryCode as String),
          if (number != _undefined && number != null)
            'number': (number as String),
        }),
      );
}

class _CopyWithStubImpl$Input$PhoneNumberInput<TRes>
    implements CopyWith$Input$PhoneNumberInput<TRes> {
  _CopyWithStubImpl$Input$PhoneNumberInput(this._res);

  TRes _res;

  call({String? countryCode, String? number}) => _res;
}

class Input$DeliveryContactInput {
  factory Input$DeliveryContactInput({
    required String name,
    required Input$PhoneNumberInput phoneNumber,
    String? email,
    required String addressLine1,
    String? addressLine2,
    String? zone,
    String? buildingNumber,
    String? apartmentNumber,
    String? city,
    String? state,
    String? instructions,
    String? postalCode,
    String? companyName,
  }) => Input$DeliveryContactInput._({
    r'name': name,
    r'phoneNumber': phoneNumber,
    if (email != null) r'email': email,
    r'addressLine1': addressLine1,
    if (addressLine2 != null) r'addressLine2': addressLine2,
    if (zone != null) r'zone': zone,
    if (buildingNumber != null) r'buildingNumber': buildingNumber,
    if (apartmentNumber != null) r'apartmentNumber': apartmentNumber,
    if (city != null) r'city': city,
    if (state != null) r'state': state,
    if (instructions != null) r'instructions': instructions,
    if (postalCode != null) r'postalCode': postalCode,
    if (companyName != null) r'companyName': companyName,
  });

  Input$DeliveryContactInput._(this._$data);

  factory Input$DeliveryContactInput.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$name = data['name'];
    result$data['name'] = (l$name as String);
    final l$phoneNumber = data['phoneNumber'];
    result$data['phoneNumber'] = Input$PhoneNumberInput.fromJson(
      (l$phoneNumber as Map<String, dynamic>),
    );
    if (data.containsKey('email')) {
      final l$email = data['email'];
      result$data['email'] = (l$email as String?);
    }
    final l$addressLine1 = data['addressLine1'];
    result$data['addressLine1'] = (l$addressLine1 as String);
    if (data.containsKey('addressLine2')) {
      final l$addressLine2 = data['addressLine2'];
      result$data['addressLine2'] = (l$addressLine2 as String?);
    }
    if (data.containsKey('zone')) {
      final l$zone = data['zone'];
      result$data['zone'] = (l$zone as String?);
    }
    if (data.containsKey('buildingNumber')) {
      final l$buildingNumber = data['buildingNumber'];
      result$data['buildingNumber'] = (l$buildingNumber as String?);
    }
    if (data.containsKey('apartmentNumber')) {
      final l$apartmentNumber = data['apartmentNumber'];
      result$data['apartmentNumber'] = (l$apartmentNumber as String?);
    }
    if (data.containsKey('city')) {
      final l$city = data['city'];
      result$data['city'] = (l$city as String?);
    }
    if (data.containsKey('state')) {
      final l$state = data['state'];
      result$data['state'] = (l$state as String?);
    }
    if (data.containsKey('instructions')) {
      final l$instructions = data['instructions'];
      result$data['instructions'] = (l$instructions as String?);
    }
    if (data.containsKey('postalCode')) {
      final l$postalCode = data['postalCode'];
      result$data['postalCode'] = (l$postalCode as String?);
    }
    if (data.containsKey('companyName')) {
      final l$companyName = data['companyName'];
      result$data['companyName'] = (l$companyName as String?);
    }
    return Input$DeliveryContactInput._(result$data);
  }

  Map<String, dynamic> _$data;

  String get name => (_$data['name'] as String);

  Input$PhoneNumberInput get phoneNumber =>
      (_$data['phoneNumber'] as Input$PhoneNumberInput);

  String? get email => (_$data['email'] as String?);

  String get addressLine1 => (_$data['addressLine1'] as String);

  String? get addressLine2 => (_$data['addressLine2'] as String?);

  String? get zone => (_$data['zone'] as String?);

  String? get buildingNumber => (_$data['buildingNumber'] as String?);

  String? get apartmentNumber => (_$data['apartmentNumber'] as String?);

  String? get city => (_$data['city'] as String?);

  String? get state => (_$data['state'] as String?);

  String? get instructions => (_$data['instructions'] as String?);

  String? get postalCode => (_$data['postalCode'] as String?);

  String? get companyName => (_$data['companyName'] as String?);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$name = name;
    result$data['name'] = l$name;
    final l$phoneNumber = phoneNumber;
    result$data['phoneNumber'] = l$phoneNumber.toJson();
    if (_$data.containsKey('email')) {
      final l$email = email;
      result$data['email'] = l$email;
    }
    final l$addressLine1 = addressLine1;
    result$data['addressLine1'] = l$addressLine1;
    if (_$data.containsKey('addressLine2')) {
      final l$addressLine2 = addressLine2;
      result$data['addressLine2'] = l$addressLine2;
    }
    if (_$data.containsKey('zone')) {
      final l$zone = zone;
      result$data['zone'] = l$zone;
    }
    if (_$data.containsKey('buildingNumber')) {
      final l$buildingNumber = buildingNumber;
      result$data['buildingNumber'] = l$buildingNumber;
    }
    if (_$data.containsKey('apartmentNumber')) {
      final l$apartmentNumber = apartmentNumber;
      result$data['apartmentNumber'] = l$apartmentNumber;
    }
    if (_$data.containsKey('city')) {
      final l$city = city;
      result$data['city'] = l$city;
    }
    if (_$data.containsKey('state')) {
      final l$state = state;
      result$data['state'] = l$state;
    }
    if (_$data.containsKey('instructions')) {
      final l$instructions = instructions;
      result$data['instructions'] = l$instructions;
    }
    if (_$data.containsKey('postalCode')) {
      final l$postalCode = postalCode;
      result$data['postalCode'] = l$postalCode;
    }
    if (_$data.containsKey('companyName')) {
      final l$companyName = companyName;
      result$data['companyName'] = l$companyName;
    }
    return result$data;
  }

  CopyWith$Input$DeliveryContactInput<Input$DeliveryContactInput>
  get copyWith => CopyWith$Input$DeliveryContactInput(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Input$DeliveryContactInput ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$name = name;
    final lOther$name = other.name;
    if (l$name != lOther$name) {
      return false;
    }
    final l$phoneNumber = phoneNumber;
    final lOther$phoneNumber = other.phoneNumber;
    if (l$phoneNumber != lOther$phoneNumber) {
      return false;
    }
    final l$email = email;
    final lOther$email = other.email;
    if (_$data.containsKey('email') != other._$data.containsKey('email')) {
      return false;
    }
    if (l$email != lOther$email) {
      return false;
    }
    final l$addressLine1 = addressLine1;
    final lOther$addressLine1 = other.addressLine1;
    if (l$addressLine1 != lOther$addressLine1) {
      return false;
    }
    final l$addressLine2 = addressLine2;
    final lOther$addressLine2 = other.addressLine2;
    if (_$data.containsKey('addressLine2') !=
        other._$data.containsKey('addressLine2')) {
      return false;
    }
    if (l$addressLine2 != lOther$addressLine2) {
      return false;
    }
    final l$zone = zone;
    final lOther$zone = other.zone;
    if (_$data.containsKey('zone') != other._$data.containsKey('zone')) {
      return false;
    }
    if (l$zone != lOther$zone) {
      return false;
    }
    final l$buildingNumber = buildingNumber;
    final lOther$buildingNumber = other.buildingNumber;
    if (_$data.containsKey('buildingNumber') !=
        other._$data.containsKey('buildingNumber')) {
      return false;
    }
    if (l$buildingNumber != lOther$buildingNumber) {
      return false;
    }
    final l$apartmentNumber = apartmentNumber;
    final lOther$apartmentNumber = other.apartmentNumber;
    if (_$data.containsKey('apartmentNumber') !=
        other._$data.containsKey('apartmentNumber')) {
      return false;
    }
    if (l$apartmentNumber != lOther$apartmentNumber) {
      return false;
    }
    final l$city = city;
    final lOther$city = other.city;
    if (_$data.containsKey('city') != other._$data.containsKey('city')) {
      return false;
    }
    if (l$city != lOther$city) {
      return false;
    }
    final l$state = state;
    final lOther$state = other.state;
    if (_$data.containsKey('state') != other._$data.containsKey('state')) {
      return false;
    }
    if (l$state != lOther$state) {
      return false;
    }
    final l$instructions = instructions;
    final lOther$instructions = other.instructions;
    if (_$data.containsKey('instructions') !=
        other._$data.containsKey('instructions')) {
      return false;
    }
    if (l$instructions != lOther$instructions) {
      return false;
    }
    final l$postalCode = postalCode;
    final lOther$postalCode = other.postalCode;
    if (_$data.containsKey('postalCode') !=
        other._$data.containsKey('postalCode')) {
      return false;
    }
    if (l$postalCode != lOther$postalCode) {
      return false;
    }
    final l$companyName = companyName;
    final lOther$companyName = other.companyName;
    if (_$data.containsKey('companyName') !=
        other._$data.containsKey('companyName')) {
      return false;
    }
    if (l$companyName != lOther$companyName) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$name = name;
    final l$phoneNumber = phoneNumber;
    final l$email = email;
    final l$addressLine1 = addressLine1;
    final l$addressLine2 = addressLine2;
    final l$zone = zone;
    final l$buildingNumber = buildingNumber;
    final l$apartmentNumber = apartmentNumber;
    final l$city = city;
    final l$state = state;
    final l$instructions = instructions;
    final l$postalCode = postalCode;
    final l$companyName = companyName;
    return Object.hashAll([
      l$name,
      l$phoneNumber,
      _$data.containsKey('email') ? l$email : const {},
      l$addressLine1,
      _$data.containsKey('addressLine2') ? l$addressLine2 : const {},
      _$data.containsKey('zone') ? l$zone : const {},
      _$data.containsKey('buildingNumber') ? l$buildingNumber : const {},
      _$data.containsKey('apartmentNumber') ? l$apartmentNumber : const {},
      _$data.containsKey('city') ? l$city : const {},
      _$data.containsKey('state') ? l$state : const {},
      _$data.containsKey('instructions') ? l$instructions : const {},
      _$data.containsKey('postalCode') ? l$postalCode : const {},
      _$data.containsKey('companyName') ? l$companyName : const {},
    ]);
  }
}

abstract class CopyWith$Input$DeliveryContactInput<TRes> {
  factory CopyWith$Input$DeliveryContactInput(
    Input$DeliveryContactInput instance,
    TRes Function(Input$DeliveryContactInput) then,
  ) = _CopyWithImpl$Input$DeliveryContactInput;

  factory CopyWith$Input$DeliveryContactInput.stub(TRes res) =
      _CopyWithStubImpl$Input$DeliveryContactInput;

  TRes call({
    String? name,
    Input$PhoneNumberInput? phoneNumber,
    String? email,
    String? addressLine1,
    String? addressLine2,
    String? zone,
    String? buildingNumber,
    String? apartmentNumber,
    String? city,
    String? state,
    String? instructions,
    String? postalCode,
    String? companyName,
  });
  CopyWith$Input$PhoneNumberInput<TRes> get phoneNumber;
}

class _CopyWithImpl$Input$DeliveryContactInput<TRes>
    implements CopyWith$Input$DeliveryContactInput<TRes> {
  _CopyWithImpl$Input$DeliveryContactInput(this._instance, this._then);

  final Input$DeliveryContactInput _instance;

  final TRes Function(Input$DeliveryContactInput) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? name = _undefined,
    Object? phoneNumber = _undefined,
    Object? email = _undefined,
    Object? addressLine1 = _undefined,
    Object? addressLine2 = _undefined,
    Object? zone = _undefined,
    Object? buildingNumber = _undefined,
    Object? apartmentNumber = _undefined,
    Object? city = _undefined,
    Object? state = _undefined,
    Object? instructions = _undefined,
    Object? postalCode = _undefined,
    Object? companyName = _undefined,
  }) => _then(
    Input$DeliveryContactInput._({
      ..._instance._$data,
      if (name != _undefined && name != null) 'name': (name as String),
      if (phoneNumber != _undefined && phoneNumber != null)
        'phoneNumber': (phoneNumber as Input$PhoneNumberInput),
      if (email != _undefined) 'email': (email as String?),
      if (addressLine1 != _undefined && addressLine1 != null)
        'addressLine1': (addressLine1 as String),
      if (addressLine2 != _undefined) 'addressLine2': (addressLine2 as String?),
      if (zone != _undefined) 'zone': (zone as String?),
      if (buildingNumber != _undefined)
        'buildingNumber': (buildingNumber as String?),
      if (apartmentNumber != _undefined)
        'apartmentNumber': (apartmentNumber as String?),
      if (city != _undefined) 'city': (city as String?),
      if (state != _undefined) 'state': (state as String?),
      if (instructions != _undefined) 'instructions': (instructions as String?),
      if (postalCode != _undefined) 'postalCode': (postalCode as String?),
      if (companyName != _undefined) 'companyName': (companyName as String?),
    }),
  );

  CopyWith$Input$PhoneNumberInput<TRes> get phoneNumber {
    final local$phoneNumber = _instance.phoneNumber;
    return CopyWith$Input$PhoneNumberInput(
      local$phoneNumber,
      (e) => call(phoneNumber: e),
    );
  }
}

class _CopyWithStubImpl$Input$DeliveryContactInput<TRes>
    implements CopyWith$Input$DeliveryContactInput<TRes> {
  _CopyWithStubImpl$Input$DeliveryContactInput(this._res);

  TRes _res;

  call({
    String? name,
    Input$PhoneNumberInput? phoneNumber,
    String? email,
    String? addressLine1,
    String? addressLine2,
    String? zone,
    String? buildingNumber,
    String? apartmentNumber,
    String? city,
    String? state,
    String? instructions,
    String? postalCode,
    String? companyName,
  }) => _res;

  CopyWith$Input$PhoneNumberInput<TRes> get phoneNumber =>
      CopyWith$Input$PhoneNumberInput.stub(_res);
}

class Input$CalculateFareInput {
  factory Input$CalculateFareInput({
    required List<Input$PointInput> points,
    Enum$TaxiOrderType? orderType,
    bool? twoWay,
    String? couponCode,
    List<String>? selectedOptionIds,
    int? waitTime,
  }) => Input$CalculateFareInput._({
    r'points': points,
    if (orderType != null) r'orderType': orderType,
    if (twoWay != null) r'twoWay': twoWay,
    if (couponCode != null) r'couponCode': couponCode,
    if (selectedOptionIds != null) r'selectedOptionIds': selectedOptionIds,
    if (waitTime != null) r'waitTime': waitTime,
  });

  Input$CalculateFareInput._(this._$data);

  factory Input$CalculateFareInput.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$points = data['points'];
    result$data['points'] = (l$points as List<dynamic>)
        .map((e) => Input$PointInput.fromJson((e as Map<String, dynamic>)))
        .toList();
    if (data.containsKey('orderType')) {
      final l$orderType = data['orderType'];
      result$data['orderType'] = fromJson$Enum$TaxiOrderType(
        (l$orderType as String),
      );
    }
    if (data.containsKey('twoWay')) {
      final l$twoWay = data['twoWay'];
      result$data['twoWay'] = (l$twoWay as bool?);
    }
    if (data.containsKey('couponCode')) {
      final l$couponCode = data['couponCode'];
      result$data['couponCode'] = (l$couponCode as String?);
    }
    if (data.containsKey('selectedOptionIds')) {
      final l$selectedOptionIds = data['selectedOptionIds'];
      result$data['selectedOptionIds'] = (l$selectedOptionIds as List<dynamic>?)
          ?.map((e) => (e as String))
          .toList();
    }
    if (data.containsKey('waitTime')) {
      final l$waitTime = data['waitTime'];
      result$data['waitTime'] = (l$waitTime as int?);
    }
    return Input$CalculateFareInput._(result$data);
  }

  Map<String, dynamic> _$data;

  List<Input$PointInput> get points =>
      (_$data['points'] as List<Input$PointInput>);

  Enum$TaxiOrderType? get orderType =>
      (_$data['orderType'] as Enum$TaxiOrderType?);

  bool? get twoWay => (_$data['twoWay'] as bool?);

  String? get couponCode => (_$data['couponCode'] as String?);

  List<String>? get selectedOptionIds =>
      (_$data['selectedOptionIds'] as List<String>?);

  int? get waitTime => (_$data['waitTime'] as int?);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$points = points;
    result$data['points'] = l$points.map((e) => e.toJson()).toList();
    if (_$data.containsKey('orderType')) {
      final l$orderType = orderType;
      result$data['orderType'] = toJson$Enum$TaxiOrderType(
        (l$orderType as Enum$TaxiOrderType),
      );
    }
    if (_$data.containsKey('twoWay')) {
      final l$twoWay = twoWay;
      result$data['twoWay'] = l$twoWay;
    }
    if (_$data.containsKey('couponCode')) {
      final l$couponCode = couponCode;
      result$data['couponCode'] = l$couponCode;
    }
    if (_$data.containsKey('selectedOptionIds')) {
      final l$selectedOptionIds = selectedOptionIds;
      result$data['selectedOptionIds'] = l$selectedOptionIds
          ?.map((e) => e)
          .toList();
    }
    if (_$data.containsKey('waitTime')) {
      final l$waitTime = waitTime;
      result$data['waitTime'] = l$waitTime;
    }
    return result$data;
  }

  CopyWith$Input$CalculateFareInput<Input$CalculateFareInput> get copyWith =>
      CopyWith$Input$CalculateFareInput(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Input$CalculateFareInput ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$points = points;
    final lOther$points = other.points;
    if (l$points.length != lOther$points.length) {
      return false;
    }
    for (int i = 0; i < l$points.length; i++) {
      final l$points$entry = l$points[i];
      final lOther$points$entry = lOther$points[i];
      if (l$points$entry != lOther$points$entry) {
        return false;
      }
    }
    final l$orderType = orderType;
    final lOther$orderType = other.orderType;
    if (_$data.containsKey('orderType') !=
        other._$data.containsKey('orderType')) {
      return false;
    }
    if (l$orderType != lOther$orderType) {
      return false;
    }
    final l$twoWay = twoWay;
    final lOther$twoWay = other.twoWay;
    if (_$data.containsKey('twoWay') != other._$data.containsKey('twoWay')) {
      return false;
    }
    if (l$twoWay != lOther$twoWay) {
      return false;
    }
    final l$couponCode = couponCode;
    final lOther$couponCode = other.couponCode;
    if (_$data.containsKey('couponCode') !=
        other._$data.containsKey('couponCode')) {
      return false;
    }
    if (l$couponCode != lOther$couponCode) {
      return false;
    }
    final l$selectedOptionIds = selectedOptionIds;
    final lOther$selectedOptionIds = other.selectedOptionIds;
    if (_$data.containsKey('selectedOptionIds') !=
        other._$data.containsKey('selectedOptionIds')) {
      return false;
    }
    if (l$selectedOptionIds != null && lOther$selectedOptionIds != null) {
      if (l$selectedOptionIds.length != lOther$selectedOptionIds.length) {
        return false;
      }
      for (int i = 0; i < l$selectedOptionIds.length; i++) {
        final l$selectedOptionIds$entry = l$selectedOptionIds[i];
        final lOther$selectedOptionIds$entry = lOther$selectedOptionIds[i];
        if (l$selectedOptionIds$entry != lOther$selectedOptionIds$entry) {
          return false;
        }
      }
    } else if (l$selectedOptionIds != lOther$selectedOptionIds) {
      return false;
    }
    final l$waitTime = waitTime;
    final lOther$waitTime = other.waitTime;
    if (_$data.containsKey('waitTime') !=
        other._$data.containsKey('waitTime')) {
      return false;
    }
    if (l$waitTime != lOther$waitTime) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$points = points;
    final l$orderType = orderType;
    final l$twoWay = twoWay;
    final l$couponCode = couponCode;
    final l$selectedOptionIds = selectedOptionIds;
    final l$waitTime = waitTime;
    return Object.hashAll([
      Object.hashAll(l$points.map((v) => v)),
      _$data.containsKey('orderType') ? l$orderType : const {},
      _$data.containsKey('twoWay') ? l$twoWay : const {},
      _$data.containsKey('couponCode') ? l$couponCode : const {},
      _$data.containsKey('selectedOptionIds')
          ? l$selectedOptionIds == null
                ? null
                : Object.hashAll(l$selectedOptionIds.map((v) => v))
          : const {},
      _$data.containsKey('waitTime') ? l$waitTime : const {},
    ]);
  }
}

abstract class CopyWith$Input$CalculateFareInput<TRes> {
  factory CopyWith$Input$CalculateFareInput(
    Input$CalculateFareInput instance,
    TRes Function(Input$CalculateFareInput) then,
  ) = _CopyWithImpl$Input$CalculateFareInput;

  factory CopyWith$Input$CalculateFareInput.stub(TRes res) =
      _CopyWithStubImpl$Input$CalculateFareInput;

  TRes call({
    List<Input$PointInput>? points,
    Enum$TaxiOrderType? orderType,
    bool? twoWay,
    String? couponCode,
    List<String>? selectedOptionIds,
    int? waitTime,
  });
  TRes points(
    Iterable<Input$PointInput> Function(
      Iterable<CopyWith$Input$PointInput<Input$PointInput>>,
    )
    _fn,
  );
}

class _CopyWithImpl$Input$CalculateFareInput<TRes>
    implements CopyWith$Input$CalculateFareInput<TRes> {
  _CopyWithImpl$Input$CalculateFareInput(this._instance, this._then);

  final Input$CalculateFareInput _instance;

  final TRes Function(Input$CalculateFareInput) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? points = _undefined,
    Object? orderType = _undefined,
    Object? twoWay = _undefined,
    Object? couponCode = _undefined,
    Object? selectedOptionIds = _undefined,
    Object? waitTime = _undefined,
  }) => _then(
    Input$CalculateFareInput._({
      ..._instance._$data,
      if (points != _undefined && points != null)
        'points': (points as List<Input$PointInput>),
      if (orderType != _undefined && orderType != null)
        'orderType': (orderType as Enum$TaxiOrderType),
      if (twoWay != _undefined) 'twoWay': (twoWay as bool?),
      if (couponCode != _undefined) 'couponCode': (couponCode as String?),
      if (selectedOptionIds != _undefined)
        'selectedOptionIds': (selectedOptionIds as List<String>?),
      if (waitTime != _undefined) 'waitTime': (waitTime as int?),
    }),
  );

  TRes points(
    Iterable<Input$PointInput> Function(
      Iterable<CopyWith$Input$PointInput<Input$PointInput>>,
    )
    _fn,
  ) => call(
    points: _fn(
      _instance.points.map((e) => CopyWith$Input$PointInput(e, (i) => i)),
    ).toList(),
  );
}

class _CopyWithStubImpl$Input$CalculateFareInput<TRes>
    implements CopyWith$Input$CalculateFareInput<TRes> {
  _CopyWithStubImpl$Input$CalculateFareInput(this._res);

  TRes _res;

  call({
    List<Input$PointInput>? points,
    Enum$TaxiOrderType? orderType,
    bool? twoWay,
    String? couponCode,
    List<String>? selectedOptionIds,
    int? waitTime,
  }) => _res;

  points(_fn) => _res;
}

class Input$UpdateRiderInput {
  factory Input$UpdateRiderInput({
    String? firstName,
    String? lastName,
    Enum$Gender? gender,
    String? email,
  }) => Input$UpdateRiderInput._({
    if (firstName != null) r'firstName': firstName,
    if (lastName != null) r'lastName': lastName,
    if (gender != null) r'gender': gender,
    if (email != null) r'email': email,
  });

  Input$UpdateRiderInput._(this._$data);

  factory Input$UpdateRiderInput.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    if (data.containsKey('firstName')) {
      final l$firstName = data['firstName'];
      result$data['firstName'] = (l$firstName as String?);
    }
    if (data.containsKey('lastName')) {
      final l$lastName = data['lastName'];
      result$data['lastName'] = (l$lastName as String?);
    }
    if (data.containsKey('gender')) {
      final l$gender = data['gender'];
      result$data['gender'] = l$gender == null
          ? null
          : fromJson$Enum$Gender((l$gender as String));
    }
    if (data.containsKey('email')) {
      final l$email = data['email'];
      result$data['email'] = (l$email as String?);
    }
    return Input$UpdateRiderInput._(result$data);
  }

  Map<String, dynamic> _$data;

  String? get firstName => (_$data['firstName'] as String?);

  String? get lastName => (_$data['lastName'] as String?);

  Enum$Gender? get gender => (_$data['gender'] as Enum$Gender?);

  String? get email => (_$data['email'] as String?);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    if (_$data.containsKey('firstName')) {
      final l$firstName = firstName;
      result$data['firstName'] = l$firstName;
    }
    if (_$data.containsKey('lastName')) {
      final l$lastName = lastName;
      result$data['lastName'] = l$lastName;
    }
    if (_$data.containsKey('gender')) {
      final l$gender = gender;
      result$data['gender'] = l$gender == null
          ? null
          : toJson$Enum$Gender(l$gender);
    }
    if (_$data.containsKey('email')) {
      final l$email = email;
      result$data['email'] = l$email;
    }
    return result$data;
  }

  CopyWith$Input$UpdateRiderInput<Input$UpdateRiderInput> get copyWith =>
      CopyWith$Input$UpdateRiderInput(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Input$UpdateRiderInput || runtimeType != other.runtimeType) {
      return false;
    }
    final l$firstName = firstName;
    final lOther$firstName = other.firstName;
    if (_$data.containsKey('firstName') !=
        other._$data.containsKey('firstName')) {
      return false;
    }
    if (l$firstName != lOther$firstName) {
      return false;
    }
    final l$lastName = lastName;
    final lOther$lastName = other.lastName;
    if (_$data.containsKey('lastName') !=
        other._$data.containsKey('lastName')) {
      return false;
    }
    if (l$lastName != lOther$lastName) {
      return false;
    }
    final l$gender = gender;
    final lOther$gender = other.gender;
    if (_$data.containsKey('gender') != other._$data.containsKey('gender')) {
      return false;
    }
    if (l$gender != lOther$gender) {
      return false;
    }
    final l$email = email;
    final lOther$email = other.email;
    if (_$data.containsKey('email') != other._$data.containsKey('email')) {
      return false;
    }
    if (l$email != lOther$email) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$firstName = firstName;
    final l$lastName = lastName;
    final l$gender = gender;
    final l$email = email;
    return Object.hashAll([
      _$data.containsKey('firstName') ? l$firstName : const {},
      _$data.containsKey('lastName') ? l$lastName : const {},
      _$data.containsKey('gender') ? l$gender : const {},
      _$data.containsKey('email') ? l$email : const {},
    ]);
  }
}

abstract class CopyWith$Input$UpdateRiderInput<TRes> {
  factory CopyWith$Input$UpdateRiderInput(
    Input$UpdateRiderInput instance,
    TRes Function(Input$UpdateRiderInput) then,
  ) = _CopyWithImpl$Input$UpdateRiderInput;

  factory CopyWith$Input$UpdateRiderInput.stub(TRes res) =
      _CopyWithStubImpl$Input$UpdateRiderInput;

  TRes call({
    String? firstName,
    String? lastName,
    Enum$Gender? gender,
    String? email,
  });
}

class _CopyWithImpl$Input$UpdateRiderInput<TRes>
    implements CopyWith$Input$UpdateRiderInput<TRes> {
  _CopyWithImpl$Input$UpdateRiderInput(this._instance, this._then);

  final Input$UpdateRiderInput _instance;

  final TRes Function(Input$UpdateRiderInput) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? firstName = _undefined,
    Object? lastName = _undefined,
    Object? gender = _undefined,
    Object? email = _undefined,
  }) => _then(
    Input$UpdateRiderInput._({
      ..._instance._$data,
      if (firstName != _undefined) 'firstName': (firstName as String?),
      if (lastName != _undefined) 'lastName': (lastName as String?),
      if (gender != _undefined) 'gender': (gender as Enum$Gender?),
      if (email != _undefined) 'email': (email as String?),
    }),
  );
}

class _CopyWithStubImpl$Input$UpdateRiderInput<TRes>
    implements CopyWith$Input$UpdateRiderInput<TRes> {
  _CopyWithStubImpl$Input$UpdateRiderInput(this._res);

  TRes _res;

  call({
    String? firstName,
    String? lastName,
    Enum$Gender? gender,
    String? email,
  }) => _res;
}

class Input$CreateOrderInput {
  factory Input$CreateOrderInput({
    required int serviceId,
    Enum$TaxiOrderType? orderType,
    required List<Input$WaypointInput> waypoints,
    int? intervalMinutes,
    bool? twoWay,
    int? waitTime,
    List<String>? optionIds,
    String? couponCode,
    Enum$PaymentMode? paymentMode,
    String? paymentMethodId,
  }) => Input$CreateOrderInput._({
    r'serviceId': serviceId,
    if (orderType != null) r'orderType': orderType,
    r'waypoints': waypoints,
    if (intervalMinutes != null) r'intervalMinutes': intervalMinutes,
    if (twoWay != null) r'twoWay': twoWay,
    if (waitTime != null) r'waitTime': waitTime,
    if (optionIds != null) r'optionIds': optionIds,
    if (couponCode != null) r'couponCode': couponCode,
    if (paymentMode != null) r'paymentMode': paymentMode,
    if (paymentMethodId != null) r'paymentMethodId': paymentMethodId,
  });

  Input$CreateOrderInput._(this._$data);

  factory Input$CreateOrderInput.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$serviceId = data['serviceId'];
    result$data['serviceId'] = (l$serviceId as int);
    if (data.containsKey('orderType')) {
      final l$orderType = data['orderType'];
      result$data['orderType'] = fromJson$Enum$TaxiOrderType(
        (l$orderType as String),
      );
    }
    final l$waypoints = data['waypoints'];
    result$data['waypoints'] = (l$waypoints as List<dynamic>)
        .map((e) => Input$WaypointInput.fromJson((e as Map<String, dynamic>)))
        .toList();
    if (data.containsKey('intervalMinutes')) {
      final l$intervalMinutes = data['intervalMinutes'];
      result$data['intervalMinutes'] = (l$intervalMinutes as int?);
    }
    if (data.containsKey('twoWay')) {
      final l$twoWay = data['twoWay'];
      result$data['twoWay'] = (l$twoWay as bool?);
    }
    if (data.containsKey('waitTime')) {
      final l$waitTime = data['waitTime'];
      result$data['waitTime'] = (l$waitTime as int?);
    }
    if (data.containsKey('optionIds')) {
      final l$optionIds = data['optionIds'];
      result$data['optionIds'] = (l$optionIds as List<dynamic>?)
          ?.map((e) => (e as String))
          .toList();
    }
    if (data.containsKey('couponCode')) {
      final l$couponCode = data['couponCode'];
      result$data['couponCode'] = (l$couponCode as String?);
    }
    if (data.containsKey('paymentMode')) {
      final l$paymentMode = data['paymentMode'];
      result$data['paymentMode'] = l$paymentMode == null
          ? null
          : fromJson$Enum$PaymentMode((l$paymentMode as String));
    }
    if (data.containsKey('paymentMethodId')) {
      final l$paymentMethodId = data['paymentMethodId'];
      result$data['paymentMethodId'] = (l$paymentMethodId as String?);
    }
    return Input$CreateOrderInput._(result$data);
  }

  Map<String, dynamic> _$data;

  int get serviceId => (_$data['serviceId'] as int);

  Enum$TaxiOrderType? get orderType =>
      (_$data['orderType'] as Enum$TaxiOrderType?);

  List<Input$WaypointInput> get waypoints =>
      (_$data['waypoints'] as List<Input$WaypointInput>);

  int? get intervalMinutes => (_$data['intervalMinutes'] as int?);

  bool? get twoWay => (_$data['twoWay'] as bool?);

  int? get waitTime => (_$data['waitTime'] as int?);

  List<String>? get optionIds => (_$data['optionIds'] as List<String>?);

  String? get couponCode => (_$data['couponCode'] as String?);

  Enum$PaymentMode? get paymentMode =>
      (_$data['paymentMode'] as Enum$PaymentMode?);

  String? get paymentMethodId => (_$data['paymentMethodId'] as String?);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$serviceId = serviceId;
    result$data['serviceId'] = l$serviceId;
    if (_$data.containsKey('orderType')) {
      final l$orderType = orderType;
      result$data['orderType'] = toJson$Enum$TaxiOrderType(
        (l$orderType as Enum$TaxiOrderType),
      );
    }
    final l$waypoints = waypoints;
    result$data['waypoints'] = l$waypoints.map((e) => e.toJson()).toList();
    if (_$data.containsKey('intervalMinutes')) {
      final l$intervalMinutes = intervalMinutes;
      result$data['intervalMinutes'] = l$intervalMinutes;
    }
    if (_$data.containsKey('twoWay')) {
      final l$twoWay = twoWay;
      result$data['twoWay'] = l$twoWay;
    }
    if (_$data.containsKey('waitTime')) {
      final l$waitTime = waitTime;
      result$data['waitTime'] = l$waitTime;
    }
    if (_$data.containsKey('optionIds')) {
      final l$optionIds = optionIds;
      result$data['optionIds'] = l$optionIds?.map((e) => e).toList();
    }
    if (_$data.containsKey('couponCode')) {
      final l$couponCode = couponCode;
      result$data['couponCode'] = l$couponCode;
    }
    if (_$data.containsKey('paymentMode')) {
      final l$paymentMode = paymentMode;
      result$data['paymentMode'] = l$paymentMode == null
          ? null
          : toJson$Enum$PaymentMode(l$paymentMode);
    }
    if (_$data.containsKey('paymentMethodId')) {
      final l$paymentMethodId = paymentMethodId;
      result$data['paymentMethodId'] = l$paymentMethodId;
    }
    return result$data;
  }

  CopyWith$Input$CreateOrderInput<Input$CreateOrderInput> get copyWith =>
      CopyWith$Input$CreateOrderInput(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Input$CreateOrderInput || runtimeType != other.runtimeType) {
      return false;
    }
    final l$serviceId = serviceId;
    final lOther$serviceId = other.serviceId;
    if (l$serviceId != lOther$serviceId) {
      return false;
    }
    final l$orderType = orderType;
    final lOther$orderType = other.orderType;
    if (_$data.containsKey('orderType') !=
        other._$data.containsKey('orderType')) {
      return false;
    }
    if (l$orderType != lOther$orderType) {
      return false;
    }
    final l$waypoints = waypoints;
    final lOther$waypoints = other.waypoints;
    if (l$waypoints.length != lOther$waypoints.length) {
      return false;
    }
    for (int i = 0; i < l$waypoints.length; i++) {
      final l$waypoints$entry = l$waypoints[i];
      final lOther$waypoints$entry = lOther$waypoints[i];
      if (l$waypoints$entry != lOther$waypoints$entry) {
        return false;
      }
    }
    final l$intervalMinutes = intervalMinutes;
    final lOther$intervalMinutes = other.intervalMinutes;
    if (_$data.containsKey('intervalMinutes') !=
        other._$data.containsKey('intervalMinutes')) {
      return false;
    }
    if (l$intervalMinutes != lOther$intervalMinutes) {
      return false;
    }
    final l$twoWay = twoWay;
    final lOther$twoWay = other.twoWay;
    if (_$data.containsKey('twoWay') != other._$data.containsKey('twoWay')) {
      return false;
    }
    if (l$twoWay != lOther$twoWay) {
      return false;
    }
    final l$waitTime = waitTime;
    final lOther$waitTime = other.waitTime;
    if (_$data.containsKey('waitTime') !=
        other._$data.containsKey('waitTime')) {
      return false;
    }
    if (l$waitTime != lOther$waitTime) {
      return false;
    }
    final l$optionIds = optionIds;
    final lOther$optionIds = other.optionIds;
    if (_$data.containsKey('optionIds') !=
        other._$data.containsKey('optionIds')) {
      return false;
    }
    if (l$optionIds != null && lOther$optionIds != null) {
      if (l$optionIds.length != lOther$optionIds.length) {
        return false;
      }
      for (int i = 0; i < l$optionIds.length; i++) {
        final l$optionIds$entry = l$optionIds[i];
        final lOther$optionIds$entry = lOther$optionIds[i];
        if (l$optionIds$entry != lOther$optionIds$entry) {
          return false;
        }
      }
    } else if (l$optionIds != lOther$optionIds) {
      return false;
    }
    final l$couponCode = couponCode;
    final lOther$couponCode = other.couponCode;
    if (_$data.containsKey('couponCode') !=
        other._$data.containsKey('couponCode')) {
      return false;
    }
    if (l$couponCode != lOther$couponCode) {
      return false;
    }
    final l$paymentMode = paymentMode;
    final lOther$paymentMode = other.paymentMode;
    if (_$data.containsKey('paymentMode') !=
        other._$data.containsKey('paymentMode')) {
      return false;
    }
    if (l$paymentMode != lOther$paymentMode) {
      return false;
    }
    final l$paymentMethodId = paymentMethodId;
    final lOther$paymentMethodId = other.paymentMethodId;
    if (_$data.containsKey('paymentMethodId') !=
        other._$data.containsKey('paymentMethodId')) {
      return false;
    }
    if (l$paymentMethodId != lOther$paymentMethodId) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$serviceId = serviceId;
    final l$orderType = orderType;
    final l$waypoints = waypoints;
    final l$intervalMinutes = intervalMinutes;
    final l$twoWay = twoWay;
    final l$waitTime = waitTime;
    final l$optionIds = optionIds;
    final l$couponCode = couponCode;
    final l$paymentMode = paymentMode;
    final l$paymentMethodId = paymentMethodId;
    return Object.hashAll([
      l$serviceId,
      _$data.containsKey('orderType') ? l$orderType : const {},
      Object.hashAll(l$waypoints.map((v) => v)),
      _$data.containsKey('intervalMinutes') ? l$intervalMinutes : const {},
      _$data.containsKey('twoWay') ? l$twoWay : const {},
      _$data.containsKey('waitTime') ? l$waitTime : const {},
      _$data.containsKey('optionIds')
          ? l$optionIds == null
                ? null
                : Object.hashAll(l$optionIds.map((v) => v))
          : const {},
      _$data.containsKey('couponCode') ? l$couponCode : const {},
      _$data.containsKey('paymentMode') ? l$paymentMode : const {},
      _$data.containsKey('paymentMethodId') ? l$paymentMethodId : const {},
    ]);
  }
}

abstract class CopyWith$Input$CreateOrderInput<TRes> {
  factory CopyWith$Input$CreateOrderInput(
    Input$CreateOrderInput instance,
    TRes Function(Input$CreateOrderInput) then,
  ) = _CopyWithImpl$Input$CreateOrderInput;

  factory CopyWith$Input$CreateOrderInput.stub(TRes res) =
      _CopyWithStubImpl$Input$CreateOrderInput;

  TRes call({
    int? serviceId,
    Enum$TaxiOrderType? orderType,
    List<Input$WaypointInput>? waypoints,
    int? intervalMinutes,
    bool? twoWay,
    int? waitTime,
    List<String>? optionIds,
    String? couponCode,
    Enum$PaymentMode? paymentMode,
    String? paymentMethodId,
  });
  TRes waypoints(
    Iterable<Input$WaypointInput> Function(
      Iterable<CopyWith$Input$WaypointInput<Input$WaypointInput>>,
    )
    _fn,
  );
}

class _CopyWithImpl$Input$CreateOrderInput<TRes>
    implements CopyWith$Input$CreateOrderInput<TRes> {
  _CopyWithImpl$Input$CreateOrderInput(this._instance, this._then);

  final Input$CreateOrderInput _instance;

  final TRes Function(Input$CreateOrderInput) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? serviceId = _undefined,
    Object? orderType = _undefined,
    Object? waypoints = _undefined,
    Object? intervalMinutes = _undefined,
    Object? twoWay = _undefined,
    Object? waitTime = _undefined,
    Object? optionIds = _undefined,
    Object? couponCode = _undefined,
    Object? paymentMode = _undefined,
    Object? paymentMethodId = _undefined,
  }) => _then(
    Input$CreateOrderInput._({
      ..._instance._$data,
      if (serviceId != _undefined && serviceId != null)
        'serviceId': (serviceId as int),
      if (orderType != _undefined && orderType != null)
        'orderType': (orderType as Enum$TaxiOrderType),
      if (waypoints != _undefined && waypoints != null)
        'waypoints': (waypoints as List<Input$WaypointInput>),
      if (intervalMinutes != _undefined)
        'intervalMinutes': (intervalMinutes as int?),
      if (twoWay != _undefined) 'twoWay': (twoWay as bool?),
      if (waitTime != _undefined) 'waitTime': (waitTime as int?),
      if (optionIds != _undefined) 'optionIds': (optionIds as List<String>?),
      if (couponCode != _undefined) 'couponCode': (couponCode as String?),
      if (paymentMode != _undefined)
        'paymentMode': (paymentMode as Enum$PaymentMode?),
      if (paymentMethodId != _undefined)
        'paymentMethodId': (paymentMethodId as String?),
    }),
  );

  TRes waypoints(
    Iterable<Input$WaypointInput> Function(
      Iterable<CopyWith$Input$WaypointInput<Input$WaypointInput>>,
    )
    _fn,
  ) => call(
    waypoints: _fn(
      _instance.waypoints.map((e) => CopyWith$Input$WaypointInput(e, (i) => i)),
    ).toList(),
  );
}

class _CopyWithStubImpl$Input$CreateOrderInput<TRes>
    implements CopyWith$Input$CreateOrderInput<TRes> {
  _CopyWithStubImpl$Input$CreateOrderInput(this._res);

  TRes _res;

  call({
    int? serviceId,
    Enum$TaxiOrderType? orderType,
    List<Input$WaypointInput>? waypoints,
    int? intervalMinutes,
    bool? twoWay,
    int? waitTime,
    List<String>? optionIds,
    String? couponCode,
    Enum$PaymentMode? paymentMode,
    String? paymentMethodId,
  }) => _res;

  waypoints(_fn) => _res;
}

class Input$WaypointInput {
  factory Input$WaypointInput({
    required Input$PointInput point,
    required String address,
    Input$DeliveryContactInput? deliveryContact,
  }) => Input$WaypointInput._({
    r'point': point,
    r'address': address,
    if (deliveryContact != null) r'deliveryContact': deliveryContact,
  });

  Input$WaypointInput._(this._$data);

  factory Input$WaypointInput.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$point = data['point'];
    result$data['point'] = Input$PointInput.fromJson(
      (l$point as Map<String, dynamic>),
    );
    final l$address = data['address'];
    result$data['address'] = (l$address as String);
    if (data.containsKey('deliveryContact')) {
      final l$deliveryContact = data['deliveryContact'];
      result$data['deliveryContact'] = l$deliveryContact == null
          ? null
          : Input$DeliveryContactInput.fromJson(
              (l$deliveryContact as Map<String, dynamic>),
            );
    }
    return Input$WaypointInput._(result$data);
  }

  Map<String, dynamic> _$data;

  Input$PointInput get point => (_$data['point'] as Input$PointInput);

  String get address => (_$data['address'] as String);

  Input$DeliveryContactInput? get deliveryContact =>
      (_$data['deliveryContact'] as Input$DeliveryContactInput?);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$point = point;
    result$data['point'] = l$point.toJson();
    final l$address = address;
    result$data['address'] = l$address;
    if (_$data.containsKey('deliveryContact')) {
      final l$deliveryContact = deliveryContact;
      result$data['deliveryContact'] = l$deliveryContact?.toJson();
    }
    return result$data;
  }

  CopyWith$Input$WaypointInput<Input$WaypointInput> get copyWith =>
      CopyWith$Input$WaypointInput(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Input$WaypointInput || runtimeType != other.runtimeType) {
      return false;
    }
    final l$point = point;
    final lOther$point = other.point;
    if (l$point != lOther$point) {
      return false;
    }
    final l$address = address;
    final lOther$address = other.address;
    if (l$address != lOther$address) {
      return false;
    }
    final l$deliveryContact = deliveryContact;
    final lOther$deliveryContact = other.deliveryContact;
    if (_$data.containsKey('deliveryContact') !=
        other._$data.containsKey('deliveryContact')) {
      return false;
    }
    if (l$deliveryContact != lOther$deliveryContact) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$point = point;
    final l$address = address;
    final l$deliveryContact = deliveryContact;
    return Object.hashAll([
      l$point,
      l$address,
      _$data.containsKey('deliveryContact') ? l$deliveryContact : const {},
    ]);
  }
}

abstract class CopyWith$Input$WaypointInput<TRes> {
  factory CopyWith$Input$WaypointInput(
    Input$WaypointInput instance,
    TRes Function(Input$WaypointInput) then,
  ) = _CopyWithImpl$Input$WaypointInput;

  factory CopyWith$Input$WaypointInput.stub(TRes res) =
      _CopyWithStubImpl$Input$WaypointInput;

  TRes call({
    Input$PointInput? point,
    String? address,
    Input$DeliveryContactInput? deliveryContact,
  });
  CopyWith$Input$PointInput<TRes> get point;
  CopyWith$Input$DeliveryContactInput<TRes> get deliveryContact;
}

class _CopyWithImpl$Input$WaypointInput<TRes>
    implements CopyWith$Input$WaypointInput<TRes> {
  _CopyWithImpl$Input$WaypointInput(this._instance, this._then);

  final Input$WaypointInput _instance;

  final TRes Function(Input$WaypointInput) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? point = _undefined,
    Object? address = _undefined,
    Object? deliveryContact = _undefined,
  }) => _then(
    Input$WaypointInput._({
      ..._instance._$data,
      if (point != _undefined && point != null)
        'point': (point as Input$PointInput),
      if (address != _undefined && address != null)
        'address': (address as String),
      if (deliveryContact != _undefined)
        'deliveryContact': (deliveryContact as Input$DeliveryContactInput?),
    }),
  );

  CopyWith$Input$PointInput<TRes> get point {
    final local$point = _instance.point;
    return CopyWith$Input$PointInput(local$point, (e) => call(point: e));
  }

  CopyWith$Input$DeliveryContactInput<TRes> get deliveryContact {
    final local$deliveryContact = _instance.deliveryContact;
    return local$deliveryContact == null
        ? CopyWith$Input$DeliveryContactInput.stub(_then(_instance))
        : CopyWith$Input$DeliveryContactInput(
            local$deliveryContact,
            (e) => call(deliveryContact: e),
          );
  }
}

class _CopyWithStubImpl$Input$WaypointInput<TRes>
    implements CopyWith$Input$WaypointInput<TRes> {
  _CopyWithStubImpl$Input$WaypointInput(this._res);

  TRes _res;

  call({
    Input$PointInput? point,
    String? address,
    Input$DeliveryContactInput? deliveryContact,
  }) => _res;

  CopyWith$Input$PointInput<TRes> get point =>
      CopyWith$Input$PointInput.stub(_res);

  CopyWith$Input$DeliveryContactInput<TRes> get deliveryContact =>
      CopyWith$Input$DeliveryContactInput.stub(_res);
}

class Input$SubmitFeedbackInput {
  factory Input$SubmitFeedbackInput({
    required int score,
    String? description,
    required String requestId,
    List<String>? parameterIds,
    bool? addToFavorite,
  }) => Input$SubmitFeedbackInput._({
    r'score': score,
    if (description != null) r'description': description,
    r'requestId': requestId,
    if (parameterIds != null) r'parameterIds': parameterIds,
    if (addToFavorite != null) r'addToFavorite': addToFavorite,
  });

  Input$SubmitFeedbackInput._(this._$data);

  factory Input$SubmitFeedbackInput.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$score = data['score'];
    result$data['score'] = (l$score as int);
    if (data.containsKey('description')) {
      final l$description = data['description'];
      result$data['description'] = (l$description as String?);
    }
    final l$requestId = data['requestId'];
    result$data['requestId'] = (l$requestId as String);
    if (data.containsKey('parameterIds')) {
      final l$parameterIds = data['parameterIds'];
      result$data['parameterIds'] = (l$parameterIds as List<dynamic>)
          .map((e) => (e as String))
          .toList();
    }
    if (data.containsKey('addToFavorite')) {
      final l$addToFavorite = data['addToFavorite'];
      result$data['addToFavorite'] = (l$addToFavorite as bool?);
    }
    return Input$SubmitFeedbackInput._(result$data);
  }

  Map<String, dynamic> _$data;

  int get score => (_$data['score'] as int);

  String? get description => (_$data['description'] as String?);

  String get requestId => (_$data['requestId'] as String);

  List<String>? get parameterIds => (_$data['parameterIds'] as List<String>?);

  bool? get addToFavorite => (_$data['addToFavorite'] as bool?);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$score = score;
    result$data['score'] = l$score;
    if (_$data.containsKey('description')) {
      final l$description = description;
      result$data['description'] = l$description;
    }
    final l$requestId = requestId;
    result$data['requestId'] = l$requestId;
    if (_$data.containsKey('parameterIds')) {
      final l$parameterIds = parameterIds;
      result$data['parameterIds'] = (l$parameterIds as List<String>)
          .map((e) => e)
          .toList();
    }
    if (_$data.containsKey('addToFavorite')) {
      final l$addToFavorite = addToFavorite;
      result$data['addToFavorite'] = l$addToFavorite;
    }
    return result$data;
  }

  CopyWith$Input$SubmitFeedbackInput<Input$SubmitFeedbackInput> get copyWith =>
      CopyWith$Input$SubmitFeedbackInput(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Input$SubmitFeedbackInput ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$score = score;
    final lOther$score = other.score;
    if (l$score != lOther$score) {
      return false;
    }
    final l$description = description;
    final lOther$description = other.description;
    if (_$data.containsKey('description') !=
        other._$data.containsKey('description')) {
      return false;
    }
    if (l$description != lOther$description) {
      return false;
    }
    final l$requestId = requestId;
    final lOther$requestId = other.requestId;
    if (l$requestId != lOther$requestId) {
      return false;
    }
    final l$parameterIds = parameterIds;
    final lOther$parameterIds = other.parameterIds;
    if (_$data.containsKey('parameterIds') !=
        other._$data.containsKey('parameterIds')) {
      return false;
    }
    if (l$parameterIds != null && lOther$parameterIds != null) {
      if (l$parameterIds.length != lOther$parameterIds.length) {
        return false;
      }
      for (int i = 0; i < l$parameterIds.length; i++) {
        final l$parameterIds$entry = l$parameterIds[i];
        final lOther$parameterIds$entry = lOther$parameterIds[i];
        if (l$parameterIds$entry != lOther$parameterIds$entry) {
          return false;
        }
      }
    } else if (l$parameterIds != lOther$parameterIds) {
      return false;
    }
    final l$addToFavorite = addToFavorite;
    final lOther$addToFavorite = other.addToFavorite;
    if (_$data.containsKey('addToFavorite') !=
        other._$data.containsKey('addToFavorite')) {
      return false;
    }
    if (l$addToFavorite != lOther$addToFavorite) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$score = score;
    final l$description = description;
    final l$requestId = requestId;
    final l$parameterIds = parameterIds;
    final l$addToFavorite = addToFavorite;
    return Object.hashAll([
      l$score,
      _$data.containsKey('description') ? l$description : const {},
      l$requestId,
      _$data.containsKey('parameterIds')
          ? l$parameterIds == null
                ? null
                : Object.hashAll(l$parameterIds.map((v) => v))
          : const {},
      _$data.containsKey('addToFavorite') ? l$addToFavorite : const {},
    ]);
  }
}

abstract class CopyWith$Input$SubmitFeedbackInput<TRes> {
  factory CopyWith$Input$SubmitFeedbackInput(
    Input$SubmitFeedbackInput instance,
    TRes Function(Input$SubmitFeedbackInput) then,
  ) = _CopyWithImpl$Input$SubmitFeedbackInput;

  factory CopyWith$Input$SubmitFeedbackInput.stub(TRes res) =
      _CopyWithStubImpl$Input$SubmitFeedbackInput;

  TRes call({
    int? score,
    String? description,
    String? requestId,
    List<String>? parameterIds,
    bool? addToFavorite,
  });
}

class _CopyWithImpl$Input$SubmitFeedbackInput<TRes>
    implements CopyWith$Input$SubmitFeedbackInput<TRes> {
  _CopyWithImpl$Input$SubmitFeedbackInput(this._instance, this._then);

  final Input$SubmitFeedbackInput _instance;

  final TRes Function(Input$SubmitFeedbackInput) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? score = _undefined,
    Object? description = _undefined,
    Object? requestId = _undefined,
    Object? parameterIds = _undefined,
    Object? addToFavorite = _undefined,
  }) => _then(
    Input$SubmitFeedbackInput._({
      ..._instance._$data,
      if (score != _undefined && score != null) 'score': (score as int),
      if (description != _undefined) 'description': (description as String?),
      if (requestId != _undefined && requestId != null)
        'requestId': (requestId as String),
      if (parameterIds != _undefined && parameterIds != null)
        'parameterIds': (parameterIds as List<String>),
      if (addToFavorite != _undefined)
        'addToFavorite': (addToFavorite as bool?),
    }),
  );
}

class _CopyWithStubImpl$Input$SubmitFeedbackInput<TRes>
    implements CopyWith$Input$SubmitFeedbackInput<TRes> {
  _CopyWithStubImpl$Input$SubmitFeedbackInput(this._res);

  TRes _res;

  call({
    int? score,
    String? description,
    String? requestId,
    List<String>? parameterIds,
    bool? addToFavorite,
  }) => _res;
}

class Input$PaymentMethodInput {
  factory Input$PaymentMethodInput({
    required Enum$PaymentMode mode,
    String? id,
  }) => Input$PaymentMethodInput._({r'mode': mode, if (id != null) r'id': id});

  Input$PaymentMethodInput._(this._$data);

  factory Input$PaymentMethodInput.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$mode = data['mode'];
    result$data['mode'] = fromJson$Enum$PaymentMode((l$mode as String));
    if (data.containsKey('id')) {
      final l$id = data['id'];
      result$data['id'] = (l$id as String?);
    }
    return Input$PaymentMethodInput._(result$data);
  }

  Map<String, dynamic> _$data;

  Enum$PaymentMode get mode => (_$data['mode'] as Enum$PaymentMode);

  String? get id => (_$data['id'] as String?);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$mode = mode;
    result$data['mode'] = toJson$Enum$PaymentMode(l$mode);
    if (_$data.containsKey('id')) {
      final l$id = id;
      result$data['id'] = l$id;
    }
    return result$data;
  }

  CopyWith$Input$PaymentMethodInput<Input$PaymentMethodInput> get copyWith =>
      CopyWith$Input$PaymentMethodInput(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Input$PaymentMethodInput ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$mode = mode;
    final lOther$mode = other.mode;
    if (l$mode != lOther$mode) {
      return false;
    }
    final l$id = id;
    final lOther$id = other.id;
    if (_$data.containsKey('id') != other._$data.containsKey('id')) {
      return false;
    }
    if (l$id != lOther$id) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$mode = mode;
    final l$id = id;
    return Object.hashAll([l$mode, _$data.containsKey('id') ? l$id : const {}]);
  }
}

abstract class CopyWith$Input$PaymentMethodInput<TRes> {
  factory CopyWith$Input$PaymentMethodInput(
    Input$PaymentMethodInput instance,
    TRes Function(Input$PaymentMethodInput) then,
  ) = _CopyWithImpl$Input$PaymentMethodInput;

  factory CopyWith$Input$PaymentMethodInput.stub(TRes res) =
      _CopyWithStubImpl$Input$PaymentMethodInput;

  TRes call({Enum$PaymentMode? mode, String? id});
}

class _CopyWithImpl$Input$PaymentMethodInput<TRes>
    implements CopyWith$Input$PaymentMethodInput<TRes> {
  _CopyWithImpl$Input$PaymentMethodInput(this._instance, this._then);

  final Input$PaymentMethodInput _instance;

  final TRes Function(Input$PaymentMethodInput) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? mode = _undefined, Object? id = _undefined}) => _then(
    Input$PaymentMethodInput._({
      ..._instance._$data,
      if (mode != _undefined && mode != null)
        'mode': (mode as Enum$PaymentMode),
      if (id != _undefined) 'id': (id as String?),
    }),
  );
}

class _CopyWithStubImpl$Input$PaymentMethodInput<TRes>
    implements CopyWith$Input$PaymentMethodInput<TRes> {
  _CopyWithStubImpl$Input$PaymentMethodInput(this._res);

  TRes _res;

  call({Enum$PaymentMode? mode, String? id}) => _res;
}

class Input$CreateRiderAddressInput {
  factory Input$CreateRiderAddressInput({
    required String title,
    required String details,
    required Input$PointInput location,
    required Enum$RiderAddressType type,
    required Input$PhoneNumberInput phoneNumber,
  }) => Input$CreateRiderAddressInput._({
    r'title': title,
    r'details': details,
    r'location': location,
    r'type': type,
    r'phoneNumber': phoneNumber,
  });

  Input$CreateRiderAddressInput._(this._$data);

  factory Input$CreateRiderAddressInput.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$title = data['title'];
    result$data['title'] = (l$title as String);
    final l$details = data['details'];
    result$data['details'] = (l$details as String);
    final l$location = data['location'];
    result$data['location'] = Input$PointInput.fromJson(
      (l$location as Map<String, dynamic>),
    );
    final l$type = data['type'];
    result$data['type'] = fromJson$Enum$RiderAddressType((l$type as String));
    final l$phoneNumber = data['phoneNumber'];
    result$data['phoneNumber'] = Input$PhoneNumberInput.fromJson(
      (l$phoneNumber as Map<String, dynamic>),
    );
    return Input$CreateRiderAddressInput._(result$data);
  }

  Map<String, dynamic> _$data;

  String get title => (_$data['title'] as String);

  String get details => (_$data['details'] as String);

  Input$PointInput get location => (_$data['location'] as Input$PointInput);

  Enum$RiderAddressType get type => (_$data['type'] as Enum$RiderAddressType);

  Input$PhoneNumberInput get phoneNumber =>
      (_$data['phoneNumber'] as Input$PhoneNumberInput);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$title = title;
    result$data['title'] = l$title;
    final l$details = details;
    result$data['details'] = l$details;
    final l$location = location;
    result$data['location'] = l$location.toJson();
    final l$type = type;
    result$data['type'] = toJson$Enum$RiderAddressType(l$type);
    final l$phoneNumber = phoneNumber;
    result$data['phoneNumber'] = l$phoneNumber.toJson();
    return result$data;
  }

  CopyWith$Input$CreateRiderAddressInput<Input$CreateRiderAddressInput>
  get copyWith => CopyWith$Input$CreateRiderAddressInput(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Input$CreateRiderAddressInput ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$title = title;
    final lOther$title = other.title;
    if (l$title != lOther$title) {
      return false;
    }
    final l$details = details;
    final lOther$details = other.details;
    if (l$details != lOther$details) {
      return false;
    }
    final l$location = location;
    final lOther$location = other.location;
    if (l$location != lOther$location) {
      return false;
    }
    final l$type = type;
    final lOther$type = other.type;
    if (l$type != lOther$type) {
      return false;
    }
    final l$phoneNumber = phoneNumber;
    final lOther$phoneNumber = other.phoneNumber;
    if (l$phoneNumber != lOther$phoneNumber) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$title = title;
    final l$details = details;
    final l$location = location;
    final l$type = type;
    final l$phoneNumber = phoneNumber;
    return Object.hashAll([
      l$title,
      l$details,
      l$location,
      l$type,
      l$phoneNumber,
    ]);
  }
}

abstract class CopyWith$Input$CreateRiderAddressInput<TRes> {
  factory CopyWith$Input$CreateRiderAddressInput(
    Input$CreateRiderAddressInput instance,
    TRes Function(Input$CreateRiderAddressInput) then,
  ) = _CopyWithImpl$Input$CreateRiderAddressInput;

  factory CopyWith$Input$CreateRiderAddressInput.stub(TRes res) =
      _CopyWithStubImpl$Input$CreateRiderAddressInput;

  TRes call({
    String? title,
    String? details,
    Input$PointInput? location,
    Enum$RiderAddressType? type,
    Input$PhoneNumberInput? phoneNumber,
  });
  CopyWith$Input$PointInput<TRes> get location;
  CopyWith$Input$PhoneNumberInput<TRes> get phoneNumber;
}

class _CopyWithImpl$Input$CreateRiderAddressInput<TRes>
    implements CopyWith$Input$CreateRiderAddressInput<TRes> {
  _CopyWithImpl$Input$CreateRiderAddressInput(this._instance, this._then);

  final Input$CreateRiderAddressInput _instance;

  final TRes Function(Input$CreateRiderAddressInput) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? title = _undefined,
    Object? details = _undefined,
    Object? location = _undefined,
    Object? type = _undefined,
    Object? phoneNumber = _undefined,
  }) => _then(
    Input$CreateRiderAddressInput._({
      ..._instance._$data,
      if (title != _undefined && title != null) 'title': (title as String),
      if (details != _undefined && details != null)
        'details': (details as String),
      if (location != _undefined && location != null)
        'location': (location as Input$PointInput),
      if (type != _undefined && type != null)
        'type': (type as Enum$RiderAddressType),
      if (phoneNumber != _undefined && phoneNumber != null)
        'phoneNumber': (phoneNumber as Input$PhoneNumberInput),
    }),
  );

  CopyWith$Input$PointInput<TRes> get location {
    final local$location = _instance.location;
    return CopyWith$Input$PointInput(local$location, (e) => call(location: e));
  }

  CopyWith$Input$PhoneNumberInput<TRes> get phoneNumber {
    final local$phoneNumber = _instance.phoneNumber;
    return CopyWith$Input$PhoneNumberInput(
      local$phoneNumber,
      (e) => call(phoneNumber: e),
    );
  }
}

class _CopyWithStubImpl$Input$CreateRiderAddressInput<TRes>
    implements CopyWith$Input$CreateRiderAddressInput<TRes> {
  _CopyWithStubImpl$Input$CreateRiderAddressInput(this._res);

  TRes _res;

  call({
    String? title,
    String? details,
    Input$PointInput? location,
    Enum$RiderAddressType? type,
    Input$PhoneNumberInput? phoneNumber,
  }) => _res;

  CopyWith$Input$PointInput<TRes> get location =>
      CopyWith$Input$PointInput.stub(_res);

  CopyWith$Input$PhoneNumberInput<TRes> get phoneNumber =>
      CopyWith$Input$PhoneNumberInput.stub(_res);
}

class Input$ComplaintInput {
  factory Input$ComplaintInput({
    required String requestId,
    required String subject,
    String? content,
    bool? requestedByDriver,
  }) => Input$ComplaintInput._({
    r'requestId': requestId,
    r'subject': subject,
    if (content != null) r'content': content,
    if (requestedByDriver != null) r'requestedByDriver': requestedByDriver,
  });

  Input$ComplaintInput._(this._$data);

  factory Input$ComplaintInput.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$requestId = data['requestId'];
    result$data['requestId'] = (l$requestId as String);
    final l$subject = data['subject'];
    result$data['subject'] = (l$subject as String);
    if (data.containsKey('content')) {
      final l$content = data['content'];
      result$data['content'] = (l$content as String?);
    }
    if (data.containsKey('requestedByDriver')) {
      final l$requestedByDriver = data['requestedByDriver'];
      result$data['requestedByDriver'] = (l$requestedByDriver as bool?);
    }
    return Input$ComplaintInput._(result$data);
  }

  Map<String, dynamic> _$data;

  String get requestId => (_$data['requestId'] as String);

  String get subject => (_$data['subject'] as String);

  String? get content => (_$data['content'] as String?);

  bool? get requestedByDriver => (_$data['requestedByDriver'] as bool?);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$requestId = requestId;
    result$data['requestId'] = l$requestId;
    final l$subject = subject;
    result$data['subject'] = l$subject;
    if (_$data.containsKey('content')) {
      final l$content = content;
      result$data['content'] = l$content;
    }
    if (_$data.containsKey('requestedByDriver')) {
      final l$requestedByDriver = requestedByDriver;
      result$data['requestedByDriver'] = l$requestedByDriver;
    }
    return result$data;
  }

  CopyWith$Input$ComplaintInput<Input$ComplaintInput> get copyWith =>
      CopyWith$Input$ComplaintInput(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Input$ComplaintInput || runtimeType != other.runtimeType) {
      return false;
    }
    final l$requestId = requestId;
    final lOther$requestId = other.requestId;
    if (l$requestId != lOther$requestId) {
      return false;
    }
    final l$subject = subject;
    final lOther$subject = other.subject;
    if (l$subject != lOther$subject) {
      return false;
    }
    final l$content = content;
    final lOther$content = other.content;
    if (_$data.containsKey('content') != other._$data.containsKey('content')) {
      return false;
    }
    if (l$content != lOther$content) {
      return false;
    }
    final l$requestedByDriver = requestedByDriver;
    final lOther$requestedByDriver = other.requestedByDriver;
    if (_$data.containsKey('requestedByDriver') !=
        other._$data.containsKey('requestedByDriver')) {
      return false;
    }
    if (l$requestedByDriver != lOther$requestedByDriver) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$requestId = requestId;
    final l$subject = subject;
    final l$content = content;
    final l$requestedByDriver = requestedByDriver;
    return Object.hashAll([
      l$requestId,
      l$subject,
      _$data.containsKey('content') ? l$content : const {},
      _$data.containsKey('requestedByDriver') ? l$requestedByDriver : const {},
    ]);
  }
}

abstract class CopyWith$Input$ComplaintInput<TRes> {
  factory CopyWith$Input$ComplaintInput(
    Input$ComplaintInput instance,
    TRes Function(Input$ComplaintInput) then,
  ) = _CopyWithImpl$Input$ComplaintInput;

  factory CopyWith$Input$ComplaintInput.stub(TRes res) =
      _CopyWithStubImpl$Input$ComplaintInput;

  TRes call({
    String? requestId,
    String? subject,
    String? content,
    bool? requestedByDriver,
  });
}

class _CopyWithImpl$Input$ComplaintInput<TRes>
    implements CopyWith$Input$ComplaintInput<TRes> {
  _CopyWithImpl$Input$ComplaintInput(this._instance, this._then);

  final Input$ComplaintInput _instance;

  final TRes Function(Input$ComplaintInput) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? requestId = _undefined,
    Object? subject = _undefined,
    Object? content = _undefined,
    Object? requestedByDriver = _undefined,
  }) => _then(
    Input$ComplaintInput._({
      ..._instance._$data,
      if (requestId != _undefined && requestId != null)
        'requestId': (requestId as String),
      if (subject != _undefined && subject != null)
        'subject': (subject as String),
      if (content != _undefined) 'content': (content as String?),
      if (requestedByDriver != _undefined)
        'requestedByDriver': (requestedByDriver as bool?),
    }),
  );
}

class _CopyWithStubImpl$Input$ComplaintInput<TRes>
    implements CopyWith$Input$ComplaintInput<TRes> {
  _CopyWithStubImpl$Input$ComplaintInput(this._res);

  TRes _res;

  call({
    String? requestId,
    String? subject,
    String? content,
    bool? requestedByDriver,
  }) => _res;
}

class Input$TopUpWalletInput {
  factory Input$TopUpWalletInput({
    required String gatewayId,
    required double amount,
    required String currency,
    String? token,
    double? pin,
    double? otp,
    String? transactionId,
    String? orderNumber,
    Enum$PaymentMode? paymentMode,
  }) => Input$TopUpWalletInput._({
    r'gatewayId': gatewayId,
    r'amount': amount,
    r'currency': currency,
    if (token != null) r'token': token,
    if (pin != null) r'pin': pin,
    if (otp != null) r'otp': otp,
    if (transactionId != null) r'transactionId': transactionId,
    if (orderNumber != null) r'orderNumber': orderNumber,
    if (paymentMode != null) r'paymentMode': paymentMode,
  });

  Input$TopUpWalletInput._(this._$data);

  factory Input$TopUpWalletInput.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$gatewayId = data['gatewayId'];
    result$data['gatewayId'] = (l$gatewayId as String);
    final l$amount = data['amount'];
    result$data['amount'] = (l$amount as num).toDouble();
    final l$currency = data['currency'];
    result$data['currency'] = (l$currency as String);
    if (data.containsKey('token')) {
      final l$token = data['token'];
      result$data['token'] = (l$token as String?);
    }
    if (data.containsKey('pin')) {
      final l$pin = data['pin'];
      result$data['pin'] = (l$pin as num?)?.toDouble();
    }
    if (data.containsKey('otp')) {
      final l$otp = data['otp'];
      result$data['otp'] = (l$otp as num?)?.toDouble();
    }
    if (data.containsKey('transactionId')) {
      final l$transactionId = data['transactionId'];
      result$data['transactionId'] = (l$transactionId as String?);
    }
    if (data.containsKey('orderNumber')) {
      final l$orderNumber = data['orderNumber'];
      result$data['orderNumber'] = (l$orderNumber as String?);
    }
    if (data.containsKey('paymentMode')) {
      final l$paymentMode = data['paymentMode'];
      result$data['paymentMode'] = fromJson$Enum$PaymentMode(
        (l$paymentMode as String),
      );
    }
    return Input$TopUpWalletInput._(result$data);
  }

  Map<String, dynamic> _$data;

  String get gatewayId => (_$data['gatewayId'] as String);

  double get amount => (_$data['amount'] as double);

  String get currency => (_$data['currency'] as String);

  String? get token => (_$data['token'] as String?);

  double? get pin => (_$data['pin'] as double?);

  double? get otp => (_$data['otp'] as double?);

  String? get transactionId => (_$data['transactionId'] as String?);

  String? get orderNumber => (_$data['orderNumber'] as String?);

  Enum$PaymentMode? get paymentMode =>
      (_$data['paymentMode'] as Enum$PaymentMode?);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$gatewayId = gatewayId;
    result$data['gatewayId'] = l$gatewayId;
    final l$amount = amount;
    result$data['amount'] = l$amount;
    final l$currency = currency;
    result$data['currency'] = l$currency;
    if (_$data.containsKey('token')) {
      final l$token = token;
      result$data['token'] = l$token;
    }
    if (_$data.containsKey('pin')) {
      final l$pin = pin;
      result$data['pin'] = l$pin;
    }
    if (_$data.containsKey('otp')) {
      final l$otp = otp;
      result$data['otp'] = l$otp;
    }
    if (_$data.containsKey('transactionId')) {
      final l$transactionId = transactionId;
      result$data['transactionId'] = l$transactionId;
    }
    if (_$data.containsKey('orderNumber')) {
      final l$orderNumber = orderNumber;
      result$data['orderNumber'] = l$orderNumber;
    }
    if (_$data.containsKey('paymentMode')) {
      final l$paymentMode = paymentMode;
      result$data['paymentMode'] = toJson$Enum$PaymentMode(
        (l$paymentMode as Enum$PaymentMode),
      );
    }
    return result$data;
  }

  CopyWith$Input$TopUpWalletInput<Input$TopUpWalletInput> get copyWith =>
      CopyWith$Input$TopUpWalletInput(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Input$TopUpWalletInput || runtimeType != other.runtimeType) {
      return false;
    }
    final l$gatewayId = gatewayId;
    final lOther$gatewayId = other.gatewayId;
    if (l$gatewayId != lOther$gatewayId) {
      return false;
    }
    final l$amount = amount;
    final lOther$amount = other.amount;
    if (l$amount != lOther$amount) {
      return false;
    }
    final l$currency = currency;
    final lOther$currency = other.currency;
    if (l$currency != lOther$currency) {
      return false;
    }
    final l$token = token;
    final lOther$token = other.token;
    if (_$data.containsKey('token') != other._$data.containsKey('token')) {
      return false;
    }
    if (l$token != lOther$token) {
      return false;
    }
    final l$pin = pin;
    final lOther$pin = other.pin;
    if (_$data.containsKey('pin') != other._$data.containsKey('pin')) {
      return false;
    }
    if (l$pin != lOther$pin) {
      return false;
    }
    final l$otp = otp;
    final lOther$otp = other.otp;
    if (_$data.containsKey('otp') != other._$data.containsKey('otp')) {
      return false;
    }
    if (l$otp != lOther$otp) {
      return false;
    }
    final l$transactionId = transactionId;
    final lOther$transactionId = other.transactionId;
    if (_$data.containsKey('transactionId') !=
        other._$data.containsKey('transactionId')) {
      return false;
    }
    if (l$transactionId != lOther$transactionId) {
      return false;
    }
    final l$orderNumber = orderNumber;
    final lOther$orderNumber = other.orderNumber;
    if (_$data.containsKey('orderNumber') !=
        other._$data.containsKey('orderNumber')) {
      return false;
    }
    if (l$orderNumber != lOther$orderNumber) {
      return false;
    }
    final l$paymentMode = paymentMode;
    final lOther$paymentMode = other.paymentMode;
    if (_$data.containsKey('paymentMode') !=
        other._$data.containsKey('paymentMode')) {
      return false;
    }
    if (l$paymentMode != lOther$paymentMode) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$gatewayId = gatewayId;
    final l$amount = amount;
    final l$currency = currency;
    final l$token = token;
    final l$pin = pin;
    final l$otp = otp;
    final l$transactionId = transactionId;
    final l$orderNumber = orderNumber;
    final l$paymentMode = paymentMode;
    return Object.hashAll([
      l$gatewayId,
      l$amount,
      l$currency,
      _$data.containsKey('token') ? l$token : const {},
      _$data.containsKey('pin') ? l$pin : const {},
      _$data.containsKey('otp') ? l$otp : const {},
      _$data.containsKey('transactionId') ? l$transactionId : const {},
      _$data.containsKey('orderNumber') ? l$orderNumber : const {},
      _$data.containsKey('paymentMode') ? l$paymentMode : const {},
    ]);
  }
}

abstract class CopyWith$Input$TopUpWalletInput<TRes> {
  factory CopyWith$Input$TopUpWalletInput(
    Input$TopUpWalletInput instance,
    TRes Function(Input$TopUpWalletInput) then,
  ) = _CopyWithImpl$Input$TopUpWalletInput;

  factory CopyWith$Input$TopUpWalletInput.stub(TRes res) =
      _CopyWithStubImpl$Input$TopUpWalletInput;

  TRes call({
    String? gatewayId,
    double? amount,
    String? currency,
    String? token,
    double? pin,
    double? otp,
    String? transactionId,
    String? orderNumber,
    Enum$PaymentMode? paymentMode,
  });
}

class _CopyWithImpl$Input$TopUpWalletInput<TRes>
    implements CopyWith$Input$TopUpWalletInput<TRes> {
  _CopyWithImpl$Input$TopUpWalletInput(this._instance, this._then);

  final Input$TopUpWalletInput _instance;

  final TRes Function(Input$TopUpWalletInput) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? gatewayId = _undefined,
    Object? amount = _undefined,
    Object? currency = _undefined,
    Object? token = _undefined,
    Object? pin = _undefined,
    Object? otp = _undefined,
    Object? transactionId = _undefined,
    Object? orderNumber = _undefined,
    Object? paymentMode = _undefined,
  }) => _then(
    Input$TopUpWalletInput._({
      ..._instance._$data,
      if (gatewayId != _undefined && gatewayId != null)
        'gatewayId': (gatewayId as String),
      if (amount != _undefined && amount != null) 'amount': (amount as double),
      if (currency != _undefined && currency != null)
        'currency': (currency as String),
      if (token != _undefined) 'token': (token as String?),
      if (pin != _undefined) 'pin': (pin as double?),
      if (otp != _undefined) 'otp': (otp as double?),
      if (transactionId != _undefined)
        'transactionId': (transactionId as String?),
      if (orderNumber != _undefined) 'orderNumber': (orderNumber as String?),
      if (paymentMode != _undefined && paymentMode != null)
        'paymentMode': (paymentMode as Enum$PaymentMode),
    }),
  );
}

class _CopyWithStubImpl$Input$TopUpWalletInput<TRes>
    implements CopyWith$Input$TopUpWalletInput<TRes> {
  _CopyWithStubImpl$Input$TopUpWalletInput(this._res);

  TRes _res;

  call({
    String? gatewayId,
    double? amount,
    String? currency,
    String? token,
    double? pin,
    double? otp,
    String? transactionId,
    String? orderNumber,
    Enum$PaymentMode? paymentMode,
  }) => _res;
}

class Input$LoginInput {
  factory Input$LoginInput({required String firebaseToken}) =>
      Input$LoginInput._({r'firebaseToken': firebaseToken});

  Input$LoginInput._(this._$data);

  factory Input$LoginInput.fromJson(Map<String, dynamic> data) {
    final result$data = <String, dynamic>{};
    final l$firebaseToken = data['firebaseToken'];
    result$data['firebaseToken'] = (l$firebaseToken as String);
    return Input$LoginInput._(result$data);
  }

  Map<String, dynamic> _$data;

  String get firebaseToken => (_$data['firebaseToken'] as String);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$firebaseToken = firebaseToken;
    result$data['firebaseToken'] = l$firebaseToken;
    return result$data;
  }

  CopyWith$Input$LoginInput<Input$LoginInput> get copyWith =>
      CopyWith$Input$LoginInput(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Input$LoginInput || runtimeType != other.runtimeType) {
      return false;
    }
    final l$firebaseToken = firebaseToken;
    final lOther$firebaseToken = other.firebaseToken;
    if (l$firebaseToken != lOther$firebaseToken) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$firebaseToken = firebaseToken;
    return Object.hashAll([l$firebaseToken]);
  }
}

abstract class CopyWith$Input$LoginInput<TRes> {
  factory CopyWith$Input$LoginInput(
    Input$LoginInput instance,
    TRes Function(Input$LoginInput) then,
  ) = _CopyWithImpl$Input$LoginInput;

  factory CopyWith$Input$LoginInput.stub(TRes res) =
      _CopyWithStubImpl$Input$LoginInput;

  TRes call({String? firebaseToken});
}

class _CopyWithImpl$Input$LoginInput<TRes>
    implements CopyWith$Input$LoginInput<TRes> {
  _CopyWithImpl$Input$LoginInput(this._instance, this._then);

  final Input$LoginInput _instance;

  final TRes Function(Input$LoginInput) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({Object? firebaseToken = _undefined}) => _then(
    Input$LoginInput._({
      ..._instance._$data,
      if (firebaseToken != _undefined && firebaseToken != null)
        'firebaseToken': (firebaseToken as String),
    }),
  );
}

class _CopyWithStubImpl$Input$LoginInput<TRes>
    implements CopyWith$Input$LoginInput<TRes> {
  _CopyWithStubImpl$Input$LoginInput(this._res);

  TRes _res;

  call({String? firebaseToken}) => _res;
}

class Input$CompletePasskeyRegistrationInput {
  factory Input$CompletePasskeyRegistrationInput({
    required String id,
    required String rawId,
    required String type,
    required String clientDataJSON,
    required String attestationObject,
    List<String>? transports,
  }) => Input$CompletePasskeyRegistrationInput._({
    r'id': id,
    r'rawId': rawId,
    r'type': type,
    r'clientDataJSON': clientDataJSON,
    r'attestationObject': attestationObject,
    if (transports != null) r'transports': transports,
  });

  Input$CompletePasskeyRegistrationInput._(this._$data);

  factory Input$CompletePasskeyRegistrationInput.fromJson(
    Map<String, dynamic> data,
  ) {
    final result$data = <String, dynamic>{};
    final l$id = data['id'];
    result$data['id'] = (l$id as String);
    final l$rawId = data['rawId'];
    result$data['rawId'] = (l$rawId as String);
    final l$type = data['type'];
    result$data['type'] = (l$type as String);
    final l$clientDataJSON = data['clientDataJSON'];
    result$data['clientDataJSON'] = (l$clientDataJSON as String);
    final l$attestationObject = data['attestationObject'];
    result$data['attestationObject'] = (l$attestationObject as String);
    if (data.containsKey('transports')) {
      final l$transports = data['transports'];
      result$data['transports'] = (l$transports as List<dynamic>?)
          ?.map((e) => (e as String))
          .toList();
    }
    return Input$CompletePasskeyRegistrationInput._(result$data);
  }

  Map<String, dynamic> _$data;

  String get id => (_$data['id'] as String);

  String get rawId => (_$data['rawId'] as String);

  String get type => (_$data['type'] as String);

  String get clientDataJSON => (_$data['clientDataJSON'] as String);

  String get attestationObject => (_$data['attestationObject'] as String);

  List<String>? get transports => (_$data['transports'] as List<String>?);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$id = id;
    result$data['id'] = l$id;
    final l$rawId = rawId;
    result$data['rawId'] = l$rawId;
    final l$type = type;
    result$data['type'] = l$type;
    final l$clientDataJSON = clientDataJSON;
    result$data['clientDataJSON'] = l$clientDataJSON;
    final l$attestationObject = attestationObject;
    result$data['attestationObject'] = l$attestationObject;
    if (_$data.containsKey('transports')) {
      final l$transports = transports;
      result$data['transports'] = l$transports?.map((e) => e).toList();
    }
    return result$data;
  }

  CopyWith$Input$CompletePasskeyRegistrationInput<
    Input$CompletePasskeyRegistrationInput
  >
  get copyWith =>
      CopyWith$Input$CompletePasskeyRegistrationInput(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Input$CompletePasskeyRegistrationInput ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$id = id;
    final lOther$id = other.id;
    if (l$id != lOther$id) {
      return false;
    }
    final l$rawId = rawId;
    final lOther$rawId = other.rawId;
    if (l$rawId != lOther$rawId) {
      return false;
    }
    final l$type = type;
    final lOther$type = other.type;
    if (l$type != lOther$type) {
      return false;
    }
    final l$clientDataJSON = clientDataJSON;
    final lOther$clientDataJSON = other.clientDataJSON;
    if (l$clientDataJSON != lOther$clientDataJSON) {
      return false;
    }
    final l$attestationObject = attestationObject;
    final lOther$attestationObject = other.attestationObject;
    if (l$attestationObject != lOther$attestationObject) {
      return false;
    }
    final l$transports = transports;
    final lOther$transports = other.transports;
    if (_$data.containsKey('transports') !=
        other._$data.containsKey('transports')) {
      return false;
    }
    if (l$transports != null && lOther$transports != null) {
      if (l$transports.length != lOther$transports.length) {
        return false;
      }
      for (int i = 0; i < l$transports.length; i++) {
        final l$transports$entry = l$transports[i];
        final lOther$transports$entry = lOther$transports[i];
        if (l$transports$entry != lOther$transports$entry) {
          return false;
        }
      }
    } else if (l$transports != lOther$transports) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$id = id;
    final l$rawId = rawId;
    final l$type = type;
    final l$clientDataJSON = clientDataJSON;
    final l$attestationObject = attestationObject;
    final l$transports = transports;
    return Object.hashAll([
      l$id,
      l$rawId,
      l$type,
      l$clientDataJSON,
      l$attestationObject,
      _$data.containsKey('transports')
          ? l$transports == null
                ? null
                : Object.hashAll(l$transports.map((v) => v))
          : const {},
    ]);
  }
}

abstract class CopyWith$Input$CompletePasskeyRegistrationInput<TRes> {
  factory CopyWith$Input$CompletePasskeyRegistrationInput(
    Input$CompletePasskeyRegistrationInput instance,
    TRes Function(Input$CompletePasskeyRegistrationInput) then,
  ) = _CopyWithImpl$Input$CompletePasskeyRegistrationInput;

  factory CopyWith$Input$CompletePasskeyRegistrationInput.stub(TRes res) =
      _CopyWithStubImpl$Input$CompletePasskeyRegistrationInput;

  TRes call({
    String? id,
    String? rawId,
    String? type,
    String? clientDataJSON,
    String? attestationObject,
    List<String>? transports,
  });
}

class _CopyWithImpl$Input$CompletePasskeyRegistrationInput<TRes>
    implements CopyWith$Input$CompletePasskeyRegistrationInput<TRes> {
  _CopyWithImpl$Input$CompletePasskeyRegistrationInput(
    this._instance,
    this._then,
  );

  final Input$CompletePasskeyRegistrationInput _instance;

  final TRes Function(Input$CompletePasskeyRegistrationInput) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? id = _undefined,
    Object? rawId = _undefined,
    Object? type = _undefined,
    Object? clientDataJSON = _undefined,
    Object? attestationObject = _undefined,
    Object? transports = _undefined,
  }) => _then(
    Input$CompletePasskeyRegistrationInput._({
      ..._instance._$data,
      if (id != _undefined && id != null) 'id': (id as String),
      if (rawId != _undefined && rawId != null) 'rawId': (rawId as String),
      if (type != _undefined && type != null) 'type': (type as String),
      if (clientDataJSON != _undefined && clientDataJSON != null)
        'clientDataJSON': (clientDataJSON as String),
      if (attestationObject != _undefined && attestationObject != null)
        'attestationObject': (attestationObject as String),
      if (transports != _undefined) 'transports': (transports as List<String>?),
    }),
  );
}

class _CopyWithStubImpl$Input$CompletePasskeyRegistrationInput<TRes>
    implements CopyWith$Input$CompletePasskeyRegistrationInput<TRes> {
  _CopyWithStubImpl$Input$CompletePasskeyRegistrationInput(this._res);

  TRes _res;

  call({
    String? id,
    String? rawId,
    String? type,
    String? clientDataJSON,
    String? attestationObject,
    List<String>? transports,
  }) => _res;
}

class Input$CompletePasskeyAuthenticationInput {
  factory Input$CompletePasskeyAuthenticationInput({
    required String sessionId,
    required String id,
    required String rawId,
    required String type,
    required String clientDataJSON,
    required String authenticatorData,
    required String signature,
    String? userHandle,
  }) => Input$CompletePasskeyAuthenticationInput._({
    r'sessionId': sessionId,
    r'id': id,
    r'rawId': rawId,
    r'type': type,
    r'clientDataJSON': clientDataJSON,
    r'authenticatorData': authenticatorData,
    r'signature': signature,
    if (userHandle != null) r'userHandle': userHandle,
  });

  Input$CompletePasskeyAuthenticationInput._(this._$data);

  factory Input$CompletePasskeyAuthenticationInput.fromJson(
    Map<String, dynamic> data,
  ) {
    final result$data = <String, dynamic>{};
    final l$sessionId = data['sessionId'];
    result$data['sessionId'] = (l$sessionId as String);
    final l$id = data['id'];
    result$data['id'] = (l$id as String);
    final l$rawId = data['rawId'];
    result$data['rawId'] = (l$rawId as String);
    final l$type = data['type'];
    result$data['type'] = (l$type as String);
    final l$clientDataJSON = data['clientDataJSON'];
    result$data['clientDataJSON'] = (l$clientDataJSON as String);
    final l$authenticatorData = data['authenticatorData'];
    result$data['authenticatorData'] = (l$authenticatorData as String);
    final l$signature = data['signature'];
    result$data['signature'] = (l$signature as String);
    if (data.containsKey('userHandle')) {
      final l$userHandle = data['userHandle'];
      result$data['userHandle'] = (l$userHandle as String?);
    }
    return Input$CompletePasskeyAuthenticationInput._(result$data);
  }

  Map<String, dynamic> _$data;

  String get sessionId => (_$data['sessionId'] as String);

  String get id => (_$data['id'] as String);

  String get rawId => (_$data['rawId'] as String);

  String get type => (_$data['type'] as String);

  String get clientDataJSON => (_$data['clientDataJSON'] as String);

  String get authenticatorData => (_$data['authenticatorData'] as String);

  String get signature => (_$data['signature'] as String);

  String? get userHandle => (_$data['userHandle'] as String?);

  Map<String, dynamic> toJson() {
    final result$data = <String, dynamic>{};
    final l$sessionId = sessionId;
    result$data['sessionId'] = l$sessionId;
    final l$id = id;
    result$data['id'] = l$id;
    final l$rawId = rawId;
    result$data['rawId'] = l$rawId;
    final l$type = type;
    result$data['type'] = l$type;
    final l$clientDataJSON = clientDataJSON;
    result$data['clientDataJSON'] = l$clientDataJSON;
    final l$authenticatorData = authenticatorData;
    result$data['authenticatorData'] = l$authenticatorData;
    final l$signature = signature;
    result$data['signature'] = l$signature;
    if (_$data.containsKey('userHandle')) {
      final l$userHandle = userHandle;
      result$data['userHandle'] = l$userHandle;
    }
    return result$data;
  }

  CopyWith$Input$CompletePasskeyAuthenticationInput<
    Input$CompletePasskeyAuthenticationInput
  >
  get copyWith =>
      CopyWith$Input$CompletePasskeyAuthenticationInput(this, (i) => i);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) {
      return true;
    }
    if (other is! Input$CompletePasskeyAuthenticationInput ||
        runtimeType != other.runtimeType) {
      return false;
    }
    final l$sessionId = sessionId;
    final lOther$sessionId = other.sessionId;
    if (l$sessionId != lOther$sessionId) {
      return false;
    }
    final l$id = id;
    final lOther$id = other.id;
    if (l$id != lOther$id) {
      return false;
    }
    final l$rawId = rawId;
    final lOther$rawId = other.rawId;
    if (l$rawId != lOther$rawId) {
      return false;
    }
    final l$type = type;
    final lOther$type = other.type;
    if (l$type != lOther$type) {
      return false;
    }
    final l$clientDataJSON = clientDataJSON;
    final lOther$clientDataJSON = other.clientDataJSON;
    if (l$clientDataJSON != lOther$clientDataJSON) {
      return false;
    }
    final l$authenticatorData = authenticatorData;
    final lOther$authenticatorData = other.authenticatorData;
    if (l$authenticatorData != lOther$authenticatorData) {
      return false;
    }
    final l$signature = signature;
    final lOther$signature = other.signature;
    if (l$signature != lOther$signature) {
      return false;
    }
    final l$userHandle = userHandle;
    final lOther$userHandle = other.userHandle;
    if (_$data.containsKey('userHandle') !=
        other._$data.containsKey('userHandle')) {
      return false;
    }
    if (l$userHandle != lOther$userHandle) {
      return false;
    }
    return true;
  }

  @override
  int get hashCode {
    final l$sessionId = sessionId;
    final l$id = id;
    final l$rawId = rawId;
    final l$type = type;
    final l$clientDataJSON = clientDataJSON;
    final l$authenticatorData = authenticatorData;
    final l$signature = signature;
    final l$userHandle = userHandle;
    return Object.hashAll([
      l$sessionId,
      l$id,
      l$rawId,
      l$type,
      l$clientDataJSON,
      l$authenticatorData,
      l$signature,
      _$data.containsKey('userHandle') ? l$userHandle : const {},
    ]);
  }
}

abstract class CopyWith$Input$CompletePasskeyAuthenticationInput<TRes> {
  factory CopyWith$Input$CompletePasskeyAuthenticationInput(
    Input$CompletePasskeyAuthenticationInput instance,
    TRes Function(Input$CompletePasskeyAuthenticationInput) then,
  ) = _CopyWithImpl$Input$CompletePasskeyAuthenticationInput;

  factory CopyWith$Input$CompletePasskeyAuthenticationInput.stub(TRes res) =
      _CopyWithStubImpl$Input$CompletePasskeyAuthenticationInput;

  TRes call({
    String? sessionId,
    String? id,
    String? rawId,
    String? type,
    String? clientDataJSON,
    String? authenticatorData,
    String? signature,
    String? userHandle,
  });
}

class _CopyWithImpl$Input$CompletePasskeyAuthenticationInput<TRes>
    implements CopyWith$Input$CompletePasskeyAuthenticationInput<TRes> {
  _CopyWithImpl$Input$CompletePasskeyAuthenticationInput(
    this._instance,
    this._then,
  );

  final Input$CompletePasskeyAuthenticationInput _instance;

  final TRes Function(Input$CompletePasskeyAuthenticationInput) _then;

  static const _undefined = <dynamic, dynamic>{};

  TRes call({
    Object? sessionId = _undefined,
    Object? id = _undefined,
    Object? rawId = _undefined,
    Object? type = _undefined,
    Object? clientDataJSON = _undefined,
    Object? authenticatorData = _undefined,
    Object? signature = _undefined,
    Object? userHandle = _undefined,
  }) => _then(
    Input$CompletePasskeyAuthenticationInput._({
      ..._instance._$data,
      if (sessionId != _undefined && sessionId != null)
        'sessionId': (sessionId as String),
      if (id != _undefined && id != null) 'id': (id as String),
      if (rawId != _undefined && rawId != null) 'rawId': (rawId as String),
      if (type != _undefined && type != null) 'type': (type as String),
      if (clientDataJSON != _undefined && clientDataJSON != null)
        'clientDataJSON': (clientDataJSON as String),
      if (authenticatorData != _undefined && authenticatorData != null)
        'authenticatorData': (authenticatorData as String),
      if (signature != _undefined && signature != null)
        'signature': (signature as String),
      if (userHandle != _undefined) 'userHandle': (userHandle as String?),
    }),
  );
}

class _CopyWithStubImpl$Input$CompletePasskeyAuthenticationInput<TRes>
    implements CopyWith$Input$CompletePasskeyAuthenticationInput<TRes> {
  _CopyWithStubImpl$Input$CompletePasskeyAuthenticationInput(this._res);

  TRes _res;

  call({
    String? sessionId,
    String? id,
    String? rawId,
    String? type,
    String? clientDataJSON,
    String? authenticatorData,
    String? signature,
    String? userHandle,
  }) => _res;
}

enum Enum$WaypointRole {
  Pickup,
  Stop,
  Dropoff,
  $unknown;

  factory Enum$WaypointRole.fromJson(String value) =>
      fromJson$Enum$WaypointRole(value);

  String toJson() => toJson$Enum$WaypointRole(this);
}

String toJson$Enum$WaypointRole(Enum$WaypointRole e) {
  switch (e) {
    case Enum$WaypointRole.Pickup:
      return r'Pickup';
    case Enum$WaypointRole.Stop:
      return r'Stop';
    case Enum$WaypointRole.Dropoff:
      return r'Dropoff';
    case Enum$WaypointRole.$unknown:
      return r'$unknown';
  }
}

Enum$WaypointRole fromJson$Enum$WaypointRole(String value) {
  switch (value) {
    case r'Pickup':
      return Enum$WaypointRole.Pickup;
    case r'Stop':
      return Enum$WaypointRole.Stop;
    case r'Dropoff':
      return Enum$WaypointRole.Dropoff;
    default:
      return Enum$WaypointRole.$unknown;
  }
}

enum Enum$WaypointService {
  Ride,
  Delivery,
  Shop,
  $unknown;

  factory Enum$WaypointService.fromJson(String value) =>
      fromJson$Enum$WaypointService(value);

  String toJson() => toJson$Enum$WaypointService(this);
}

String toJson$Enum$WaypointService(Enum$WaypointService e) {
  switch (e) {
    case Enum$WaypointService.Ride:
      return r'Ride';
    case Enum$WaypointService.Delivery:
      return r'Delivery';
    case Enum$WaypointService.Shop:
      return r'Shop';
    case Enum$WaypointService.$unknown:
      return r'$unknown';
  }
}

Enum$WaypointService fromJson$Enum$WaypointService(String value) {
  switch (value) {
    case r'Ride':
      return Enum$WaypointService.Ride;
    case r'Delivery':
      return Enum$WaypointService.Delivery;
    case r'Shop':
      return Enum$WaypointService.Shop;
    default:
      return Enum$WaypointService.$unknown;
  }
}

enum Enum$PaymentMode {
  Cash,
  SavedPaymentMethod,
  PaymentGateway,
  Wallet,
  $unknown;

  factory Enum$PaymentMode.fromJson(String value) =>
      fromJson$Enum$PaymentMode(value);

  String toJson() => toJson$Enum$PaymentMode(this);
}

String toJson$Enum$PaymentMode(Enum$PaymentMode e) {
  switch (e) {
    case Enum$PaymentMode.Cash:
      return r'Cash';
    case Enum$PaymentMode.SavedPaymentMethod:
      return r'SavedPaymentMethod';
    case Enum$PaymentMode.PaymentGateway:
      return r'PaymentGateway';
    case Enum$PaymentMode.Wallet:
      return r'Wallet';
    case Enum$PaymentMode.$unknown:
      return r'$unknown';
  }
}

Enum$PaymentMode fromJson$Enum$PaymentMode(String value) {
  switch (value) {
    case r'Cash':
      return Enum$PaymentMode.Cash;
    case r'SavedPaymentMethod':
      return Enum$PaymentMode.SavedPaymentMethod;
    case r'PaymentGateway':
      return Enum$PaymentMode.PaymentGateway;
    case r'Wallet':
      return Enum$PaymentMode.Wallet;
    default:
      return Enum$PaymentMode.$unknown;
  }
}

enum Enum$AppColorScheme {
  Cobalt,
  CoralRed,
  EarthyGreen,
  SunburstYellow,
  HyperPink,
  ElectricIndigo,
  AutumnOrange,
  Noir,
  $unknown;

  factory Enum$AppColorScheme.fromJson(String value) =>
      fromJson$Enum$AppColorScheme(value);

  String toJson() => toJson$Enum$AppColorScheme(this);
}

String toJson$Enum$AppColorScheme(Enum$AppColorScheme e) {
  switch (e) {
    case Enum$AppColorScheme.Cobalt:
      return r'Cobalt';
    case Enum$AppColorScheme.CoralRed:
      return r'CoralRed';
    case Enum$AppColorScheme.EarthyGreen:
      return r'EarthyGreen';
    case Enum$AppColorScheme.SunburstYellow:
      return r'SunburstYellow';
    case Enum$AppColorScheme.HyperPink:
      return r'HyperPink';
    case Enum$AppColorScheme.ElectricIndigo:
      return r'ElectricIndigo';
    case Enum$AppColorScheme.AutumnOrange:
      return r'AutumnOrange';
    case Enum$AppColorScheme.Noir:
      return r'Noir';
    case Enum$AppColorScheme.$unknown:
      return r'$unknown';
  }
}

Enum$AppColorScheme fromJson$Enum$AppColorScheme(String value) {
  switch (value) {
    case r'Cobalt':
      return Enum$AppColorScheme.Cobalt;
    case r'CoralRed':
      return Enum$AppColorScheme.CoralRed;
    case r'EarthyGreen':
      return Enum$AppColorScheme.EarthyGreen;
    case r'SunburstYellow':
      return Enum$AppColorScheme.SunburstYellow;
    case r'HyperPink':
      return Enum$AppColorScheme.HyperPink;
    case r'ElectricIndigo':
      return Enum$AppColorScheme.ElectricIndigo;
    case r'AutumnOrange':
      return Enum$AppColorScheme.AutumnOrange;
    case r'Noir':
      return Enum$AppColorScheme.Noir;
    default:
      return Enum$AppColorScheme.$unknown;
  }
}

enum Enum$LicenseType {
  Regular,
  Extended,
  Bronze,
  Silver,
  Gold,
  $unknown;

  factory Enum$LicenseType.fromJson(String value) =>
      fromJson$Enum$LicenseType(value);

  String toJson() => toJson$Enum$LicenseType(this);
}

String toJson$Enum$LicenseType(Enum$LicenseType e) {
  switch (e) {
    case Enum$LicenseType.Regular:
      return r'Regular';
    case Enum$LicenseType.Extended:
      return r'Extended';
    case Enum$LicenseType.Bronze:
      return r'Bronze';
    case Enum$LicenseType.Silver:
      return r'Silver';
    case Enum$LicenseType.Gold:
      return r'Gold';
    case Enum$LicenseType.$unknown:
      return r'$unknown';
  }
}

Enum$LicenseType fromJson$Enum$LicenseType(String value) {
  switch (value) {
    case r'Regular':
      return Enum$LicenseType.Regular;
    case r'Extended':
      return Enum$LicenseType.Extended;
    case r'Bronze':
      return Enum$LicenseType.Bronze;
    case r'Silver':
      return Enum$LicenseType.Silver;
    case r'Gold':
      return Enum$LicenseType.Gold;
    default:
      return Enum$LicenseType.$unknown;
  }
}

enum Enum$AppType {
  Taxi,
  Shop,
  Parking,
  $unknown;

  factory Enum$AppType.fromJson(String value) => fromJson$Enum$AppType(value);

  String toJson() => toJson$Enum$AppType(this);
}

String toJson$Enum$AppType(Enum$AppType e) {
  switch (e) {
    case Enum$AppType.Taxi:
      return r'Taxi';
    case Enum$AppType.Shop:
      return r'Shop';
    case Enum$AppType.Parking:
      return r'Parking';
    case Enum$AppType.$unknown:
      return r'$unknown';
  }
}

Enum$AppType fromJson$Enum$AppType(String value) {
  switch (value) {
    case r'Taxi':
      return Enum$AppType.Taxi;
    case r'Shop':
      return Enum$AppType.Shop;
    case r'Parking':
      return Enum$AppType.Parking;
    default:
      return Enum$AppType.$unknown;
  }
}

enum Enum$PlatformAddOn {
  FleetAddOn,
  $unknown;

  factory Enum$PlatformAddOn.fromJson(String value) =>
      fromJson$Enum$PlatformAddOn(value);

  String toJson() => toJson$Enum$PlatformAddOn(this);
}

String toJson$Enum$PlatformAddOn(Enum$PlatformAddOn e) {
  switch (e) {
    case Enum$PlatformAddOn.FleetAddOn:
      return r'FleetAddOn';
    case Enum$PlatformAddOn.$unknown:
      return r'$unknown';
  }
}

Enum$PlatformAddOn fromJson$Enum$PlatformAddOn(String value) {
  switch (value) {
    case r'FleetAddOn':
      return Enum$PlatformAddOn.FleetAddOn;
    default:
      return Enum$PlatformAddOn.$unknown;
  }
}

enum Enum$TaxiOrderType {
  Ride,
  Rideshare,
  ParcelDelivery,
  FoodDelivery,
  ShopDelivery,
  $unknown;

  factory Enum$TaxiOrderType.fromJson(String value) =>
      fromJson$Enum$TaxiOrderType(value);

  String toJson() => toJson$Enum$TaxiOrderType(this);
}

String toJson$Enum$TaxiOrderType(Enum$TaxiOrderType e) {
  switch (e) {
    case Enum$TaxiOrderType.Ride:
      return r'Ride';
    case Enum$TaxiOrderType.Rideshare:
      return r'Rideshare';
    case Enum$TaxiOrderType.ParcelDelivery:
      return r'ParcelDelivery';
    case Enum$TaxiOrderType.FoodDelivery:
      return r'FoodDelivery';
    case Enum$TaxiOrderType.ShopDelivery:
      return r'ShopDelivery';
    case Enum$TaxiOrderType.$unknown:
      return r'$unknown';
  }
}

Enum$TaxiOrderType fromJson$Enum$TaxiOrderType(String value) {
  switch (value) {
    case r'Ride':
      return Enum$TaxiOrderType.Ride;
    case r'Rideshare':
      return Enum$TaxiOrderType.Rideshare;
    case r'ParcelDelivery':
      return Enum$TaxiOrderType.ParcelDelivery;
    case r'FoodDelivery':
      return Enum$TaxiOrderType.FoodDelivery;
    case r'ShopDelivery':
      return Enum$TaxiOrderType.ShopDelivery;
    default:
      return Enum$TaxiOrderType.$unknown;
  }
}

enum Enum$PricingMode {
  FIXED,
  RANGE,
  $unknown;

  factory Enum$PricingMode.fromJson(String value) =>
      fromJson$Enum$PricingMode(value);

  String toJson() => toJson$Enum$PricingMode(this);
}

String toJson$Enum$PricingMode(Enum$PricingMode e) {
  switch (e) {
    case Enum$PricingMode.FIXED:
      return r'FIXED';
    case Enum$PricingMode.RANGE:
      return r'RANGE';
    case Enum$PricingMode.$unknown:
      return r'$unknown';
  }
}

Enum$PricingMode fromJson$Enum$PricingMode(String value) {
  switch (value) {
    case r'FIXED':
      return Enum$PricingMode.FIXED;
    case r'RANGE':
      return Enum$PricingMode.RANGE;
    default:
      return Enum$PricingMode.$unknown;
  }
}

enum Enum$RangePolicy {
  ENFORCE,
  SOFT,
  OPEN,
  $unknown;

  factory Enum$RangePolicy.fromJson(String value) =>
      fromJson$Enum$RangePolicy(value);

  String toJson() => toJson$Enum$RangePolicy(this);
}

String toJson$Enum$RangePolicy(Enum$RangePolicy e) {
  switch (e) {
    case Enum$RangePolicy.ENFORCE:
      return r'ENFORCE';
    case Enum$RangePolicy.SOFT:
      return r'SOFT';
    case Enum$RangePolicy.OPEN:
      return r'OPEN';
    case Enum$RangePolicy.$unknown:
      return r'$unknown';
  }
}

Enum$RangePolicy fromJson$Enum$RangePolicy(String value) {
  switch (value) {
    case r'ENFORCE':
      return Enum$RangePolicy.ENFORCE;
    case r'SOFT':
      return Enum$RangePolicy.SOFT;
    case r'OPEN':
      return Enum$RangePolicy.OPEN;
    default:
      return Enum$RangePolicy.$unknown;
  }
}

enum Enum$ServiceOptionIcon {
  Pet,
  TwoWay,
  Luggage,
  PackageDelivery,
  Shopping,
  Custom1,
  Custom2,
  Custom3,
  Custom4,
  Custom5,
  $unknown;

  factory Enum$ServiceOptionIcon.fromJson(String value) =>
      fromJson$Enum$ServiceOptionIcon(value);

  String toJson() => toJson$Enum$ServiceOptionIcon(this);
}

String toJson$Enum$ServiceOptionIcon(Enum$ServiceOptionIcon e) {
  switch (e) {
    case Enum$ServiceOptionIcon.Pet:
      return r'Pet';
    case Enum$ServiceOptionIcon.TwoWay:
      return r'TwoWay';
    case Enum$ServiceOptionIcon.Luggage:
      return r'Luggage';
    case Enum$ServiceOptionIcon.PackageDelivery:
      return r'PackageDelivery';
    case Enum$ServiceOptionIcon.Shopping:
      return r'Shopping';
    case Enum$ServiceOptionIcon.Custom1:
      return r'Custom1';
    case Enum$ServiceOptionIcon.Custom2:
      return r'Custom2';
    case Enum$ServiceOptionIcon.Custom3:
      return r'Custom3';
    case Enum$ServiceOptionIcon.Custom4:
      return r'Custom4';
    case Enum$ServiceOptionIcon.Custom5:
      return r'Custom5';
    case Enum$ServiceOptionIcon.$unknown:
      return r'$unknown';
  }
}

Enum$ServiceOptionIcon fromJson$Enum$ServiceOptionIcon(String value) {
  switch (value) {
    case r'Pet':
      return Enum$ServiceOptionIcon.Pet;
    case r'TwoWay':
      return Enum$ServiceOptionIcon.TwoWay;
    case r'Luggage':
      return Enum$ServiceOptionIcon.Luggage;
    case r'PackageDelivery':
      return Enum$ServiceOptionIcon.PackageDelivery;
    case r'Shopping':
      return Enum$ServiceOptionIcon.Shopping;
    case r'Custom1':
      return Enum$ServiceOptionIcon.Custom1;
    case r'Custom2':
      return Enum$ServiceOptionIcon.Custom2;
    case r'Custom3':
      return Enum$ServiceOptionIcon.Custom3;
    case r'Custom4':
      return Enum$ServiceOptionIcon.Custom4;
    case r'Custom5':
      return Enum$ServiceOptionIcon.Custom5;
    default:
      return Enum$ServiceOptionIcon.$unknown;
  }
}

enum Enum$ProviderBrand {
  Visa,
  Mastercard,
  Amex,
  Discover,
  Diners,
  EftPosAu,
  JCB,
  UnionPay,
  Unknown,
  $unknown;

  factory Enum$ProviderBrand.fromJson(String value) =>
      fromJson$Enum$ProviderBrand(value);

  String toJson() => toJson$Enum$ProviderBrand(this);
}

String toJson$Enum$ProviderBrand(Enum$ProviderBrand e) {
  switch (e) {
    case Enum$ProviderBrand.Visa:
      return r'Visa';
    case Enum$ProviderBrand.Mastercard:
      return r'Mastercard';
    case Enum$ProviderBrand.Amex:
      return r'Amex';
    case Enum$ProviderBrand.Discover:
      return r'Discover';
    case Enum$ProviderBrand.Diners:
      return r'Diners';
    case Enum$ProviderBrand.EftPosAu:
      return r'EftPosAu';
    case Enum$ProviderBrand.JCB:
      return r'JCB';
    case Enum$ProviderBrand.UnionPay:
      return r'UnionPay';
    case Enum$ProviderBrand.Unknown:
      return r'Unknown';
    case Enum$ProviderBrand.$unknown:
      return r'$unknown';
  }
}

Enum$ProviderBrand fromJson$Enum$ProviderBrand(String value) {
  switch (value) {
    case r'Visa':
      return Enum$ProviderBrand.Visa;
    case r'Mastercard':
      return Enum$ProviderBrand.Mastercard;
    case r'Amex':
      return Enum$ProviderBrand.Amex;
    case r'Discover':
      return Enum$ProviderBrand.Discover;
    case r'Diners':
      return Enum$ProviderBrand.Diners;
    case r'EftPosAu':
      return Enum$ProviderBrand.EftPosAu;
    case r'JCB':
      return Enum$ProviderBrand.JCB;
    case r'UnionPay':
      return Enum$ProviderBrand.UnionPay;
    case r'Unknown':
      return Enum$ProviderBrand.Unknown;
    default:
      return Enum$ProviderBrand.$unknown;
  }
}

enum Enum$GatewayLinkMethod {
  none,
  redirect,
  manual,
  $unknown;

  factory Enum$GatewayLinkMethod.fromJson(String value) =>
      fromJson$Enum$GatewayLinkMethod(value);

  String toJson() => toJson$Enum$GatewayLinkMethod(this);
}

String toJson$Enum$GatewayLinkMethod(Enum$GatewayLinkMethod e) {
  switch (e) {
    case Enum$GatewayLinkMethod.none:
      return r'none';
    case Enum$GatewayLinkMethod.redirect:
      return r'redirect';
    case Enum$GatewayLinkMethod.manual:
      return r'manual';
    case Enum$GatewayLinkMethod.$unknown:
      return r'$unknown';
  }
}

Enum$GatewayLinkMethod fromJson$Enum$GatewayLinkMethod(String value) {
  switch (value) {
    case r'none':
      return Enum$GatewayLinkMethod.none;
    case r'redirect':
      return Enum$GatewayLinkMethod.redirect;
    case r'manual':
      return Enum$GatewayLinkMethod.manual;
    default:
      return Enum$GatewayLinkMethod.$unknown;
  }
}

enum Enum$RiderOrderUpdateType {
  StatusUpdated,
  NewMessageReceived,
  DriverLocationUpdated,
  DriverAssigned,
  DriverCancelled,
  OrderCompleted,
  NewEphemeralMessage,
  NoDriverFound,
  $unknown;

  factory Enum$RiderOrderUpdateType.fromJson(String value) =>
      fromJson$Enum$RiderOrderUpdateType(value);

  String toJson() => toJson$Enum$RiderOrderUpdateType(this);
}

String toJson$Enum$RiderOrderUpdateType(Enum$RiderOrderUpdateType e) {
  switch (e) {
    case Enum$RiderOrderUpdateType.StatusUpdated:
      return r'StatusUpdated';
    case Enum$RiderOrderUpdateType.NewMessageReceived:
      return r'NewMessageReceived';
    case Enum$RiderOrderUpdateType.DriverLocationUpdated:
      return r'DriverLocationUpdated';
    case Enum$RiderOrderUpdateType.DriverAssigned:
      return r'DriverAssigned';
    case Enum$RiderOrderUpdateType.DriverCancelled:
      return r'DriverCancelled';
    case Enum$RiderOrderUpdateType.OrderCompleted:
      return r'OrderCompleted';
    case Enum$RiderOrderUpdateType.NewEphemeralMessage:
      return r'NewEphemeralMessage';
    case Enum$RiderOrderUpdateType.NoDriverFound:
      return r'NoDriverFound';
    case Enum$RiderOrderUpdateType.$unknown:
      return r'$unknown';
  }
}

Enum$RiderOrderUpdateType fromJson$Enum$RiderOrderUpdateType(String value) {
  switch (value) {
    case r'StatusUpdated':
      return Enum$RiderOrderUpdateType.StatusUpdated;
    case r'NewMessageReceived':
      return Enum$RiderOrderUpdateType.NewMessageReceived;
    case r'DriverLocationUpdated':
      return Enum$RiderOrderUpdateType.DriverLocationUpdated;
    case r'DriverAssigned':
      return Enum$RiderOrderUpdateType.DriverAssigned;
    case r'DriverCancelled':
      return Enum$RiderOrderUpdateType.DriverCancelled;
    case r'OrderCompleted':
      return Enum$RiderOrderUpdateType.OrderCompleted;
    case r'NewEphemeralMessage':
      return Enum$RiderOrderUpdateType.NewEphemeralMessage;
    case r'NoDriverFound':
      return Enum$RiderOrderUpdateType.NoDriverFound;
    default:
      return Enum$RiderOrderUpdateType.$unknown;
  }
}

enum Enum$OrderStatus {
  Requested,
  NotFound,
  NoCloseFound,
  Found,
  DriverAccepted,
  Arrived,
  WaitingForPrePay,
  DriverCanceled,
  RiderCanceled,
  Started,
  WaitingForDriverFee,
  WaitingForPostPay,
  WaitingForReview,
  Finished,
  Booked,
  Expired,
  $unknown;

  factory Enum$OrderStatus.fromJson(String value) =>
      fromJson$Enum$OrderStatus(value);

  String toJson() => toJson$Enum$OrderStatus(this);
}

String toJson$Enum$OrderStatus(Enum$OrderStatus e) {
  switch (e) {
    case Enum$OrderStatus.Requested:
      return r'Requested';
    case Enum$OrderStatus.NotFound:
      return r'NotFound';
    case Enum$OrderStatus.NoCloseFound:
      return r'NoCloseFound';
    case Enum$OrderStatus.Found:
      return r'Found';
    case Enum$OrderStatus.DriverAccepted:
      return r'DriverAccepted';
    case Enum$OrderStatus.Arrived:
      return r'Arrived';
    case Enum$OrderStatus.WaitingForPrePay:
      return r'WaitingForPrePay';
    case Enum$OrderStatus.DriverCanceled:
      return r'DriverCanceled';
    case Enum$OrderStatus.RiderCanceled:
      return r'RiderCanceled';
    case Enum$OrderStatus.Started:
      return r'Started';
    case Enum$OrderStatus.WaitingForDriverFee:
      return r'WaitingForDriverFee';
    case Enum$OrderStatus.WaitingForPostPay:
      return r'WaitingForPostPay';
    case Enum$OrderStatus.WaitingForReview:
      return r'WaitingForReview';
    case Enum$OrderStatus.Finished:
      return r'Finished';
    case Enum$OrderStatus.Booked:
      return r'Booked';
    case Enum$OrderStatus.Expired:
      return r'Expired';
    case Enum$OrderStatus.$unknown:
      return r'$unknown';
  }
}

Enum$OrderStatus fromJson$Enum$OrderStatus(String value) {
  switch (value) {
    case r'Requested':
      return Enum$OrderStatus.Requested;
    case r'NotFound':
      return Enum$OrderStatus.NotFound;
    case r'NoCloseFound':
      return Enum$OrderStatus.NoCloseFound;
    case r'Found':
      return Enum$OrderStatus.Found;
    case r'DriverAccepted':
      return Enum$OrderStatus.DriverAccepted;
    case r'Arrived':
      return Enum$OrderStatus.Arrived;
    case r'WaitingForPrePay':
      return Enum$OrderStatus.WaitingForPrePay;
    case r'DriverCanceled':
      return Enum$OrderStatus.DriverCanceled;
    case r'RiderCanceled':
      return Enum$OrderStatus.RiderCanceled;
    case r'Started':
      return Enum$OrderStatus.Started;
    case r'WaitingForDriverFee':
      return Enum$OrderStatus.WaitingForDriverFee;
    case r'WaitingForPostPay':
      return Enum$OrderStatus.WaitingForPostPay;
    case r'WaitingForReview':
      return Enum$OrderStatus.WaitingForReview;
    case r'Finished':
      return Enum$OrderStatus.Finished;
    case r'Booked':
      return Enum$OrderStatus.Booked;
    case r'Expired':
      return Enum$OrderStatus.Expired;
    default:
      return Enum$OrderStatus.$unknown;
  }
}

enum Enum$AuthMethodType {
  PHONE,
  EMAIL,
  GOOGLE,
  APPLE,
  PASSKEY,
  $unknown;

  factory Enum$AuthMethodType.fromJson(String value) =>
      fromJson$Enum$AuthMethodType(value);

  String toJson() => toJson$Enum$AuthMethodType(this);
}

String toJson$Enum$AuthMethodType(Enum$AuthMethodType e) {
  switch (e) {
    case Enum$AuthMethodType.PHONE:
      return r'PHONE';
    case Enum$AuthMethodType.EMAIL:
      return r'EMAIL';
    case Enum$AuthMethodType.GOOGLE:
      return r'GOOGLE';
    case Enum$AuthMethodType.APPLE:
      return r'APPLE';
    case Enum$AuthMethodType.PASSKEY:
      return r'PASSKEY';
    case Enum$AuthMethodType.$unknown:
      return r'$unknown';
  }
}

Enum$AuthMethodType fromJson$Enum$AuthMethodType(String value) {
  switch (value) {
    case r'PHONE':
      return Enum$AuthMethodType.PHONE;
    case r'EMAIL':
      return Enum$AuthMethodType.EMAIL;
    case r'GOOGLE':
      return Enum$AuthMethodType.GOOGLE;
    case r'APPLE':
      return Enum$AuthMethodType.APPLE;
    case r'PASSKEY':
      return Enum$AuthMethodType.PASSKEY;
    default:
      return Enum$AuthMethodType.$unknown;
  }
}

enum Enum$Gender {
  Male,
  Female,
  Other,
  Unknown,
  $unknown;

  factory Enum$Gender.fromJson(String value) => fromJson$Enum$Gender(value);

  String toJson() => toJson$Enum$Gender(this);
}

String toJson$Enum$Gender(Enum$Gender e) {
  switch (e) {
    case Enum$Gender.Male:
      return r'Male';
    case Enum$Gender.Female:
      return r'Female';
    case Enum$Gender.Other:
      return r'Other';
    case Enum$Gender.Unknown:
      return r'Unknown';
    case Enum$Gender.$unknown:
      return r'$unknown';
  }
}

Enum$Gender fromJson$Enum$Gender(String value) {
  switch (value) {
    case r'Male':
      return Enum$Gender.Male;
    case r'Female':
      return Enum$Gender.Female;
    case r'Other':
      return Enum$Gender.Other;
    case r'Unknown':
      return Enum$Gender.Unknown;
    default:
      return Enum$Gender.$unknown;
  }
}

enum Enum$ServiceOptionType {
  Free,
  Paid,
  TwoWay,
  $unknown;

  factory Enum$ServiceOptionType.fromJson(String value) =>
      fromJson$Enum$ServiceOptionType(value);

  String toJson() => toJson$Enum$ServiceOptionType(this);
}

String toJson$Enum$ServiceOptionType(Enum$ServiceOptionType e) {
  switch (e) {
    case Enum$ServiceOptionType.Free:
      return r'Free';
    case Enum$ServiceOptionType.Paid:
      return r'Paid';
    case Enum$ServiceOptionType.TwoWay:
      return r'TwoWay';
    case Enum$ServiceOptionType.$unknown:
      return r'$unknown';
  }
}

Enum$ServiceOptionType fromJson$Enum$ServiceOptionType(String value) {
  switch (value) {
    case r'Free':
      return Enum$ServiceOptionType.Free;
    case r'Paid':
      return Enum$ServiceOptionType.Paid;
    case r'TwoWay':
      return Enum$ServiceOptionType.TwoWay;
    default:
      return Enum$ServiceOptionType.$unknown;
  }
}

enum Enum$ServicePaymentMethod {
  CashCredit,
  OnlyCredit,
  OnlyCash,
  $unknown;

  factory Enum$ServicePaymentMethod.fromJson(String value) =>
      fromJson$Enum$ServicePaymentMethod(value);

  String toJson() => toJson$Enum$ServicePaymentMethod(this);
}

String toJson$Enum$ServicePaymentMethod(Enum$ServicePaymentMethod e) {
  switch (e) {
    case Enum$ServicePaymentMethod.CashCredit:
      return r'CashCredit';
    case Enum$ServicePaymentMethod.OnlyCredit:
      return r'OnlyCredit';
    case Enum$ServicePaymentMethod.OnlyCash:
      return r'OnlyCash';
    case Enum$ServicePaymentMethod.$unknown:
      return r'$unknown';
  }
}

Enum$ServicePaymentMethod fromJson$Enum$ServicePaymentMethod(String value) {
  switch (value) {
    case r'CashCredit':
      return Enum$ServicePaymentMethod.CashCredit;
    case r'OnlyCredit':
      return Enum$ServicePaymentMethod.OnlyCredit;
    case r'OnlyCash':
      return Enum$ServicePaymentMethod.OnlyCash;
    default:
      return Enum$ServicePaymentMethod.$unknown;
  }
}

enum Enum$CalculateFareError {
  RegionUnsupported,
  NoServiceInRegion,
  $unknown;

  factory Enum$CalculateFareError.fromJson(String value) =>
      fromJson$Enum$CalculateFareError(value);

  String toJson() => toJson$Enum$CalculateFareError(this);
}

String toJson$Enum$CalculateFareError(Enum$CalculateFareError e) {
  switch (e) {
    case Enum$CalculateFareError.RegionUnsupported:
      return r'RegionUnsupported';
    case Enum$CalculateFareError.NoServiceInRegion:
      return r'NoServiceInRegion';
    case Enum$CalculateFareError.$unknown:
      return r'$unknown';
  }
}

Enum$CalculateFareError fromJson$Enum$CalculateFareError(String value) {
  switch (value) {
    case r'RegionUnsupported':
      return Enum$CalculateFareError.RegionUnsupported;
    case r'NoServiceInRegion':
      return Enum$CalculateFareError.NoServiceInRegion;
    default:
      return Enum$CalculateFareError.$unknown;
  }
}

enum Enum$TopUpWalletStatus {
  OK,
  Redirect,
  Failed,
  $unknown;

  factory Enum$TopUpWalletStatus.fromJson(String value) =>
      fromJson$Enum$TopUpWalletStatus(value);

  String toJson() => toJson$Enum$TopUpWalletStatus(this);
}

String toJson$Enum$TopUpWalletStatus(Enum$TopUpWalletStatus e) {
  switch (e) {
    case Enum$TopUpWalletStatus.OK:
      return r'OK';
    case Enum$TopUpWalletStatus.Redirect:
      return r'Redirect';
    case Enum$TopUpWalletStatus.Failed:
      return r'Failed';
    case Enum$TopUpWalletStatus.$unknown:
      return r'$unknown';
  }
}

Enum$TopUpWalletStatus fromJson$Enum$TopUpWalletStatus(String value) {
  switch (value) {
    case r'OK':
      return Enum$TopUpWalletStatus.OK;
    case r'Redirect':
      return Enum$TopUpWalletStatus.Redirect;
    case r'Failed':
      return Enum$TopUpWalletStatus.Failed;
    default:
      return Enum$TopUpWalletStatus.$unknown;
  }
}

enum Enum$TransactionAction {
  Recharge,
  Deduct,
  $unknown;

  factory Enum$TransactionAction.fromJson(String value) =>
      fromJson$Enum$TransactionAction(value);

  String toJson() => toJson$Enum$TransactionAction(this);
}

String toJson$Enum$TransactionAction(Enum$TransactionAction e) {
  switch (e) {
    case Enum$TransactionAction.Recharge:
      return r'Recharge';
    case Enum$TransactionAction.Deduct:
      return r'Deduct';
    case Enum$TransactionAction.$unknown:
      return r'$unknown';
  }
}

Enum$TransactionAction fromJson$Enum$TransactionAction(String value) {
  switch (value) {
    case r'Recharge':
      return Enum$TransactionAction.Recharge;
    case r'Deduct':
      return Enum$TransactionAction.Deduct;
    default:
      return Enum$TransactionAction.$unknown;
  }
}

enum Enum$RiderDeductTransactionType {
  OrderFee,
  ParkingFee,
  CancellationFee,
  Withdraw,
  Correction,
  $unknown;

  factory Enum$RiderDeductTransactionType.fromJson(String value) =>
      fromJson$Enum$RiderDeductTransactionType(value);

  String toJson() => toJson$Enum$RiderDeductTransactionType(this);
}

String toJson$Enum$RiderDeductTransactionType(
  Enum$RiderDeductTransactionType e,
) {
  switch (e) {
    case Enum$RiderDeductTransactionType.OrderFee:
      return r'OrderFee';
    case Enum$RiderDeductTransactionType.ParkingFee:
      return r'ParkingFee';
    case Enum$RiderDeductTransactionType.CancellationFee:
      return r'CancellationFee';
    case Enum$RiderDeductTransactionType.Withdraw:
      return r'Withdraw';
    case Enum$RiderDeductTransactionType.Correction:
      return r'Correction';
    case Enum$RiderDeductTransactionType.$unknown:
      return r'$unknown';
  }
}

Enum$RiderDeductTransactionType fromJson$Enum$RiderDeductTransactionType(
  String value,
) {
  switch (value) {
    case r'OrderFee':
      return Enum$RiderDeductTransactionType.OrderFee;
    case r'ParkingFee':
      return Enum$RiderDeductTransactionType.ParkingFee;
    case r'CancellationFee':
      return Enum$RiderDeductTransactionType.CancellationFee;
    case r'Withdraw':
      return Enum$RiderDeductTransactionType.Withdraw;
    case r'Correction':
      return Enum$RiderDeductTransactionType.Correction;
    default:
      return Enum$RiderDeductTransactionType.$unknown;
  }
}

enum Enum$RiderRechargeTransactionType {
  BankTransfer,
  Gift,
  Correction,
  InAppPayment,
  $unknown;

  factory Enum$RiderRechargeTransactionType.fromJson(String value) =>
      fromJson$Enum$RiderRechargeTransactionType(value);

  String toJson() => toJson$Enum$RiderRechargeTransactionType(this);
}

String toJson$Enum$RiderRechargeTransactionType(
  Enum$RiderRechargeTransactionType e,
) {
  switch (e) {
    case Enum$RiderRechargeTransactionType.BankTransfer:
      return r'BankTransfer';
    case Enum$RiderRechargeTransactionType.Gift:
      return r'Gift';
    case Enum$RiderRechargeTransactionType.Correction:
      return r'Correction';
    case Enum$RiderRechargeTransactionType.InAppPayment:
      return r'InAppPayment';
    case Enum$RiderRechargeTransactionType.$unknown:
      return r'$unknown';
  }
}

Enum$RiderRechargeTransactionType fromJson$Enum$RiderRechargeTransactionType(
  String value,
) {
  switch (value) {
    case r'BankTransfer':
      return Enum$RiderRechargeTransactionType.BankTransfer;
    case r'Gift':
      return Enum$RiderRechargeTransactionType.Gift;
    case r'Correction':
      return Enum$RiderRechargeTransactionType.Correction;
    case r'InAppPayment':
      return Enum$RiderRechargeTransactionType.InAppPayment;
    default:
      return Enum$RiderRechargeTransactionType.$unknown;
  }
}

enum Enum$ComplaintStatus {
  Submitted,
  UnderInvestigation,
  Resolved,
  $unknown;

  factory Enum$ComplaintStatus.fromJson(String value) =>
      fromJson$Enum$ComplaintStatus(value);

  String toJson() => toJson$Enum$ComplaintStatus(this);
}

String toJson$Enum$ComplaintStatus(Enum$ComplaintStatus e) {
  switch (e) {
    case Enum$ComplaintStatus.Submitted:
      return r'Submitted';
    case Enum$ComplaintStatus.UnderInvestigation:
      return r'UnderInvestigation';
    case Enum$ComplaintStatus.Resolved:
      return r'Resolved';
    case Enum$ComplaintStatus.$unknown:
      return r'$unknown';
  }
}

Enum$ComplaintStatus fromJson$Enum$ComplaintStatus(String value) {
  switch (value) {
    case r'Submitted':
      return Enum$ComplaintStatus.Submitted;
    case r'UnderInvestigation':
      return Enum$ComplaintStatus.UnderInvestigation;
    case r'Resolved':
      return Enum$ComplaintStatus.Resolved;
    default:
      return Enum$ComplaintStatus.$unknown;
  }
}

enum Enum$EphemeralMessageType {
  RateDriver,
  RiderCanceled,
  DriverCanceled,
  RideExpired,
  $unknown;

  factory Enum$EphemeralMessageType.fromJson(String value) =>
      fromJson$Enum$EphemeralMessageType(value);

  String toJson() => toJson$Enum$EphemeralMessageType(this);
}

String toJson$Enum$EphemeralMessageType(Enum$EphemeralMessageType e) {
  switch (e) {
    case Enum$EphemeralMessageType.RateDriver:
      return r'RateDriver';
    case Enum$EphemeralMessageType.RiderCanceled:
      return r'RiderCanceled';
    case Enum$EphemeralMessageType.DriverCanceled:
      return r'DriverCanceled';
    case Enum$EphemeralMessageType.RideExpired:
      return r'RideExpired';
    case Enum$EphemeralMessageType.$unknown:
      return r'$unknown';
  }
}

Enum$EphemeralMessageType fromJson$Enum$EphemeralMessageType(String value) {
  switch (value) {
    case r'RateDriver':
      return Enum$EphemeralMessageType.RateDriver;
    case r'RiderCanceled':
      return Enum$EphemeralMessageType.RiderCanceled;
    case r'DriverCanceled':
      return Enum$EphemeralMessageType.DriverCanceled;
    case r'RideExpired':
      return Enum$EphemeralMessageType.RideExpired;
    default:
      return Enum$EphemeralMessageType.$unknown;
  }
}

enum Enum$RiderAddressType {
  Home,
  Work,
  Partner,
  Gym,
  Parent,
  Cafe,
  Park,
  Other,
  $unknown;

  factory Enum$RiderAddressType.fromJson(String value) =>
      fromJson$Enum$RiderAddressType(value);

  String toJson() => toJson$Enum$RiderAddressType(this);
}

String toJson$Enum$RiderAddressType(Enum$RiderAddressType e) {
  switch (e) {
    case Enum$RiderAddressType.Home:
      return r'Home';
    case Enum$RiderAddressType.Work:
      return r'Work';
    case Enum$RiderAddressType.Partner:
      return r'Partner';
    case Enum$RiderAddressType.Gym:
      return r'Gym';
    case Enum$RiderAddressType.Parent:
      return r'Parent';
    case Enum$RiderAddressType.Cafe:
      return r'Cafe';
    case Enum$RiderAddressType.Park:
      return r'Park';
    case Enum$RiderAddressType.Other:
      return r'Other';
    case Enum$RiderAddressType.$unknown:
      return r'$unknown';
  }
}

Enum$RiderAddressType fromJson$Enum$RiderAddressType(String value) {
  switch (value) {
    case r'Home':
      return Enum$RiderAddressType.Home;
    case r'Work':
      return Enum$RiderAddressType.Work;
    case r'Partner':
      return Enum$RiderAddressType.Partner;
    case r'Gym':
      return Enum$RiderAddressType.Gym;
    case r'Parent':
      return Enum$RiderAddressType.Parent;
    case r'Cafe':
      return Enum$RiderAddressType.Cafe;
    case r'Park':
      return Enum$RiderAddressType.Park;
    case r'Other':
      return Enum$RiderAddressType.Other;
    default:
      return Enum$RiderAddressType.$unknown;
  }
}

enum Enum$GeoProvider {
  GOOGLE,
  MAPBOX,
  NOMINATIM,
  $unknown;

  factory Enum$GeoProvider.fromJson(String value) =>
      fromJson$Enum$GeoProvider(value);

  String toJson() => toJson$Enum$GeoProvider(this);
}

String toJson$Enum$GeoProvider(Enum$GeoProvider e) {
  switch (e) {
    case Enum$GeoProvider.GOOGLE:
      return r'GOOGLE';
    case Enum$GeoProvider.MAPBOX:
      return r'MAPBOX';
    case Enum$GeoProvider.NOMINATIM:
      return r'NOMINATIM';
    case Enum$GeoProvider.$unknown:
      return r'$unknown';
  }
}

Enum$GeoProvider fromJson$Enum$GeoProvider(String value) {
  switch (value) {
    case r'GOOGLE':
      return Enum$GeoProvider.GOOGLE;
    case r'MAPBOX':
      return Enum$GeoProvider.MAPBOX;
    case r'NOMINATIM':
      return Enum$GeoProvider.NOMINATIM;
    default:
      return Enum$GeoProvider.$unknown;
  }
}

enum Enum$VersionStatus {
  Latest,
  MandatoryUpdate,
  OptionalUpdate,
  $unknown;

  factory Enum$VersionStatus.fromJson(String value) =>
      fromJson$Enum$VersionStatus(value);

  String toJson() => toJson$Enum$VersionStatus(this);
}

String toJson$Enum$VersionStatus(Enum$VersionStatus e) {
  switch (e) {
    case Enum$VersionStatus.Latest:
      return r'Latest';
    case Enum$VersionStatus.MandatoryUpdate:
      return r'MandatoryUpdate';
    case Enum$VersionStatus.OptionalUpdate:
      return r'OptionalUpdate';
    case Enum$VersionStatus.$unknown:
      return r'$unknown';
  }
}

Enum$VersionStatus fromJson$Enum$VersionStatus(String value) {
  switch (value) {
    case r'Latest':
      return Enum$VersionStatus.Latest;
    case r'MandatoryUpdate':
      return Enum$VersionStatus.MandatoryUpdate;
    case r'OptionalUpdate':
      return Enum$VersionStatus.OptionalUpdate;
    default:
      return Enum$VersionStatus.$unknown;
  }
}

enum Enum$__TypeKind {
  SCALAR,
  OBJECT,
  INTERFACE,
  UNION,
  ENUM,
  INPUT_OBJECT,
  LIST,
  NON_NULL,
  $unknown;

  factory Enum$__TypeKind.fromJson(String value) =>
      fromJson$Enum$__TypeKind(value);

  String toJson() => toJson$Enum$__TypeKind(this);
}

String toJson$Enum$__TypeKind(Enum$__TypeKind e) {
  switch (e) {
    case Enum$__TypeKind.SCALAR:
      return r'SCALAR';
    case Enum$__TypeKind.OBJECT:
      return r'OBJECT';
    case Enum$__TypeKind.INTERFACE:
      return r'INTERFACE';
    case Enum$__TypeKind.UNION:
      return r'UNION';
    case Enum$__TypeKind.ENUM:
      return r'ENUM';
    case Enum$__TypeKind.INPUT_OBJECT:
      return r'INPUT_OBJECT';
    case Enum$__TypeKind.LIST:
      return r'LIST';
    case Enum$__TypeKind.NON_NULL:
      return r'NON_NULL';
    case Enum$__TypeKind.$unknown:
      return r'$unknown';
  }
}

Enum$__TypeKind fromJson$Enum$__TypeKind(String value) {
  switch (value) {
    case r'SCALAR':
      return Enum$__TypeKind.SCALAR;
    case r'OBJECT':
      return Enum$__TypeKind.OBJECT;
    case r'INTERFACE':
      return Enum$__TypeKind.INTERFACE;
    case r'UNION':
      return Enum$__TypeKind.UNION;
    case r'ENUM':
      return Enum$__TypeKind.ENUM;
    case r'INPUT_OBJECT':
      return Enum$__TypeKind.INPUT_OBJECT;
    case r'LIST':
      return Enum$__TypeKind.LIST;
    case r'NON_NULL':
      return Enum$__TypeKind.NON_NULL;
    default:
      return Enum$__TypeKind.$unknown;
  }
}

enum Enum$__DirectiveLocation {
  QUERY,
  MUTATION,
  SUBSCRIPTION,
  FIELD,
  FRAGMENT_DEFINITION,
  FRAGMENT_SPREAD,
  INLINE_FRAGMENT,
  VARIABLE_DEFINITION,
  SCHEMA,
  SCALAR,
  OBJECT,
  FIELD_DEFINITION,
  ARGUMENT_DEFINITION,
  INTERFACE,
  UNION,
  ENUM,
  ENUM_VALUE,
  INPUT_OBJECT,
  INPUT_FIELD_DEFINITION,
  $unknown;

  factory Enum$__DirectiveLocation.fromJson(String value) =>
      fromJson$Enum$__DirectiveLocation(value);

  String toJson() => toJson$Enum$__DirectiveLocation(this);
}

String toJson$Enum$__DirectiveLocation(Enum$__DirectiveLocation e) {
  switch (e) {
    case Enum$__DirectiveLocation.QUERY:
      return r'QUERY';
    case Enum$__DirectiveLocation.MUTATION:
      return r'MUTATION';
    case Enum$__DirectiveLocation.SUBSCRIPTION:
      return r'SUBSCRIPTION';
    case Enum$__DirectiveLocation.FIELD:
      return r'FIELD';
    case Enum$__DirectiveLocation.FRAGMENT_DEFINITION:
      return r'FRAGMENT_DEFINITION';
    case Enum$__DirectiveLocation.FRAGMENT_SPREAD:
      return r'FRAGMENT_SPREAD';
    case Enum$__DirectiveLocation.INLINE_FRAGMENT:
      return r'INLINE_FRAGMENT';
    case Enum$__DirectiveLocation.VARIABLE_DEFINITION:
      return r'VARIABLE_DEFINITION';
    case Enum$__DirectiveLocation.SCHEMA:
      return r'SCHEMA';
    case Enum$__DirectiveLocation.SCALAR:
      return r'SCALAR';
    case Enum$__DirectiveLocation.OBJECT:
      return r'OBJECT';
    case Enum$__DirectiveLocation.FIELD_DEFINITION:
      return r'FIELD_DEFINITION';
    case Enum$__DirectiveLocation.ARGUMENT_DEFINITION:
      return r'ARGUMENT_DEFINITION';
    case Enum$__DirectiveLocation.INTERFACE:
      return r'INTERFACE';
    case Enum$__DirectiveLocation.UNION:
      return r'UNION';
    case Enum$__DirectiveLocation.ENUM:
      return r'ENUM';
    case Enum$__DirectiveLocation.ENUM_VALUE:
      return r'ENUM_VALUE';
    case Enum$__DirectiveLocation.INPUT_OBJECT:
      return r'INPUT_OBJECT';
    case Enum$__DirectiveLocation.INPUT_FIELD_DEFINITION:
      return r'INPUT_FIELD_DEFINITION';
    case Enum$__DirectiveLocation.$unknown:
      return r'$unknown';
  }
}

Enum$__DirectiveLocation fromJson$Enum$__DirectiveLocation(String value) {
  switch (value) {
    case r'QUERY':
      return Enum$__DirectiveLocation.QUERY;
    case r'MUTATION':
      return Enum$__DirectiveLocation.MUTATION;
    case r'SUBSCRIPTION':
      return Enum$__DirectiveLocation.SUBSCRIPTION;
    case r'FIELD':
      return Enum$__DirectiveLocation.FIELD;
    case r'FRAGMENT_DEFINITION':
      return Enum$__DirectiveLocation.FRAGMENT_DEFINITION;
    case r'FRAGMENT_SPREAD':
      return Enum$__DirectiveLocation.FRAGMENT_SPREAD;
    case r'INLINE_FRAGMENT':
      return Enum$__DirectiveLocation.INLINE_FRAGMENT;
    case r'VARIABLE_DEFINITION':
      return Enum$__DirectiveLocation.VARIABLE_DEFINITION;
    case r'SCHEMA':
      return Enum$__DirectiveLocation.SCHEMA;
    case r'SCALAR':
      return Enum$__DirectiveLocation.SCALAR;
    case r'OBJECT':
      return Enum$__DirectiveLocation.OBJECT;
    case r'FIELD_DEFINITION':
      return Enum$__DirectiveLocation.FIELD_DEFINITION;
    case r'ARGUMENT_DEFINITION':
      return Enum$__DirectiveLocation.ARGUMENT_DEFINITION;
    case r'INTERFACE':
      return Enum$__DirectiveLocation.INTERFACE;
    case r'UNION':
      return Enum$__DirectiveLocation.UNION;
    case r'ENUM':
      return Enum$__DirectiveLocation.ENUM;
    case r'ENUM_VALUE':
      return Enum$__DirectiveLocation.ENUM_VALUE;
    case r'INPUT_OBJECT':
      return Enum$__DirectiveLocation.INPUT_OBJECT;
    case r'INPUT_FIELD_DEFINITION':
      return Enum$__DirectiveLocation.INPUT_FIELD_DEFINITION;
    default:
      return Enum$__DirectiveLocation.$unknown;
  }
}

const possibleTypesMap = <String, Set<String>>{
  'WaypointBase': {'RideWaypoint', 'DeliveryWaypoint', 'ShopWaypoint'},
  'PaymentMethodBase': {
    'CashPaymentMethod',
    'WalletPaymentMethod',
    'SavedAccount',
    'OnlinePaymentMethod',
  },
  'CostResult': {'FixedCost', 'RangeCost'},
};
