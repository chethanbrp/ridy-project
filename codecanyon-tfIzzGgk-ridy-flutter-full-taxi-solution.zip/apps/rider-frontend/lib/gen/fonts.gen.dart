// dart format width=80
/// GENERATED CODE - DO NOT MODIFY BY HAND
/// *****************************************************
///  FlutterGen
/// *****************************************************

// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: deprecated_member_use,directives_ordering,implicit_dynamic_list_literal,unnecessary_import

class FontFamily {
  FontFamily._();

  /// Font family: GeneralSans
  static const String generalSans = 'GeneralSans';

  /// Font family: Inter
  static const String inter = 'Inter';
}
