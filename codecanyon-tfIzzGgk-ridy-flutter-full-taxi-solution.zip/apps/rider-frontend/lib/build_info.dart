const String appVersion = '3.5.0';
final DateTime buildTime = DateTime.utc(2026, 2, 3, 17, 30, 45);
