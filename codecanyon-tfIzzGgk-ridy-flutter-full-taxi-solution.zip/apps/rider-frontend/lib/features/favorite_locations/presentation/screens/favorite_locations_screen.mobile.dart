import 'package:flutter/material.dart';

class FavoriteLocationsScreenMobile extends StatelessWidget {
  final Widget child;

  const FavoriteLocationsScreenMobile({
    super.key,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return child;
  }
}
