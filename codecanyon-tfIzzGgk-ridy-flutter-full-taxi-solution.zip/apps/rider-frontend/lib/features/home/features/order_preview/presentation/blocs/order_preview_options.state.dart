// part of 'order_preview_options.bloc.dart';

// @freezed
// sealed class OrderPreviewOptionsState with _$OrderPreviewOptionsState {
//   const factory OrderPreviewOptionsState({
//     required Fragment$ServiceCategory? selectedServiceCategory,
//     required Fragment$Service? selectedService,
//     required PaymentMethodUnion? paymentMethod,
//   }) = _OrderPreviewOptionsState;

//   factory OrderPreviewOptionsState.initial() => const OrderPreviewOptionsState(
//         selectedServiceCategory: null,
//         selectedService: null,
//         paymentMethod: null,
//       );

//   const OrderPreviewOptionsState._();

//   bool get canConfirm => paymentMethod != null && selectedService != null;
// }
