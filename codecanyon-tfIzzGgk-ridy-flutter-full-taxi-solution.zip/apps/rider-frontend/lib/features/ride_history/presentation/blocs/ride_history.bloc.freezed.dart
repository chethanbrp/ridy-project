// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'ride_history.bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$RideHistoryState {

 ApiResponse<Query$RideHistory> get rideHistoryState;
/// Create a copy of RideHistoryState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$RideHistoryStateCopyWith<RideHistoryState> get copyWith => _$RideHistoryStateCopyWithImpl<RideHistoryState>(this as RideHistoryState, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is RideHistoryState&&(identical(other.rideHistoryState, rideHistoryState) || other.rideHistoryState == rideHistoryState));
}


@override
int get hashCode => Object.hash(runtimeType,rideHistoryState);

@override
String toString() {
  return 'RideHistoryState(rideHistoryState: $rideHistoryState)';
}


}

/// @nodoc
abstract mixin class $RideHistoryStateCopyWith<$Res>  {
  factory $RideHistoryStateCopyWith(RideHistoryState value, $Res Function(RideHistoryState) _then) = _$RideHistoryStateCopyWithImpl;
@useResult
$Res call({
 ApiResponse<Query$RideHistory> rideHistoryState
});


$ApiResponseCopyWith<Query$RideHistory, $Res> get rideHistoryState;

}
/// @nodoc
class _$RideHistoryStateCopyWithImpl<$Res>
    implements $RideHistoryStateCopyWith<$Res> {
  _$RideHistoryStateCopyWithImpl(this._self, this._then);

  final RideHistoryState _self;
  final $Res Function(RideHistoryState) _then;

/// Create a copy of RideHistoryState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? rideHistoryState = null,}) {
  return _then(_self.copyWith(
rideHistoryState: null == rideHistoryState ? _self.rideHistoryState : rideHistoryState // ignore: cast_nullable_to_non_nullable
as ApiResponse<Query$RideHistory>,
  ));
}
/// Create a copy of RideHistoryState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<Query$RideHistory, $Res> get rideHistoryState {
  
  return $ApiResponseCopyWith<Query$RideHistory, $Res>(_self.rideHistoryState, (value) {
    return _then(_self.copyWith(rideHistoryState: value));
  });
}
}


/// Adds pattern-matching-related methods to [RideHistoryState].
extension RideHistoryStatePatterns on RideHistoryState {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _RideHistoryState value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _RideHistoryState() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _RideHistoryState value)  $default,){
final _that = this;
switch (_that) {
case _RideHistoryState():
return $default(_that);}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _RideHistoryState value)?  $default,){
final _that = this;
switch (_that) {
case _RideHistoryState() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( ApiResponse<Query$RideHistory> rideHistoryState)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _RideHistoryState() when $default != null:
return $default(_that.rideHistoryState);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( ApiResponse<Query$RideHistory> rideHistoryState)  $default,) {final _that = this;
switch (_that) {
case _RideHistoryState():
return $default(_that.rideHistoryState);}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( ApiResponse<Query$RideHistory> rideHistoryState)?  $default,) {final _that = this;
switch (_that) {
case _RideHistoryState() when $default != null:
return $default(_that.rideHistoryState);case _:
  return null;

}
}

}

/// @nodoc


class _RideHistoryState implements RideHistoryState {
  const _RideHistoryState({this.rideHistoryState = const ApiResponseInitial()});
  

@override@JsonKey() final  ApiResponse<Query$RideHistory> rideHistoryState;

/// Create a copy of RideHistoryState
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$RideHistoryStateCopyWith<_RideHistoryState> get copyWith => __$RideHistoryStateCopyWithImpl<_RideHistoryState>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _RideHistoryState&&(identical(other.rideHistoryState, rideHistoryState) || other.rideHistoryState == rideHistoryState));
}


@override
int get hashCode => Object.hash(runtimeType,rideHistoryState);

@override
String toString() {
  return 'RideHistoryState(rideHistoryState: $rideHistoryState)';
}


}

/// @nodoc
abstract mixin class _$RideHistoryStateCopyWith<$Res> implements $RideHistoryStateCopyWith<$Res> {
  factory _$RideHistoryStateCopyWith(_RideHistoryState value, $Res Function(_RideHistoryState) _then) = __$RideHistoryStateCopyWithImpl;
@override @useResult
$Res call({
 ApiResponse<Query$RideHistory> rideHistoryState
});


@override $ApiResponseCopyWith<Query$RideHistory, $Res> get rideHistoryState;

}
/// @nodoc
class __$RideHistoryStateCopyWithImpl<$Res>
    implements _$RideHistoryStateCopyWith<$Res> {
  __$RideHistoryStateCopyWithImpl(this._self, this._then);

  final _RideHistoryState _self;
  final $Res Function(_RideHistoryState) _then;

/// Create a copy of RideHistoryState
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? rideHistoryState = null,}) {
  return _then(_RideHistoryState(
rideHistoryState: null == rideHistoryState ? _self.rideHistoryState : rideHistoryState // ignore: cast_nullable_to_non_nullable
as ApiResponse<Query$RideHistory>,
  ));
}

/// Create a copy of RideHistoryState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<Query$RideHistory, $Res> get rideHistoryState {
  
  return $ApiResponseCopyWith<Query$RideHistory, $Res>(_self.rideHistoryState, (value) {
    return _then(_self.copyWith(rideHistoryState: value));
  });
}
}

// dart format on
