import 'package:flutter/material.dart';

class AnnouncementsScreenMobile extends StatelessWidget {
  const AnnouncementsScreenMobile({super.key});

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
