import 'package:flutter/material.dart';

class AnnouncementsScreenDesktop extends StatelessWidget {
  const AnnouncementsScreenDesktop({super.key});

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
