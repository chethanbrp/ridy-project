// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'wallet.bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$WalletState {

 ApiResponse<Query$Wallet> get walletState; FetchPolicy? get fetchPolicy;
/// Create a copy of WalletState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$WalletStateCopyWith<WalletState> get copyWith => _$WalletStateCopyWithImpl<WalletState>(this as WalletState, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is WalletState&&(identical(other.walletState, walletState) || other.walletState == walletState)&&(identical(other.fetchPolicy, fetchPolicy) || other.fetchPolicy == fetchPolicy));
}


@override
int get hashCode => Object.hash(runtimeType,walletState,fetchPolicy);

@override
String toString() {
  return 'WalletState(walletState: $walletState, fetchPolicy: $fetchPolicy)';
}


}

/// @nodoc
abstract mixin class $WalletStateCopyWith<$Res>  {
  factory $WalletStateCopyWith(WalletState value, $Res Function(WalletState) _then) = _$WalletStateCopyWithImpl;
@useResult
$Res call({
 ApiResponse<Query$Wallet> walletState, FetchPolicy? fetchPolicy
});


$ApiResponseCopyWith<Query$Wallet, $Res> get walletState;

}
/// @nodoc
class _$WalletStateCopyWithImpl<$Res>
    implements $WalletStateCopyWith<$Res> {
  _$WalletStateCopyWithImpl(this._self, this._then);

  final WalletState _self;
  final $Res Function(WalletState) _then;

/// Create a copy of WalletState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? walletState = null,Object? fetchPolicy = freezed,}) {
  return _then(_self.copyWith(
walletState: null == walletState ? _self.walletState : walletState // ignore: cast_nullable_to_non_nullable
as ApiResponse<Query$Wallet>,fetchPolicy: freezed == fetchPolicy ? _self.fetchPolicy : fetchPolicy // ignore: cast_nullable_to_non_nullable
as FetchPolicy?,
  ));
}
/// Create a copy of WalletState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<Query$Wallet, $Res> get walletState {
  
  return $ApiResponseCopyWith<Query$Wallet, $Res>(_self.walletState, (value) {
    return _then(_self.copyWith(walletState: value));
  });
}
}


/// Adds pattern-matching-related methods to [WalletState].
extension WalletStatePatterns on WalletState {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _WalletState value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _WalletState() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _WalletState value)  $default,){
final _that = this;
switch (_that) {
case _WalletState():
return $default(_that);}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _WalletState value)?  $default,){
final _that = this;
switch (_that) {
case _WalletState() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( ApiResponse<Query$Wallet> walletState,  FetchPolicy? fetchPolicy)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _WalletState() when $default != null:
return $default(_that.walletState,_that.fetchPolicy);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( ApiResponse<Query$Wallet> walletState,  FetchPolicy? fetchPolicy)  $default,) {final _that = this;
switch (_that) {
case _WalletState():
return $default(_that.walletState,_that.fetchPolicy);}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( ApiResponse<Query$Wallet> walletState,  FetchPolicy? fetchPolicy)?  $default,) {final _that = this;
switch (_that) {
case _WalletState() when $default != null:
return $default(_that.walletState,_that.fetchPolicy);case _:
  return null;

}
}

}

/// @nodoc


class _WalletState implements WalletState {
  const _WalletState({this.walletState = const ApiResponseInitial(), this.fetchPolicy});
  

@override@JsonKey() final  ApiResponse<Query$Wallet> walletState;
@override final  FetchPolicy? fetchPolicy;

/// Create a copy of WalletState
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$WalletStateCopyWith<_WalletState> get copyWith => __$WalletStateCopyWithImpl<_WalletState>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _WalletState&&(identical(other.walletState, walletState) || other.walletState == walletState)&&(identical(other.fetchPolicy, fetchPolicy) || other.fetchPolicy == fetchPolicy));
}


@override
int get hashCode => Object.hash(runtimeType,walletState,fetchPolicy);

@override
String toString() {
  return 'WalletState(walletState: $walletState, fetchPolicy: $fetchPolicy)';
}


}

/// @nodoc
abstract mixin class _$WalletStateCopyWith<$Res> implements $WalletStateCopyWith<$Res> {
  factory _$WalletStateCopyWith(_WalletState value, $Res Function(_WalletState) _then) = __$WalletStateCopyWithImpl;
@override @useResult
$Res call({
 ApiResponse<Query$Wallet> walletState, FetchPolicy? fetchPolicy
});


@override $ApiResponseCopyWith<Query$Wallet, $Res> get walletState;

}
/// @nodoc
class __$WalletStateCopyWithImpl<$Res>
    implements _$WalletStateCopyWith<$Res> {
  __$WalletStateCopyWithImpl(this._self, this._then);

  final _WalletState _self;
  final $Res Function(_WalletState) _then;

/// Create a copy of WalletState
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? walletState = null,Object? fetchPolicy = freezed,}) {
  return _then(_WalletState(
walletState: null == walletState ? _self.walletState : walletState // ignore: cast_nullable_to_non_nullable
as ApiResponse<Query$Wallet>,fetchPolicy: freezed == fetchPolicy ? _self.fetchPolicy : fetchPolicy // ignore: cast_nullable_to_non_nullable
as FetchPolicy?,
  ));
}

/// Create a copy of WalletState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<Query$Wallet, $Res> get walletState {
  
  return $ApiResponseCopyWith<Query$Wallet, $Res>(_self.walletState, (value) {
    return _then(_self.copyWith(walletState: value));
  });
}
}

// dart format on
