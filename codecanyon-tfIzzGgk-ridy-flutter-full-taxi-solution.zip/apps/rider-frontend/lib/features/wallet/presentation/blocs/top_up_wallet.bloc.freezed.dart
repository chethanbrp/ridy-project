// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'top_up_wallet.bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$TopUpWalletState {

 ApiResponse<Mutation$TopUpWallet> get topUpWalletState;
/// Create a copy of TopUpWalletState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$TopUpWalletStateCopyWith<TopUpWalletState> get copyWith => _$TopUpWalletStateCopyWithImpl<TopUpWalletState>(this as TopUpWalletState, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is TopUpWalletState&&(identical(other.topUpWalletState, topUpWalletState) || other.topUpWalletState == topUpWalletState));
}


@override
int get hashCode => Object.hash(runtimeType,topUpWalletState);

@override
String toString() {
  return 'TopUpWalletState(topUpWalletState: $topUpWalletState)';
}


}

/// @nodoc
abstract mixin class $TopUpWalletStateCopyWith<$Res>  {
  factory $TopUpWalletStateCopyWith(TopUpWalletState value, $Res Function(TopUpWalletState) _then) = _$TopUpWalletStateCopyWithImpl;
@useResult
$Res call({
 ApiResponse<Mutation$TopUpWallet> topUpWalletState
});


$ApiResponseCopyWith<Mutation$TopUpWallet, $Res> get topUpWalletState;

}
/// @nodoc
class _$TopUpWalletStateCopyWithImpl<$Res>
    implements $TopUpWalletStateCopyWith<$Res> {
  _$TopUpWalletStateCopyWithImpl(this._self, this._then);

  final TopUpWalletState _self;
  final $Res Function(TopUpWalletState) _then;

/// Create a copy of TopUpWalletState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? topUpWalletState = null,}) {
  return _then(_self.copyWith(
topUpWalletState: null == topUpWalletState ? _self.topUpWalletState : topUpWalletState // ignore: cast_nullable_to_non_nullable
as ApiResponse<Mutation$TopUpWallet>,
  ));
}
/// Create a copy of TopUpWalletState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<Mutation$TopUpWallet, $Res> get topUpWalletState {
  
  return $ApiResponseCopyWith<Mutation$TopUpWallet, $Res>(_self.topUpWalletState, (value) {
    return _then(_self.copyWith(topUpWalletState: value));
  });
}
}


/// Adds pattern-matching-related methods to [TopUpWalletState].
extension TopUpWalletStatePatterns on TopUpWalletState {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _TopUpWalletState value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _TopUpWalletState() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _TopUpWalletState value)  $default,){
final _that = this;
switch (_that) {
case _TopUpWalletState():
return $default(_that);}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _TopUpWalletState value)?  $default,){
final _that = this;
switch (_that) {
case _TopUpWalletState() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( ApiResponse<Mutation$TopUpWallet> topUpWalletState)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _TopUpWalletState() when $default != null:
return $default(_that.topUpWalletState);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( ApiResponse<Mutation$TopUpWallet> topUpWalletState)  $default,) {final _that = this;
switch (_that) {
case _TopUpWalletState():
return $default(_that.topUpWalletState);}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( ApiResponse<Mutation$TopUpWallet> topUpWalletState)?  $default,) {final _that = this;
switch (_that) {
case _TopUpWalletState() when $default != null:
return $default(_that.topUpWalletState);case _:
  return null;

}
}

}

/// @nodoc


class _TopUpWalletState implements TopUpWalletState {
  const _TopUpWalletState({this.topUpWalletState = const ApiResponseInitial()});
  

@override@JsonKey() final  ApiResponse<Mutation$TopUpWallet> topUpWalletState;

/// Create a copy of TopUpWalletState
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$TopUpWalletStateCopyWith<_TopUpWalletState> get copyWith => __$TopUpWalletStateCopyWithImpl<_TopUpWalletState>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _TopUpWalletState&&(identical(other.topUpWalletState, topUpWalletState) || other.topUpWalletState == topUpWalletState));
}


@override
int get hashCode => Object.hash(runtimeType,topUpWalletState);

@override
String toString() {
  return 'TopUpWalletState(topUpWalletState: $topUpWalletState)';
}


}

/// @nodoc
abstract mixin class _$TopUpWalletStateCopyWith<$Res> implements $TopUpWalletStateCopyWith<$Res> {
  factory _$TopUpWalletStateCopyWith(_TopUpWalletState value, $Res Function(_TopUpWalletState) _then) = __$TopUpWalletStateCopyWithImpl;
@override @useResult
$Res call({
 ApiResponse<Mutation$TopUpWallet> topUpWalletState
});


@override $ApiResponseCopyWith<Mutation$TopUpWallet, $Res> get topUpWalletState;

}
/// @nodoc
class __$TopUpWalletStateCopyWithImpl<$Res>
    implements _$TopUpWalletStateCopyWith<$Res> {
  __$TopUpWalletStateCopyWithImpl(this._self, this._then);

  final _TopUpWalletState _self;
  final $Res Function(_TopUpWalletState) _then;

/// Create a copy of TopUpWalletState
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? topUpWalletState = null,}) {
  return _then(_TopUpWalletState(
topUpWalletState: null == topUpWalletState ? _self.topUpWalletState : topUpWalletState // ignore: cast_nullable_to_non_nullable
as ApiResponse<Mutation$TopUpWallet>,
  ));
}

/// Create a copy of TopUpWalletState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ApiResponseCopyWith<Mutation$TopUpWallet, $Res> get topUpWalletState {
  
  return $ApiResponseCopyWith<Mutation$TopUpWallet, $Res>(_self.topUpWalletState, (value) {
    return _then(_self.copyWith(topUpWalletState: value));
  });
}
}

// dart format on
