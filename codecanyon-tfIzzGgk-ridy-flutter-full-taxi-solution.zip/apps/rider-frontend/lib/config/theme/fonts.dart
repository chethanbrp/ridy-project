import 'package:rider_flutter/gen/fonts.gen.dart';

class Fonts {
  static const primary = FontFamily.generalSans;
  static const secondary = FontFamily.inter;
}
