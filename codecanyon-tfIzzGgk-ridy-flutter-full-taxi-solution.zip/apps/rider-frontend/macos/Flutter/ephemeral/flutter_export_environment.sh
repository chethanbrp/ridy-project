#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/opt/hostedtoolcache/flutter/stable-3.38.2-x64"
export "FLUTTER_APPLICATION_PATH=/home/runner/work/ridy-monorepo/ridy-monorepo/apps/rider-frontend"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=3.5.0"
export "FLUTTER_BUILD_NUMBER=311"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
